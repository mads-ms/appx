const allStrings = '[[^£]]ALL_TRANSLATIONS[[/^]]';

export default {
    /**
     * Calls to this method is replaced by babel-plugin-localize-replace in production
     * with strings that are translated on the fly, which is more efficient
     * since it removes the key from the source.
     * @param key
     * @returns {string}
     */
    getText(key) {
        return allStrings[key] || key;
    },

};
