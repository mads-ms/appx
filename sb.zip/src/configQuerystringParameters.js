import _ from 'lodash';

const configQuerystringParameters = _.chain(window.location.search.substring(1))
    .split('&')
    .invokeMap(String.prototype.split, '=')
    .reduce((obj, field) => {
        obj[field[0]] = field[1];
        return obj;
    }, {})
    .value();

export default configQuerystringParameters;
