import PropTypes from 'prop-types';
import React from 'react';
import _ from 'lodash';
import classNames from 'classnames';
import $ from 'jqueryAll';
import { detect } from 'openui';
import { VelocityComponent } from 'velocity-react';
import { bindHandlers } from 'src/utils/bindHandlers';
import TabLink from './tabLink';
import TabLinks from './tabLinks';
import TabFiller from './tabFiller';
import Button from 'src/components/button/button';
import Icon from 'src/components/icon/icon';

const DEFAULT_TABS_TO_SCROLL = 2;
const SCROLL_DURATION = 300;

class TabPanelHeader extends React.Component {
    constructor() {
        super();
        this.handleTabLinksDomRef = (ref) => {
            this.listEl = ref;
        };
        this.state = {
            tabIndex: 0,
            isScrollable: false,
            tabSizes: {},
        };
    }

    componentDidMount() {
        const elWidth = $(this.listEl).width();
        this.updateIsScrollable(elWidth);
        this.updateWidthChange(elWidth);
    }

    componentWillReceiveProps(nextProps) {
        if (!_.isEqual(nextProps.tabs, this.props.tabs)) {
            const tabIds = _.map(nextProps.tabs, 'id');
            this.setState(({ tabSizes }) => ({
                tabSizes: _.pick(tabSizes, tabIds),
            }));
        }
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !_.isEqual(nextProps.tabs, this.props.tabs) ||
            nextProps.fixedTabs !== this.props.fixedTabs ||
            nextProps.selectedTabId !== this.props.selectedTabId ||
            nextProps.hasMenus !== this.props.hasMenus ||
            nextState.tabIndex !== this.state.tabIndex ||
            nextState.isScrollable !== this.state.isScrollable ||
            !_.isEqual(nextState.tabSizes, this.state.tabSizes);
    }

    componentDidUpdate(prevProps) {
        const elWidth = $(this.listEl).outerWidth();
        this.updateIsScrollable(elWidth);
        this.updateWidthChange(elWidth);
        if (prevProps.tabs.length < this.props.tabs.length) {
            this.scrollToEnd();
        }
    }

    updateIsScrollable(elWidth) {
        let scrollWidth = this.listEl.scrollWidth;

        // https://developer.microsoft.com/en-us/microsoft-edge/platform/issues/11689089/
        if (detect.os.ms || detect.os.edge) {

            // Because of IE/Edge rounding issue we need to decrease scrollWidth by 1px
            scrollWidth -= 1;
        }

        const isScrollable = this.props.tabs.length > 1 && scrollWidth > elWidth;
        this.setState({
            isScrollable,
        });
    }

    updateWidthChange(elWidth) {
        const { onWidthChange } = this.props;
        if (onWidthChange && this.width !== elWidth) {
            this.width = elWidth;
            onWidthChange(this.width);
        }
    }

    getTabsToScroll() {
        const maxTabWidth = _.max(_.map(this.listEl.children, (tab) => $(tab).outerWidth()));
        return maxTabWidth >= $(this.listEl).width() ? 1 : DEFAULT_TABS_TO_SCROLL;
    }

    handleBack() {
        this.setState(({ tabIndex }) => ({
            tabIndex: Math.max(tabIndex - this.getTabsToScroll(), 0),
        }));
    }

    handleForward() {
        this.setState((state, props) => {
            const { tabIndex } = state;
            return {
                tabIndex: Math.min(tabIndex + this.getTabsToScroll(), this.getMaxTabIndex(state, props)),
            };
        });
    }

    scrollToEnd() {
        this.setState((state, props) => ({
            tabIndex: this.getMaxTabIndex(state, props),
        }));
    }

    handleTabSizeChange(id, size) {
        if (this.state.tabSizes[id] === size) {
            return;
        }
        this.setState(({ tabSizes }) => ({
            tabSizes: _.defaults({
                [id]: size,
            }, tabSizes),
        }));
    }

    getMaxTabIndex(state = this.state, props = this.props) {
        const { tabs } = props;
        const { tabSizes } = state;

        const availableWidth = this.listEl.clientWidth;
        let width = availableWidth;

        for (let index = tabs.length - 1; index >= 0; index--) {
            const tab = tabs[index];
            const tabSize = tabSizes[tab.id];
            width -= tabSize;
            if (width <= 0) {
                return index + ((tabSize >= availableWidth) ? 0 : 1);
            }
        }
        return 0;
    }

    render() {
        const {
            tabs,
            selectedTabId,
            hasMenus,
            isSubTab,
            hasDisabledButtons,
            extraTabs,
            fixedTabs,
            onTap,
            onTabMenuTap,
            onPanStart,
            onPanelPanStart,
        } = this.props;
        const { tabIndex, isScrollable } = this.state;

        const listItems = _.chain(tabs)
            .map((tab, index) => {
                let listItem = (
                    <TabLink
                        id={tab.id}
                        key={tab.id}
                        isActive={tab.id === selectedTabId}
                        className={classNames(tab.className, 'tst-tab-' + tab.id)}
                        hasMenu={hasMenus}
                        onMenuTap={onTabMenuTap}
                        onTap={onTap}
                        onPanStart={onPanStart}
                        onSizeChange={this.handleTabSizeChange}
                    >
                        {tab.content}
                    </TabLink>
                );

                if (isScrollable && index === tabIndex) {
                    listItem = (
                        <VelocityComponent
                            key={tab.id}
                            runOnMount
                            animation="scroll"
                            duration={SCROLL_DURATION}
                            axis="x"
                            container={this.listEl}
                        >
                            {listItem}
                        </VelocityComponent>
                    );
                }

                return listItem;
            })
            .concat(extraTabs)
            .value();

        let tabFiller;
        if (onPanelPanStart) {
            tabFiller = <TabFiller onPanStart={onPanelPanStart}/>;
        }

        let isBackButtonEnabled;
        let backButton;
        let isForwardButtonEnabled;
        let forwardButton;

        if (isScrollable) {
            const buttonClassNames = 'btn--noround tab-links-nav grid-cell';
            isBackButtonEnabled = tabIndex > 0;
            if (hasDisabledButtons || isBackButtonEnabled) {
                const backButtonClassNames = classNames(buttonClassNames, 'tab-links-nav--back', {
                    'is-disabled': !isBackButtonEnabled,
                });
                backButton = (
                    <Button className={backButtonClassNames} onTap={isBackButtonEnabled && this.handleBack}>
                        <Icon type="back"/>
                    </Button>
                );
            }
            isForwardButtonEnabled = tabIndex < this.getMaxTabIndex();
            if (hasDisabledButtons || isForwardButtonEnabled) {
                const forwardButtonClassNames = classNames(buttonClassNames, 'tab-links-nav--fwd', {
                    'is-disabled': !isForwardButtonEnabled,
                });
                forwardButton = (
                    <Button className={forwardButtonClassNames} onTap={isForwardButtonEnabled && this.handleForward}>
                        <Icon type="fwd"/>
                    </Button>
                );
            }
        }

        const tabLinksClassNames = classNames('g--shrink', {
            'is-overflow-both': forwardButton && backButton,
            'is-overflow-left': backButton && !forwardButton,
            'is-overflow-right': forwardButton && !backButton,
        });

        const tabHeaderClassNames = classNames('tab-header grid grid--space grid--seriessm', {
            'tab-header--sub': isSubTab,
        });

        return (
            <div className={tabHeaderClassNames} ref={this.setEl}>
                {tabFiller}
                {backButton}
                <TabLinks
                    className={tabLinksClassNames}
                    onDomRef={this.handleTabLinksDomRef}
                >
                    {listItems}
                </TabLinks>
                {forwardButton}
                <TabLinks>
                    {fixedTabs}
                </TabLinks>
            </div>
        );
    }
}

TabPanelHeader.propTypes = {
    tabs: PropTypes.arrayOf(PropTypes.object).isRequired,
    selectedTabId: PropTypes.string.isRequired,
    extraTabs: PropTypes.arrayOf(PropTypes.element),
    fixedTabs: PropTypes.arrayOf(PropTypes.element),
    hasMenus: PropTypes.bool,
    hasDisabledButtons: PropTypes.bool,
    isSubTab: PropTypes.bool,
    onTap: PropTypes.func,
    onTabMenuTap: PropTypes.func,
    onPanStart: PropTypes.func,
    onPanelPanStart: PropTypes.func,
    onWidthChange: PropTypes.func,
};

TabPanelHeader.defaultProps = {
    isSubTab: false,
    hasDisabledButtons: false,
};

export default bindHandlers(TabPanelHeader);
