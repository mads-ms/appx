import PropTypes from 'prop-types';
import React from 'react';
import _ from 'lodash';
import classNames from 'classnames';
import Touchable from 'src/components/touchable/touchable';
import Pannable from 'src/components/touchable/pannable';
import MenuButton from 'src/components/menuButton/menuButton';
import { bindHandlers } from 'src/utils/bindHandlers';

class TabLink extends React.Component {

    constructor() {
        super();

        this.setEl = (ref) => {
            this.el = ref;
        };
    }

    componentDidMount() {
        this.updateSize();
    }

    componentDidUpdate() {
        this.updateSize();
    }

    updateSize() {
        const { onSizeChange, id } = this.props;
        if (onSizeChange) {
            onSizeChange(id, this.el.offsetWidth);
        }
    }

    handleTap(event) {
        if (event.defaultPrevented) {
            return;
        }
        this.props.onTap(this.props.id);
    }

    handleMenuTap(element) {
        this.props.onMenuTap(this.props.id, element);
    }

    handlePanStart(event) {
        event.preventDefault();
        this.props.onPanStart({
            tabId: this.props.id,
            panElement: this.el,
            event,
        });
    }

    render() {
        const { children, className, hasMenu, isActive, onPanStart } = this.props;

        const classes = {
            'active': isActive,
            'tab-link--menu': hasMenu,
        };

        const menuButton = (
            <div className="grid-cell tab-link-menu">
                <MenuButton onTap={this.handleMenuTap}/>
            </div>);

        let tabLink = (
            <Touchable onTap={this.handleTap}>
                <li className={classNames('tab-link', classes, className)} ref={this.setEl}>
                    <div className="grid g--fit grid--cross-center">
                        <div className="grid-cell g--fill tab-link-children">
                            {children}
                        </div>
                        {hasMenu && menuButton}
                    </div>
                </li>
            </Touchable>
        );

        if (onPanStart) {
            tabLink = (
                <Pannable onPanStart={this.handlePanStart}>
                    {tabLink}
                </Pannable>
            );
        }

        return tabLink;
    }
}

TabLink.propTypes = {
    id: PropTypes.string.isRequired,
    className: PropTypes.string,
    hasMenu: PropTypes.bool,
    isActive: PropTypes.bool.isRequired,
    onPanStart: PropTypes.func,
    onTap: PropTypes.func.isRequired,
    onMenuTap: PropTypes.func,
    onSizeChange: PropTypes.func.isRequired,
};

TabLink.defaultProps = {
    hasMenu: false,
    onMenuTap: _.noop,
};

export default bindHandlers(TabLink);
