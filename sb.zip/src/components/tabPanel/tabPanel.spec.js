import React from 'react';
import { mount } from 'enzyme';
import TabPanel from 'src/components/tabPanel/tabPanel';
import { tap } from 'test/mocks/touchableHelper';

describe('src/components/tabPanel/tabPanel', () => {

    let wrapper;
    let onSelectedTabChange;
    let tabs;
    let defaultProps;

    beforeEach(() => {
        tabs = [
            {
                id: '1',
                className: 'js-real-tab js-tab-1',
                content: 'myTab',
            }, {
                id: '2',
                className: 'js-real-tab  js-tab-2',
                content: 'myTab',
            },
        ];
        onSelectedTabChange = jasmine.createSpy('onSelectedTabChange');
        defaultProps = {
            id: '99',
            selectedTabId: '1',
            tabs,
            onSelectedTabChange,
        };
    });

    afterEach(() => {
        wrapper.unmount();
    });

    it('loads', () => {
        wrapper = mount(
            <TabPanel
                {...defaultProps}
            />
        );
        expect(onSelectedTabChange).not.toHaveBeenCalled();

        expect(wrapper.find('li.js-real-tab').length).toEqual(2);
    });

    it('sends a tab change when you click the other tab', () => {
        wrapper = mount(
            <TabPanel
                {...defaultProps}
            />
        );
        expect(onSelectedTabChange).not.toHaveBeenCalled();
        tap(wrapper.find('.js-tab-2'));
        expect(onSelectedTabChange).toHaveBeenCalledTimes(1);
    });

    it('does not send a tab changed when clicking the current tab', () => {
        wrapper = mount(
            <TabPanel
                {...defaultProps}
            />
        );
        expect(onSelectedTabChange).not.toHaveBeenCalled();
        tap(wrapper.find('.js-tab-1'));
        expect(onSelectedTabChange).not.toHaveBeenCalled();
    });

    it('renders children', () => {
        wrapper = mount(
            <TabPanel
                {...defaultProps}
                fixedTabs={[<div key="fixed-tab" className="js-fixed-tab"/>]}
            >
                <div className="js-inner"/>
            </TabPanel>
        );
        expect(wrapper.find('.js-fixed-tab').length).toEqual(1);
        expect(wrapper.find('.js-inner').length).toEqual(1);
    });
});
