import PropTypes from 'prop-types';
import React from 'react';
import ReactDOM from 'react-dom';
import Pannable from 'src/components/touchable/pannable';
import { bindHandlers } from 'src/utils/bindHandlers';

class TabFiller extends React.Component {

    handlePanStart(event) {
        event.preventDefault();
        this.props.onPanStart({
            panElement: ReactDOM.findDOMNode(this),
            event,
        });
    }

    render() {
        // We have issues with hammer and pannable - it is difficult to cancel the pan start event.
        // The solution to this is a filler tab that is a sibling of the other tabs (so events don't bubble to it)
        // but because it is underneath the other tabs it only gets events when you pan on the area outside
        // the other tabs.
        // So we only add this if the consumer is interested in pan events
        return (
            <Pannable onPanStart={this.handlePanStart}>
                <div className="tab-filler"></div>
            </Pannable>
        );
    }
}

TabFiller.propTypes = {
    onPanStart: PropTypes.func.isRequired,
};

export default bindHandlers(TabFiller);
