import PropTypes from 'prop-types';

/* TabPanel
 * --------------
 * This tab panel is in charge of showing a group of tabs and optionally
 * a settings tab and some fixed tabs. The parent is responsible for setting
 * the selected tab id and making the child reflect the currently selected item.
 *
 * If using this in the future for a generic tab panel you may consider wrapping
 * this in a new generic TabPanel that takes a array of children and does the work
 * of rendering the selected one only. That is why this is "static".
 *
 * Performance notes
 * --------------------------------------------------------------------
 *
 * Every effort has been made to optimise the activation of a tab in
 * response to user input. In doing so the tabPanel implementation is a
 * little more complex than simply showing and hiding the correct DOM
 * element. Specifically:
 *
 *  - Tab content wrappers and their associated controller instances are
 *    kept detached from the main DOM tree when not active.
 *  - Tabs only listen to resize events when activated (and this only when)
 *    appended into the DOM.
 *  - Tabs pass an options hash to the activate method of each controller
 *    instance indicating if they have inferred the controller should
 *    render itself or not (namely in response to viewport changes)
 *  - Appending and activation are deferred by a tick to allow tab links
 *    to update quickly (so user feedback is provided quickly)
 */
import _ from 'lodash';
import React from 'react';
import TabPanelHeader from './tabPanelHeader';
import classNames from 'classnames';
import { bindHandlers } from 'src/utils/bindHandlers';

class TabPanel extends React.Component {

    componentDidUpdate(prevProps) {
        const { tabs, dockInProgressList, onDockedTabLoaded, id } = this.props;

        // if dock into tabs in progress, fire tab mounted for all new tabs
        if (dockInProgressList && prevProps.tabs !== tabs) {
            const newTabs = _.difference(_.map(tabs, 'id'), _.map(prevProps.tabs, 'id'));
            if (_.isEqual(newTabs, dockInProgressList)) {
                _.forEach(newTabs, (tabId) => onDockedTabLoaded(tabId, id));
            }
        }
    }

    handleTabLinkTap(id) {
        if (id !== this.props.selectedTabId) {
            this.props.onSelectedTabChange(this.props.id, id);
        }
    }

    handleTabLinkPanStart({ tabId, panElement, event }) {
        const { onTabPanStart, onTabPanelPanStart, id, tabs } = this.props;
        const onPanStart = tabs.length > 1 ? onTabPanStart : onTabPanelPanStart;
        if (onPanStart) {
            onPanStart({
                tabPanelId: id,
                tabId,
                panElement,
                event,
            });
        }
    }

    handleTabPanelPanStart({ panElement, event }) {
        const { onTabPanelPanStart, id } = this.props;
        if (onTabPanelPanStart) {
            onTabPanelPanStart({
                tabPanelId: id,
                panElement,
                event,
            });
        }
    }

    handleTabHeaderWidthChange(width) {
        const { onTabHeaderWidthChange } = this.props;
        if (onTabHeaderWidthChange) {
            onTabHeaderWidthChange(width);
        }
    }

    render() {
        const {
            tabs,
            extraTabs,
            fixedTabs,
            style,
            children,
            className,
            isPanel,
            isAstroStyle,
            isTabPaneInset,
            selectedTabId,
            hasMenus,
            onTabMenuTap,
            onTabPanStart,
            onTabPanelPanStart,
        } = this.props;

        const classes = classNames(
            'tab tab--sized',
            className,
            'tst-tab-panel-' + this.props.id,
            {
                'tab--panel': isPanel,
                'tab--astro': isAstroStyle,
            }
        );

        const tabPanelHeader = (
            <TabPanelHeader
                tabs={tabs}
                extraTabs={extraTabs}
                fixedTabs={fixedTabs}
                selectedTabId={selectedTabId}
                hasMenus={hasMenus}
                onTap={this.handleTabLinkTap}
                onPanStart={onTabPanStart && this.handleTabLinkPanStart}
                onPanelPanStart={onTabPanelPanStart && this.handleTabPanelPanStart}
                onTabMenuTap={onTabMenuTap}
                onWidthChange={this.handleTabHeaderWidthChange}
            />
        );

        const tabPaneClasses = classNames('tab-pane', { 'tab-pane--inset': isTabPaneInset });

        return (
            <section
                className={classes}
                style={style}
            >
                {tabPanelHeader}
                <div className="tab-content">
                    <div className={tabPaneClasses}>
                        {children}
                    </div>
                </div>
            </section>
        );
    }
}

TabPanel.propTypes = {
    id: PropTypes.string.isRequired,
    tabs: PropTypes.arrayOf(PropTypes.shape({
        id: PropTypes.string.isRequired,
        content: PropTypes.oneOfType([
            PropTypes.string,
            PropTypes.element,
        ]).isRequired,
        className: PropTypes.string,
    })).isRequired,
    selectedTabId: PropTypes.string.isRequired,
    className: PropTypes.string,
    style: PropTypes.object,
    isPanel: PropTypes.bool,
    isAstroStyle: PropTypes.bool,
    isTabPaneInset: PropTypes.bool,
    hasMenus: PropTypes.bool,
    extraTabs: PropTypes.arrayOf(PropTypes.element),
    fixedTabs: PropTypes.arrayOf(PropTypes.element),
    dockInProgressList: PropTypes.array,
    onSelectedTabChange: PropTypes.func,
    onTabPanStart: PropTypes.func,
    onTabPanelPanStart: PropTypes.func,
    onTabMenuTap: PropTypes.func,
    onTabHeaderWidthChange: PropTypes.func,
    onDockedTabLoaded: PropTypes.func,
};

TabPanel.defaultProps = {
    isPanel: true,
    isAstroStyle: false,
    isTabPaneInset: false,
    onSelectedTabChange: _.noop,
    onDockedTabLoaded: _.noop,
};

export default bindHandlers(TabPanel);
