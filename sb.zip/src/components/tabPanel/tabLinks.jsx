import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';

function TabLinks(props) {
    const { children, className, onDomRef } = props;
    const listClassNames = classNames('tab-links grid-cell', className);
    if (children && children.length > 0) {
        return (
            <ul className={listClassNames} ref={onDomRef}>
                {children}
            </ul>
        );
    }
    return null;
}

TabLinks.propTypes = {
    className: PropTypes.string,
    onDomRef: PropTypes.func,
};

export default TabLinks;
