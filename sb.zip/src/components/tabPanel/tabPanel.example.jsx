import React from 'react';
import { bindHandlers } from 'src/utils/bindHandlers';
import TabPanel from './tabPanel';
import { examplesOf } from 'src/modules/examples/utils';

class TabPanelExample extends React.Component {
    constructor() {
        super();

        this.state = {
            selectedTabId: 'tab1',
        };
    }

    handleSelectedTabChange(tabPanelId, tabId) {
        this.setState({
            selectedTabId: tabId,
        });
    }

    render() {
        const { selectedTabId } = this.state;

        return (
            <TabPanel
                id="tab-panel-example-default"
                tabs={[{
                    id: 'tab1',
                    content: 'Tab 1',
                },
                {
                    id: 'tab2',
                    content: 'Tab 2',
                },
                {
                    id: 'tab3',
                    content: <span className="t-upper">Tab 3</span>,
                }]}
                selectedTabId={selectedTabId}
                onSelectedTabChange={this.handleSelectedTabChange}
                {...this.props}
            >
                {selectedTabId === 'tab1' &&
                    <div>Tab 1 Content</div>
                }
                {selectedTabId === 'tab2' &&
                    <div>Tab 2 Content</div>
                }
                {selectedTabId === 'tab3' &&
                    <div>Tab 3 Content</div>
                }
            </TabPanel>
        );
    }
}

const TabPanelExampleBound = bindHandlers(TabPanelExample);

export default examplesOf('Tab Panel')
    .add('Default', () => <TabPanelExampleBound/>)
    .add('Clear Style', () => <TabPanelExampleBound isPanel={false}/>)
    .add('Astro Style 🚀', () => <TabPanelExampleBound isAstroStyle/>);
