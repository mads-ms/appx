import React from 'react';
import ReactDOM from 'react-dom';
import Pannable from 'src/components/touchable/pannable';

describe('src/components/touchable/pannable', () => {
    let hammerSpy;
    let mountElement;
    beforeEach(() => {
        hammerSpy = jasmine.createSpy('Hammer');
        hammerSpy.prototype.on = jasmine.createSpy('Hammer.on');
        hammerSpy.prototype.destroy = jasmine.createSpy('Hammer.destroy');

        hammerSpy.Swipe = 'Swipe';
        hammerSpy.Pan = 'Pan';
        hammerSpy.DIRECTION_HORIZONTAL = 'DIRECTION_HORIZONTAL';
        hammerSpy.DIRECTION_VERTICAL = 'DIRECTION_VERTICAL';

        mountElement = document.createElement('div');
    });

    function mount(jsx) {
        return ReactDOM.render(jsx, mountElement);
    }

    function unmount() {
        ReactDOM.unmountComponentAtNode(mountElement);
        mountElement = null;
    }

    afterEach(() => {
        if (mountElement) {
            unmount();
        }
    });

    it('creates and destroys a hammer manager', () => {
        const panSpy = jasmine.createSpy('panSpy');

        mount(<Pannable Hammer={hammerSpy} onPan={panSpy}><span/></Pannable>);

        expect(hammerSpy).toHaveBeenCalledTimes(1);
        expect(hammerSpy.prototype.on).toHaveBeenCalledTimes(1);
        expect(hammerSpy.prototype.destroy).not.toHaveBeenCalled();

        ReactDOM.unmountComponentAtNode(mountElement);

        expect(hammerSpy).toHaveBeenCalledTimes(1);
        expect(hammerSpy.prototype.on).toHaveBeenCalledTimes(1);
        expect(hammerSpy.prototype.destroy).toHaveBeenCalledTimes(1);
    });

    it('fires on pan', () => {
        const panSpy = jasmine.createSpy('panSpy');
        mount(<Pannable Hammer={hammerSpy} onPan={panSpy}><span/></Pannable>);

        expect(hammerSpy.prototype.on).toHaveBeenCalledTimes(1);
        expect(panSpy).not.toHaveBeenCalled();

        const callback = hammerSpy.prototype.on.calls.argsFor(0)[1];
        const event = {};
        callback(event);
        expect(panSpy).toHaveBeenCalledTimes(1);
        expect(panSpy.calls.argsFor(0)).toEqual([event]);

        unmount(mountElement);

        expect(panSpy).toHaveBeenCalledTimes(1);
    });

    describe('pan start', () => {
        it('calls panstart if it was missed', () => {
            const panStartSpy = jasmine.createSpy('panStartSpy');
            const pannable = mount(<Pannable Hammer={hammerSpy} onPanStart={panStartSpy}><span/></Pannable>);

            expect(hammerSpy.prototype.on).toHaveBeenCalledTimes(3);
            expect(panStartSpy).not.toHaveBeenCalled();

            const event = {};
            pannable.eventHandlersProxies['onPan'](event);
            expect(panStartSpy).toHaveBeenCalledTimes(1);
            expect(panStartSpy.calls.argsFor(0)).toEqual([event]);

            unmount(mountElement);

            expect(panStartSpy).toHaveBeenCalledTimes(1);
        });

        it('doesnt call pan spy twice', () => {
            const panStartSpy = jasmine.createSpy('panStartSpy');
            const pannable = mount(<Pannable Hammer={hammerSpy} onPanStart={panStartSpy}><span/></Pannable>);

            expect(hammerSpy.prototype.on).toHaveBeenCalledTimes(3);
            expect(panStartSpy).not.toHaveBeenCalled();

            const event = {};
            pannable.eventHandlersProxies['onPanStart'](event);
            expect(panStartSpy).toHaveBeenCalledTimes(1);
            expect(panStartSpy.calls.argsFor(0)).toEqual([event]);

            pannable.eventHandlersProxies['onPan'](event);
            expect(panStartSpy).toHaveBeenCalledTimes(1);

            unmount(mountElement);

            expect(panStartSpy).toHaveBeenCalledTimes(1);
        });

        it('re-detects after pan end', () => {
            const panStartSpy = jasmine.createSpy('panStartSpy');
            const pannable = mount(<Pannable Hammer={hammerSpy} onPanStart={panStartSpy}><span/></Pannable>);

            expect(hammerSpy.prototype.on).toHaveBeenCalledTimes(3);
            expect(panStartSpy).not.toHaveBeenCalled();

            const event = {};
            pannable.eventHandlersProxies['onPanStart'](event);
            pannable.eventHandlersProxies['onPan'](event);
            pannable.eventHandlersProxies['onPanEnd'](event);
            pannable.eventHandlersProxies['onPan'](event);
            expect(panStartSpy).toHaveBeenCalledTimes(2);
            expect(panStartSpy.calls.argsFor(1)).toEqual([event]);

            unmount(mountElement);

            expect(panStartSpy).toHaveBeenCalledTimes(2);
        });
    });

    describe('isEnabled', () => {
        it('does not create a hammer manager if not enabled', () => {
            const panSpy = jasmine.createSpy('panSpy');

            mount(<Pannable Hammer={hammerSpy} onPan={panSpy} isEnabled={false}><span/></Pannable>);

            expect(hammerSpy).not.toHaveBeenCalled();

            unmount(mountElement);

            expect(hammerSpy).not.toHaveBeenCalled();
        });

        it('creates a hammer manager once enabled', () => {
            const panSpy = jasmine.createSpy('panSpy');

            mount(<Pannable Hammer={hammerSpy} onPan={panSpy} isEnabled={false}><span/></Pannable>);

            expect(hammerSpy).not.toHaveBeenCalled();

            mount(<Pannable Hammer={hammerSpy} onPan={panSpy} isEnabled><span/></Pannable>);

            expect(hammerSpy).toHaveBeenCalledTimes(1);

            unmount(mountElement);

            expect(hammerSpy).toHaveBeenCalledTimes(1);
        });

        it('destroys a hammer manager when disabled', () => {
            const panSpy = jasmine.createSpy('panSpy');

            mount(<Pannable Hammer={hammerSpy} onPan={panSpy}><span/></Pannable>);

            expect(hammerSpy).toHaveBeenCalledTimes(1);

            mount(<Pannable Hammer={hammerSpy} onPan={panSpy} isEnabled={false}><span/></Pannable>);

            expect(hammerSpy).toHaveBeenCalledTimes(1);
            expect(hammerSpy.prototype.destroy).toHaveBeenCalledTimes(1);

            unmount(mountElement);

            expect(hammerSpy).toHaveBeenCalledTimes(1);
            expect(hammerSpy.prototype.destroy).toHaveBeenCalledTimes(1);
        });
    });

    describe('recognizers', () => {

        it('adds pan recognizer for pan', () => {
            const panSpy = jasmine.createSpy('panSpy');
            mount(<Pannable Hammer={hammerSpy} onPan={panSpy}><span/></Pannable>);

            expect(hammerSpy).toHaveBeenCalledTimes(1);
            expect(hammerSpy.calls.argsFor(0)[1]).toEqual(jasmine.objectContaining({
                recognizers: jasmine.arrayContaining([
                    jasmine.arrayContaining(['Pan']),
                ]),
            }));
        });

        it('adds swipe recognizer for swipe', () => {
            const swipeSpy = jasmine.createSpy('swipeSpy');
            mount(<Pannable Hammer={hammerSpy} onSwipe={swipeSpy}><span/></Pannable>);

            expect(hammerSpy).toHaveBeenCalledTimes(1);
            expect(hammerSpy.calls.argsFor(0)[1]).toEqual(jasmine.objectContaining({
                recognizers: jasmine.arrayContaining([
                    jasmine.arrayContaining(['Swipe']),
                ]),
            }));
        });

    });

    describe('props changing', () => {
        it('destroys hammer if events listening to change', () => {
            const swipeSpy = jasmine.createSpy('swipeSpy');
            const panSpy = jasmine.createSpy('panSpy');

            mount(<Pannable Hammer={hammerSpy} onPan={panSpy}><span/></Pannable>);

            expect(hammerSpy).toHaveBeenCalledTimes(1);
            expect(hammerSpy.prototype.on).toHaveBeenCalledTimes(1);

            mount(<Pannable Hammer={hammerSpy} onSwipe={swipeSpy}><span/></Pannable>);

            expect(hammerSpy.prototype.destroy).toHaveBeenCalledTimes(1);
            expect(hammerSpy).toHaveBeenCalledTimes(2);
            expect(hammerSpy.prototype.on).toHaveBeenCalledTimes(2);

            unmount(mountElement);

            expect(hammerSpy).toHaveBeenCalledTimes(2);
            expect(hammerSpy.prototype.destroy).toHaveBeenCalledTimes(2);
        });

        it('destroys hammer if child changes', () => {
            const panSpy = jasmine.createSpy('panSpy');

            mount(<Pannable Hammer={hammerSpy} onPan={panSpy}><span/></Pannable>);

            expect(hammerSpy).toHaveBeenCalledTimes(1);
            expect(hammerSpy.prototype.on).toHaveBeenCalledTimes(1);

            mount(<Pannable Hammer={hammerSpy} onPan={panSpy}><div/></Pannable>);

            expect(hammerSpy.prototype.destroy).toHaveBeenCalledTimes(1);
            expect(hammerSpy).toHaveBeenCalledTimes(2);
            expect(hammerSpy.prototype.on).toHaveBeenCalledTimes(2);

            unmount(mountElement);

            expect(hammerSpy).toHaveBeenCalledTimes(2);
            expect(hammerSpy.prototype.destroy).toHaveBeenCalledTimes(2);
        });

        it('does not destroy if only the handler changes', () => {
            const panSpy = jasmine.createSpy('panSpy');
            const panSpy2 = jasmine.createSpy('panSpy2');

            mount(<Pannable Hammer={hammerSpy} onPan={panSpy}><span/></Pannable>);

            expect(hammerSpy).toHaveBeenCalledTimes(1);
            expect(hammerSpy.prototype.on).toHaveBeenCalledTimes(1);

            mount(<Pannable Hammer={hammerSpy} onPan={panSpy2}><span/></Pannable>);

            expect(hammerSpy).toHaveBeenCalledTimes(1);
            expect(hammerSpy.prototype.on).toHaveBeenCalledTimes(1);

            unmount(mountElement);

            expect(hammerSpy.prototype.destroy).toHaveBeenCalledTimes(1);
        });

        it('continues to work if only the handler changes', () => {
            const panSpy = jasmine.createSpy('panSpy');
            const panSpy2 = jasmine.createSpy('panSpy2');

            mount(<Pannable Hammer={hammerSpy} onPan={panSpy}><span/></Pannable>);
            mount(<Pannable Hammer={hammerSpy} onPan={panSpy2}><span/></Pannable>);

            expect(hammerSpy.prototype.on).toHaveBeenCalledTimes(1);
            const callback = hammerSpy.prototype.on.calls.argsFor(0)[1];
            callback('eventObjectArg');
            expect(panSpy).not.toHaveBeenCalled();
            expect(panSpy2).toHaveBeenCalledTimes(1);
            expect(panSpy2.calls.argsFor(0)).toEqual(['eventObjectArg']);
        });

        it('does nothing if nothing changes', () => {
            const panSpy = jasmine.createSpy('panSpy');

            mount(<Pannable Hammer={hammerSpy} onPan={panSpy}><span/></Pannable>);

            expect(hammerSpy).toHaveBeenCalledTimes(1);
            expect(hammerSpy.prototype.on).toHaveBeenCalledTimes(1);

            mount(<Pannable Hammer={hammerSpy} onPan={panSpy}><span/></Pannable>);

            expect(hammerSpy.prototype.destroy).not.toHaveBeenCalled();
            expect(hammerSpy).toHaveBeenCalledTimes(1);
            expect(hammerSpy.prototype.on).toHaveBeenCalledTimes(1);

            unmount(mountElement);
        });

        it('destroys hammer if directionSupport changes', () => {
            const panSpy = jasmine.createSpy('panSpy');

            mount(<Pannable Hammer={hammerSpy} onPan={panSpy} directionSupport="horizontal"><span/></Pannable>);

            expect(hammerSpy).toHaveBeenCalledTimes(1);
            expect(hammerSpy.prototype.on).toHaveBeenCalledTimes(1);

            mount(<Pannable Hammer={hammerSpy} onPan={panSpy} directionSupport="vertical"><span/></Pannable>);

            expect(hammerSpy.prototype.destroy).toHaveBeenCalledTimes(1);
            expect(hammerSpy).toHaveBeenCalledTimes(2);
            expect(hammerSpy.prototype.on).toHaveBeenCalledTimes(2);

            unmount(mountElement);

            expect(hammerSpy).toHaveBeenCalledTimes(2);
            expect(hammerSpy.prototype.destroy).toHaveBeenCalledTimes(2);
        });
    });
});
