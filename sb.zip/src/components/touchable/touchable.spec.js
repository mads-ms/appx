import PropTypes from 'prop-types';
import React from 'react';
import Touchable from 'src/components/touchable/touchable';
import { mount } from 'enzyme';
import _ from 'lodash';
import { tap, touch, press, doubletap } from 'test/mocks/touchableHelper';

describe('src/components/touchable/touchable', () => {

    let wrapper;

    afterEach(() => {
        if (wrapper) {
            wrapper.unmount();
        }
    });

    describe('events', () => {
        function testEvent(eventFire, props, assertions) {
            wrapper = mount(<Touchable {...props}><span/></Touchable>);
            eventFire(wrapper.find('span'));
            assertions(props);
        }

        it('fires on tap',
            _.partial(testEvent, tap, { onTap: jasmine.createSpy() }, (props) => expect(props.onTap).toHaveBeenCalledTimes(1))
        );

        it('fires on touch',
            _.partial(testEvent, touch, { onTouch: jasmine.createSpy() }, (props) => expect(props.onTouch).toHaveBeenCalledTimes(1))
        );

        it('fires on press',
            _.partial(testEvent, press, { onPress: jasmine.createSpy() }, (props) => expect(props.onPress).toHaveBeenCalledTimes(1))
        );

        it('fires on doubletap',
            _.partial(testEvent, doubletap, { onDoubleTap: jasmine.createSpy() }, (props) => expect(props.onDoubleTap).toHaveBeenCalledTimes(1))
        );

        it('does not fire on tap if not enabled',
            _.partial(testEvent, tap, {
                onTap: jasmine.createSpy(),
                isEnabled: false,
            }, (props) => expect(props.onTap).not.toHaveBeenCalled())
        );
    });

    describe('event propagation', () => {
        it('bubbles tap events in hierarchy', () => {
            const tapSpy = jasmine.createSpy('touchSpy');
            wrapper = mount(
                <Touchable onTap={_.partial(tapSpy, 'root')}>
                    <div>
                        <Touchable onTap={_.partial(tapSpy, 'child')}>
                            <span/>
                        </Touchable>
                    </div>
                </Touchable>
            );

            tap(wrapper.find('span'));

            expect(tapSpy).toHaveBeenCalledTimes(2);
            expect(tapSpy.calls.argsFor(0)).toEqual(['child', jasmine.any(Event)]);
            expect(tapSpy.calls.argsFor(1)).toEqual(['root', jasmine.any(Event)]);
        });

        it('bubbles tap events in dynamic hierarchy', () => {
            const tapSpy = jasmine.createSpy('tapSpy');

            const TouchableNode = (props) => (
                <Touchable onTap={_.partial(tapSpy, props.id)} isEnabled>
                    <div className={props.id}>
                        {props.children}
                    </div>
                </Touchable>
            );

            TouchableNode.propTypes = {
                id: PropTypes.string,
            };

            wrapper = mount(<TouchableNode id="root"/>);
            wrapper.setProps({
                children: [<TouchableNode key="child" id="child"/>],
            });

            tap(wrapper.find('.child'));

            expect(tapSpy).toHaveBeenCalledTimes(2);
            expect(tapSpy.calls.argsFor(0)).toEqual(['child', jasmine.any(Event)]);
            expect(tapSpy.calls.argsFor(1)).toEqual(['root', jasmine.any(Event)]);
        });
    });

    describe('props changing', () => {
        it('supports new bindings', () => {
            const onTap = jasmine.createSpy('tapSpy');
            const onPress = jasmine.createSpy('pressSpy');

            wrapper = mount(
                <Touchable>
                    <div/>
                </Touchable>
            );

            const div = wrapper.find('div');

            wrapper.setProps({ onTap });
            tap(div);
            expect(onTap).toHaveBeenCalledTimes(1);

            wrapper.setProps({ onPress });
            press(div);
            expect(onPress).toHaveBeenCalledTimes(1);
        });

        it('support bindings when children change', () => {
            const onTap = jasmine.createSpy('tapSpy');
            wrapper = mount(
                <Touchable>
                    <div/>
                </Touchable>
            );

            let div = wrapper.find('div');

            wrapper.setProps({ onTap });
            tap(div);
            expect(onTap).toHaveBeenCalledTimes(1);

            wrapper.setProps({ children: <p/> });

            div = wrapper.find('p');
            tap(div);
            expect(onTap).toHaveBeenCalledTimes(2);

        });

        it('supports change bindings', () => {
            const onTap = jasmine.createSpy('tapSpy');
            const onNewTap = jasmine.createSpy('tapSpy');

            wrapper = mount(
                <Touchable>
                    <div/>
                </Touchable>
            );

            const div = wrapper.find('div');
            wrapper.setProps({ onTap });
            wrapper.setProps({ onTap: onNewTap });
            tap(div);
            expect(onTap).not.toHaveBeenCalled();
            expect(onNewTap).toHaveBeenCalledTimes(1);
        });

        it('supports remove bindings', () => {
            const onTap = jasmine.createSpy('tapSpy');

            wrapper = mount(
                <Touchable>
                    <div/>
                </Touchable>
            );

            const div = wrapper.find('div');
            wrapper.setProps({ onTap });
            wrapper.setProps({ onTap: undefined });
            tap(div);
            expect(onTap).not.toHaveBeenCalled();
        });
    });
});
