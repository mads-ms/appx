import _ from 'lodash';
import { Hammer } from 'openui';
import PropTypes from 'prop-types';
import React from 'react';
import ReactDOM from 'react-dom';
import config from 'src/config';

const eventMap = {
    onSwipe: 'swipe',
    onSwipeLeft: 'swipeleft',
    onSwipeRight: 'swiperight',
    onPanStart: 'panstart',
    onPan: 'pan',
    onPanEnd: 'panend',
    onPanCancel: 'pancancel',
};

const directionKeyToHammerConst = {
    'all': Hammer.DIRECTION_ALL,
    'horizontal': Hammer.DIRECTION_HORIZONTAL,
    'vertical': Hammer.DIRECTION_VERTICAL,
    'left': Hammer.DIRECTION_LEFT,
    'right': Hammer.DIRECTION_RIGHT,
};

/**
 * Pannable is a pseudo component (it doesn't add any html) which integrates hammer with React
 * You can use it to pick up hammer events
 * e.g.
 *
 * <Pannable onPan={this.handlePan}><div>My Content</div></Pannable>
 */
export default class Pannable extends React.Component {

    constructor(props) {
        super(props);

        this.eventHandlersProxies = _.mapValues(eventMap, (ignore, propKey) => this.handleEvent.bind(this, propKey));
    }

    componentDidMount() {
        if (this.props.isEnabled) {
            this.createHammerManager();
        }
    }

    componentDidUpdate(prevProps) {
        const newEl = ReactDOM.findDOMNode(this);

        // if only the handler changes, this does not require us doing anything since we bind through
        // a proxy. So we only need to do something if the events subscribed to changes or the options change
        const isNewHammerRequired = this.props.isEnabled !== prevProps.isEnabled ||
            this.props.directionSupport !== prevProps.directionSupport ||
            this.childEl !== newEl ||
            _.some(eventMap, (hammerEventName, eventKey) => {
                if (this.props[eventKey] !== prevProps[eventKey]) {
                    return this.props[eventKey] === undefined || prevProps[eventKey] === undefined;
                }
            });

        // return early if we don't need to change the hammer manager
        if (!isNewHammerRequired) {
            return;
        }

        this.destroyHammerManager();

        // destroy and exit if we are not enabled
        if (!this.props.isEnabled) {
            return;
        }

        this.createHammerManager();
    }

    componentWillUnmount() {
        this.destroyHammerManager();
    }

    handleEvent(propKey, ...args) {
        const targetEventHandler = this.props[propKey];

        // pan start is unreliable - it can in very rare instances not fire. pan-end doesn't seem to have that issue.
        // So this code runs in the first pan only, to get sizes and trigger busy.
        if (this.props.onPanStart) {
            if (propKey === 'onPanStart') {
                this.isPanStarted = true;
            } else if (propKey === 'onPan') {
                if (!this.isPanStarted) {
                    this.handleEvent('onPanStart', ...args);
                }
            } else if (propKey === 'onPanEnd') {
                this.isPanStarted = false;
            }
        }

        if (targetEventHandler) {
            targetEventHandler(...args);
        }
    }

    getHammerOptions() {
        const HammerLibrary = this.props.Hammer;
        const recognizers = [];
        const hammerOptions = {
            recognizers,
        };

        const panSwipeOptions = {
            direction: directionKeyToHammerConst[this.props.directionSupport],
        };

        if (this.props.threshold) {
            panSwipeOptions.threshold = this.props.threshold;
        }

        const hasVerticalDirection = panSwipeOptions.direction & HammerLibrary.DIRECTION_VERTICAL;

        let swipeEvents;
        if (this.props.onSwipe || this.props.onSwipeLeft || this.props.onSwipeRight) {
            recognizers.push([HammerLibrary.Swipe, panSwipeOptions]);
            swipeEvents = ['swipe'];
            if (hasVerticalDirection) {
                hammerOptions.touchAction = 'auto';
            }
        }

        if (this.props.onPan || this.props.onPanStart || this.props.onPanEnd) {
            // clone panSwipeOptions or hammer merges the 2 recognizers
            recognizers.push([HammerLibrary.Pan, _.clone(panSwipeOptions), swipeEvents]);
            if (hasVerticalDirection) {
                hammerOptions.touchAction = 'auto';
            }
        }

        // Due to limitations in the client station IE web view,
        // force MouseInput events
        if (config.appId === 'saxoselect') {
            hammerOptions.inputClass = this.props.Hammer.MouseInput;
        }

        return hammerOptions;
    }

    /**
     * Creates the hammer manager
     */
    createHammerManager() {
        this.childEl = ReactDOM.findDOMNode(this);

        this.hammerManager = new this.props.Hammer(this.childEl, this.getHammerOptions());

        const isPanStartRequired = Boolean(this.props.onPanStart);
        _.forEach(eventMap, (hammerEventName, eventKey) => {
            if (this.props[eventKey] ||
                (isPanStartRequired && (eventKey === 'onPan' || eventKey === 'onPanEnd'))) {
                this.hammerManager.on(hammerEventName, this.eventHandlersProxies[eventKey]);
            }
        });
    }

    /**
     * Destroys the hammer manager. this unbinds our events and the input events
     */
    destroyHammerManager() {
        if (!this.hammerManager) {
            return;
        }
        this.hammerManager.destroy();
        this.hammerManager = null;
    }

    render() {
        // Wraps a single React component without outputting a DOM element.
        return React.Children.only(this.props.children);
    }
}

Pannable.propTypes = {
    Hammer: PropTypes.func, // dependency injection for tests
    directionSupport: PropTypes.oneOf(_.keys(directionKeyToHammerConst)),
    threshold: PropTypes.number,
    isEnabled: PropTypes.bool,
    onPan: PropTypes.func,
    onPanCancel: PropTypes.func,
    onPanEnd: PropTypes.func,
    onPanStart: PropTypes.func,
    onSwipe: PropTypes.func,
    onSwipeLeft: PropTypes.func,
    onSwipeRight: PropTypes.func,
};

Pannable.defaultProps = {
    directionSupport: 'horizontal',
    isEnabled: true,
    Hammer,
};
