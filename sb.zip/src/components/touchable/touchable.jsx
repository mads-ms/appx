import _ from 'lodash';
import { UI, detect } from 'openui';
import PropTypes from 'prop-types';
import React from 'react';
import ReactDOM from 'react-dom';
import log from 'src/modules/log';

/**
 * Note on `onPressUp`: It appears that `<eventname>up` handlers are not emitted
 * because multiple instances of the Hammer Press recognizers are used.
 * Subsequent recognizers will not have their corresponding `<eventname>up`
 * event emitted (likely because the Hammer Managers' internal session is
 * deleted.)
 *
 * For similar reasons, tap doesn't work superbly in MSIE:
 * When you tap the chrome (i.e. scrollbar), it doesn't always trigger "up",
 * meaning the subsequent tap event doesn't fire on first tap
 *
 * Unfortunately, the Hammer project is looking for a maintainer so it's a long
 * shot to get this fixed upstream anytime soon.
 */
const eventMap = {
    onTouch: 'touch',
    onTap: detect.os.ms ? 'click' : 'tap',
    onPress: 'press',
    onPressUp: 'touchend mouseup',
    onDoubleTap: 'doubletap',
    onRightClick: 'contextmenu',
    onMouseEnter: 'mouseenter',
    onMouseLeave: 'mouseleave',
    onMouseUp: 'mouseup',
    onTouchStart: 'touchstart',
    onTouchEnd: 'touchend',
};

export const supportedEvents = _.map(eventMap, (value, key) => _.lowerFirst(key.substr(2)));

function combine(funcs) {
    if (funcs.length === 1) {
        return funcs[0];
    }

    return (...args) => {
        _.forEach(funcs, (func) => {
            func.apply(undefined, args);
        });
    };
}

export default class Touchable extends React.PureComponent {
    constructor(props) {
        super(props);

        this.prevEl = null;
        this.currentEl = null;

        if (!props.UI.getHammerManager()) {
            props.UI.initHammer();
        }

        this.eventHandlersProxies = {};
        const propKeysGroupedByEvents = _.reduce(eventMap, (result, eventNames, propKey) => {
            _.forEach(_.split(eventNames, ' '), (eventName) => {
                if (!result[eventName]) {
                    result[eventName] = [];
                }

                result[eventName].push(propKey);
            });
            return result;
        }, {});

        _.forEach(propKeysGroupedByEvents, (propKeys, eventName) => {
            const handler = combine(_.map(propKeys, (propKey) => this.handleEvent.bind(this, propKey)));

            this.eventHandlersProxies[eventName] = handler;
        });
    }

    componentDidMount() {
        this.currentEl = ReactDOM.findDOMNode(this);
        this.addEventListeners(this.getEventNamesFromProps(this.props));
    }

    componentDidUpdate(prevProps) {
        const nextCurrentEl = ReactDOM.findDOMNode(this);

        const unsubscribeEventNames = this.getEventNamesFromProps(prevProps);
        const subscribeEventNames = this.getEventNamesFromProps(this.props);

        if (this.currentEl === nextCurrentEl &&
            subscribeEventNames === unsubscribeEventNames) {
            return;
        }

        this.currentEl = nextCurrentEl;

        try {
            this.removeEventListeners(unsubscribeEventNames);
            this.addEventListeners(subscribeEventNames);
        } catch (error) {
            // #775720 Sometimes this.prevEl is null when orientation changes on ipad
            log.error('Failed to resubscribe to event names', { error, unsubscribeEventNames, subscribeEventNames });
        }
    }

    componentWillUnmount() {
        this.removeEventListeners(this.getEventNamesFromProps(this.props));
        this.prevEl = null;
    }

    getEventNamesFromProps(props) {
        if (!props.isEnabled) {
            return '';
        }

        return _
            .chain(props)
            .keys()
            .flatMap((key) => _.split(eventMap[key], ' '))
            .compact()
            .uniq()
            .sortBy()
            .join(',')
            .value();
    }

    handleEvent(propKey, ...args) {
        const targetEventHandler = this.props[propKey];

        if (targetEventHandler) {
            targetEventHandler.apply(this, args);
        }
    }

    addEventListeners(eventNames) {
        const el = this.prevEl = this.currentEl;
        const events = _.split(eventNames, ',');
        _.forEach(events, (eventName) => {
            el.addEventListener(eventName, this.eventHandlersProxies[eventName], false);
        });
    }

    removeEventListeners(eventNames) {
        const el = this.prevEl;
        const events = _.split(eventNames, ',');
        _.forEach(events, (eventName) => {
            el.removeEventListener(eventName, this.eventHandlersProxies[eventName], false);
        });
    }

    render() {
        // wraps a single React component without outputting a DOM element.
        return React.Children.only(this.props.children);
    }
}

Touchable.propTypes = {
    UI: PropTypes.object, // dependency injection for tests
    isEnabled: PropTypes.bool,
    onDoubleTap: PropTypes.func,
    onRightClick: PropTypes.func,
    onPress: PropTypes.func,
    onPressUp: PropTypes.func,
    onTap: PropTypes.func,
    onTouch: PropTypes.func,
    onTouchUp: PropTypes.func,
    onMouseEnter: PropTypes.func,
    onMouseLeave: PropTypes.func,
    onMouseUp: PropTypes.func,
    onTouchStart: PropTypes.func,
    onTouchEnd: PropTypes.func,
};

Touchable.defaultProps = {
    isEnabled: true,
    UI,
};
