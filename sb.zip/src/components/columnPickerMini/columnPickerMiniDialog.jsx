import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import { bindHandlers } from 'src/utils/bindHandlers';
import ColumnPicker from './columnPickerMini';

class ColumnPickerMiniDialog extends React.Component {
    constructor(props) {
        super(props);

        const miniColumnPickerHeaderId = this.getMiniColumnPickerHeaderId(this.props);

        this.state = {
            miniColumnPickerHeaderId,
        };
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.doubleColumns === this.props.doubleColumns &&
            nextProps.visibleColumnNames === this.props.visibleColumnNames) {
            return;
        }

        const miniColumnPickerHeaderId = this.getMiniColumnPickerHeaderId(nextProps);

        if (this.state.miniColumnPickerHeaderId !== miniColumnPickerHeaderId) {
            this.setState({
                miniColumnPickerHeaderId,
            });
        }
    }

    getMiniColumnPickerHeaderId(props) {
        const { visibleColumnNames } = props;

        if (!visibleColumnNames || !visibleColumnNames.length) {
            return null;
        }

        return this.isColumnPickerBtnEnabled(props) && _.last(visibleColumnNames) || null;
    }

    isColumnPickerBtnEnabled(props) {
        const { visibleColumnNames, doubleColumns } = props;
        return visibleColumnNames.length !== doubleColumns.length;
    }

    handleDialogShown() {
        this.props.onShow();
    }

    handleDialogHide() {
        this.props.onHide();
    }

    render() {
        const {
            isVisible,
            doubleColumns,
            visibleColumnNames,
            isFullHeight,
            rowHeight,
            rowDoubleHeight,
            onColumnsChange,
            onGridRowSort,
        } = this.props;

        const { miniColumnPickerHeaderId } = this.state;

        if (!isVisible || !miniColumnPickerHeaderId) {
            return false;
        }

        return (
            <ColumnPicker
                isFullHeight={isFullHeight}
                doubleColumns={doubleColumns}
                visibleColumnNames={visibleColumnNames}
                miniColumnPickerHeaderId={miniColumnPickerHeaderId}
                rowHeight={rowHeight}
                rowDoubleHeight={rowDoubleHeight}
                onHide={this.handleDialogHide}
                onShow={this.handleDialogShown}
                onColumnsChange={onColumnsChange}
                onGridRowSort={onGridRowSort}
            />
        );
    }
}

ColumnPickerMiniDialog.propTypes = {
    isFullHeight: PropTypes.bool,
    isVisible: PropTypes.bool,
    doubleColumns: PropTypes.arrayOf(PropTypes.object).isRequired,
    visibleColumnNames: PropTypes.arrayOf(PropTypes.string).isRequired,
    rowHeight: PropTypes.number,
    rowDoubleHeight: PropTypes.number,
    onColumnsChange: PropTypes.func.isRequired,
    onGridRowSort: PropTypes.func.isRequired,
    onHide: PropTypes.func.isRequired,
    onShow: PropTypes.func,
};

ColumnPickerMiniDialog.defaultProps = {
    onShow: _.noop,
};

export default bindHandlers(ColumnPickerMiniDialog);
