import React from 'react';
import { mount } from 'enzyme';
import ColumnPickerMiniSort from 'src/components/columnPickerMini/columnPickerMiniSort';

describe('src/components/columnPickerMini/columnPickerMiniSort', () => {
    let wrapper;

    afterEach(() => {
        wrapper.unmount();
    });

    it('renders successfully', () => {
        const rowData = {
            id: 'd_pl_account_closeprice',
            name: 'P/L (ccy)',
            subtitle: 'Close Price',
            sortKey: 'TotalPLAccount',
            height: 50,
            isNotSortable: false,
        };

        wrapper = mount(<ColumnPickerMiniSort/>);
        wrapper.setProps(rowData);
        expect(wrapper.find('div[data-sortkey]').length).toBe(1);
    });

    it('returns false if not sortable', () => {
        const rowData = {
            id: 'd_pl_account_closeprice',
            name: 'P/L (ccy)',
            subtitle: 'Close Price',
            sortKey: 'TotalPLAccount',
            height: 50,
            isNotSortable: true,
        };

        wrapper = mount(<ColumnPickerMiniSort/>);
        wrapper.setProps(rowData);
        expect(wrapper.children().length).toBe(0);
    });
});
