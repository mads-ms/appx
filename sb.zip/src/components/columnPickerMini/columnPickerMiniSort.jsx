import PropTypes from 'prop-types';
import React from 'react';
import Icon from 'src/components/icon/icon';

function ColumnPickerMiniSort(rowData) {
    if (rowData.isNotSortable) {
        return false;
    }

    return (
        <div data-sortkey={rowData.sortKey}>
            <Icon key="iconhigh" type="high" size="large"/>
            <Icon key="iconlow" type="low" size="large"/>
        </div>
    );
}

ColumnPickerMiniSort.propTypes = {
    rowData: PropTypes.object,
};

export default ColumnPickerMiniSort;
