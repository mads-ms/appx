import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import Dialog from 'src/components/dialog/dialog';
import Sheet from 'src/components/sheet/sheet';
import SheetHeader from 'src/components/sheet/sheetHeader';
import Localization from 'src/localization';
import ColumnPickerGrid from './columnPickerMiniGrid';
import { bindHandlers } from 'src/utils/bindHandlers';

const ROW_HEIGHT = 25;
const ROW_DOUBLE_HEIGHT = 50;

class ColumnPickerMini extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            rows: this.getRows(this.props),
        };
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.doubleColumns !== this.props.doubleColumns ||
            nextProps.visibleColumnNames !== this.props.visibleColumnNames) {

            this.setState({
                rows: this.getRows(nextProps),
            });
        }
    }

    mapColumnToRow(column) {
        const { rowHeight, rowDoubleHeight } = this.props;

        // column.sortKey is required to support old implementation. Should we removed after we move to new sorting implementation.
        const sortKey = column.sortKey || _.get(column, ['sort', 'id']);

        return {
            id: column.id,
            data: {
                name: column.primaryTitle,
                subtitle: column.secondaryTitle || '',
                sortKey,
                isFixed: column.isFixedStart || column.isFixedEnd,
                isNotSortable: column.isNotSortable,
            },
            className: `tst-col-item-${column.id}`,
            height: column.secondaryTitle ? rowDoubleHeight : rowHeight,
        };
    }

    getRows({ doubleColumns, visibleColumnNames, miniColumnPickerHeaderId }) {
        const visibleColsExcludingColPicker = _.reject(visibleColumnNames, (colId) => colId === miniColumnPickerHeaderId);

        return _.chain(doubleColumns)

            // remove fixed columns and visible columns except the column picker header
            .reject((column) => column && (column.isFixed || _.includes(visibleColsExcludingColPicker, column.id)))
            .map(this.mapColumnToRow.bind(this))
            .value();
    }

    handleColumnSelect(columnId) {
        const { doubleColumns, visibleColumnNames, miniColumnPickerHeaderId } = this.props;
        const isAlreadyVisible = _.includes(visibleColumnNames, columnId);
        const columns = _.clone(doubleColumns);

        if (!isAlreadyVisible) {
            const colPickerIndex = _.findIndex(columns, (col) => col.id === miniColumnPickerHeaderId);
            const selectedColumn = _.chain(columns)
                .remove((col) => col.id === columnId)
                .head()
                .value();

            if (selectedColumn) {
                // insert selected column before previous column picker header i.e. last visible column
                columns.splice(colPickerIndex, 0, selectedColumn);
                this.props.onColumnsChange(columns);
            }
        }

        this.props.onHide();
    }

    handleGridRowSort(columnId) {
        this.props.onGridRowSort(columnId);
        this.props.onHide();
    }

    render() {
        const { rows } = this.state;
        const { miniColumnPickerHeaderId, isFullHeight, onHide, onShow } = this.props;

        return (
            <Dialog
                isFullHeight={isFullHeight}
                onHide={onHide}
                onShow={onShow}
            >
                <Sheet isAlt className="colpickermini dropdown-sheet">
                    <SheetHeader onClose={onHide}>
                        {Localization.getText('HTML5_SelectColumn')}
                    </SheetHeader>
                    <ColumnPickerGrid
                        rows={rows}
                        selectedRow={miniColumnPickerHeaderId}
                        onColumnSelect={this.handleColumnSelect}
                        onGridRowSort={this.handleGridRowSort}
                    />
                </Sheet>
            </Dialog>
        );
    }
}

ColumnPickerMini.propTypes = {
    isFullHeight: PropTypes.bool,
    doubleColumns: PropTypes.arrayOf(PropTypes.object).isRequired,
    visibleColumnNames: PropTypes.arrayOf(PropTypes.string).isRequired,
    miniColumnPickerHeaderId: PropTypes.string.isRequired,
    rowHeight: PropTypes.number,
    rowDoubleHeight: PropTypes.number,
    onColumnsChange: PropTypes.func.isRequired,
    onHide: PropTypes.func.isRequired,
    onShow: PropTypes.func,
    onGridRowSort: PropTypes.func.isRequired,
};

ColumnPickerMini.defaultProps = {
    isFullHeight: false,
    rowHeight: ROW_HEIGHT,
    rowDoubleHeight: ROW_DOUBLE_HEIGHT,
    onShow: _.noop,
};

export default bindHandlers(ColumnPickerMini);
