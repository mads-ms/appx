import PropTypes from 'prop-types';
import React from 'react';
import { bindHandlers } from 'src/utils/bindHandlers';
import ReactGrid from 'src/components/reactGrid/reactGrid';
import Touchable from 'src/components/touchable/touchable';
import ColumnPickerSort from './columnPickerMiniSort';

class ColumnPickerMiniGrid extends React.Component {

    handleColumnSelect(evt, rowId) {
        evt.preventDefault();
        this.props.onColumnSelect(rowId);
    }

    handleGridRowSort(evt, rowId) {
        evt.preventDefault();
        this.props.onGridRowSort(rowId);
    }

    render() {
        const { rows, selectedRow } = this.props;
        return (
            <ReactGrid
                isHeader={false}
                className="list list--alt list--lines"
                rowClass="list-item"
                cellClass="grid-cell"
                selectedRow={selectedRow}
                cols={[
                    {
                        id: 'name',
                        template: ({ rowId, rowData }) => {
                            const onTap = (evt) => this.handleColumnSelect(evt, rowId);
                            return (
                                <Touchable onTap={onTap}>
                                    <div className="grid grid--y" >
                                        <p className="grid-cell">{rowData.name}</p>
                                        { rowData.subtitle && (
                                            <p className="grid-cell beta">{rowData.subtitle}</p>
                                        )}
                                    </div>
                                </Touchable>
                            );
                        },
                        align: 'start',

                        // Fluid width
                        minWidth: 1,
                        maxWidth: 9999,
                    },
                    {
                        id: 'icon',
                        template: ({ rowId, rowData }) => {
                            const onTap = (evt) => this.handleGridRowSort(evt, rowId);
                            return (
                                <Touchable onTap={onTap}>
                                    <div className="grid grid--grail">
                                        {ColumnPickerSort(rowData)}
                                    </div>
                                </Touchable>
                            );
                        },
                        width: 65,
                    },
                ]}
                rows={rows}
            />
        );
    }
}

ColumnPickerMiniGrid.propTypes = {
    rows: PropTypes.arrayOf(PropTypes.object).isRequired,
    selectedRow: PropTypes.string.isRequired,
    onColumnSelect: PropTypes.func.isRequired,
    onGridRowSort: PropTypes.func.isRequired,
};

export default bindHandlers(ColumnPickerMiniGrid);
