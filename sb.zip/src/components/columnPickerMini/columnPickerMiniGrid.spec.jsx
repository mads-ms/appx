import _ from 'lodash';
import React from 'react';
import { mount } from 'enzyme';
import ColumnPickerMiniGrid from 'src/components/columnPickerMini/columnPickerMiniGrid';

describe('src/components/columnPickerMini/columnPickerMiniGrid', () => {

    let wrapper;
    const rows = [{
        id: 'd_pl_account_closeprice',
        name: 'P/L (ccy)',
        subtitle: 'Close Price',
        sortKey: 'TotalPLAccount',
        height: 50,
        isNotSortable: false,
    },
    {
        id: 'd_close_time_open_time',
        name: 'Close Time',
        subtitle: 'Open Time',
        sortKey: 'ExecutionTimeClose',
        height: 50,
        isNotSortable: false,
    },
    ];

    const selectedRow = 'd_close_time_open_time';

    afterEach(() => {
        wrapper.unmount();
    });

    it('renders successfully', () => {

        wrapper = mount(
            <ColumnPickerMiniGrid
                rows={rows}
                selectedRow={selectedRow}
            />
        );

        expect(wrapper.instance() instanceof ColumnPickerMiniGrid).toBe(true);
    });

    it('handle column select', () => {
        const columnPickerMiniSpy = jasmine.createSpyObj('columnPickerMini', ['onColumnSelect']);
        wrapper = mount(
            <ColumnPickerMiniGrid
                rows={rows}
                selectedRow={selectedRow}
                onColumnSelect={columnPickerMiniSpy.onColumnSelect}
            />
        );
        const evt = {
            preventDefault: _.noop,
        };
        wrapper.instance().handleColumnSelect(evt, 'd_close_time_open_time');
        expect(columnPickerMiniSpy.onColumnSelect).toHaveBeenCalledWith('d_close_time_open_time');
    });

    it('handle grid row sort', () => {
        const columnPickerMiniSpy = jasmine.createSpyObj('columnPickerMini', ['onGridRowSort']);
        wrapper = mount(
            <ColumnPickerMiniGrid
                rows={rows}
                selectedRow={selectedRow}
                onGridRowSort={columnPickerMiniSpy.onGridRowSort}
            />
        );
        const evt = {
            preventDefault: _.noop,
        };
        wrapper.instance().handleGridRowSort(evt, 'd_pl_account_closeprice');
        expect(columnPickerMiniSpy.onGridRowSort).toHaveBeenCalledWith('d_pl_account_closeprice');
    });
});
