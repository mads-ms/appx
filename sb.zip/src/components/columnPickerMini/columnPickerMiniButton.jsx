import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import { ActionButton, IconHigh, IconLow } from 'src/components/reactGrid/reactGridBlocks';

function ColumnPickerMiniButton({ column, sortDataValue, className }) {
    const { primaryTitle, secondaryTitle, isSortAlignEnd, isNotSortable } = column;
    const sortButtons = isNotSortable ? [] : [<IconHigh key="icon-high"/>, <IconLow key="icon-low"/>];
    const buttonElements = isSortAlignEnd ? [primaryTitle, ...sortButtons] : [...sortButtons, primaryTitle];
    const actionBtnProps = {
        betaValue: secondaryTitle,
        isEnabled: true,
        title: primaryTitle,
        value: buttonElements,
        column,
    };

    return (
        <div
            className={classNames('col-header', className)}
            data-sortdir={sortDataValue}
        >
            <ActionButton {...actionBtnProps}/>
        </div>
    );
}

ColumnPickerMiniButton.propTypes = {
    className: PropTypes.string,
    column: PropTypes.object.isRequired,
    sortDataValue: PropTypes.string,
};

export default ColumnPickerMiniButton;
