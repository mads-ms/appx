import _ from 'lodash';
import React from 'react';
import { mount } from 'enzyme';
import ColumnPickerMini from 'src/components/columnPickerMini/columnPickerMini';

describe('src/components/columnPickerMini/columnPickerMini', () => {
    let wrapper;

    const doubleColumns = [
        {
            isMiniColumnPickerHeader: false,
            id: 'd_instrument_double',
            primaryTitle: 'Instrument',
            isFixed: true,
            sortKey: 'symbol',
        },
        {
            isMiniColumnPickerHeader: true,
            id: 'd_close_time_open_time',
            primaryTitle: 'Close Time',
            secondaryTitle: 'Open Time',
            isFixed: false,
            sortKey: 'ExecutionTimeClose',
        },
        {
            isMiniColumnPickerHeader: false,
            id: 'd_pl_account_closeprice',
            primaryTitle: 'P/L (ccy)',
            secondaryTitle: 'Close Price',
            isFixed: false,
            sortKey: 'TotalPLAccount',
        },
    ];
    const visibleColumnNames = [
        'd_instrument_double',
        'd_close_time_open_time',
    ];
    const miniColumnPickerHeaderId = 'd_close_time_open_time';
    const props = {
        isFullHeight: false,
        doubleColumns,
        visibleColumnNames,
        miniColumnPickerHeaderId,
        onHide: _.noop,
        onColumnsChange: _.noop,
        onGridRowSort: _.noop,
    };

    afterEach(() => {
        wrapper.unmount();
    });

    it('renders successfully', () => {

        wrapper = mount(
            <ColumnPickerMini/>
        );
        wrapper.setProps(props);
        expect(wrapper.instance() instanceof ColumnPickerMini).toBe(true);
    });

    it('correctly computes columns to render from given set of columns', () => {
        wrapper = mount(
            <ColumnPickerMini/>
        );
        wrapper.setProps(props);
        const columnsToRender = wrapper.instance().getRows(props);
        expect(_.isEqual(_.map(columnsToRender, 'id'), ['d_close_time_open_time', 'd_pl_account_closeprice'])).toBe(true);
    });

    it('handle column select when selected column is not visible', () => {
        const columnPickerMiniSpy = jasmine.createSpyObj('columnPickerMini', ['onColumnsChange', 'onHide']);
        const expectedColumns = [
            {
                isMiniColumnPickerHeader: false,
                id: 'd_instrument_double',
                primaryTitle: 'Instrument',
                isFixed: true,
                sortKey: 'symbol',
            },
            {
                isMiniColumnPickerHeader: false,
                id: 'd_pl_account_closeprice',
                primaryTitle: 'P/L (ccy)',
                secondaryTitle: 'Close Price',
                isFixed: false,
                sortKey: 'TotalPLAccount',
            },
            {
                isMiniColumnPickerHeader: true,
                id: 'd_close_time_open_time',
                primaryTitle: 'Close Time',
                secondaryTitle: 'Open Time',
                isFixed: false,
                sortKey: 'ExecutionTimeClose',
            },
        ];
        wrapper = mount(
            <ColumnPickerMini/>
        );
        const newProps = _.defaults({
            onColumnsChange: columnPickerMiniSpy.onColumnsChange,
            onHide: columnPickerMiniSpy.onHide,
        }, props);
        wrapper.setProps(newProps);
        wrapper.instance().handleColumnSelect('d_pl_account_closeprice');
        expect(columnPickerMiniSpy.onHide).toHaveBeenCalled();
        expect(columnPickerMiniSpy.onColumnsChange).toHaveBeenCalledWith(expectedColumns);
    });

    it('handle column select when selected column is already visible', () => {
        const columnPickerMiniSpy = jasmine.createSpyObj('columnPickerMini', ['onColumnsChange', 'onHide']);
        wrapper = mount(
            <ColumnPickerMini/>
        );
        const newProps = _.defaults({
            onColumnsChange: columnPickerMiniSpy.onColumnsChange,
            onHide: columnPickerMiniSpy.onHide,
        });
        wrapper.setProps(newProps);
        wrapper.instance().handleColumnSelect('d_pl_account_closeprice');
        expect(columnPickerMiniSpy.onHide).toHaveBeenCalled();
        expect(columnPickerMiniSpy.onColumnsChange).not.toHaveBeenCalled();
    });
});
