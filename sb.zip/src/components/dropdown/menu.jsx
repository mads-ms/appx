import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import Dialog from 'src/components/dialog/dialog';
import Sheet from 'src/components/sheet/sheet';
import SheetHeader from 'src/components/sheet/sheetHeader';
import classNames from 'classnames';

class Menu extends React.PureComponent {
    render() {
        const {
            label,
            selectedValue,
            position,
            align,
            anchor,
            children,
            dialogParent,
            dialogType,
            onHide,
            onSelect,
            isAltStyle,
            isAstroStyle,
        } = this.props;

        const items = React.Children.map(children, (child) =>
            React.cloneElement(child, {
                isSelected: child.props.value === selectedValue,
                onSelect,
            })
        );

        const sheetClasses = classNames('sheet--dropdown grid grid--y', {
            'sheet--alt': isAltStyle,
            'sheet--astro': isAstroStyle,
        });

        const listClasses = classNames('list list--lines', {
            'list--alt': isAltStyle,
            'list--astro': isAstroStyle,
        });

        return (
            <Dialog
                anchor={anchor}
                position={position}
                align={align}
                parent={dialogParent}
                type={dialogType}
                onHide={onHide}
            >
                <Sheet className={sheetClasses}>
                    {label &&
                        <SheetHeader
                            className="grid-cell g--fit"
                        >
                            {label}
                        </SheetHeader>
                    }
                    <div className="grid-cell grid grid--scroll">
                        <div className="grid-cell">
                            <ul className={listClasses}>
                                {items}
                            </ul>
                        </div>
                    </div>
                </Sheet>
            </Dialog>
        );
    }
}

Menu.propTypes = {
    label: PropTypes.string,
    position: PropTypes.string,
    align: PropTypes.string,
    anchor: PropTypes.object.isRequired,
    selectedValue: PropTypes.any,
    onSelect: PropTypes.func,
    onHide: PropTypes.func,
    isAltStyle: PropTypes.bool,
    isAstroStyle: PropTypes.bool,
    dialogParent: PropTypes.instanceOf(HTMLElement),
    dialogType: PropTypes.string,
};

Menu.defaultProps = {
    position: 'bottom',
    align: 'left',
    onSelect: _.noop,
    onHide: _.noop,
};

export default Menu;
