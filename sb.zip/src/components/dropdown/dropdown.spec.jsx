import _ from 'lodash';
import React from 'react';
import { mount } from 'enzyme';
import Dropdown from 'src/components/dropdown/dropdown';
import DropdownItem from 'src/components/dropdown/dropdownItem';

describe('src/components/dropdown/dropdown', () => {
    let wrapper;

    afterEach(() => {
        wrapper.unmount();
    });

    it('renders a dropdown', () => {
        wrapper = mount(
            <Dropdown>
                <DropdownItem value="foo">Foo</DropdownItem>
            </Dropdown>
        );

        const instance = wrapper.instance();

        expect(instance instanceof Dropdown).toBe(true);
    });

    it('can rerender items', () => {
        let children = [
            <DropdownItem key={0} value="foo">Foo</DropdownItem>,
        ];

        wrapper = mount(
            <Dropdown>
                {children}
            </Dropdown>
        );

        expect(_.keys(wrapper.prop('children')).length).toEqual(1);

        children = [
            <DropdownItem key={0} value="foo">Foo</DropdownItem>,
            <DropdownItem key={1} value="bar">Bar</DropdownItem>,
            <DropdownItem key={2} value="baz">Baz</DropdownItem>,
        ];

        wrapper.setProps({ children });

        expect(_.keys(wrapper.prop('children')).length).toEqual(3);
    });

    it('honors the value prop', () => {
        wrapper = mount(
            <Dropdown value="bar">
                <DropdownItem value="foo">Foo</DropdownItem>
                <DropdownItem value="bar">Bar</DropdownItem>
                <DropdownItem value="baz">Baz</DropdownItem>
            </Dropdown>
        );

        expect(wrapper.prop('value')).toEqual('bar');
    });

    it('honors the isEnabled prop', () => {
        wrapper = mount(
            <Dropdown isEnabled>
                <DropdownItem value="foo">Foo</DropdownItem>
            </Dropdown>
        );

        expect(wrapper.prop('isEnabled')).toBe(true);

        wrapper.setProps({
            isEnabled: false,
        });

        expect(wrapper.prop('isEnabled')).toBe(false);
    });

    it('honors the isMenuShown', () => {
        const handleChange = jasmine.createSpy('handleChange');

        wrapper = mount(
            <Dropdown onChange={handleChange} value="foo">
                <DropdownItem value="foo">Foo</DropdownItem>
                <DropdownItem value="bar" isEnabled={false}>Bar</DropdownItem>
                <DropdownItem value="baz">Baz</DropdownItem>
            </Dropdown>
        );

        const instance = wrapper.instance();

        expect(wrapper.state('isMenuShown')).toBe(false);

        instance.handleButtonTap();

        expect(wrapper.state('isMenuShown')).toBe(true);
    });

    it('calls onChange prop when item is selected', () => {
        const handleChange = jasmine.createSpy('handleChange');

        wrapper = mount(
            <Dropdown onChange={handleChange} value="foo">
                <DropdownItem value="foo">Foo</DropdownItem>
                <DropdownItem value="bar">Bar</DropdownItem>
                <DropdownItem value="baz">Baz</DropdownItem>
            </Dropdown>
        );

        const instance = wrapper.instance();

        expect(wrapper.prop('value')).toEqual('foo');
        expect(handleChange).not.toHaveBeenCalled();

        instance.handleMenuSelect('bar');

        expect(handleChange).toHaveBeenCalledWith('bar');
        expect(handleChange).toHaveBeenCalledTimes(1);
    });
});
