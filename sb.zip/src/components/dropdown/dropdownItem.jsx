import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import Touchable from 'src/components/touchable/touchable';
import { bindHandlers } from 'src/utils/bindHandlers';
import classNames from 'classnames';

class DropdownItem extends React.PureComponent {
    handleTap() {
        const {
            value,
            onSelect,
        } = this.props;

        onSelect(value);
    }

    render() {
        const {
            isEnabled,
            isSelected,
            children,
            className,
        } = this.props;

        const classes = classNames(className || 'list-item', {
            'is-disabled': !isEnabled,
            'is-selected': isSelected,
        });

        return (
            <Touchable
                onTap={this.handleTap}
                isEnabled={isEnabled}
            >
                <li className={classes}>
                    {children}
                </li>
            </Touchable>
        );
    }
}

DropdownItem.propTypes = {
    value: PropTypes.any,
    className: PropTypes.string,
    isEnabled: PropTypes.bool,
    isSelected: PropTypes.bool,
    onSelect: PropTypes.func,
};

DropdownItem.defaultProps = {
    isEnabled: true,
    isSelected: false,
    onSelect: _.noop,
};

export default bindHandlers(DropdownItem);
