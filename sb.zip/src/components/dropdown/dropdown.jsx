import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import { bindHandlers } from 'src/utils/bindHandlers';
import Menu from './menu';
import DropdownItem from './dropdownItem';
import Button from 'src/components/button/button';
import classNames from 'classnames';

/**
 * Usage:
 *     <Dropdown onChange={} value="foo" isEnabled={[OPTIONAL BOOL]} label="[OPTIONAL STR]"">
 *         <DropdownItem value="foo" isEnabled={[OPTIONAL BOOL]}>Foo</DropdownItem>
 *     </Dropdown>
 */

class Dropdown extends React.PureComponent {
    constructor() {
        super();

        this.state = {
            isMenuShown: false,
        };

        this.setEl = (ref) => {
            this.el = ref;
        };
    }

    handleButtonTap() {
        this.setState({
            isMenuShown: !this.state.isMenuShown,
        });
    }

    handleMenuSelect(value) {
        this.handleMenuHide();
        this.props.onChange(value);
    }

    handleMenuHide() {
        this.setState({
            isMenuShown: false,
        });
    }

    render() {
        const {
            label,
            value,
            children,
            className,
            dialogParent,
            dialogType,
            isEnabled,
            isAltStyle,
            isAstroStyle,
        } = this.props;

        const {
            isMenuShown,
        } = this.state;

        const classes = classNames('dropdown select icon icon--toggle', {
            'is-disabled': !isEnabled,
            'is-open': isMenuShown,
            'dropdown--alt select--alt': isAltStyle,
            'dropdown--astro select--astro': isAstroStyle,
        });

        const selectedItem = _.find(
            React.Children.toArray(children),
            (child) => child.props.value === value
        );

        return (
            <div
                className={className}
                ref={this.setEl}
            >
                <div className={classes}>

                    <Button
                        className="btn--clear dropdown-input form-control"
                        onTap={this.handleButtonTap}
                        isEnabled={isEnabled}
                    >
                        <ul>
                            {selectedItem}
                        </ul>
                    </Button>

                    {isMenuShown &&
                        <Menu
                            label={label}
                            selectedValue={value}
                            anchor={this.el}
                            dialogParent={dialogParent}
                            dialogType={dialogType}
                            onSelect={this.handleMenuSelect}
                            onHide={this.handleMenuHide}
                            isAltStyle={isAltStyle}
                            isAstroStyle={isAstroStyle}
                        >
                            {children}
                        </Menu>
                    }
                </div>
            </div>
        );
    }
}

const DROPDOWN_ITEM_PROP_TYPE = PropTypes.shape({
    type: PropTypes.oneOf([DropdownItem]),
});

Dropdown.propTypes = {
    children: PropTypes.oneOfType([
        DROPDOWN_ITEM_PROP_TYPE,
        PropTypes.arrayOf(DROPDOWN_ITEM_PROP_TYPE),
    ]),
    onChange: PropTypes.func,
    label: PropTypes.string,
    value: PropTypes.any,
    className: PropTypes.string,
    isEnabled: PropTypes.bool,
    isAltStyle: PropTypes.bool,
    isAstroStyle: PropTypes.bool,
    dialogParent: PropTypes.instanceOf(HTMLElement),
    dialogType: PropTypes.oneOf(['popup', 'card']),
};

Dropdown.defaultProps = {
    onChange: _.noop,
    isEnabled: true,
    isAltStyle: false,
};

export default bindHandlers(Dropdown);
