import React from 'react';
import Dropdown from './dropdown';
import DropdownItem from './dropdownItem';
import { examplesOf } from 'src/modules/examples/utils';

// set key props to force re-render, since Dropdown still wraps a spine controller
export default examplesOf('Dropdown')
    .add('Default', ({ action }) => (
        <Dropdown
            key="default"
            onChange={action('change')}
        >
            <DropdownItem value="item1">Item 1</DropdownItem>
            <DropdownItem value="item2">Item 2</DropdownItem>
            <DropdownItem value="item3">Item 3</DropdownItem>
            <DropdownItem value="item4" isEnabled={false}>Item 4 - disabled</DropdownItem>
        </Dropdown>
    ))
    .add('Disabled', ({ action }) => (
        <Dropdown
            key="disabled"
            isEnabled={false}
            onChange={action('change')}
        >
            <DropdownItem value="item1">Item 1</DropdownItem>
            <DropdownItem value="item2">Item 2</DropdownItem>
            <DropdownItem value="item3">Item 3</DropdownItem>
            <DropdownItem value="item4" isEnabled={false}>Item 4 - disabled</DropdownItem>
        </Dropdown>
    ))
    .add('Alt Style', ({ action }) => (
        <Dropdown
            key="alt-style"
            isAltStyle
            onChange={action('change')}
        >
            <DropdownItem value="item1">Item 1</DropdownItem>
            <DropdownItem value="item2">Item 2</DropdownItem>
            <DropdownItem value="item3">Item 3</DropdownItem>
            <DropdownItem value="item4" isEnabled={false}>Item 4 - disabled</DropdownItem>
        </Dropdown>
    ))
    .add('Astro Style 🚀', ({ action }) => (
        <Dropdown
            key="pro-style"
            isAstroStyle
            onChange={action('change')}
        >
            <DropdownItem value="item1">Item 1</DropdownItem>
            <DropdownItem value="item2">Item 2</DropdownItem>
            <DropdownItem value="item3">Item 3</DropdownItem>
            <DropdownItem value="item4" isEnabled={false}>Item 4 - disabled</DropdownItem>
        </Dropdown>
    ));
