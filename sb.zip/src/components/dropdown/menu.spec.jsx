import React from 'react';
import { shallow } from 'enzyme';
import Menu from 'src/components/dropdown/menu';
import DropdownItem from 'src/components/dropdown/dropdownItem';

describe('src/components/dropdown/menu', () => {
    let wrapper;

    it('render the menu dialog', () => {
        wrapper = shallow(
            <Menu
                anchor={document}
            >
                <DropdownItem value="foo">Foo</DropdownItem>
                <DropdownItem value="bar">Bar</DropdownItem>
            </Menu>
        );

        const instance = wrapper.instance();

        expect(instance instanceof Menu).toBe(true);
        expect(wrapper.find(DropdownItem).length).toBe(2);
    });

    it('honors the isEnabled prop', () => {
        wrapper = shallow(
            <Menu
                anchor={document}
            >
                <DropdownItem value="foo">Foo</DropdownItem>
                <DropdownItem value="bar" isEnabled={false}>Bar</DropdownItem>
            </Menu>
        );

        expect(wrapper.find(DropdownItem).at(0).prop('isEnabled')).toBe(true);
        expect(wrapper.find(DropdownItem).at(1).prop('isEnabled')).toBe(false);
    });

    it('honors the isSelected prop', () => {
        wrapper = shallow(
            <Menu
                anchor={document}
                selectedValue="foo"
            >
                <DropdownItem value="foo">Foo</DropdownItem>
                <DropdownItem value="bar">Bar</DropdownItem>
            </Menu>
        );

        expect(wrapper.find(DropdownItem).at(0).prop('isSelected')).toBe(true);
        expect(wrapper.find(DropdownItem).at(1).prop('isSelected')).toBe(false);
    });

    it('calls onSelect prop when item is selected', () => {
        const handleSelect = jasmine.createSpy('handleSelect');

        wrapper = shallow(
            <Menu
                onSelect={handleSelect}
                anchor={document.body}
            >
                <DropdownItem value="foo">Foo</DropdownItem>
            </Menu>
        );

        wrapper.find(DropdownItem).first().dive()
            .simulate('tap');

        expect(handleSelect).toHaveBeenCalledTimes(1);
        expect(handleSelect).toHaveBeenCalledWith('foo');
    });
});
