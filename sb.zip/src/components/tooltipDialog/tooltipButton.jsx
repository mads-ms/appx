import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import { bindHandlers } from 'src/utils/bindHandlers';
import Button from 'src/components/button/button';
import Icon from 'src/components/icon/icon';
import TooltipDialog from './tooltipDialog';
import classNames from 'classnames';

class TooltipButton extends React.Component {
    constructor() {
        super();

        this.state = {
            isTooltipShown: false,
        };
    }

    handleSetAnchor(ref) {
        this.anchorEl = ref;
    }

    handleHideTooltip() {
        this.setState({
            isTooltipShown: false,
        });

        this.props.onHideTooltip();
    }

    handleShowTooltip() {
        if (this.state.isTooltipShown) {
            return;
        }

        this.setState({
            isTooltipShown: true,
        });

        this.props.onShowTooltip();
    }

    render() {
        const {
            tooltipDialogType,
            tooltipDialogParent,
            tooltipPosition,
            tooltipTitle,
            tooltipText,
            isAstroStyle,
            isCompact,
        } = this.props;

        const { isTooltipShown } = this.state;
        const btnClassNames = classNames('tooltip-btn btn--clear btn--inline', {
            'btn--compact': isCompact,
        });

        return (
            <span>
                <Button
                    className={btnClassNames}
                    onDomRef={this.handleSetAnchor}
                    onTap={this.handleShowTooltip}
                >
                    <Icon type="details"/>
                </Button>
                {isTooltipShown &&
                    <TooltipDialog
                        type={tooltipDialogType}
                        parent={tooltipDialogParent}
                        anchor={this.anchorEl}
                        position={tooltipPosition}
                        title={tooltipTitle}
                        text={tooltipText}
                        isAstroStyle={isAstroStyle}
                        onHide={this.handleHideTooltip}
                    />
                }
            </span>
        );
    }
}

TooltipButton.propTypes = {
    tooltipTitle: PropTypes.string,
    tooltipText: PropTypes.string,
    tooltipPosition: PropTypes.string,
    isAstroStyle: PropTypes.bool,
    isCompact: PropTypes.bool,
    tooltipDialogType: PropTypes.oneOf(['popup', 'card']),
    tooltipDialogParent: PropTypes.instanceOf(HTMLElement),
    onShowTooltip: PropTypes.func,
    onHideTooltip: PropTypes.func,
};

TooltipButton.defaultProps = {
    isCompact: false,
    onShowTooltip: _.noop,
    onHideTooltip: _.noop,
};

export default bindHandlers(TooltipButton);
