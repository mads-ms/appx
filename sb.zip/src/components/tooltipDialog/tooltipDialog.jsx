import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import Dialog from 'src/components/dialog/dialog';
import Sheet from 'src/components/sheet/sheet';
import SheetHeader from 'src/components/sheet/sheetHeader';
import SheetBody from 'src/components/sheet/sheetBody';
import config from 'src/config';

class TooltipDialog extends React.PureComponent {
    render() {
        const {
            type,
            parent,
            anchor,
            position,
            title,
            text,
            isAstroStyle,
            onHide,
        } = this.props;

        const tooltipItems = _.chain(text)
            .split('\n')
            .map((tooltipItem) => {
                const tooltipItemText = _.trim(tooltipItem);
                return (<p key={tooltipItemText}>{tooltipItemText}</p>);
            })
            .compact()
            .value();

        const sheetClasses = classNames({
            'tooltip-sheet': type === 'popup',
        });

        return (
            <Dialog
                type={type}
                parent={parent}
                anchor={config.isPhoneApp ? null : anchor}
                position={position}
                onHide={onHide}
            >
                <Sheet
                    className={sheetClasses}
                    isAlt={!isAstroStyle}
                    isAstroStyle={isAstroStyle}
                >
                    <div className="grid grid--y">
                        <SheetHeader
                            className="grid-cell"
                            onClose={onHide}
                        >
                            {title}
                        </SheetHeader>
                        <SheetBody className="grid-cell">
                            {tooltipItems}
                        </SheetBody>
                    </div>
                </Sheet>
            </Dialog>
        );
    }
}

TooltipDialog.propTypes = {
    anchor: PropTypes.object,
    position: PropTypes.string,
    type: PropTypes.oneOf(['popup', 'card']),
    parent: PropTypes.instanceOf(HTMLElement),
    title: PropTypes.string,
    text: PropTypes.string,
    isAstroStyle: PropTypes.bool,
    onHide: PropTypes.func,
};

TooltipDialog.defaultProps = {
    position: config.isPhoneApp ? 'bottom' : 'right',
    type: config.isPhoneApp ? 'card' : 'popup',
    isAstroStyle: false,
    onHide: _.noop,
};

export default TooltipDialog;
