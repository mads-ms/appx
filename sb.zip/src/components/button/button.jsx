import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import Loader from 'src/components/loader/loader';
import Touchable from 'src/components/touchable/touchable';

/**
 * Button component that supports three states: Enabled, Disabled and Waiting.
 * When Button is in Waiting state then Loader component is being rendered in place.
 */
export default class Button extends React.Component {

    render() {
        const {
            className,
            isEnabled,
            onTap,
            onDoubleTap,
            onTouchStart,
            onTouchEnd,
            title,
            onContextMenu,
            isWaiting,
            loaderAlign,
            children,
            isLoaderInstant,
            loaderSize,
        } = this.props;

        const btnClassNames = classNames('btn', className, {
            'btn--blank': isWaiting && loaderAlign === 'center',
        });

        const btn = (
            <button
                onContextMenu={onContextMenu}
                className={btnClassNames}
                type="button"
                disabled={!isEnabled || isWaiting}
                title={title}
                ref={this.props.onDomRef}
            >
                {children}
                {isWaiting &&
                    <Loader
                        isInstant={isLoaderInstant}
                        size={loaderSize}
                        align={loaderAlign}
                        isVisible
                        isTransparent
                    />
                }
            </button>
        );

        if (onTap || onDoubleTap) {
            return (
                <Touchable
                    onTap={onTap}
                    onDoubleTap={onDoubleTap}
                    onTouchStart={onTouchStart}
                    onTouchEnd={onTouchEnd}
                    isEnabled={isEnabled && !isWaiting}
                >
                    {btn}
                </Touchable>
            );
        }

        return btn;
    }
}

/**
 * @property {Object} propTypes                  -  props that can be passed to the component
 * @property {string} propTypes.className        -  additional class name
 * @property {string} propTypes.title            -  sets Button's title element
 * @property {bool} propTypes.isEnabled          -  enables Button
 * @property {bool} propTypes.isWaiting          -  shows Loader spinner
 * @property {bool} propTypes.isLoaderInstant    -  loader is in Instant mode
 * @property {Function} propTypes.onContextMenu  -  handler run on context menu
 * @property {Function} propTypes.onTap          -  handler run on tap
 * @property {Function} propTypes.onDoubleTap    -  handler run on double tap
 */
Button.propTypes = {
    className: PropTypes.string,
    isEnabled: PropTypes.bool,
    isWaiting: PropTypes.bool,
    isLoaderInstant: PropTypes.bool,
    loaderAlign: PropTypes.string,
    loaderSize: PropTypes.string,
    onContextMenu: PropTypes.func,
    onDoubleTap: PropTypes.func,
    onDomRef: PropTypes.func,
    onTap: PropTypes.func,
    onTouchStart: PropTypes.func,
    onTouchEnd: PropTypes.func,
    title: PropTypes.string,
};

Button.defaultProps = {
    className: '',
    isEnabled: true,
    isWaiting: false,
    isLoaderInstant: false,
    loaderAlign: 'right',
    loaderSize: 'none',
};
