import React from 'react';
import Button from './button';
import { examplesOf } from 'src/modules/examples/utils';

export default examplesOf('Button', 'button')
    .add('Default', ({ action }) => (
        <Button onTap={action('tap')}>Button</Button>
    ), 'default')
    .add('Large', ({ action }) => (
        <Button className="btn--large" onTap={action('tap')}>Button</Button>
    ), 'large')
    .add('Inline', ({ action }) => (
        <Button className="btn--inline" onTap={action('tap')}>Button</Button>
    ), 'inline')
    .add('Primary', ({ action }) => (
        <Button className="btn--primary" onTap={action('tap')}>Button</Button>
    ))
    .add('Loading', () => (
        <div className="grid grid--y grid--series grid--fit-all">
            <div className="grid-cell">
                <Button isWaiting>Button</Button>
            </div>
            <div className="grid-cell">
                <Button isWaiting loaderAlign="center">Button</Button>
            </div>
            <div className="grid-cell">
                <Button isWaiting loaderAlign="left">Button</Button>
            </div>
        </div>
    ), 'loading')
    .add('Astro Style 🚀', ({ action }) => (
        <Button className="btn--astro" onTap={action('tap')}>Button</Button>
    ));
