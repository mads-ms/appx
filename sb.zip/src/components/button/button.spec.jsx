import React from 'react';
import { shallow } from 'enzyme';
import Button from 'src/components/button/button';
import Touchable from 'src/components/touchable/touchable';
import Loader from 'src/components/loader/loader';

describe('src/components/button/button', () => {
    it('renders successfully', () => {
        const children = <span/>;
        const wrapper = shallow(<Button>{children}</Button>);
        expect(wrapper.contains(children)).toBe(true);
    });

    it('accepts a title property', () => {
        const wrapper = shallow(<Button title="title_1"> - </Button>);
        expect(wrapper.prop('title')).toEqual('title_1');
    });

    it('is wrapped by <Touchable/> component if it has an onTap prop', () => {
        const wrapper = shallow(<Button onTap={function() {}}/>);
        expect(wrapper.find(Touchable).length).toEqual(1);
        expect(wrapper.find(Touchable).prop('isEnabled')).toEqual(true);
    });

    it('is wrapped by <Touchable/> component if it has an onDoubleTap prop', () => {
        const wrapper = shallow(<Button onDoubleTap={function() {}}/>);
        expect(wrapper.find(Touchable).length).toEqual(1);
        expect(wrapper.find(Touchable).prop('isEnabled')).toEqual(true);
    });

    it('passes on its isEnabled prop to Touchable', () => {
        const wrapper = shallow(<Button onTap={function() {}} isEnabled={false}/>);
        expect(wrapper.find(Touchable).prop('isEnabled')).toEqual(false);
    });

    describe('Button with Loader', () => {
        it('render a loader when isWaiting prop is passed', () => {
            const wrapper = shallow(<Button isWaiting/>);
            expect(wrapper.find(Loader).length).toEqual(1);
        });

        it('render a loader with no delay when isInstantLoader prop is passed', () => {
            const wrapper = shallow(<Button isWaiting isLoaderInstant/>);
            expect(wrapper.find(Loader).length).toEqual(1);
            expect(wrapper.find(Loader).prop('isInstant')).toEqual(true);
        });

        it('disables <Touchable/> component when isWaiting prop is passed', () => {
            const wrapper = shallow(<Button onTap={function() {}} isWaiting/>);
            expect(wrapper.find(Touchable).length).toEqual(1);
            expect(wrapper.find(Touchable).prop('isEnabled')).toEqual(false);
        });
    });
});
