import PropTypes from 'prop-types';

/**
 * Loader wrapper component to ease consumption in React components.
 */
import React from 'react';
import classNames from 'classnames';
import Localization from 'src/localization';
import AnimationWrapper from './animationWrapper';

/**
 * Loader is a Component that provides generic loader mask.
 * Supports instant mode (do not perfom initial animations).
 * Provides  customization options
 * @see propTypes
 */
function Loader(props) {
    const {
        isAlt,
        isApp,
        isAstroStyle,
        isTranslucent,
        isTransparent,
        size,
        align,
    } = props;

    const loadMaskClasses = classNames('load-mask', {
        'load-mask--alt': isAlt,
        'load-mask--app': isApp,
        'load-mask--astro': isAstroStyle,
        'load-mask--translucent': isTranslucent,
        'load-mask--transparent': isTransparent,
    });

    const loadClasses = classNames('load', `load--${align}`, {
        [`load--${size}`]: size !== 'none',
    });

    return (
        <AnimationWrapper {...props}>
            <div className={loadMaskClasses}>
                <div className={loadClasses} data-loading={Localization.getText('HTML5_Loading')}/>
            </div>
        </AnimationWrapper>
    );
}

/**
 * @property {Object} propTypes              -  props that can be passed to the component
 * @property {string} propTypes.size         -  size of loader ('none', 'lg' or 'xlg')
 * @property {string} propTypes.align        -  alignment of loader ('left', 'right', 'center' or 'inline')
 * @property {bool} propTypes.isVisible      -  is Loader visible
 * @property {bool} propTypes.isAlt          -  sets the '--alt' class
 * @property {bool} propTypes.isApp          -  Sets the '--app' class
 * @property {bool} propTypes.isTranslucent  -  sets the '--translucent' class
 * @property {bool} propTypes.isTransparent  -  sets the '--transparent' class
 * @property {bool} propTypes.isInstant      -  do not perform initial animations
 */
Loader.propTypes = {
    size: PropTypes.oneOf(['none', 'lg', 'xlg']),
    align: PropTypes.oneOf(['left', 'right', 'center', 'inline']),
    isAlt: PropTypes.bool,
    isApp: PropTypes.bool,
    isAstroStyle: PropTypes.bool,
    isTranslucent: PropTypes.bool,
    isTransparent: PropTypes.bool,
};

Loader.defaultProps = {
    size: 'xlg',
    align: 'center',
    isAlt: false,
    isApp: false,
    isAstroStyle: false,
    isTranslucent: false,
    isTransparent: false,
};

export default Loader;
