import PropTypes from 'prop-types';
import React from 'react';
import { VelocityTransitionGroup } from 'velocity-react';
import { detect } from 'openui';
import _ from 'lodash';
import config from 'src/config';

/**
 * Simple wrapper for any component that supports the "isInstant" property.
 * It wraps the component in VelocityTransitionGroup if "isInstant" property is not being passed
 * otherwise it just return the component itself.
 * Compatible with old Spine based code.
 *
 * @param {ReactElement} componentToWrap - component to be wrapped
 * @returns {ReactElement} Wrapped component
 *
 */

/**
 * Check is animation allowed on device
 */
function isAnimationAllowed() {
    return config.isPhoneApp ||
           config.isTabletApp ||
           detect.os.chrome ||
           detect.os.safari ||
           detect.os.moz;
}

function AnimationWrapper(props) {
    const childElement = props.children;

    if (!isAnimationAllowed() || props.isInstant) {
        return props.isVisible ? childElement : null;
    }

    return React.createElement(VelocityTransitionGroup, {
        enter: {
            animation: props.showEffect,
            duration: props.showDuration,
            begin: props.onBeforeShow,
            complete: props.onShow,
        },
        leave: {
            animation: props.hideEffect,
            duration: props.hideDuration,
            begin: props.onBeforeHide,
            complete: props.onHide,
        },
    }, props.isVisible ? childElement : null);
}

/**
 * Note that `delay` is not currently supported as a property - see https://github.com/julianshapiro/velocity/issues/819
 * @property {Object} propTypes                 -  props that can be passed to the component
 * @property {bool} propTypes.isInstant         -  do not perform initial animations
 * @property {string} propTypes.showEffect      -  initial transition
 * @property {string} propTypes.hideEffect      -  end transition
 * @property {number} propTypes.showDuration    -  initinal transition duration
 * @property {number} propTypes.hideDuration    -  end transition duration
 * @property {Function} propTypes.onBeforeShow  -  callback runs before the initial transition started
 * @property {Function} propTypes.onShow        -  callback runs after the initial transition ends
 * @property {Function} propTypes.onBeforeHide  -  callback runs before the end transition starded
 * @property {Function} propTypes.onHide        -  callback runs after the end transition ends
 */
AnimationWrapper.propTypes = {
    isInstant: PropTypes.bool,
    isVisible: PropTypes.bool,
    showEffect: PropTypes.string,
    hideEffect: PropTypes.string,
    showDuration: PropTypes.number,
    hideDuration: PropTypes.number,
    onBeforeShow: PropTypes.func,
    onShow: PropTypes.func,
    onBeforeHide: PropTypes.func,
    onHide: PropTypes.func,
};

AnimationWrapper.defaultProps = {
    isInstant: false,
    isVisible: false,
    showEffect: 'transition.fadeIn',
    hideEffect: 'transition.fadeOut',
    showDuration: 300,
    hideDuration: 300,
    onBeforeShow: _.noop,
    onShow: _.noop,
    onBeforeHide: _.noop,
    onHide: _.noop,
};

AnimationWrapper.displayName = 'AnimationWrapper';

export default AnimationWrapper;
