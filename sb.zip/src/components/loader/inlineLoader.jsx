import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import AnimationWrapper from './animationWrapper';

/**
 * InlineLoader is a Component that exposes a simple inline loading indicator.
 * Supports instant mode (do not perfom initial animations).
 * Size can be customized.
 * @see propTypes
 */
function InlineLoader(props) {
    const classes = classNames('load', 'load--inline', `load--${props.size}`);
    return (
        <AnimationWrapper {...props}>
            <div className={classes}/>
        </AnimationWrapper>
    );
}

/**
 * @property {Object} propTypes          -  props that can be passed to the component
 * @property {string} propTypes.size     -  size of loader ('none', 'lg' or 'xlg')
 * @property {bool} propTypes.isInstant  -  do not perform initial animations
 */
InlineLoader.propTypes = {
    size: PropTypes.oneOf(['none', 'lg', 'xlg']),
};

export default InlineLoader;
