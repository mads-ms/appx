import React from 'react';
import { mount } from 'enzyme';
import { VelocityTransitionGroup } from 'velocity-react';
import Loader from 'src/components/loader/loader';

describe('src/components/loader/loader', () => {
    describe('isVisible', () => {
        it('should render when isVisible is set', () => {
            const wrapper = mount(<Loader isVisible/>);
            expect(wrapper.find('.load-mask').length).toEqual(1);
        });

        it('should not render when isVisible is false', () => {
            const wrapper = mount(<Loader/>);
            expect(wrapper.find('.load-mask').length).toEqual(0);
        });

        it('should not render when isVisible is false in instant mode', () => {
            const wrapper = mount(<Loader isInstant/>);
            expect(wrapper.find('.load-mask').length).toEqual(0);
        });
    });

    describe('isInstant', () => {
        it('supports isInstant', () => {
            const wrapper = mount(<Loader isVisible isInstant/>);
            expect(wrapper.find(VelocityTransitionGroup).length).toEqual(0);
        });

        it('runs the animation by default', () => {
            const wrapper = mount(<Loader isVisible/>);
            expect(wrapper.find(VelocityTransitionGroup).length).toEqual(1);
        });
    });

    describe('.load-mask', () => {
        it('renders successfully', () => {
            const wrapper = mount(<Loader isVisible/>);
            expect(wrapper.find('.load-mask').length).toEqual(1);
        });

        it('supports isAlt property', () => {
            const wrapper = mount(<Loader isVisible isAlt/>);
            expect(wrapper.find('.load-mask--alt').length).toEqual(1);
        });

        it('supports isTranslucent property', () => {
            const wrapper = mount(<Loader isVisible isTranslucent/>);
            expect(wrapper.find('.load-mask--translucent').length).toEqual(1);
        });

        it('supports isTransparent property', () => {
            const wrapper = mount(<Loader isVisible isTransparent/>);
            expect(wrapper.find('.load-mask--transparent').length).toEqual(1);
        });

        it('supports isApp property', () => {
            const wrapper = mount(<Loader isVisible isApp/>);
            expect(wrapper.find('.load-mask--app').length).toEqual(1);
        });
    });

    describe('.load', () => {
        it('renders successfully', () => {
            const wrapper = mount(<Loader isVisible/>);
            expect(wrapper.find('.load').length).toEqual(1);
        });

        describe('size', () => {
            it('support lg size', () => {
                const wrapper = mount(<Loader isVisible size="lg"/>);
                expect(wrapper.find('.load--lg').length).toEqual(1);
            });

            it('support xlg size', () => {
                const wrapper = mount(<Loader isVisible size="xlg"/>);
                expect(wrapper.find('.load--xlg').length).toEqual(1);
            });

            it('none does not set the class', () => {
                const wrapper = mount(<Loader isVisible size="none"/>);
                expect(wrapper.find('.load--none').length).toEqual(0);
            });
        });

        describe('align', () => {
            it('support left align', () => {
                const wrapper = mount(<Loader isVisible align="left"/>);
                expect(wrapper.find('.load--left').length).toEqual(1);
            });

            it('support right align', () => {
                const wrapper = mount(<Loader isVisible align="right"/>);
                expect(wrapper.find('.load--right').length).toEqual(1);
            });

            it('support center align', () => {
                const wrapper = mount(<Loader isVisible align="center"/>);
                expect(wrapper.find('.load--center').length).toEqual(1);
            });

            it('support inline align', () => {
                const wrapper = mount(<Loader isVisible align="inline"/>);
                expect(wrapper.find('.load--inline').length).toEqual(1);
            });
        });

        describe('callbacks', () => {
            it('should run onBeforeShow callback', () => {
                const spy = jasmine.createSpy('onBeforeShow');
                mount(<Loader isVisible onBeforeShow={spy}/>);

                VelocityTransitionGroup.callAllBegins();

                expect(spy).toHaveBeenCalled();
            });

            it('should run onShow callback', () => {
                const spy = jasmine.createSpy('onShow');
                mount(<Loader isVisible onShow={spy}/>);

                VelocityTransitionGroup.callAllCompletes();

                expect(spy).toHaveBeenCalled();
            });

            it('should run onBeforeHide callback', () => {
                const spy = jasmine.createSpy('onBeforeHide');
                mount(<Loader isVisible onBeforeHide={spy}/>);

                VelocityTransitionGroup.callAllBegins();

                expect(spy).toHaveBeenCalled();
            });

            it('should run onHide callback', () => {
                const spy = jasmine.createSpy('onHide');
                mount(<Loader isVisible onHide={spy}/>);

                VelocityTransitionGroup.callAllCompletes();

                expect(spy).toHaveBeenCalled();
            });
        });
    });
});
