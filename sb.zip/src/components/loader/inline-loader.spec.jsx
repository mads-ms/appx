import React from 'react';
import { mount } from 'enzyme';
import InlineLoader from 'src/components/loader/inlineLoader';
import { VelocityTransitionGroup } from 'velocity-react';

describe('src/components/loader/inlineLoader', () => {
    describe('isVisible', () => {
        it('renders successfully', () => {
            const wrapper = mount(<InlineLoader isVisible/>);
            expect(wrapper.find('.load--inline').length).toEqual(1);
        });

        it('should not render when isVisible is false', () => {
            const wrapper = mount(<InlineLoader/>);
            expect(wrapper.find('.load--inline').length).toEqual(0);
        });
    });

    describe('isInstant', () => {
        it('supports isInstant', () => {
            const wrapper = mount(<InlineLoader isVisible isInstant/>);
            expect(wrapper.find(VelocityTransitionGroup).length).toEqual(0);
        });

        it('runs the animation by default', () => {
            const wrapper = mount(<InlineLoader isVisible/>);
            expect(wrapper.find(VelocityTransitionGroup).length).toEqual(1);
        });
    });

    describe('size', () => {
        it('support lg size', () => {
            const wrapper = mount(<InlineLoader isVisible size="lg"/>);
            expect(wrapper.find('.load--lg').length).toEqual(1);
        });

        it('support xlg size', () => {
            const wrapper = mount(<InlineLoader isVisible size="xlg"/>);
            expect(wrapper.find('.load--xlg').length).toEqual(1);
        });
    });
});
