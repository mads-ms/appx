import React from 'react';

class CarouselItem extends React.PureComponent {

    render() {
        return (
            <div className="grid-cell">
                {this.props.children}
            </div>
        );
    }
}

export default CarouselItem;
