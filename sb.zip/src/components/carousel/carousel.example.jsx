import React from 'react';
import PropTypes from 'prop-types';
import Sheet from 'src/components/sheet/sheet';
import SheetHeader from 'src/components/sheet/sheetHeader';
import SheetBody from 'src/components/sheet/sheetBody';
import Button from 'src/components/button/button';
import Icon from 'src/components/icon/icon';
import { bindHandlers } from 'src/utils/bindHandlers';
import { examplesOf } from 'src/modules/examples/utils';
import Carousel from './carousel';

class DefaultExample extends React.PureComponent {

    constructor() {
        super();

        this.state = {
            step: 0,
        };
    }

    handleBack() {
        this.setState({
            step: Math.max(0, this.state.step - 1),
        });
    }

    handleForward() {
        this.setState({
            step: Math.min(this.state.step + 1, 3),
        });
    }

    render() {
        const { step } = this.state;

        return (
            <Sheet className="grid grid--y grid--fit-fill">
                <SheetHeader className="grid-cell" showClose={false}>
                    <div className="grid grid--space">
                        <Button className="grid-cell" onTap={this.handleBack} isEnabled={step > 0}>
                            <Icon type="back"/>
                        </Button>
                        <Button className="grid-cell" onTap={this.handleForward} isEnabled={step < 3}>
                            <Icon type="fwd"/>
                        </Button>
                    </div>
                </SheetHeader>
                <SheetBody>
                    <Carousel
                        step={step}
                        onAnimationBegin={this.props.onAnimationBegin}
                        onAnimationComplete={this.props.onAnimationComplete}
                    >
                        <div style={{ backgroundColor: '#f00', padding: '10px', height: '100px' }}><h1>Step 0</h1></div>
                        <div style={{ backgroundColor: '#0f0', padding: '10px', height: '100px' }}><h1>Step 1</h1></div>
                        <div style={{ backgroundColor: '#00f', padding: '10px', height: '100px' }}><h1>Step 2</h1></div>
                        <div style={{ backgroundColor: '#000', padding: '10px', height: '100px' }}><h1>Step 3</h1></div>
                    </Carousel>
                </SheetBody>
            </Sheet>
        );
    }
}

DefaultExample.propTypes = {
    onAnimationBegin: PropTypes.func,
    onAnimationComplete: PropTypes.func,
};

const CarouselDefaultExample = bindHandlers(DefaultExample);

export default examplesOf('Carousel')
    .add('Default', ({ action }) => (
        <CarouselDefaultExample
            onAnimationBegin={action('animation begin')}
            onAnimationComplete={action('animation complete')}
        />
    ), 'carousel-default');
