import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import CarouselItem from './carouselItem';
import { bindHandlers } from 'src/utils/bindHandlers';
import { VelocityComponent } from 'velocity-react';

/**
 * Carousel component that allows infinite sections of content that can be navigated to by sliding back and forth.
 *
 * Usage:
 *
 * <Carousel step={this.state.step}>
 *     <div>step 1</div>
 *     <div>step 2</div>
 *     <div>step 3</div>
 *     ...
 * </Carousel>
 */
class Carousel extends React.Component {

    constructor(props) {
        super(props);
        const { step } = props;

        this.state = {
            prevStep: step,
            nextStep: step,
            currentAnimation: null,
        };
    }

    componentWillReceiveProps(nextProps) {
        const prevStep = this.props.step;
        const nextStep = nextProps.step;

        if (nextStep === prevStep) {
            return;
        }

        let currentAnimation;
        let currentStyle = this.state.currentStyle;

        if (this.state.currentAnimation) {
            this.props.onAnimationComplete();
        }

        if (nextStep > prevStep) {
            // Velocity compares the animation by props value, add step property
            // to force animation run
            currentAnimation = { translateX: ['-50%', '0%'], step: nextStep };
            currentStyle = { transform: 'translateX(0%)' };
        } else {
            currentAnimation = { translateX: ['0%', '-50%'], step: nextStep };
            currentStyle = { transform: 'translateX(-50%)' };
        }

        this.setState({
            prevStep,
            nextStep,
            currentStyle,
        }, () => {
            this.setState({
                currentAnimation,
            });
        });
    }

    handleAnimationBegin() {
        this.props.onAnimationBegin();
    }

    handleAnimationComplete() {
        const { step } = this.props;

        this.setState({
            prevStep: step,
            nextStep: step,
            currentStyle: null,
            currentAnimation: null,
        }, () => {
            this.setState({
                currentStyle: { transform: 'translateX(0%)' },
            });
            this.props.onAnimationComplete();
        });
    }

    render() {
        const { prevStep, nextStep, currentStyle, currentAnimation } = this.state;
        const children = React.Children.toArray(this.props.children);
        const className = classNames('grid grid--double', this.props.className);

        if (nextStep < 0 || nextStep >= children.length) {
            throw new Error(`Step ${nextStep} is out of range - you only have ${children.length} children`);
        }

        const prevChild = children[prevStep];
        const nextChild = children[nextStep];

        let firstSlide;
        let secondSlide;

        if (nextStep > prevStep) {
            firstSlide = <CarouselItem key={prevStep}>{prevChild}</CarouselItem>;
            secondSlide = <CarouselItem key={nextStep}>{nextChild}</CarouselItem>;
        } else if (nextStep < prevStep) {
            firstSlide = <CarouselItem key={nextStep}>{nextChild}</CarouselItem>;
            secondSlide = <CarouselItem key={prevStep}>{prevChild}</CarouselItem>;
        } else {
            firstSlide = <CarouselItem key={nextStep}>{nextChild}</CarouselItem>;
            secondSlide = <CarouselItem/>;
        }

        return (
            /* eslint-disable react/jsx-handler-names */
            <VelocityComponent
                duration={this.props.duration}
                animation={currentAnimation}
                begin={this.handleAnimationBegin}
                complete={this.handleAnimationComplete}
            >
                <div className={className} style={currentStyle}>
                    {firstSlide}
                    {secondSlide}
                </div>
            </VelocityComponent>);
    }
}

Carousel.propTypes = {
    componentId: PropTypes.string,
    step: PropTypes.number,
    duration: PropTypes.number,
    className: PropTypes.string,
    onAnimationBegin: PropTypes.func,
    onAnimationComplete: PropTypes.func,
};

Carousel.defaultProps = {
    step: 0,
    duration: 200,
    onAnimationBegin: _.noop,
    onAnimationComplete: _.noop,
};

export default bindHandlers(Carousel);
