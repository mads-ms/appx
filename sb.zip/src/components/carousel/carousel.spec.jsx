import React from 'react';
import Carousel from './carousel';
import { mount, shallow } from 'enzyme';
import { VelocityComponent } from 'velocity-react';

describe('src/components/carousel/carousel', () => {
    describe('Carousel', () => {

        let wrapper;

        afterEach(() => {
            wrapper.unmount();

            VelocityComponent.callAllBegins();
            VelocityComponent.callAllCompletes();

        });

        it('renders successfully', () => {
            wrapper = mount(
                <Carousel step={0}>
                    <div className="step0"/>
                    <div className="step1"/>
                    <div className="step2"/>
                </Carousel>
            );

            expect(wrapper.find(Carousel).length).toEqual(1);
            expect(wrapper.find('.step0').length).toEqual(1);
        });

        it('mounts only current step', () => {
            wrapper = mount(
                <Carousel step={2}>
                    <div className="step0"/>
                    <div className="step1"/>
                    <div className="step2"/>
                </Carousel>
            );

            expect(wrapper.find('.step0').length).toEqual(0);
            expect(wrapper.find('.step1').length).toEqual(0);
            expect(wrapper.find('.step2').length).toEqual(1);
        });

        it('should change step', () => {
            wrapper = mount(
                <Carousel step={0}>
                    <div className="step0"/>
                    <div className="step1"/>
                    <div className="step2"/>
                </Carousel>
            );

            wrapper.setProps({ step: 1 });

            VelocityComponent.callAllBegins();
            VelocityComponent.callAllCompletes();

            wrapper.update();

            expect(wrapper.find('.step0').length).toEqual(0);
            expect(wrapper.find('.step1').length).toEqual(1);

            wrapper.setProps({ step: 0 });

            VelocityComponent.callAllBegins();
            VelocityComponent.callAllCompletes();

            wrapper.update();

            expect(wrapper.find('.step0').length).toEqual(1);
            expect(wrapper.find('.step1').length).toEqual(0);
        });

        it('should call animation callbacks', () => {
            const beginSpy = jasmine.createSpy('begin');
            const completeSpy = jasmine.createSpy('complete');

            wrapper = mount(
                <Carousel
                    step={0}
                    onAnimationBegin={beginSpy}
                    onAnimationComplete={completeSpy}
                >
                    <div className="step0"/>
                    <div className="step1"/>
                    <div className="step2"/>
                </Carousel>
            );

            wrapper.setProps({ step: 1 });

            VelocityComponent.callAllBegins();
            VelocityComponent.callAllCompletes();

            expect(beginSpy).toHaveBeenCalledTimes(1);
            expect(completeSpy).toHaveBeenCalledTimes(1);
        });

        it('should throw if step is out of range', () => {
            expect(() => {
                shallow(
                    <Carousel step={-1}>
                        <div className="step0"/>
                        <div className="step1"/>
                        <div className="step2"/>
                    </Carousel>
                );
            }).toThrowError();

            expect(() => {
                shallow(
                    <Carousel step={3}>
                        <div className="step0"/>
                        <div className="step1"/>
                        <div className="step2"/>
                    </Carousel>
                );
            }).toThrowError();
        });
    });
});

