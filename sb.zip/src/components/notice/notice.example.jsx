import React from 'react';
import Notice from './notice';
import { examplesOf } from 'src/modules/examples/utils';

export default examplesOf('Notice')
    .add('Default', () => (
        <Notice message="Notice message"/>
    ))
    .add('Title', () => (
        <Notice
            message="Notice message"
            title="Title"
        />
    ))
    .add('Custom Icon', () => (
        <Notice
            message="Notice message"
            iconClassName="icon--checkmark"
        />
    ))
    .add('Tap', ({ action }) => (
        <Notice
            message="Notice message"
            onTap={action('tap')}
        />
    ))
    .add('Try Again', ({ action }) => (
        <Notice
            message="Notice message"
            onTryAgain={action('try again')}
        />
    ))
    .add('Astro Style 🚀', () => (
        <Notice
            message="Notice message"
            isAstroStyle
        />
    ));
