import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import Localization from 'src/localization';
import Touchable from 'src/components/touchable/touchable';
import Button from 'src/components/button/button';

export default function Notice(props) {
    const {
        className,
        iconClassName,
        title,
        message,
        isMask,
        isAstroStyle,
        isCompact,
        isCover,
        onTryAgain,
        onTap,
    } = props;

    const classes = classNames('notice', {
        'grid': !isCover,
        'notice--cover': isCover,
        'notice--mask': isMask,
        'notice--astro': isAstroStyle,
        'notice--compact': isCompact,
    });

    // parse message if it is an array
    const formattedMessage = _.isArray(message) ?
        _.map(message, (msg) => (
            <p key={msg}>{msg}</p>
        )) : <p>{message}</p>;

    const notice = (
        <div className={classes}>
            <div className={classNames('grid grid--y grid--grail grid--series', className)}>
                <div className={classNames('notice-body icon grid-cell', iconClassName || 'icon--warn')}>
                    {title &&
                        <h2 className="h2">{title}</h2>
                    }
                    {formattedMessage}
                </div>
                {onTryAgain &&
                    <div className="grid-cell g--fit">
                        <Button
                            onTap={onTryAgain}
                            className="btn--primary btn--wide"
                        >
                            {Localization.getText('HTML5_TryAgain')}
                        </Button>
                    </div>
                }
            </div>
        </div>
    );

    if (onTap) {
        return (
            <Touchable onTap={onTap}>
                {notice}
            </Touchable>
        );
    }

    return notice;
}

Notice.propTypes = {
    title: PropTypes.string,
    message: PropTypes.oneOfType([PropTypes.string, PropTypes.array]),
    className: PropTypes.string,
    iconClassName: PropTypes.string,
    isMask: PropTypes.bool,
    isAstroStyle: PropTypes.bool,
    isCompact: PropTypes.bool,
    isCover: PropTypes.bool,
    onTryAgain: PropTypes.func,
    onTap: PropTypes.func,
};
