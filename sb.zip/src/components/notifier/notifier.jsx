import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import Dialog from 'src/components/dialog/dialog';
import Touchable from 'src/components/touchable/touchable';
import Button from 'src/components/button/button';
import Localization from 'src/localization';
import Icon from 'src/components/icon/icon';

export default function Notifier({ onHide, onNotificationTap, message }) {
    return (
        <Dialog onHide={onHide} type="card" showUnderlay={false}>
            <Touchable onTap={onNotificationTap}>
                <div className="status status--warning">
                    <div className="status-msg">{message}</div>
                    <Button onTap={onHide} className="status-close btn--inline btn--clear" title={Localization.getText('Close')}>
                        <Icon type="close"/>
                    </Button>
                </div>
            </Touchable>
        </Dialog>
    );
}

Notifier.propTypes = {
    message: PropTypes.string,
    onHide: PropTypes.func,
    onNotificationTap: PropTypes.func,
};

Notifier.defaultProps = {
    onHide: _.noop,
    onNotificationTap: _.noop,
};
