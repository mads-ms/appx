import React from 'react';
import { shallow } from 'enzyme';
import RadioButton from '../../../src/components/radioButton/radioButton';

describe('src/components/radioButton', () => {

    it('has a spare whitespace for compatibility with OpenCSS specs and Spine component', () => {
        const wrapper = shallow(<RadioButton>{'Test'}</RadioButton>);

        expect(wrapper.find('.radio').text()).toEqual('<Icon /> Test');
    });
});
