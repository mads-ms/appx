import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import Icon from 'src/components/icon/icon';
import { bindHandlers } from 'src/utils/bindHandlers';
import classNames from 'classnames';

class RadioButton extends React.Component {

    handleChange() {
        this.props.onChange(this.props.value);
    }

    render() {
        const { children, radioFamily, isChecked, value, className } = this.props;
        const classes = classNames('radio form-label', className);

        return (
            <div className="grid-cell">
                <label className={classes}>
                    <input
                        onChange={this.handleChange}
                        type="radio"
                        name={radioFamily}
                        checked={isChecked}

                        // Add a stringified version of the value for automated testing.
                        // If the value ever doesn't stringify well, we will have to add a new testValue prop
                        value={String(value)}
                    />
                    <Icon type="dot" className="radio-icon"/>
                    {

                    // Explicit space added for backwards compatibility with OpenCSS and all Spine views
                    // that render a spare white space. Remove once everything is moved to React.
                    }
                    {' '}{children}
                </label>
            </div>
        );
    }
}

RadioButton.propTypes = {
    value: PropTypes.any.isRequired,

    // The following are required but added by radioButtonGroup, so are not isRequired
    // to stop warnings on the first creation.
    radioFamily: PropTypes.string,
    isChecked: PropTypes.bool,
    onChange: PropTypes.func,
    className: PropTypes.string,
};

RadioButton.defaultProps = {
    onChange: _.noop,
};

export default bindHandlers(RadioButton);
