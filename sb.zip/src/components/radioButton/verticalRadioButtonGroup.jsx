import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';

function VerticalRadioButtonGroup(props) {
    const {
        className,
        children,
        radioFamily,
        onChange,
        value,
    } = props;

    const childrenWithExtraProps = React.Children.map(children, (radioButton) =>
        React.cloneElement(radioButton, {
            radioFamily,
            isChecked: value === radioButton.props.value,
            onChange,
        })
    );

    return (
        <div className={classNames(className, 'grid grid--y grid--fit-all')}>
            {childrenWithExtraProps}
        </div>
    );
}

VerticalRadioButtonGroup.propTypes = {
    radioFamily: PropTypes.string.isRequired,
    value: PropTypes.any.isRequired,
    onChange: PropTypes.func.isRequired,
    className: PropTypes.string,
};

export default VerticalRadioButtonGroup;
