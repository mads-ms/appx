import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';

function RadioButtonGroup(props) {

    const { groupLabel, disclaimer, className, children, radioFamily, onChange, value, isAstroStyle, isOnboardingMode } = props;
    const classes = classNames('form-group form-group--wrap', className, {
        'form-group--compact': isOnboardingMode,
        'form-group--alt': !isAstroStyle,
        'form-group--astro': isAstroStyle,
    });

    const childrenWithExtraProps = React.Children.map(children, (radioButton) =>
        React.cloneElement(radioButton, {
            radioFamily,
            isChecked: value === radioButton.props.value,
            onChange,
        })
    );

    return (
        <div className={classes}>
            <label className={classNames('form-label', { 'onboard-form-label': isOnboardingMode })}>{groupLabel}</label>
            <div className={classNames('form-value', { 'onboard-form-value': isOnboardingMode })}>
                <div className="grid grid--series grid--fit-all">
                    {childrenWithExtraProps}
                </div>
            </div>
            {disclaimer}
        </div>
    );
}

RadioButtonGroup.propTypes = {
    isAstroStyle: PropTypes.bool,
    isOnboardingMode: PropTypes.bool,
    groupLabel: PropTypes.string.isRequired,
    radioFamily: PropTypes.string.isRequired,
    disclaimer: PropTypes.element,
    className: PropTypes.string,
    value: PropTypes.any.isRequired,
    onChange: PropTypes.func.isRequired,
};

RadioButtonGroup.defaultProps = {
    isAstroStyle: false,
    isOnboardingMode: false,
};

export default RadioButtonGroup;
