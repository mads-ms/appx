import React from 'react';
import PropTypes from 'prop-types';
import * as numberFormat from 'src/numberFormat';

function FormattedNumber(props) {
    const { children, decimals } = props;
    const formattedChildren = numberFormat.format(children, decimals);

    return <span className="t-num">{formattedChildren}</span>;
}

FormattedNumber.propTypes = {
    decimals: PropTypes.number.isRequired,
    children: PropTypes.number.isRequired,
};

export default FormattedNumber;
