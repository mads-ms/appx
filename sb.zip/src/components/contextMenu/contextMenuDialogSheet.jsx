import _ from 'lodash';
import Localization from 'src/localization';
import React from 'react';
import PropTypes from 'prop-types';
import InstrumentSingle from 'src/components/instrument/instrumentSingle';
import InstrumentSecondaryInfo from 'src/components/instrument/instrumentSecondaryInfo';
import Sheet from 'src/components/sheet/sheet';
import SheetHeader from 'src/components/sheet/sheetHeader';
import SheetBody from 'src/components/sheet/sheetBody';

export default function ContextMenuDialog(props) {
    const { isDisplayedWhenNoActions, menuItems, actionsData, onAction, loadingActionId } = props;

    const { instrument, optionData } = actionsData;
    const hasMenuItems = _.size(menuItems) !== 0;

    return (
        <Sheet className="tst-context-menu contextmenu grid grid--y grid--fit-fill">
            {actionsData.instrument &&
                <SheetHeader className="grid-cell" showClose={false}>
                    <div className="grid grid--main-center grid--series">
                        <div className="grid-cell">
                            <InstrumentSingle
                                className="grid--main-center"
                                instrument={instrument.openApiInstrumentData}
                            />
                        </div>
                        {optionData &&
                            <div className="grid-cell">
                                <InstrumentSecondaryInfo
                                    instrument={instrument.openApiInstrumentData}
                                    optionData={optionData}
                                />
                            </div>}
                    </div>
                </SheetHeader>}
            <SheetBody className="grid grid--scroll">
                {!hasMenuItems && isDisplayedWhenNoActions &&
                    <p className="g-cell t-center g--fill">
                        {Localization.getText('HTML5_NoActionsAvailable')}
                    </p>
                }
                {hasMenuItems &&
                <ul className="grid-cell list list--lines">
                    {_.map(menuItems, (menuItem) => React.cloneElement(
                        menuItem, {
                            actionData: actionsData,
                            isLoading: menuItem.props.action.id === loadingActionId,
                            onAction })
                    )}
                </ul>
                }
            </SheetBody>
        </Sheet>
    );
}

ContextMenuDialog.propTypes = {
    isDisplayedWhenNoActions: PropTypes.bool,
    loadingActionId: PropTypes.string,
    actionsData: PropTypes.object.isRequired,
    menuItems: PropTypes.arrayOf(PropTypes.element).isRequired,
    onAction: PropTypes.func.isRequired,
};
