import React from 'react';
import { ContextMenu, ContextMenuItem, MenuItems, MenuTarget } from './';
import Button from 'src/components/button/button';
import { mount } from 'enzyme';
import { tap, rightclick, doubletap } from 'test/mocks/touchableHelper';

describe('src/components/contextMenu/contextMenu', () => {
    describe('ContextMenu', () => {

        let wrapper;
        let handleMenuTrigger;
        let cachedHandleMenuTrigger;

        beforeEach(() => {
            cachedHandleMenuTrigger = ContextMenu.prototype.handleMenuTrigger;
            handleMenuTrigger = spyOn(ContextMenu.prototype, 'handleMenuTrigger');
        });

        afterEach(() => {
            ContextMenu.prototype.handleMenuTrigger = cachedHandleMenuTrigger;
            wrapper.unmount();
        });

        it('renders successfully', () => {
            wrapper = mount(
                <ContextMenu>
                    <MenuItems>
                        <ContextMenuItem action={{ id: '1', label: 'Action 1' }}/>
                        <ContextMenuItem action={{ id: '2', label: 'Action 2' }}/>
                    </MenuItems>
                    <MenuTarget>
                        <Button>Right click me!</Button>
                    </MenuTarget>
                </ContextMenu>
            );

            expect(wrapper.find(ContextMenu).length).toEqual(1);
            expect(wrapper.find(Button).length).toEqual(1);
            rightclick(wrapper.find('.btn'));

            expect(handleMenuTrigger).toHaveBeenCalled();
        });

        it('renders successfully with custom trigger', () => {
            wrapper = mount(
                <ContextMenu triggerEvent="tap">
                    <MenuItems>
                        <ContextMenuItem action={{ id: '1', label: 'Action 1' }}/>
                        <ContextMenuItem action={{ id: '2', label: 'Action 2' }}/>
                    </MenuItems>
                    <MenuTarget>
                        <Button>Right click me!</Button>
                    </MenuTarget>
                </ContextMenu>
            );

            expect(wrapper.find(ContextMenu).length).toEqual(1);
            expect(wrapper.find(Button).length).toEqual(1);

            tap(wrapper.find('.btn'));
            expect(handleMenuTrigger).toHaveBeenCalledTimes(1);
            expect(handleMenuTrigger).toHaveBeenCalledWith(jasmine.objectContaining({
                type: 'tap',
            }));

            wrapper.setProps({
                triggerEvent: 'doubleTap',
            });

            doubletap(wrapper.find('.btn'));
            expect(handleMenuTrigger).toHaveBeenCalledTimes(2);
            expect(handleMenuTrigger).toHaveBeenCalledWith(jasmine.objectContaining({
                type: 'doubletap',
            }));
        });
    });
});
