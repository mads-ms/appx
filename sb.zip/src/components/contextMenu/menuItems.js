/**
 * See ContextMenu component for usage details.
 */
import PropTypes from 'prop-types';

const MenuItems = () => false;

MenuItems.propTypes = {
    // Whether the menu items are enabled
    isEnabled: PropTypes.bool,

    // Shows menu items only when trigger happened on an element
    // with a given class
    targetClassName: PropTypes.string,

    // Data associated with this menu items
    actionsData: PropTypes.object,

    // Data function that returns data associated with this menu items,
    // receives actionsData and $target (only when targetClassName was defined)
    onGetActionsData: PropTypes.func,
};

MenuItems.defaultProps = {
    isEnabled: true,
};

export default MenuItems;
