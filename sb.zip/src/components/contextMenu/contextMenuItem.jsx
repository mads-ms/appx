import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import Loader from 'src/components/loader/loader';
import Touchable from 'src/components/touchable/touchable';
import classNames from 'classnames';
import { bindHandlers } from 'src/utils/bindHandlers';

class ContextMenuItem extends React.PureComponent {

    handleOnTap() {
        const { action, actionData, onAction, isLoading } = this.props;
        if (isLoading) {
            return;
        }
        onAction(action, actionData);
    }

    // After removing spine contextMenu move getContent to render
    getContent(action, isLoading) {
        return [
            action.label,
            isLoading &&
                <Loader
                    key="loader"
                    isVisible
                    isTransparent
                    size="none"
                    align="right"
                />,
        ];
    }

    render() {
        const { action, isLoading, inSpine } = this.props;
        const { id } = action;

        // After removing spine contextMenu move getContent to render
        if (inSpine) {
            return this.getContent(action, isLoading);
        }

        const classes = classNames('list-item', `tst-${id}`);
        return (
            <Touchable onTap={this.handleOnTap}>
                <li className={classes} key={id}>
                    {this.getContent(action, isLoading)}
                </li>
            </Touchable>
        );
    }
}

ContextMenuItem.propTypes = {
    inSpine: PropTypes.bool,
    isEnabled: PropTypes.bool,
    isLoading: PropTypes.bool,
    action: PropTypes.shape({
        id: PropTypes.string.isRequired,
        label: PropTypes.string.isRequired,
        loadAction: PropTypes.func,
        performAction: PropTypes.func,
    }).isRequired,
    actionData: PropTypes.object,
    onAction: PropTypes.func,
};

ContextMenuItem.defaultProps = {
    isEnabled: true,
    onAction: _.noop,

    // After removing spine contextMenu this will disappear
    inSpine: false,
};

export default bindHandlers(ContextMenuItem);
