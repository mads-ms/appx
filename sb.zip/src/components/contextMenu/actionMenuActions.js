/* eslint max-lines: "off" */
import _ from 'lodash';
import { UI } from 'openui';
import config from 'src/config';
import Localization from 'src/localization';
import getStore from 'src/store';
import connectPromise from 'src/utils/connectPromise';

import Spine from 'spineAll';
import Enums from 'src/spine/enums';
import Account from 'src/spine/models/account';

import * as globalActions from 'src/modules/globals/actions';
import * as positionTradesActions from 'src/modules/positionTrades/actions';
import * as positionDetailsActions from 'src/modules/positionDetails/actions';
import * as perfLoggingActions from 'src/modules/perfLog/actions';
import * as perfLogConstants from 'src/modules/perfLog/constants';
import * as watchlistsModuleSelectors from 'src/modules/watchlists/watchlistsModuleSelectors';
import watchlistComponentId from 'src/modules/watchlists/watchlistComponentId';
import modules from 'src/modules/workspace/modules';
import * as moduleTypes from 'src/modules/workspace/moduleTypes';
import * as instrumentsUtils from 'src/modules/instruments/utils';
import * as tradingConditionsActions from 'src/modules/tradingConditions/actions';
import * as tradingConditionsSelectors from 'src/modules/tradingConditions/selectors';
import * as accountsSelectors from 'src/modules/accounts/selectors';
import * as instrumentSelectors from 'src/modules/instruments/selectors';
import * as workspaceDialogsActions from 'src/modules/workspace/actions/workspaceDialogsActions';

export const ACTION_SHOW_MORE = {
    id: 'showMore',
    icon: 'icon--add',
    label: Localization.getText('More'),
    performAction(actionData) {
        if (actionData.showAllActions) {
            actionData.showAllActions();
        } else if (actionData.instrument && actionData.target) {
            actionData.onMenuShow(actionData.target, actionData.instrument);
        }
    },
};

export const ACTION_TRADE = {
    id: 'trade',
    icon: 'icon--trade',
    label: Localization.getText('HTML5_Trade'),
    performAction(actionData) {
        if (actionData.instrument) {
            getStore().dispatch(globalActions.showTradeTicket({
                uic: actionData.instrument.uic,
                instrumentType: actionData.instrument.instrumentType,
                putCall: actionData.putCall,
                saveCurrentTicketData: false,
            }));
        }
    },
    isAllowed(actionData) {
        return actionData.instrument && actionData.instrument.isPreferred && actionData.instrument.isPreferred() &&
            Account.canTradeInstrumentType(actionData.instrument.instrumentType) && actionData.instrument.isTradable;
    },
};

export const ACTION_CHART = {
    id: 'chart',
    icon: 'icon--charts',
    label: Localization.getText('Chart'),
    performAction(actionData) {
        if (actionData.instrument) {
            Spine.trigger('do:setChartInstrument', actionData.instrument);
            Spine.Route.navigate('/charts/');
        }
    },
    isAllowed(actionData) {
        return actionData.instrument && actionData.instrument.isChartSupported && actionData.instrument.isChartSupported();
    },
};

export const ACTION_ALERT_ADD = {
    id: 'alertadd',
    icon: 'icon--addalert',
    label: Localization.getText('HTML5_PriceAlerts_Context_Add'),
    shortLabel: Localization.getText('HTML5_AddAlert'),
    loadAction(actionData) {
        if (actionData.instrument) {
            return modules[moduleTypes.PRICE_ALERT_SHEET].fetch()
                .then((PriceAlertSheet) =>
                    new PriceAlertSheet().createPriceAlertFromInstrumentId(
                        actionData.instrument.uic,
                        actionData.instrument.instrumentType
                    )
                );
        }
        return Promise.resolve();
    },
    performAction(actionData, actionController) {
        actionController.show();
    },
    isAllowed(actionData) {
        return _.invoke(actionData, 'instrument.isPriceAlertsAllowed');
    },
};

export const ACTION_ALERT_EDIT = {
    id: 'alertedit',
    icon: 'icon--edit',
    label: Localization.getText('HTML5_PriceAlerts_Context_Edit'),
    shortLabel: Localization.getText('Edit'),
    performAction(actionData) {
        return modules[moduleTypes.PRICE_ALERT_SHEET].fetch()
            .then((PriceAlertSheet) =>
                new PriceAlertSheet().load(actionData.priceAlert.AlertDefinitionId)
            );
    },
    isAllowed(actionData) {
        return _.get(actionData, 'priceAlert.AlertDefinitionId', false);
    },
};

export const ACTION_ALERT_DELETE = {
    id: 'alertdelete',
    icon: 'icon--delete',
    label: Localization.getText('HTML5_PriceAlerts_Context_Delete'),
    shortLabel: Localization.getText('Delete'),
    performAction(actionData) {
        return modules[moduleTypes.PRICE_ALERT_SHEET].fetch()
            .then((PriceAlertSheet) =>
                new PriceAlertSheet().deletePriceAlert(actionData.priceAlert.AlertDefinitionId)
            );
    },
    isAllowed(actionData) {
        return _.get(actionData, 'priceAlert.AlertDefinitionId', false);
    },
};

export const ACTION_ADD_TO_WATCHLIST = {
    id: 'addtowatchlist',
    icon: 'icon--add',
    label: Localization.getText('HTML5_AddToWatchlist'),
    performAction(actionData) {
        if (actionData.instrument) {
            // add instrument once watchlist module gets activated
            connectPromise((state) => watchlistsModuleSelectors.getIsWatchlistActivated(state, watchlistComponentId) && { isSuccess: true })
                .then(() => {
                    Spine.trigger('do:addToWatchlist', actionData.instrument);
                });
            Spine.Route.navigate('/watchlist/');
        }
    },
    isAllowed(actionData) {
        return watchlistsModuleSelectors.getIsInstrumentAllowedToBeAddedToWatchlist(
            getStore().getState(),
            actionData.instrument,
            watchlistComponentId
        );
    },
};

export const ACTION_REMOVE_FROM_WATCHLIST = {
    id: 'removefromwatchlist',
    icon: 'icon--delete',
    label: Localization.getText('HTML5_RemoveFromWatchlist'),
    shortLabel: Localization.getText('HTML5_Remove'),
    performAction(actionData) {
        if (actionData.instrument) {
            Spine.trigger('do:removeFromWatchlist', instrumentsUtils.getLegacyId(actionData.instrument), actionData.instrument.symbol);
        }
    },
    isAllowed() {
        return true;
    },
};

export const ACTION_CLOSED_POSITION_DETAILS = {
    id: 'closedposdetails',
    icon: 'icon--info',
    label: Localization.getText('Details'),
    loadAction(actionData) {
        if (actionData.closedPositionId) {
            return getStore().dispatch(positionDetailsActions.fetchClosedPositionDetails(
                actionData.closedPositionId,
                actionData.positionAccountId
            ));
        }
        return Promise.resolve();
    },
    performAction: _.noop,
};

export const ACTION_POSITION_DETAILS = {
    id: 'posdetails',
    icon: 'icon--info',
    label: Localization.getText('Details'),
    loadAction(actionData) {
        return modules[moduleTypes.POSITION_DETAILS].fetch()
            .then((PositionDetailsViewController) => {
                const positionId = actionData.isPositionNet ? actionData.position.NetPositionId : actionData.position.PositionId;
                const positionDetails = new PositionDetailsViewController()
                    .on(UI.Events.Hide, (actionController) => {
                        actionController.release();
                    });

                return positionDetails.load({
                    positionId,
                    isNet: actionData.isPositionNet,
                    showGreekInfo: false,
                    accountId: actionData.positionAccountId,
                });
            });
    },
    performAction(actionData, actionController) {
        actionController.show();
    },
    isAllowed(actionData) {
        return actionData.position;
    },
};

export const ACTION_POSITION_ADD_ORDERS = {
    id: 'posaddrelorders',
    icon: 'icon--add',
    label: Localization.getText('HTML5_TakeProfitStopLoss'),
    shortLabel: Localization.getText('Related'),
    performAction(actionData) {
        if (actionData.position) {
            const positionId = (actionData.isPositionNet) ? actionData.position.NetPositionId : actionData.position.PositionId;
            Spine.trigger('do:showAddRelatedOrders', positionId, actionData.isPositionNet);
        }
    },
};

export const ACTION_POSITION_ADD_LIMIT_ORDER = {
    id: 'posaddlimitorder',
    icon: 'icon--add',
    label: Localization.getText('HTML5_AddTakeProfit'),
    performAction(actionData) {
        if (actionData.controller && actionData.position) {
            const netposId = actionData.position.NetPositionId;
            actionData.controller.onAddLimitOrder(netposId);
        }
    },
    isAllowed(actionData) {
        return actionData.controller && actionData.controller.presenter.isRealTimeNettingMode() && actionData.position &&
            actionData.instrument && Account.canTradeInstrumentType(actionData.instrument.instrumentType) &&
            actionData.position.isLimitOrderPossible();
    },
};

export const ACTION_POSITION_ADD_STOP_ORDER = {
    id: 'posaddstoporder',
    icon: 'icon--add',
    label: Localization.getText('HTML5_AddStopLoss'),
    performAction(actionData) {
        if (actionData.controller && actionData.position) {
            const netposId = actionData.position.NetPositionId;
            actionData.controller.onAddStopOrder(netposId);
        }
    },
    isAllowed(actionData) {
        return actionData.controller && actionData.controller.presenter.isRealTimeNettingMode() && actionData.position &&
            actionData.instrument && Account.canTradeInstrumentType(actionData.instrument.instrumentType) &&
            actionData.position.isStopOrderPossible();
    },
};

export const ACTION_POSITION_ADD_OCO = {
    id: 'posaddocoorder',
    icon: 'icon--add',
    label: Localization.getText('HTML5_AddBothOCO'),
    performAction(actionData) {
        if (actionData.controller && actionData.position) {
            const netposId = actionData.position.NetPositionId;
            actionData.controller.onAddOcoOrder(netposId);
        }
    },
    isAllowed(actionData) {
        return actionData.controller && actionData.controller.presenter.isRealTimeNettingMode() && actionData.position &&
            actionData.instrument && Account.canTradeInstrumentType(actionData.instrument.instrumentType) &&
            actionData.position.isLimitOrderPossible() && actionData.position.isStopOrderPossible();
    },
};

export const ACTION_POSITION_EDIT_ORDERS = {
    id: 'poseditrelorders',
    icon: 'icon--edit',
    label: Localization.getText('Edit related orders'),
    shortLabel: Localization.getText('Related'),
    performAction(actionData) {
        if (actionData.position) {
            const positionId = (actionData.isPositionNet) ? actionData.position.NetPositionId : actionData.position.PositionId;
            Spine.trigger('do:showEditRelatedOrders', positionId, actionData.isPositionNet);
        }
    },
};

export const ACTION_POSITION_CLOSE = {
    id: 'posclose',
    icon: 'icon--delete',
    label: Localization.getText('Close Position'),
    shortLabel: Localization.getText('Close'),
    loadAction(actionData) {
        const position = actionData.position;
        const id = position.IUic + '-' + position.ITyp;
        const properties = { instrumentType: position.ITyp };

        getStore().dispatch(perfLoggingActions.cancel(perfLogConstants.OPEN_TRADE_TICKET, id));
        getStore().dispatch(perfLoggingActions.start(perfLogConstants.OPEN_TRADE_TICKET, id, undefined, properties));

        return modules[moduleTypes.CLOSE_POSITION].fetch()
            .then((ClosePositionViewController) => {
                const closePosition = new ClosePositionViewController()
                    .on(UI.Events.Hide, (actionController) => {
                        actionController.release();
                    });

                closePosition.setAppHint(actionData.appHintModuleId);

                return closePosition.load(position.getClosePositionId(), position.isClosePositionNet(), actionData.positionAccountId);
            });
    },
    performAction(actionData, actionController) {
        actionController.show();
    },
    isAllowed(actionsData) {
        return actionsData.position;
    },
};

export const ACTION_POSITION_VIEW_TRADES = {
    id: 'posviewtrades',
    label: Localization.getText('HTML5_ViewTrades'),
    performAction(actionData) {
        if (actionData.position) {
            const {
                PositionsAccount,
                NetPositionId,
            } = actionData.position;

            getStore().dispatch(positionTradesActions.showPositionTradesDialog(actionData.componentId, PositionsAccount, NetPositionId));
        }
    },
    isAllowed(actionData) {
        return actionData.position && actionData.position.PositionsAccount && actionData.isPositionNet && actionData.instrument &&
            actionData.controller.presenter.isRealTimeNettingMode();
    },
};

export const ACTION_POSITION_EXERCISE = {
    id: 'posexercise',
    icon: 'icon--exercise',
    label: Localization.getText('Exercise'),
    loadAction(actionData) {
        return modules[moduleTypes.EXERCISE_POSITION].fetch()
            .then((ExercisePositionViewController) => {
                const exercisePosition = new ExercisePositionViewController()
                    .on(UI.Events.Hide, (actionController) => {
                        actionController.release();
                    });

                return exercisePosition.load(actionData.position, actionData.isPositionNet);
            });
    },
    performAction(actionData, actionController) {
        actionController.show();
    },
    isAllowed(actionData) {
        return actionData.position;
    },
};

export const ACTION_POSITION_EXERCISEAGGREGATE = {
    id: 'posexerciseaggregate',
    icon: 'icon--exercise',
    label: Localization.getText('HTML5_ExerciseAggregate'),
    loadAction(actionData) {
        return modules[moduleTypes.EXERCISE_POSITION].fetch()
            .then((ExercisePositionViewController) => {
                const exercisePosition = new ExercisePositionViewController()
                    .on(UI.Events.Hide, (actionController) => {
                        actionController.release();
                    });

                return exercisePosition.load(actionData.position, actionData.isPositionNet);
            });
    },
    performAction(actionData, actionController) {
        actionController.show();
    },
    isAllowed(actionData) {
        return actionData.position;
    },
};

export const ACTION_POSITION_DELTAHEDGE = {
    id: 'posdeltahedge',
    icon: 'icon--delta',
    label: Localization.getText('Delta Hedge'),
    loadAction(actionData) {
        return modules[moduleTypes.DELTA_HEDGE].fetch()
            .then((DeltaHedgeViewController) => {
                const deltaHedge = new DeltaHedgeViewController()
                    .on(UI.Events.Hide, (actionController) => {
                        actionController.release();
                    });

                return deltaHedge.load({
                    uic: actionData.instrument.uic,
                    type: Enums.InstrumentType.FxVanillaOption,
                    defaultAmount: actionData.position.Amount,
                    hedgePutCall: actionData.instrument.callPut,
                    expiryDate: actionData.instrument.expiryDate,
                    strike: actionData.instrument.strikePrice,
                    accountId: actionData.position.getAccountId(),
                    hedgeLong: actionData.position.Amount > 0,
                    position: actionData.position,
                });
            });
    },
    performAction(actionData, actionController) {
        actionController.show();
    },
    isAllowed(actionData) {
        return actionData.position && actionData.instrument && Account.canTradeInstrumentType(actionData.instrument.instrumentType) &&
            actionData.position.isDeltaHedgeable();
    },
};

export const ACTION_POSITION_GREEKS = {
    id: 'posgreeks',
    icon: 'icon--greeks',
    label: Localization.getText('HTML5_Greek'),
    loadAction(actionData) {
        return modules[moduleTypes.POSITION_DETAILS].fetch()
            .then((PositionDetailsViewController) => {
                const positionId = actionData.isPositionNet ? actionData.position.NetPositionId : actionData.position.PositionId;
                const positionDetails = new PositionDetailsViewController()
                    .on(UI.Events.Hide, (actionController) => {
                        actionController.release();
                    });

                return positionDetails.load({
                    positionId,
                    accountId: actionData.positionAccountId,
                    isNet: actionData.isPositionNet,
                    showGreekInfo: true,
                });
            });
    },
    performAction(actionData, actionController) {
        actionController.show();
    },
    isAllowed(actionData) {
        return actionData.position;
    },
};

export const ACTION_TRADING_CONDITIONS = {
    id: 'tradingconditions',
    label: Localization.getText('HTML5_Trading_Conditions'),
    loadAction(menu) {
        if (menu.instrument) {
            const { dispatch, getState } = getStore();
            const instrumentId = instrumentsUtils.getId(menu.instrument);
            const instrumentData = instrumentSelectors.getDataById(getState(), instrumentId);
            const accountId = _.get(menu, 'accountId', null) ||
                                accountsSelectors.getDefaultAccountIdForInstrument(getState(), instrumentData);
            dispatch(tradingConditionsActions.fetchTradingConditions({
                accountId,
                instrumentId,
            }));
            return tradingConditionsSelectors.getIsReadyPromise();
        }
        return Promise.reject();
    },
    performAction() {
        getStore().dispatch(workspaceDialogsActions.showWorkspaceDialog(moduleTypes.NEW_TRADING_CONDITIONS));
    },
    onError() {
        getStore().dispatch(workspaceDialogsActions.showWorkspaceDialog(moduleTypes.NEW_TRADING_CONDITIONS));
    },
    isAllowed() {
        return config.appFeatures.isTradingConditionsEnabled && !config.isProApp;
    },
};

export const ACTION_ORDER_CANCEL = {
    id: 'ordercancel',
    icon: 'icon--delete',
    label: Localization.getText('Cancel Order'),
    shortLabel: Localization.getText('Cancel'),
    performAction({ order }) {
        if (order) {
            Spine.trigger('do:showCancelOrder', order);
        }
    },
    isAllowed({ order }) {
        return order && order.isCancelOrderAllowed;
    },
};

export const ACTION_ORDER_EDIT = {
    id: 'orderedit',
    icon: 'icon--edit',
    label: Localization.getText('Edit Order'),
    shortLabel: Localization.getText('Edit'),
    performAction({ mainOrder }) {
        if (mainOrder) {
            Spine.trigger('do:showEditOrder', mainOrder);
        }
    },
    isAllowed({ order }) {
        return order && order.isEditOrderAllowed;
    },
};

export const ACTION_ORDER_CHANGETOMARKETORDER = {
    id: 'changetomarketorder',
    icon: 'icon--market',
    label: Localization.getText('HTML5_ChangeToMarket'),
    performAction({ order }) {
        if (order) {
            Spine.trigger('do:showToMarketOrder', order);
        }
    },
    isAllowed(actionData) {
        return actionData.order && actionData.order.isChangeToMarketOrderAllowed;
    },
};

export const ACTION_ORDER_DETAILS = {
    id: 'orderdetails',
    icon: 'icon--info',
    label: Localization.getText('Order Details'),
    shortLabel: Localization.getText('Details'),
    performAction({ order }) {
        if (order) {
            Spine.trigger('do:showOrderDetails', order);
        }
    },
};
