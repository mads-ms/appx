import _ from 'lodash';
import React from 'react';
import { mount } from 'enzyme';
import * as utils from './utils';
import { ContextMenu, ContextMenuItem, MenuItems, MenuTarget } from './index';

describe('utils', () => {

    let wrapper;

    afterEach(() => {
        if (wrapper) {
            wrapper.unmount();
        }
    });

    describe('getMenuTargetFromProps', () => {
        it('should get MenuTarget from component`s props', () => {
            const menuTarget = (
                <MenuTarget>
                    <div></div>
                </MenuTarget>
            );
            wrapper = mount(
                <ContextMenu>
                    <MenuItems>
                        <ContextMenuItem action={{ id: '1', label: 'Action' }}/>
                    </MenuItems>
                    {menuTarget}
                </ContextMenu>
            );

            expect(_.omit(utils.getMenuTargetFromProps(wrapper.props()), 'key')).toEqual(_.omit(menuTarget, 'key'));
        });
    });

    describe('getActions', () => {
        it('should get enabled actions from MenuItems', () => {
            const action2 = { id: '2', label: 'Action 2' };
            wrapper = mount(
                <ContextMenu>
                    <MenuItems isEnabled={false}>
                        <ContextMenuItem action={{ id: '1', label: 'Action 1' }}/>
                    </MenuItems>
                    <MenuItems>
                        <ContextMenuItem action={action2}/>
                    </MenuItems>
                    <MenuTarget>
                        <div target="target"/>
                    </MenuTarget>
                </ContextMenu>
            );
            const wrapperNode = wrapper.getDOMNode();
            const event = {
                target: wrapperNode.getElementsByClassName('target')[0],
            };

            expect(utils.getActions(wrapper.props(), event)).toEqual([action2]);
        });

        it('should set defaults for isAllowed and loadAction', () => {
            const action1 = { id: '1', label: 'Action 1' };
            wrapper = mount(
                <ContextMenu>
                    <MenuItems>
                        <ContextMenuItem action={action1}/>
                    </MenuItems>
                    <MenuTarget>
                        <div target="target"/>
                    </MenuTarget>
                </ContextMenu>
            );
            const wrapperNode = wrapper.getDOMNode();
            const event = {
                target: wrapperNode.getElementsByClassName('target')[0],
            };

            const action = utils.getActions(wrapper.props(), event)[0];
            expect(action.isAllowed()).toEqual(true);
            expect(action.loadAction).toBeDefined();
        });

        it('should try to find target based on targetClassName', () => {
            const innerAction = { id: '1', label: 'Action 1', isAllowed: _.noop, loadAction: _.noop };
            wrapper = mount(
                <ContextMenu>
                    <MenuItems targetClassName="inner">
                        <ContextMenuItem action={innerAction}/>
                    </MenuItems>
                    <MenuItems>
                        <ContextMenuItem action={{ id: '2', label: 'Outer Action' }}/>
                    </MenuItems>
                    <MenuTarget>
                        <div className="outer">
                            <div className="inner">
                                <div className="innerChild"/>
                            </div>
                        </div>
                    </MenuTarget>
                </ContextMenu>
            );
            const wrapperNode = wrapper.getDOMNode();
            const event = {
                target: wrapperNode.getElementsByClassName('innerChild')[0],
            };

            expect(utils.getActions(wrapper.props(), event)[0]).toEqual(innerAction);
        });
    });

    describe('getActionsData', () => {
        it('should get static actionsData if onGetActionsData is not defined', () => {
            const actionsData = { data: 'test' };
            wrapper = mount(
                <ContextMenu actionsData={actionsData}>
                    <MenuItems>
                        <ContextMenuItem action={{ id: '3', label: 'Outer Action' }}/>
                    </MenuItems>
                    <MenuTarget>
                        <div/>
                    </MenuTarget>
                </ContextMenu>
            );

            expect(utils.getActionsData(wrapper.props(), new Event('contextmenu'))).toEqual(actionsData);
        });

        it('should take static data from MenuItems if defined', () => {
            const actionsData = { data: 'test' };
            const menuItemsActionsData = { data: 'menuTest' };
            wrapper = mount(
                <ContextMenu actionsData={actionsData}>
                    <MenuItems actionsData={menuItemsActionsData}>
                        <ContextMenuItem action={{ id: '3', label: 'Outer Action' }}/>
                    </MenuItems>
                    <MenuTarget>
                        <div/>
                    </MenuTarget>
                </ContextMenu>
            );

            expect(utils.getActionsData(wrapper.props(), new Event('contextmenu'))).toEqual(menuItemsActionsData);
        });

        it('should call onGetActionsData if defined and pass static actions data and event target in arguments', () => {
            const contextMenuActionsData = { data: 'test' };
            const handlerActionsData = { data: 'handlerTest' };
            wrapper = mount(
                <ContextMenu actionsData={contextMenuActionsData} onGetActionsData={handleGetActionsData}>
                    <MenuItems>
                        <ContextMenuItem action={{ id: '3', label: 'Outer Action' }}/>
                    </MenuItems>
                    <MenuTarget>
                        <div className="target"/>
                    </MenuTarget>
                </ContextMenu>
            );
            const wrapperNode = wrapper.getDOMNode();
            const event = {
                currentTarget: wrapperNode.getElementsByClassName('target')[0],
            };

            function handleGetActionsData(actionsData, target) {
                expect(actionsData).toEqual(contextMenuActionsData);
                expect(target).toEqual(event.currentTarget);
                return handlerActionsData;
            }

            expect(utils.getActionsData(wrapper.props(), event)).toEqual(handlerActionsData);
        });

        it('should take onGetActionsData from MenuItems if defined', () => {
            const menuItemsActionsData = { data: 'test' };
            const handlerActionsData = { data: 'handlerTest' };
            wrapper = mount(
                <ContextMenu actionsData={{}} onGetActionsData={() => {}}>
                    <MenuItems actionsData={menuItemsActionsData} onGetActionsData={handleMenuGetActionsData}>
                        <ContextMenuItem action={{ id: '3', label: 'Outer Action' }}/>
                    </MenuItems>
                    <MenuTarget>
                        <div className="target"/>
                    </MenuTarget>
                </ContextMenu>
            );
            const wrapperNode = wrapper.getDOMNode();
            const event = {
                currentTarget: wrapperNode.getElementsByClassName('target')[0],
            };

            function handleMenuGetActionsData(actionsData, target) {
                expect(actionsData).toEqual(menuItemsActionsData);
                expect(target).toEqual(event.currentTarget);
                return handlerActionsData;
            }

            expect(utils.getActionsData(wrapper.props(), event)).toEqual(handlerActionsData);
        });

        it('should pass targetClassName element when targetClassName is defined', () => {
            const menuItemsActionsData = { data: 'test' };
            const handlerActionsData = { data: 'handlerTest' };
            wrapper = mount(
                <ContextMenu>
                    <MenuItems targetClassName="inner" actionsData={menuItemsActionsData} onGetActionsData={handleMenuGetActionsData}>
                        <ContextMenuItem action={{ id: '3', label: 'Outer Action' }}/>
                    </MenuItems>
                    <MenuTarget>
                        <div className="outer">
                            <div className="inner">
                                <div className="innerChild"/>
                            </div>
                        </div>
                    </MenuTarget>
                </ContextMenu>
            );
            const wrapperNode = wrapper.getDOMNode();
            const event = {
                target: wrapperNode.getElementsByClassName('innerChild')[0],
            };

            function handleMenuGetActionsData(actionsData, target) {
                expect(actionsData).toEqual(menuItemsActionsData);
                expect(target).toEqual(wrapperNode.getElementsByClassName('inner')[0]);
                return handlerActionsData;
            }

            expect(utils.getActionsData(wrapper.props(), event)).toEqual(handlerActionsData);
        });
    });

    describe('getCoordinates', () => {
        it('should get client coordinates from the event', () => {
            expect(utils.getCoordinates({ clientX: 11, clientY: 12 })).toEqual({ x: 11, y: 12 });
        });

        it('should get gesture center if available', () => {
            expect(utils.getCoordinates({ gesture: { center: { x: 11, y: 12 } } })).toEqual({ x: 11, y: 12 });
        });
    });
});
