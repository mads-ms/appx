/**
 * Temporary action menu item. It does not render anything as ActionMenu is still spine.
 * Once it's refactored it should be a menu item visual component just like ContextMenuItem or SwipeMenuItem.
 */
import PropTypes from 'prop-types';

const ActionMenuItem = () => false;

ActionMenuItem.propTypes = {
    isEnabled: PropTypes.bool,
    action: PropTypes.shape({
        id: PropTypes.string.isRequired,
        label: PropTypes.string.isRequired,
        icon: PropTypes.string,
        loadAction: PropTypes.func,
        performAction: PropTypes.func,
        isAllowed: PropTypes.func,
    }).isRequired,
};

ActionMenuItem.defaultProps = {
    isEnabled: true,
};

export default ActionMenuItem;
