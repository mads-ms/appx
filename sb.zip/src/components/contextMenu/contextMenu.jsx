/**
 * Context menu component.
 *
 * Features:
 *  - disable/enable individual menu items or groups of items
 *  - define onGetActionsData handler on context menu level or menu items level
 *  - set isDisplayedWhenNoActions for displaying context menu event though actions are not available
 *  - use shouldCloseOtherDialogs on context menu level to control all the opened dialogs in App to be closed or not(until spine ContextMenu is used)
 *  - use targetClassName for narrowing the triggering target within the wrapper component
 *    (useful for old Spine components, where you cannot simply wrap a child with a ContextMenu component)
 *  - define multiple menu items, where first that isEnabled or has a matching targetClassName
 *    is used
 *  - uses common menu components (MenuItems and MenuTarget) for defining items and target
 *
 * Usage:
 *
 * import { ContextMenu, ContextMenuItem, MenuItems, MenuTarget } from 'src/components/contextMenu';
 * import * as contextMenuActions from 'src/components/contextMenu/contextMenuActions';
 *
 * handleGetActionsData(actionsData, menuTarget) {
 *     // actionsData (Object)- is the same you set on the ContextMenu, if you don't define onGetActionsData, the component will just use actionsData
 *     // menuTarget (DOM Element) - an element matching targetClassName or event.currentTarget if targetClassName is not defined
 *     return {
 *        ... // data required by actions
 *        instrument: this.props.selectedInstrument,
 *     }
 * }
 *
 * <ContextMenu
 *      actionsData={{ instrument }}
 *      onGetActionsData={this.handleGetActionsData}
 *      isDisplayedWhenNoActions
 *      >
 *      <MenuItems isEnabled={config.isDesktopApp}>
 *          <ContextMenuItem action={contextMenuActions.ACTION_TRADE} isEnabled={isFxSpot}/>
 *          <ContextMenuItem action={contextMenuActions.ACTION_CHART}/>
 *      </MenuItems>
 *      <MenuItems targetClassName='instrument-icon'>
 *          <ContextMenuItem action={contextMenuActions.ACTION_ADD_ALERT}/>
 *          <ContextMenuItem action={contextMenuActions.ACTION_ADD_TO_WATCHLIST}/>
 *      </MenuItems>
 *
 *      <MenuTarget>
 *          <div>This div will now have a context menu!</div>
 *      </MenuTarget>
 * </ContextMenu>
 *
 */
import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import config from 'src/config';
import Touchable, { supportedEvents } from 'src/components/touchable/touchable';
import * as utils from 'src/components/contextMenu/utils';
import * as featureTracker from 'src/featureTracker';
import { bindHandlers } from 'src/utils/bindHandlers';
import makeCancelable from 'src/utils/promiseCancelable';
import DialogManager from 'spine/commonControllers/dialogManager';
import ContextMenuDialogSheet from './contextMenuDialogSheet';
import Dialog from 'src/components/dialog/dialog';
import log from 'src/modules/log';

class ContextMenu extends React.PureComponent {

    constructor(props) {
        super(props);

        this.loadActionPromise = null;

        this.state = {
            isDialogShown: false,
            loadingActionId: null,
        };
    }

    componentWillReceiveProps(nextProps) {
        if (this.props.isEnabled && !nextProps.isEnabled) {
            this.hideDialog();
        }
    }

    componentWillUnmount() {
        if (this.loadActionPromise) {
            this.loadActionPromise.cancel();
        }
    }

    handleMenuTrigger(event) {

        // Whenever we click on select button on chart order handle in tablet, context menu opens
        // which is not expected.
        if (!this.props.isEnabled ||
            (_.includes(['INPUT', 'SELECT'], event.target.nodeName) ||
            event.defaultPrevented)) {
            return;
        }

        const actionsData = utils.getActionsData(this.props, event) || {};
        const menuItems = utils.getMenuItems(this.props, event);
        const allowedMenuItems = utils.filterMenuItems(menuItems, actionsData);

        if (_.isEmpty(allowedMenuItems) && !this.props.isDisplayedWhenNoActions) {
            return;
        }

        if (this.props.shouldStopPropagation) {
            event.stopImmediatePropagation();
        }

        if (this.props.shouldPreventDefault) {
            event.preventDefault();
        }

        this.showDialog(event, allowedMenuItems, actionsData);
    }

    handleAction(action, actionData) {
        const { loadingActionId } = this.state;

        if (loadingActionId) {
            return;
        }

        if (this.loadActionPromise) {
            this.loadActionPromise.cancel();
        }

        if (action.loadAction) {
            this.setState({
                loadingActionId: action.id,
            });
            this.loadActionPromise = makeCancelable(action.loadAction(actionData));
            this.loadActionPromise.promise
                .then((controller) => {
                    this.setState({
                        loadingActionId: null,
                    });
                    this.performAction(action, actionData, controller);
                })
                .catch((error) => {
                    if (action.onError) {
                        this.hideDialog();
                        action.onError();
                    }
                    log.error('Failed to load action in context menu', error);
                });
        } else {
            this.performAction(action, actionData);
        }
    }

    performAction(action, actionData, controller) {
        const { featureArea } = this.props;
        action.performAction(actionData, controller);
        this.hideDialog();

        if (featureArea) {
            featureTracker.logEvent(this.featureArea, 'Context Menu - ' + action.id);
        }
    }

    showDialog(event, menuItems, actionsData) {
        const { shouldCloseOtherDialogs } = this.props;
        const coordinates = utils.getCoordinates(event);
        this.hideDialog(shouldCloseOtherDialogs);
        this.setState({
            isDialogShown: true,
            menuItems,
            actionsData,
            coordinates,
        });
    }

    hideDialog(force) {
        if (this.state.isDialogShown) {
            this.setState({
                isDialogShown: false,
            });
        }

        // Unfortunately this has to be here until we remove Spine context menu
        // (we need to force legacy context menues to close)
        if (force) {
            DialogManager.hidePopups();
        }
    }

    render() {
        const menuTarget = utils.getMenuTargetFromProps(this.props);
        const { isDisplayedWhenNoActions, triggerEvent } = this.props;
        const { isDialogShown, menuItems, actionsData, coordinates, loadingActionId } = this.state;

        const touchableProps = {
            ['on' + _.upperFirst(triggerEvent)]: this.handleMenuTrigger,
        };

        return [
            <Touchable
                key="touchable"
                {...touchableProps}
            >
                {menuTarget}
            </Touchable>,
            isDialogShown &&
                <Dialog
                    key="dialog"
                    isLift
                    coordinates={coordinates}
                    position="bottom"
                    align="left"
                >
                    <ContextMenuDialogSheet
                        isDisplayedWhenNoActions={isDisplayedWhenNoActions}
                        menuItems={menuItems}
                        loadingActionId={loadingActionId}
                        actionsData={actionsData}
                        onAction={this.handleAction}/>
                </Dialog>,
        ];
    }
}

ContextMenu.propTypes = {
    isEnabled: PropTypes.bool,
    featureArea: PropTypes.string,
    actionsData: PropTypes.object,
    triggerEvent: PropTypes.oneOf(supportedEvents),
    shouldPreventDefault: PropTypes.bool,
    shouldStopPropagation: PropTypes.bool,
    shouldCloseOtherDialogs: PropTypes.bool,
    onGetActionsData: PropTypes.func,
    isDisplayedWhenNoActions: PropTypes.bool,
};

ContextMenu.defaultProps = {
    isEnabled: true,
    isDisplayedWhenNoActions: false,
    triggerEvent: config.isDesktopApp ? 'rightClick' : 'tap',
    shouldPreventDefault: true,
    shouldStopPropagation: true,
    shouldCloseOtherDialogs: true,
};

ContextMenu.contextTypes = {
    store: PropTypes.object,
};

export default bindHandlers(ContextMenu);

