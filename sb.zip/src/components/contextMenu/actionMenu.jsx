/**
 * The reason this component is in the /contextMenu package is that as some point it should be unified with ContextMenu as they
 * are almost the same (the only difference is the popup vs card UI).
 *
 * actionMenu React facade
 */
import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import ActionMenuController from 'src/spine/controllers/phonego/actionMenu';
import { bindHandlers } from 'src/utils/bindHandlers';
import * as menuUtils from 'src/components/contextMenu/utils';

class ActionMenu extends React.Component {

    constructor(props) {
        super(props);

        this.actionMenu = new ActionMenuController({
            featureArea: props.featureArea,
            actions: menuUtils.getActions(props),
        });

        this.state = { isVisible: false };
    }

    componentWillReceiveProps(nextProps) {
        if (!this.state.isVisible && nextProps.isVisible) {

            if (nextProps.priceAlert) {
                this.actionMenu.setPriceAlert(nextProps.priceAlert);
            }
            if (nextProps.instrument) {
                this.actionMenu.setInstrument(nextProps.instrument, nextProps.putCall);
            }
            if (nextProps.closedPositionId && nextProps.accountId) {
                this.actionMenu.setClosedPosition(nextProps.closedPositionId, nextProps.accountId);
            }
            if (nextProps.order && nextProps.mainOrder && nextProps.spineOrderModel) {
                this.actionMenu.setOrder(nextProps.order, nextProps.mainOrder, nextProps.spineOrderModel, nextProps.instrument);
            }

            this.actionMenu.setActions(menuUtils.getActions(nextProps));
            this.actionMenu.show();

            // actionMenuController does not emit a "hide" event (unlike
            // contextMenu), so instead bind to the panel created onShow()
            // to ensure we clean up after ourselves.
            if (this.actionMenu.dialog && this.actionMenu.dialog.isShown()) {
                // isVisible needs to be in component state to be in sync with actionMenu controller
                // this.actionMenu.show() is conditional and might not show anything
                this.setState({ isVisible: true });
                this.actionMenu.dialog.on('hide', this.handleHide);
            }
        }
    }

    shouldComponentUpdate() {
        return false;
    }

    componentWillUnmount() {
        this.actionMenu.release();
    }

    handleHide() {
        this.setState({ isVisible: false });
        this.actionMenu.dialog.off('hide', this.handleHide);
        this.props.onHide();
    }

    render() {
        return <div/>;
    }

}

ActionMenu.propTypes = {
    closedPositionId: PropTypes.any,
    order: PropTypes.any,
    mainOrder: PropTypes.any,
    spineOrderModel: PropTypes.any,
    accountId: PropTypes.any,
    featureArea: PropTypes.string,
    putCall: PropTypes.string,
    priceAlert: PropTypes.object,
    instrument: PropTypes.object,
    isVisible: PropTypes.bool,
    onHide: PropTypes.func,
};

ActionMenu.defaultProps = {
    isVisible: false,
    onHide: _.noop,
};

export default bindHandlers(ActionMenu);
