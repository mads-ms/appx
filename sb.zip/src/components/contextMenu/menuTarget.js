/**
 * See ContextMenu component for usage details.
 */
const MenuTarget = (props) => props.children;

export default MenuTarget;
