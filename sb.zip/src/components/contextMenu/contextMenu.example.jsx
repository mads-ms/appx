import _ from 'lodash';
import Localization from 'src/localization';
import React from 'react';
import { examplesOf } from 'src/modules/examples/utils';
import { ContextMenu, ContextMenuItem, MenuItems, MenuTarget } from './';
import CustomTriggerExample from './examples/customTriggerExample';
import Button from 'src/components/button/button';
import Instruments from 'src/spine/models/instruments';
import instrument from 'test/mocks/data/instruments/eurusd.json';

export default examplesOf('ContextMenu')
    .add('Filtering menu items', () => (
        <div>
            <pre>{`
The menu items are filtered based on:
    - MenuItems isEnabled property
    - MenuItem isEnabled property
    - Action isAllowed method (actionData) => Boolean

This way you can control whole sets of menu items or individual items. Also the whole ContextMenu can be disabled.

            `}</pre>
            <ContextMenu>
                <MenuItems>
                    <ContextMenuItem action={{ id: '1', label: 'Action 1' }}/>
                    <ContextMenuItem action={{ id: '2', label: 'Action 2' }}/>
                    <ContextMenuItem action={{ id: '3', label: 'Action 3' }} isEnabled={false}/>
                    <ContextMenuItem action={{ id: '4', label: 'Action 4', isAllowed: () => false }}/>
                </MenuItems>
                <MenuItems isEnabled={false}>
                    <ContextMenuItem action={{ id: '1', label: 'Action 1' }}/>
                </MenuItems>
                <MenuTarget>
                    <Button>Right click me!</Button>
                </MenuTarget>
            </ContextMenu>

            <br/>

            <ContextMenu isEnabled={false}>
                <MenuItems>
                    <ContextMenuItem action={{ id: '1', label: 'Action 1' }}/>
                </MenuItems>
                <MenuTarget>
                    <Button>Right click me (disabled)!</Button>
                </MenuTarget>
            </ContextMenu>
        </div>
    ), 'context-menu-filtering')
    .add('Nested targets', () => (
        <div>
            <pre>{`
A preferred way of using ContextMenu is to wrap the target (MenuTarget) that you want to have context menu for.
Sometimes however, especially for legacy Spine components, you need to have specific menu items only for a deep nested element.

Note the order of MenuItems in this example, the first matching one is used!
            `}</pre>
            <ContextMenu>
                <MenuItems targetClassName="greenBox">
                    <ContextMenuItem action={{ id: '1', label: 'Green Box Action 1' }}/>
                    <ContextMenuItem action={{ id: '2', label: 'Green Box Action 2' }}/>
                </MenuItems>
                <MenuItems>
                    <ContextMenuItem action={{ id: '1', label: 'Red Box Action 1' }}/>
                    <ContextMenuItem action={{ id: '2', label: 'Red Box Action 2' }}/>
                </MenuItems>
                <MenuTarget>
                    <div style={{ backgroundColor: 'red', width: '100px', height: '100px', position: 'relative' }}>
                        <div style={{ backgroundColor: 'green', width: '50px', height: '50px', left: '25px', top: '25px', position: 'absolute' }}
                            className="greenBox">
                        </div>
                    </div>
                </MenuTarget>
            </ContextMenu>
        </div>
    ), 'context-menu-nested-targets')
    .add('Async actions', () => (
        <div>
            <pre>{`
ContextMenu item show a spinner when the action has an async loadAction method.
            `}</pre>
            <ContextMenu>
                <MenuItems>
                    <ContextMenuItem action={{
                        id: '1',
                        label: 'Click me!',
                        loadAction: () => new Promise((resolve) => {
                            setTimeout(() => {
                                resolve();
                            }, 3000);
                        }),
                        performAction: _.noop,
                    }}/>
                </MenuItems>
                <MenuTarget>
                    <Button>Right click me!</Button>
                </MenuTarget>
            </ContextMenu>
        </div>
    ), 'context-menu-async-actions')
    .add('Instrument header', () => {

        function handleGetActionsData() {
            return {
                instrument: Instruments.mapOpenApiInstrument(instrument),
            };
        }

        return (
            <div>
                <pre>{`
ContextMenu can display an instrument header. To do it you need to include the instrument in the actionsData.
You can use both static actionsData or onGetActionsData handler to pass data to your actions.
            `}</pre>
                <ContextMenu onGetActionsData={handleGetActionsData}>
                    <MenuItems>
                        <ContextMenuItem action={{ id: '1', label: '^^ Instrument header' }}/>
                    </MenuItems>
                    <MenuTarget>
                        <Button>Right click me!</Button>
                    </MenuTarget>
                </ContextMenu>
                <br/>
                <ContextMenu actionsData={{ instrument: Instruments.mapOpenApiInstrument(instrument) }}>
                    <MenuItems>
                        <ContextMenuItem action={{ id: '1', label: '^^ Instrument header' }}/>
                    </MenuItems>
                    <MenuTarget>
                        <Button>Right click me!</Button>
                    </MenuTarget>
                </ContextMenu>
            </div>
        );
    })
    .add('No actions message', () => {

        function handleGetActionsData() {
            return {
                instrument: Instruments.mapOpenApiInstrument(instrument),
            };
        }

        return (
            <div>
                <pre>{`
ContextMenu can be displayed even though you don't have any allowed or defined actions.
To do it you need to set isDisplayedWhenNoActions.
In such case "${Localization.getText('HTML5_NoActionsAvailable')}" message will be displayed
            `}</pre>
                <ContextMenu isDisplayedWhenNoActions onGetActionsData={handleGetActionsData}>
                    <MenuItems>
                        <ContextMenuItem action={{ id: '1', label: 'Action 1', isAllowed: () => false }}/>
                        <ContextMenuItem action={{ id: '2', label: 'Action 2', isAllowed: () => false }}/>
                        <ContextMenuItem action={{ id: '3', label: 'Action 3', isAllowed: () => false }}/>
                    </MenuItems>
                    <MenuTarget>
                        <Button>Right click me!</Button>
                    </MenuTarget>
                </ContextMenu>
            </div>
        );
    }, 'context-menu-no-actions')
    .add('Custom triggers', ({ resizeTimestamp, action }) => (
        <CustomTriggerExample resizeTimestamp={resizeTimestamp} action={action}/>
    ), 'context-menu-custom-triggers');
