import _ from 'lodash';
import $ from 'jquery';
import React from 'react';
import { MenuItems, MenuTarget } from './index';

const getMenuEventTarget = (item, event) => {
    if (item && item.props.targetClassName) {
        return $(event.target).closest(`.${item.props.targetClassName}`).get(0);
    } else if (event) {
        return event.currentTarget;
    }
    return null;
};

const filterChildren = (type, event) => (child) => (
    (!type || child.type === type) &&
    _.get(child.props, 'isEnabled', true) &&
    (child.props.targetClassName ? getMenuEventTarget(child, event) : true)
);

export const filterMenuItems = (menuItems, actionsData) => {
    if (menuItems) {
        return _.chain(menuItems.props.children)
            .thru(React.Children.toArray)
            .filter((menuItem) => {
                const { isEnabled, action } = menuItem.props;
                return isEnabled && (action.isAllowed ? action.isAllowed(actionsData) : true);
            })
            .value();
    }

    return null;
};

export const getMenuTargetFromProps = (props) => {
    const menuTarget = _.chain(props.children)
        .thru(React.Children.toArray)
        .filter(filterChildren(MenuTarget))
        .head()
        .value();

    return menuTarget;
};

const getActionsFromMenuItems = (menuItems) => {
    if (menuItems) {
        return _.chain(menuItems.props.children)
            .thru(React.Children.toArray)
            .filter(filterChildren())
            .map('props.action')
            .map((action) => _.defaults(action, {
                loadAction: () => Promise.resolve(),
                isAllowed: () => true,
            }))
            .value();
    }

    return null;
};

export const getMenuItems = (props, event) => _.chain(props.children)
    .thru(React.Children.toArray)
    .filter(filterChildren(MenuItems, event))
    .head()
    .value();

const getActionDataHandlerFromMenuItems = (menuItems) => _.get(menuItems, 'props.onGetActionsData');
const getActionDataFromMenuItems = (menuItems) => _.get(menuItems, 'props.actionsData');

export const getActionsData = (props, event) => {
    const { actionsData, onGetActionsData } = props;
    const menuItems = getMenuItems(props, event);
    const menuTarget = getMenuEventTarget(menuItems, event);
    const menuItemsDataHandler = getActionDataHandlerFromMenuItems(menuItems);
    const menuItemsActionData = getActionDataFromMenuItems(menuItems);

    const dataHandler = menuItemsDataHandler || onGetActionsData;
    const data = menuItemsActionData || actionsData;

    if (_.isFunction(dataHandler)) {
        return dataHandler(data, menuTarget);
    }
    return data;
};

export const getActions = (props, event) => {
    const menuItems = getMenuItems(props, event);
    return getActionsFromMenuItems(menuItems);
};

export const getCoordinates = (event) => {
    if (_.isNumber(event.clientX) && _.isNumber(event.clientY)) {
        return { x: event.clientX, y: event.clientY };
    }

    if (event.gesture) {
        return event.gesture.center;
    }

    if (event.changedTouches) {
        const lastTouch = _.last(event.changedTouches);
        if (lastTouch && _.isNumber(lastTouch.clientX) && _.isNumber(lastTouch.clientY)) {
            return { x: lastTouch.clientX, y: lastTouch.clientY };
        }
    }

    return { x: 0, y: 0 };
};
