import React from 'react';
import { mount } from 'enzyme';
import ContextMenuItem from 'src/components/contextMenu/contextMenuItem';

describe('src/components/contextMenu/contextMenuItem', () => {
    let wrapper;

    it('renders successfully in spine', () => {
        wrapper = mount(
            <ContextMenuItem inSpine action={{ id: '1', label: 'label' }}/>
        );

        expect(wrapper.text()).toEqual('label');
    });
});
