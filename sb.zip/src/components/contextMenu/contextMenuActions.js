/* eslint max-lines: "off" */
import _ from 'lodash';
import { UI } from 'openui';
import config from 'src/config';
import getStore from 'src/store';
import Localization from 'src/localization';

import Spine from 'spineAll';
import Enums from 'src/spine/enums';
import Account from 'src/spine/models/account';
import PriceAlertSheet from 'spine/commonViewControllers/priceAlertSheet';
import EqrSheet from 'spine/commonViewControllers/eqrSheet';
import PositionDetailsViewController from 'spine/commonViewControllers/positionDetails';
import ClosePositionViewController from 'spine/commonViewControllers/closePosition';
import ExercisePositionViewController from 'spine/commonViewControllers/exercisePosition';
import DeltaHedgeViewController from 'spine/commonViewControllers/deltaHedge';

import * as OptionsChainWorkspace from 'src/modules/optionsChain/optionsChainWorkspace';
import * as instrumentsUtils from 'src/modules/instruments/utils';
import * as globalActions from 'src/modules/globals/actions';
import * as allowedInstrumentTypes from 'src/modules/chart/allowedInstrumentTypes';
import * as workspaceActions from 'src/modules/workspace/actions/workspaceActions';
import * as workspaceSagaActions from 'src/modules/workspace/actions/workspaceSagaActions';
import * as linkedInstrumentActions from 'src/modules/linkedInstrument/actions';
import * as chartToolbarActions from 'src/modules/chartToolbar/actions/chartToolbarActions';
import * as chartActions from 'src/modules/chart/actions/chartActions';
import * as workspaceDialogsActions from 'src/modules/workspace/actions/workspaceDialogsActions';
import * as workspaceComponentActions from 'src/modules/workspace/actions/workspaceComponentActions';
import * as watchlistActions from 'src/modules/watchlists/actions/watchlistsActions';
import * as multiChartActions from 'src/modules/multiChart/actions/multiChartActions';
import * as multiChartSelectors from 'src/modules/multiChart/multiChartSelectors';
import * as chartSelectors from 'src/modules/chart/chartSelectors';
import watchlistComponentId from 'src/modules/watchlists/watchlistComponentId';
import * as watchlistsModuleSelectors from 'src/modules/watchlists/watchlistsModuleSelectors';
import * as positionDetailsActions from 'src/modules/positionDetails/actions';
import * as chartUserSettingsActions from 'src/modules/chart/actions/chartUserSettingsActions';
import * as closedPositionsActions from 'src/modules/closedPositions/actions';
import * as openOrdersActions from 'src/modules/openOrders/actions';
import * as positionTradesActions from 'src/modules/positionTrades/actions';
import * as proTradeTicketActions from 'src/modules/proTradeTicket/actions';
import * as relatedOrdersTicketActions from 'src/modules/relatedOrdersTicket/actions';
import * as perfLoggingActions from 'src/modules/perfLog/actions';
import * as perfLogConstants from 'src/modules/perfLog/constants';
import * as moduleTypes from 'src/modules/workspace/moduleTypes';
import * as tradeBlotterActions from 'src/modules/tradeBlotter/actions';
import { getSupportedType } from 'src/modules/chart/chartQueries';
import * as tradingConditionsActions from 'src/modules/tradingConditions/actions';
import * as tradingConditionsSelectors from 'src/modules/tradingConditions/selectors';
import * as accountsSelectors from 'src/modules/accounts/selectors';
import * as instrumentSelectors from 'src/modules/instruments/selectors';
import * as orderSpineActions from 'src/modules/openOrders/spineActions';

export const ACTION_OVERVIEW = {
    id: 'overview',
    icon: 'icon--details',
    label: Localization.getText('HTML5_GoToOverview'),
    performAction(actionData) {
        if (actionData.instrument) {
            const store = getStore();
            const instrumentKey = instrumentsUtils.getKey(actionData.instrument);

            store.dispatch(linkedInstrumentActions.setLinkedInstrument(instrumentKey));
            store.dispatch(workspaceActions.switchWorkspace('trading'));
            store.dispatch(workspaceComponentActions.setSelectedTabInAnyPanel('overview'));
        }
    },
};

export const ACTION_OPTIONS_CHAIN = {
    id: 'optionschain',
    icon: 'icon--info',
    label: Localization.getText('HTML5_OptionsChain'),
    performAction(actionData) {
        const store = getStore();
        const componentConfig = {
            type: moduleTypes.OPTIONS_CHAIN,
            userSettings: { selectedInstrument: actionData.instrument },
        };
        store.dispatch(linkedInstrumentActions.setLinkedInstrument(actionData.instrument));
        store.dispatch(workspaceActions.addComponentInSubWindow(componentConfig));
    },
    isAllowed(actionData) {
        return config.isDesktopApp &&
                    actionData.instrument &&
                    actionData.instrument.tradableAsOption() &&
                    OptionsChainWorkspace.isOptionsChainAvailable();
    },
};

export const ACTION_TRADE = {
    id: 'trade',
    icon: 'icon--trade',
    label: Localization.getText('HTML5_NewTrade'),
    isPrimary: true,
    performAction(actionData) {
        if (actionData.instrument) {
            getStore().dispatch(globalActions.showTradeTicket({
                uic: actionData.instrument.uic,
                instrumentType: actionData.instrument.instrumentType,
                putCall: actionData.putCall,
                saveCurrentTicketData: false,
            }));
        }
    },
    isAllowed(actionData) {
        return actionData.instrument && actionData.instrument.isPreferred && actionData.instrument.isPreferred() &&
            Account.canTradeInstrumentType(actionData.instrument.instrumentType) && actionData.instrument.isTradable &&
            (config.appFeatures.isOptionsTicketSupported || !Enums.InstrumentType.isFxOptions(actionData.instrument.instrumentType));
    },
};

export const ACTION_PRO_TRADE = {
    id: 'protrade',
    icon: 'icon--trade',
    label: 'Pro Trade',
    performAction(actionData) {
        getStore().dispatch(proTradeTicketActions.triggerLaunchTicket({
            accountId: actionData.accountId,
            instrumentId: instrumentsUtils.getId(actionData.instrument),
        }));
    },
    isAllowed(actionData) {
        return config.isProApp &&
            config.appFeatures.isProTradeTicketEnabled &&
            actionData.instrument && actionData.instrument.isPreferred && actionData.instrument.isPreferred() &&
            Account.canTradeInstrumentType(actionData.instrument.instrumentType) && actionData.instrument.isTradable &&
            (config.appFeatures.isOptionsTicketSupported || !Enums.InstrumentType.isFxOptions(actionData.instrument.instrumentType));
    },
};

export const ACTION_CHART = {
    id: 'chart',
    icon: 'icon--charts',
    label: Localization.getText('Chart'),
    performAction() {
        if (config.isProApp) {
            getStore().dispatch(workspaceActions.addComponentInSubWindow({
                type: moduleTypes.CHART,
                label: Localization.getText('Chart'),
            }));
        } else {
            getStore().dispatch(workspaceComponentActions.setSelectedTabInAnyPanel('charts'));
        }
    },
    isAllowed(actionData) {
        return actionData.instrument && actionData.instrument.isChartSupported();
    },
};

export const ACTION_CHART_MODULE = {
    id: 'chartmodule',
    icon: 'icon--charts',
    label: Localization.getText('HTML5_Chart'),
    performAction(actionData) {
        const store = getStore();
        const instrument = actionData.instrument;
        const instrumentKey = instrumentsUtils.getKey(instrument);
        const instrumentId = instrumentsUtils.getId(_.defaults({
            assetType: getSupportedType(instrumentKey.assetType),
        }, instrumentKey));
        const componentConfig = {
            type: moduleTypes.CHART,
            userSettings: {
                primaryInstrument: {
                    id: instrumentId,
                    isLinked: false,
                },
                instrumentIds: [instrumentId],
            },
        };

        store.dispatch(workspaceActions.addComponentInSubWindow(componentConfig));
    },
    isAllowed(actionData) {
        return config.isProApp && actionData.instrument && allowedInstrumentTypes.isChartAllowed(actionData.instrument.instrumentType);
    },
};

export const ACTION_CHART_SCREENSHOT = {
    id: 'chartscreenshot',
    label: Localization.getText('HTML5_ChartMenu_generateChartImage'),
    performAction(actionData) {
        getStore().dispatch(chartToolbarActions.setIsChartImageRequested(actionData.chartId, true));
    },
};

export const ACTION_CHART_LOG = {
    id: 'chartlog',
    label: Localization.getText('HTML5_Chart_logarithmicScale'),
    performAction(actionData) {
        const { getState, dispatch } = getStore();
        const isActive = chartSelectors.getIsLogScaleActive(getState(), actionData.chartId);
        dispatch(chartUserSettingsActions.updateChartUserSetting(actionData.chartId, { isLogScaleActive: !isActive || null }));
    },
    isAllowed(actionData) {
        return !chartSelectors.isPercentComparativePlotTypeSelectedSelector(getStore().getState(), actionData.chartId);
    },
};

export const ACTION_CHART_SETTINGS = {
    id: 'chartsettings',
    label: Localization.getText('HTML5_ChartMenu_chartConfiguration'),
    performAction(actionData) {
        getStore().dispatch(chartToolbarActions.setIsChartSettingsActive(actionData.chartId, true));
    },
};

export const ACTION_CHART_COPY = {
    id: 'chartcopy',
    label: Localization.getText('HTML5_ChartMenu_copyChart'),
    performAction() {
        if (config.isProApp) {
            getStore().dispatch(workspaceActions.addComponentInSubWindow({
                type: moduleTypes.CHART,
                label: Localization.getText('Chart'),
            }));
        }
    },
    isAllowed() {
        // this feature has not yet been implemented (dependency on 703220)
        return false;
    },
};

export const ACTION_CHART_REMOVE = {
    id: 'chartremove',
    label: Localization.getText('HTML5_ChartMenu_removeChart'),
    performAction(actionData) {
        getStore().dispatch(multiChartActions.removeChart(actionData.chartId));
    },
    isAllowed() {
        return multiChartSelectors.getCanRemoveChart(getStore().getState());
    },
};
export const ACTION_CHART_REMOVE_ALL_ANNOTATIONS = {
    id: 'removeAllAnnotations',
    label: Localization.getText('HTML5_Chart_removeall'),
    performAction(actionData) {
        getStore().dispatch(chartToolbarActions.updateRemoveAnnotationsRequestTimestamp(actionData.chartId));
    },
    isAllowed(actionData) {
        return !chartSelectors.isPercentComparativePlotTypeSelectedSelector(getStore().getState(), actionData.chartId);
    },
};

export const ACTION_CHART_REMOVE_ALL_INDICATORS = {
    id: 'removeAllIndicators',
    label: Localization.getText('HTML5_Chart_removeAllStudies'),
    performAction(actionData) {
        getStore().dispatch(chartToolbarActions.updateRemoveStudiesRequestTimestamp(actionData.chartId));
    },
    isAllowed(actionData) {
        return !chartSelectors.isPercentComparativePlotTypeSelectedSelector(getStore().getState(), actionData.chartId);
    },
};

export const ACTION_CHART_POSITIONS = {
    id: 'chartpositions',
    label: Localization.getText('HTML5_Chart_showPositions'),
    performAction(actionData) {
        getStore().dispatch(chartActions.togglePositionsEnabled(actionData.chartId));
    },
    isAllowed(actionData) {
        return config.isProApp &&
            chartSelectors.getIsPositionsOrOrdersAllowed(getStore().getState(), actionData.chartId);
    },
};

export const ACTION_CHART_ORDERS = {
    id: 'chartorders',
    label: Localization.getText('HTML5_Chart_showOrders'),
    performAction(actionData) {
        getStore().dispatch(chartActions.toggleOrdersEnabled(actionData.chartId));
    },
    isAllowed(actionData) {
        return config.isProApp &&
            chartSelectors.getIsPositionsOrOrdersAllowed(getStore().getState(), actionData.chartId);
    },
};

export const ACTION_NEWS = {
    id: 'news',
    icon: 'icon--news',
    label: Localization.getText('News'),
    performAction(actionData) {
        if (config.isProApp) {
            const componentConfig = {
                type: moduleTypes.NEWS,
                userSettings: { selectedInstrument: actionData.instrument },
            };

            getStore().dispatch(workspaceActions.addComponentInSubWindow(componentConfig));
        } else {
            getStore().dispatch(workspaceComponentActions.setSelectedTabInAnyPanel('news'));
        }
    },
    isAllowed() {
        // prefiltering a news module not actually supported in PRO at current moment
        return !config.isProApp;
    },
};

export const ACTION_EQR = {
    id: 'eqr',
    icon: 'icon--details',
    label: Localization.getText('HTML5_EquityResearch'),
    performAction(actionData) {
        new EqrSheet().show(actionData.instrument.isin);
    },
    isAllowed(actionData) {
        return config.isDesktopApp && config.appFeatures.isShowEQRLink && actionData.instrument && actionData.instrument.hasEqr();
    },
};

export const ACTION_MARKET_DEPTH_MODULE = {
    id: 'marketdepthmodule',
    icon: 'icon--marketdepth',
    label: Localization.getText('HTML5_MarketDepth_Label'),
    performAction(actionData) {
        const componentConfig = {
            type: moduleTypes.MARKET_DEPTH,
            userSettings: { selectedInstrument: actionData.instrument },
        };
        getStore().dispatch(workspaceActions.addComponentInSubWindow(componentConfig));
    },
    isAllowed(actionData) {
        if (!actionData.instrument) {
            return false;
        }
        const instrumentType = actionData.instrument.instrumentType;
        return config.isProApp &&
            (Enums.InstrumentType.isStock(instrumentType) ||
            Enums.InstrumentType.isCfdOnStock(instrumentType) ||
            Enums.InstrumentType.isFuture(instrumentType) ||
            (Enums.InstrumentType.isFx(instrumentType) && actionData.instrument.isDmaEnabled));
    },
};

export const ACTION_FUNDAMENTALS_MODULE = {
    id: 'fundamentalsmodule',
    icon: 'icon--fundamentals',
    label: Localization.getText('HTML5_FundamentalsBar_Label'),
    performAction(actionData) {
        const componentConfig = {
            type: moduleTypes.FUNDAMENTALS_BAR,
            userSettings: { selectedInstrument: actionData.instrument },
        };
        getStore().dispatch(workspaceActions.addComponentInSubWindow(componentConfig));
    },
    isAllowed(actionData) {
        if (!actionData.instrument) {
            return false;
        }
        const instrumentType = actionData.instrument.instrumentType;
        return config.isProApp && actionData.instrument.hasEqr() &&
            (Enums.InstrumentType.isStock(instrumentType) || Enums.InstrumentType.isCfdOnStock(instrumentType));
    },
};

export const ACTION_ALERT_ADD = {
    id: 'alertadd',
    icon: 'icon--addalert',
    label: Localization.getText('HTML5_PriceAlerts_Context_Add'),
    loadAction(actionData) {
        return new PriceAlertSheet().createPriceAlertFromInstrumentId(actionData.instrument.uic,
            actionData.instrument.instrumentType);
    },
    performAction(actionData, actionController) {
        actionController.show();
    },
    isAllowed(actionData) {
        return _.invoke(actionData, 'instrument.isPriceAlertsAllowed');
    },
};

export const ACTION_ALERT_EDIT = {
    id: 'alertedit',
    icon: 'icon--edit',
    label: Localization.getText('HTML5_PriceAlerts_Context_Edit'),
    shortLabel: Localization.getText('HTML5_Edit'),
    performAction(actionData) {
        const { priceAlert } = actionData;
        if (priceAlert) {
            new PriceAlertSheet().load(priceAlert.AlertDefinitionId);
        }
    },
    isAllowed(actionData) {
        return _.get(actionData, 'priceAlert.AlertDefinitionId', false);
    },
};

export const ACTION_ALERT_DELETE = {
    id: 'alertdelete',
    icon: 'icon--delete',
    label: Localization.getText('HTML5_PriceAlerts_Context_Delete'),
    shortLabel: Localization.getText('HTML5_Delete'),
    performAction(actionData) {
        const { priceAlert } = actionData;
        if (priceAlert) {
            new PriceAlertSheet().deletePriceAlert(priceAlert.AlertDefinitionId);
        }
    },
    isAllowed(actionData) {
        return _.get(actionData, 'priceAlert.AlertDefinitionId', false);
    },
};

export const ACTION_ADD_NEW_TO_WATCHLIST = {
    id: 'addnewtowatchlist',
    label: Localization.getText('HTML5_AddInstrument'),
    performAction(actionData) {
        const store = getStore();

        store.dispatch(watchlistActions.setEditMode(actionData.componentId, true));
        store.dispatch(watchlistActions.setVisiblePopup(actionData.componentId, 'add-instrument'));
    },
    isAllowed(actionData) {
        return actionData.isCustomWatchlist;
    },
};

export const ACTION_DELETE_WATCHLIST = {
    id: 'deletewatchlist',
    label: Localization.getText('HTML5_DeleteWatchlistTitle'),
    performAction(actionData) {
        const store = getStore();

        store.dispatch(watchlistActions.setEditMode(actionData.componentId, true));
        store.dispatch(watchlistActions.setVisiblePopup(actionData.componentId, 'delete-watchlist'));
    },
    isAllowed(actionData) {
        return actionData.isCustomWatchlist;
    },
};

export const ACTION_LAYOUT_WATCHLIST = {
    id: 'layoutwatchlist',
    label: Localization.getText('HTML5_Layout'),
    performAction(actionData) {
        const store = getStore();

        store.dispatch(watchlistActions.setEditMode(actionData.componentId, true));
        store.dispatch(watchlistActions.setVisiblePopup(actionData.componentId, 'column-picker'));
    },
};

export const ACTION_RENAME_WATCHLIST = {
    id: 'renamewatchlist',
    label: Localization.getText('HTML5_RenameWatchlistTitle'),
    performAction(actionData) {
        const store = getStore();

        store.dispatch(watchlistActions.setEditMode(actionData.componentId, true));
        store.dispatch(watchlistActions.setVisiblePopup(actionData.componentId, 'rename-watchlist'));
    },
    isAllowed(actionData) {
        return actionData.isCustomWatchlist;
    },
};

export const ACTION_ADD_TO_WATCHLIST = {
    id: 'addtowatchlist',
    icon: 'icon--add',
    label: Localization.getText('HTML5_AddToWatchlist'),
    performAction(actionData) {
        if (actionData.instrument) {
            getStore().dispatch(workspaceActions.switchWorkspace('trading'));
            getStore().dispatch(workspaceComponentActions.setSelectedTabInAnyPanel('watchlist'));

            Spine.trigger('do:addToWatchlist', actionData.instrument, watchlistComponentId);
        }
    },
    isAllowed(actionData) {
        return !config.isProApp &&
            watchlistsModuleSelectors.getIsInstrumentAllowedToBeAddedToWatchlist(
                getStore().getState(),
                actionData.instrument,
                watchlistComponentId
            );
    },
};

export const ACTION_REMOVE_FROM_WATCHLIST = {
    id: 'removefromwatchlist',
    icon: 'icon--delete',
    label: Localization.getText('HTML5_RemoveFromWatchlist'),
    performAction(actionData) {
        const legacyInstrumentId = instrumentsUtils.getLegacyId(actionData.instrument);
        if (config.isProApp) {
            getStore().dispatch(watchlistActions.removeInstrument(
                actionData.componentId, legacyInstrumentId, actionData.instrument.symbol, { isRemoveEmptyWatchlistAllowed: true }
            ));
        } else {
            Spine.trigger('do:removeFromWatchlist', legacyInstrumentId, actionData.instrument.symbol, actionData.componentId);
        }
    },
    isAllowed() {
        return true;
    },
};

export const ACTION_REMOVE_WATCHLIST_COLUMN = {
    id: 'removewatchlistcolumn',
    label: Localization.getText('HTML5_RemoveColumn'),
    performAction(actionData) {
        getStore().dispatch(watchlistActions.setColumns(actionData.componentId, actionData.columns));
    },
    isAllowed(actionData) {
        return Boolean(actionData.columns);
    },
};

export const ACTION_REMOVE_OPEN_ORDERS_COLUMN = {
    id: 'removeopenorderscolumn',
    label: Localization.getText('HTML5_RemoveColumn'),
    performAction(actionData) {
        getStore().dispatch(
            openOrdersActions.updateColumns(actionData.componentId, actionData.columns)
        );
    },
    isAllowed(actionData) {
        return Boolean(actionData.columns);
    },
};

export const ACTION_REMOVE_CLOSED_POSITIONS_COLUMN = {
    id: 'removeclosedpositiontcolumn',
    label: Localization.getText('HTML5_RemoveColumn'),
    performAction(actionData) {
        getStore().dispatch(closedPositionsActions.updateColumns(actionData.componentId, actionData.columns));
    },
    isAllowed(actionData) {
        return Boolean(actionData.columns);
    },
};

export const ACTION_REMOVE_TRADE_BLOTTER_COLUMN = {
    id: 'removeclosedpositiontcolumn',
    label: Localization.getText('HTML5_RemoveColumn'),
    performAction(actionData) {
        getStore().dispatch(tradeBlotterActions.updateColumns(actionData.componentId, actionData.columns));
    },
    isAllowed(actionData) {
        return Boolean(actionData.columns);
    },
};

export const ACTION_ORDER_DETAILS = {
    id: 'orderdetails',
    icon: 'icon--info',
    label: Localization.getText('HTML5_OrderDetails'),
    performAction({ controllerConfig, order }) {
        if (controllerConfig && order) {
            orderSpineActions.handleOrderDetailsTap(controllerConfig, order);
        }
    },
};

export const ACTION_ORDER_EDIT = {
    id: 'orderedit',
    icon: 'icon--edit',
    label: Localization.getText('HTML5_EditOrder'),
    performAction({ controllerConfig, order }) {
        if (controllerConfig && order) {
            orderSpineActions.handleEditOrder(controllerConfig, order);
        }
    },
    isAllowed(actionData) {
        return actionData.order && Account.canTradeInstrumentType(actionData.instrument.instrumentType) && actionData.order.isEditOrderAllowed;
    },
};

export const ACTION_ORDER_CANCEL = {
    id: 'ordercancel',
    icon: 'icon--delete',
    label: Localization.getText('HTML5_CancelOrder'),
    performAction({ controllerConfig, order }) {
        if (controllerConfig && order) {
            orderSpineActions.handleCancelOrder(controllerConfig, order);
        }
    },
    isAllowed({ order, instrument }) {
        return order && instrument && Account.canTradeInstrumentType(instrument.instrumentType) && order.isCancelOrderAllowed;
    },
};

export const ACTION_ORDER_CHANGETOMARKETORDER = {
    id: 'changetomarketorder',
    icon: 'icon--market',
    label: Localization.getText('HTML5_ChangeToMarketOrder'),
    performAction({ controllerConfig, order }) {
        if (controllerConfig && order) {
            orderSpineActions.handleOrderChangeToMarket(controllerConfig, order);
        }
    },
    isAllowed({ order, instrument }) {
        return order && Account.canTradeInstrumentType(instrument.instrumentType) && order.isChangeToMarketOrderAllowed;
    },
};

export const ACTION_POSITION_DETAILS = {
    id: 'posdetails',
    icon: 'icon--info',
    label: Localization.getText('Details'),
    loadAction(actionData) {
        if (actionData.position) {
            const positionId = actionData.isPositionNet ? actionData.position.NetPositionId : actionData.position.PositionId;
            const positionDetails = new PositionDetailsViewController({
                dialogOptions: {
                    showUnderlay: true,
                    isSignalActivity: config.isTabletApp,
                },
            })
                .on(UI.Events.Hide, (actionController) => {
                    actionController.release();
                });

            return positionDetails.load({
                positionId,
                isNet: actionData.isPositionNet,
                showGreekInfo: false,
                accountId: actionData.positionAccountId,
            });
        }
        return Promise.resolve();
    },
    performAction(actionData, actionController) {
        actionController.show();
    },
    isAllowed(actionData) {
        return actionData.position; // not require to be traded, detail should be shown for all instrument
    },
};

export const ACTION_CLOSED_POSITION_DETAILS = {
    id: 'closedposdetails',
    icon: 'icon--info',
    label: Localization.getText('Details'),
    loadAction(actionData) {
        if (actionData.closedPositionId) {
            return getStore().dispatch(positionDetailsActions.fetchClosedPositionDetails(
                actionData.closedPositionId,
                actionData.positionAccountId
            ));
        }
        return Promise.resolve();
    },
    performAction: _.noop,
    isAllowed() {
        return true; // not require to be traded, detail should be shown for all instrument
    },
};

export const ACTION_POSITION_ADD_ORDERS = {
    id: 'posaddrelorders',
    icon: 'icon--add',
    label: Localization.getText('HTML5_TakeProfitStopLoss'),
    performAction(actionData) {
        if (actionData.controller && actionData.position) {
            const positionId = actionData.isPositionNet ? actionData.position.NetPositionId : actionData.position.PositionId;

            if (config.appFeatures.isProRelatedOrdersTicketEnabled && config.isProApp && _.isEmpty(actionData.position.RelatedOpenOrders)) {
                const position = actionData.isPositionNet ?
                    actionData.controller.presenter.getNetPosition(positionId) :
                    actionData.controller.presenter.getPosition(positionId);

                getStore().dispatch(relatedOrdersTicketActions.triggerLaunchRelatedOrdersPositionTicket(position));

            } else {
                actionData.controller.onAddRelatedOrders(positionId);
            }
        }
    },
    isAllowed(actionData) {
        const hasRelatedOrder = actionData.isPositionNet ? false : actionData.position.hasRelatedOrder();

        return actionData.position && actionData.instrument &&
            Account.canTradeInstrumentType(actionData.instrument.instrumentType) &&
            (actionData.isRealTimeNettingEnabled || !actionData.isPositionNet) &&

            // don't allow if DGO and isRealTimeNettingEnabled - remove once pro related orders ticket is supported in DGO
            (config.isProApp || !actionData.isRealTimeNettingEnabled) &&
            (actionData.position.isLimitOrderPossible() || actionData.position.isStopOrderPossible()) &&
            !hasRelatedOrder;
    },
};

// after pro trade ticket is supported in GO, this action can be removed
export const ACTION_POSITION_ADD_LIMIT_ORDER = {
    id: 'posaddlimitorder',
    icon: 'icon--add',
    label: Localization.getText('HTML5_AddTakeProfit'),
    performAction(actionData) {
        if (actionData.controller && actionData.position) {
            const netposId = actionData.position.NetPositionId;
            actionData.controller.onAddLimitOrder(netposId);
        }
    },
    isAllowed(actionData) {
        return !config.isProApp &&
            actionData.isRealTimeNettingEnabled && actionData.position && actionData.instrument &&
            Account.canTradeInstrumentType(actionData.instrument.instrumentType) &&
            actionData.position.isLimitOrderPossible();
    },
};

// after pro trade ticket is supported in GO, this action can be removed
export const ACTION_POSITION_ADD_STOP_ORDER = {
    id: 'posaddstoporder',
    icon: 'icon--add',
    label: Localization.getText('HTML5_AddStopLoss'),
    performAction(actionData) {
        if (actionData.controller && actionData.position) {
            const netposId = actionData.position.NetPositionId;
            actionData.controller.onAddStopOrder(netposId);
        }
    },
    isAllowed(actionData) {
        return !config.isProApp &&
            actionData.isRealTimeNettingEnabled && actionData.position && actionData.instrument &&
            Account.canTradeInstrumentType(actionData.instrument.instrumentType) &&
            actionData.position.isStopOrderPossible();
    },
};

// after pro trade ticket is supported in GO, this action can be removed
export const ACTION_POSITION_ADD_OCO = {
    id: 'posaddocoorder',
    icon: 'icon--add',
    label: Localization.getText('HTML5_AddBothOCO'),
    performAction(actionData) {
        if (actionData.controller && actionData.position) {
            const netposId = actionData.position.NetPositionId;
            actionData.controller.onAddOcoOrder(netposId);
        }
    },
    isAllowed(actionData) {
        return !config.isProApp &&
            actionData.isRealTimeNettingEnabled && actionData.position && actionData.instrument &&
            Account.canTradeInstrumentType(actionData.instrument.instrumentType) &&
            actionData.position.isLimitOrderPossible() && actionData.position.isStopOrderPossible();
    },
};

export const ACTION_POSITION_VIEW_TRADES = {
    id: 'posviewtrades',
    label: Localization.getText('HTML5_ViewTrades'),
    performAction(actionData) {
        if (actionData.position) {
            const {
                positionTradesComponentId,
                positionAccountId,
                position: { NetPositionId },
            } = actionData;

            const action = positionTradesActions.showPositionTradesDialog(positionTradesComponentId, positionAccountId, NetPositionId);
            getStore().dispatch(action);
        }
    },
    isAllowed(actionData) {
        return actionData.position && actionData.isPositionNet && actionData.position.PositionsAccount && actionData.instrument &&
            !Enums.InstrumentType.isMutualFunds(actionData.position.ITyp) && actionData.isRealTimeNettingEnabled;
    },
};

export const ACTION_POSITION_EDIT_ORDERS = {
    id: 'poseditrelorders',
    icon: 'icon--edit',
    label: Localization.getText('Edit related orders'),
    performAction(actionData) {
        if (actionData.controller && actionData.position) {
            const positionId = (actionData.isPositionNet) ? actionData.position.NetPositionId : actionData.position.PositionId;
            actionData.controller.onAddRelatedOrders(positionId);
        }
    },
    isAllowed(actionData) {
        return actionData.position && actionData.instrument && !actionData.isPositionNet &&
            Account.canTradeInstrumentType(actionData.instrument.instrumentType) &&
            (actionData.position.isLimitOrderPossible() || actionData.position.isStopOrderPossible()) &&
            (actionData.position.hasRelatedOrder());
    },
};

export const ACTION_POSITION_CLOSE = {
    id: 'posclose',
    icon: 'icon--delete',
    label: Localization.getText('Close Position'),
    isPrimary: true,
    loadAction(actionData) {
        const position = actionData.position;
        if (position) {
            const id = position.IUic + '-' + position.ITyp;
            const properties = { instrumentType: position.ITyp };

            getStore().dispatch(perfLoggingActions.cancel(perfLogConstants.OPEN_TRADE_TICKET, id));
            getStore().dispatch(perfLoggingActions.start(perfLogConstants.OPEN_TRADE_TICKET, id, undefined, properties));

            const closePosition = new ClosePositionViewController()
                .on(UI.Events.Hide, (actionController) => {
                    actionController.release();
                });

            closePosition.setAppHint(actionData.appHintModuleId);

            return closePosition.load(position.getClosePositionId(), position.isClosePositionNet(), actionData.positionAccountId);
        }
        return Promise.resolve();
    },
    performAction(actionData, actionController) {
        actionController.show();
    },
    isAllowed(actionData) {
        return actionData.position && actionData.instrument && actionData.position.isClosable();
    },
};

export const ACTION_POSITION_EXERCISE = {
    id: 'posexercise',
    icon: 'icon--exercise',
    label: Localization.getText('Exercise'),
    loadAction(actionData) {
        if (actionData.position) {
            const exercisePosition = new ExercisePositionViewController({
                dialogOptions: {
                    showUnderlay: true,
                    isSignalActivity: config.isTabletApp,
                },
            })
                .on(UI.Events.Hide, (actionController) => {
                    actionController.release();
                });

            return exercisePosition.load(actionData.position, actionData.isPositionNet);
        }
        return Promise.resolve();
    },
    performAction(actionData, actionController) {
        actionController.show();
    },
    isAllowed(actionData) {
        return actionData.position && actionData.instrument && Account.canTradeInstrumentType(actionData.instrument.instrumentType) &&
            actionData.position.isExercisable();
    },
};

export const ACTION_POSITION_EXERCISEAGGREGATE = {
    id: 'posexerciseaggregate',
    icon: 'icon--exercise',
    label: Localization.getText('HTML5_ExerciseAggregate'),
    loadAction(actionData) {
        if (actionData.position) {
            const exercisePosition = new ExercisePositionViewController({
                dialogOptions: {
                    showUnderlay: true,
                    isSignalActivity: config.isTabletApp,
                },
            })
                .on(UI.Events.Hide, (actionController) => {
                    actionController.release();
                });

            return exercisePosition.load(actionData.position, actionData.isPositionNet);
        }
        return Promise.resolve();
    },
    performAction(actionData, actionController) {
        actionController.show();
    },
    isAllowed(actionData) {
        const position = actionData.position;
        const instrument = actionData.instrument;

        return position &&
            instrument &&
            Account.canTradeInstrumentType(actionData.instrument.instrumentType) &&
            actionData.isPositionNet &&
            position.isAggregateExercisable();
    },
};

export const ACTION_POSITION_DELTAHEDGE = {
    id: 'posdeltahedge',
    icon: 'icon--delta',
    label: Localization.getText('Delta Hedge'),
    loadAction(actionData) {
        if (actionData.position) {
            const deltaHedge = new DeltaHedgeViewController({
                component: {
                    id: 'posdeltaheadge',
                },
                dialogOptions: {
                    showUnderlay: true,
                    isSignalActivity: config.isTabletApp,
                },
            })
                .on(UI.Events.Hide, (actionController) => {
                    actionController.release();
                });

            return deltaHedge.load({
                uic: actionData.instrument.uic,
                type: Enums.InstrumentType.FxVanillaOption,
                defaultAmount: actionData.position.Amount,
                hedgePutCall: actionData.instrument.callPut,
                expiryDate: actionData.instrument.expiryDate,
                strike: actionData.instrument.strikePrice,
                accountId: actionData.position.getAccountId(),
                hedgeLong: actionData.position.Amount > 0,
                position: actionData.position,
            });
        }
        return Promise.resolve();
    },
    performAction(actionData, actionController) {
        actionController.show();
    },
    isAllowed(actionData) {
        return actionData.position &&
            actionData.instrument &&
            Account.canTradeInstrumentType(actionData.instrument.instrumentType) &&
            actionData.position.isDeltaHedgeable();
    },
};

export const ACTION_POSITION_GREEKS = {
    id: 'posgreeks',
    icon: 'icon--greeks',
    label: Localization.getText('HTML5_Greek'),
    loadAction(actionData) {
        if (actionData.position) {
            const positionId = actionData.isPositionNet ? actionData.position.NetPositionId : actionData.position.PositionId;
            const positionDetails = new PositionDetailsViewController({
                dialogOptions: {
                    showUnderlay: true,
                    isSignalActivity: config.isTabletApp,
                },
            })
                .on(UI.Events.Hide, (actionController) => {
                    actionController.release();
                });

            return positionDetails.load({
                positionId,
                accountId: actionData.positionAccountId,
                isNet: actionData.isPositionNet,
                showGreekInfo: true,
            });
        }
        return Promise.resolve();
    },
    performAction(actionData, actionController) {
        actionController.show();
    },
    isAllowed(actionData) {
        return actionData.position && actionData.instrument && Enums.InstrumentType.isFxOptions(actionData.instrument.instrumentType);
    },
};

export const ACTION_COLUMN_REMOVE = {
    id: 'columnremove',
    label: Localization.getText('HTML5_RemoveColumn'),
    performAction(actionData) {
        actionData.controller.removeColumn(actionData.columnName);
    },
};

export const ACTION_APP_LOGOUT = {
    id: 'applogout',
    label: Localization.getText('HTML5_Masthead_Logout'),
    performAction() {
        Spine.trigger('app:userSignout');
    },
};

export const ACTION_APP_SETTINGS = {
    id: 'appsettings',
    label: Localization.getText('HTML5_Settings'),
    performAction() {
        getStore().dispatch(workspaceDialogsActions.showWorkspaceDialog(moduleTypes.SETTINGS));
    },
};

export const ACTION_APP_MODULE_PICKER = {
    id: 'appmodulepicker',
    label: Localization.getText('HTML5_ModuleMenu'),
    performAction() {
        getStore().dispatch(workspaceSagaActions.openModulePicker());
    },
    isAllowed() {
        return config.isProApp;
    },
};

export const ACTION_APP_ADDMODULE_ALERTS = {
    id: 'addmodulealerts',
    label: Localization.getText('HTML5_Alerts'),
    performAction(actionData) {
        if (config.isProApp) {
            getStore().dispatch(workspaceActions.addComponentInSubWindow({
                type: moduleTypes.PRICE_ALERTS,
                label: Localization.getText('HTML5_Alerts'),
                userSettings: { selectedInstrument: actionData.instrument },
            }));
        }
    },
};

export const ACTION_TRADING_CONDITIONS = {
    id: 'tradingconditions',
    label: Localization.getText('HTML5_Trading_Conditions'),
    loadAction(menu) {
        if (menu.instrument) {
            const { dispatch, getState } = getStore();
            const instrumentId = instrumentsUtils.getId(menu.instrument);
            const instrumentData = instrumentSelectors.getDataById(getState(), instrumentId);
            const accountId = _.get(menu, 'accountId', null) ||
                                accountsSelectors.getDefaultAccountIdForInstrument(getState(), instrumentData);
            dispatch(tradingConditionsActions.fetchTradingConditions({
                accountId,
                instrumentId,
            }));
            return tradingConditionsSelectors.getIsReadyPromise();
        }
        return Promise.reject();
    },
    performAction() {
        getStore().dispatch(workspaceDialogsActions.showWorkspaceDialog(moduleTypes.NEW_TRADING_CONDITIONS));
    },
    onError() {
        getStore().dispatch(workspaceDialogsActions.showWorkspaceDialog(moduleTypes.NEW_TRADING_CONDITIONS));
    },
    isAllowed() {
        return config.appFeatures.isTradingConditionsEnabled && !config.isProApp;
    },
};
