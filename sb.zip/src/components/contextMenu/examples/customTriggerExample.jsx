import PropTypes from 'prop-types';
import React from 'react';
import _ from 'lodash';
import { bindHandlers } from 'src/utils/bindHandlers';
import DropDown from 'src/components/dropdown/dropdown';
import DropdownItem from 'src/components/dropdown/dropdownItem';
import Button from 'src/components/button/button';
import { ContextMenu, ContextMenuItem, MenuItems, MenuTarget } from '../';
import { supportedEvents } from 'src/components/touchable/touchable';

class CustomTriggerExample extends React.PureComponent {

    constructor(props) {
        super(props);

        this.state = {
            triggerEvent: 'tap',
        };
    }

    handleTriggerEventChange(value) {
        this.setState({
            triggerEvent: value,
        });
    }

    render() {
        const {
            triggerEvent,
        } = this.state;

        return (
            <div className="grid grid--y grid--fit-fill">
                <div className="grid-cell toolbar g--fit">
                    <div className="grid--x grid grid--cross-center grid--series">
                        <div className="grid-cell g--fit">
                            Trigger event:
                        </div>
                        <div className="grid-cell g--fit">
                            <DropDown
                                value={triggerEvent}
                                onChange={this.handleTriggerEventChange}
                            >
                                {_.map(supportedEvents, (item) =>
                                    (<DropdownItem
                                        key={item}
                                        value={item}>
                                        {item}
                                    </DropdownItem>)
                                )}
                            </DropDown>
                        </div>
                    </div>
                </div>
                <div className="grid-cell g--fill">
                    <ContextMenu triggerEvent={triggerEvent}>
                        <MenuItems>
                            <ContextMenuItem action={{ id: '1', label: 'Action 1' }}/>
                            <ContextMenuItem action={{ id: '2', label: 'Action 2' }}/>
                        </MenuItems>
                        <MenuTarget>
                            <Button>Right click me!</Button>
                        </MenuTarget>
                    </ContextMenu>
                </div>
            </div>
        );
    }
}

CustomTriggerExample.propTypes = {
    resizeTimestamp: PropTypes.number,
    action: PropTypes.func,
};

export default bindHandlers(CustomTriggerExample);

