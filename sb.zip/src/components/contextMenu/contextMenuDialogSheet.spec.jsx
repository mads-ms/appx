import _ from 'lodash';
import React from 'react';
import ContextMenuDialogSheet from './contextMenuDialogSheet';
import ContextMenuItem from './contextMenuItem';
import SheetBody from 'src/components/sheet/sheetBody';
import SheetHeader from 'src/components/sheet/sheetHeader';
import InstrumentSecondaryInfo from 'src/components/instrument/instrumentSecondaryInfo';
import Localization from 'src/localization';
import { mount } from 'enzyme';

describe('src/components/contextMenu/contextMenuDialogSheet', () => {
    let wrapper;
    const actionsData = { };
    const menuItems = [
        <ContextMenuItem
            key="item1"
            action={{
                id: '1',
                label: 'Click me!',
                loadAction: () => new Promise((resolve) => {
                    setTimeout(() => {
                        resolve();
                    }, 3000);
                }),
                performAction: _.noop,
            }}/>,
        <ContextMenuItem
            key="item2"
            action={{
                id: '2',
                label: 'Click me!',
                loadAction: () => new Promise((resolve) => {
                    setTimeout(() => {
                        resolve();
                    }, 3000);
                }),
                performAction: _.noop,
            }}/>,
    ];

    describe('ContextMenuDialogSheet', () => {

        it('should render successfully', () => {
            wrapper = mount(
                <ContextMenuDialogSheet
                    menuItems={menuItems}
                    actionsData={actionsData}
                    onAction={_.noop}
                />);

            expect(wrapper.find(SheetBody).length).toEqual(1);
        });

        it('should render No Actions Available when menuItems is empty and flag "isDisplayedWhenNoActions" is set to true', () => {
            wrapper = mount(
                <ContextMenuDialogSheet
                    isDisplayedWhenNoActions
                    menuItems={[]}
                    actionsData={actionsData}
                    onAction={_.noop}
                />);

            expect(wrapper.find(SheetBody).text()).toEqual(Localization.getText('HTML5_NoActionsAvailable'));
        });

        it('should render instrument header when instrument is provided in actionsData', () => {
            const actionsDataWithInstrument = { instrument: { openApiInstrumentData: {} } };
            wrapper = mount(
                <ContextMenuDialogSheet
                    menuItems={menuItems}
                    actionsData={actionsDataWithInstrument}
                    onAction={_.noop}
                />);

            expect(wrapper.find(SheetHeader).length).toEqual(1);
        });

        it('should render secondary instrument info when optionData is provided in actionsData', () => {
            const actionsDataWithInstrument = { instrument: { openApiInstrumentData: {} }, optionData: {} };
            wrapper = mount(
                <ContextMenuDialogSheet
                    menuItems={menuItems}
                    actionsData={actionsDataWithInstrument}
                    onAction={_.noop}
                />);

            expect(wrapper.find(InstrumentSecondaryInfo).length).toEqual(1);
        });
    });
});
