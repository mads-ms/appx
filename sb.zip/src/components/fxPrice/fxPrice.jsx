import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import * as numberFormat from 'src/numberFormat';

function FxPrice({ price, instrument, className }) {
    const { Pre, First, Pips, DeciPips } = numberFormat.formatPriceParts(price, instrument.Format);
    const fxPriceClassNames = classNames(
        'fxprice',
        className
    );

    return (
        <div className={fxPriceClassNames}>
            <span className="fxprice-beta">{Pre}{First}</span>
            <span className="fxprice-pips">{Pips}</span>
            <span className="fxprice-beta">{DeciPips}</span>
        </div>
    );
}

FxPrice.propTypes = {
    price: PropTypes.number,
    instrument: PropTypes.object.isRequired,
    className: PropTypes.string,
};

export default FxPrice;
