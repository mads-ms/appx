import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import { bindHandlers } from 'src/utils/bindHandlers';
import * as accountQueries from 'src/modules/accounts/queries';
import InstrumentIcon from 'src/components/instrument/instrumentIcon';

class RelatedInstruments extends React.PureComponent {
    handleInstrumentIconTap(event, instrument) {
        this.props.onInstrumentSelect(instrument);
    }

    render() {
        const { accounts, relatedInstruments } = this.props;

        const allowedRelatedInstruments = accountQueries.getTradableInstruments(accounts, relatedInstruments);

        const relatedButtons = _.map(allowedRelatedInstruments, (relatedInstrument) => (
            <div
                key={relatedInstrument.AssetType}
                className="grid-cell"
            >
                <InstrumentIcon
                    isBlock
                    className="relatedinstr-icon"
                    instrument={relatedInstrument}
                    onTap={this.handleInstrumentIconTap}
                />
            </div>
        ));

        return (
            <div className="relatedinstr tst-relatedinstr grid grid--grail g--fit">
                {relatedButtons}
            </div>
        );
    }
}

RelatedInstruments.propTypes = {
    accounts: PropTypes.array.isRequired,
    onInstrumentSelect: PropTypes.func,
    relatedInstruments: PropTypes.array,
};

RelatedInstruments.defaultProps = {
    onInstrumentSelect: _.noop,
};

export default bindHandlers(RelatedInstruments);
