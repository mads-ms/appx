import React from 'react';
import Localization from 'src/localization';
import Notice from 'src/components/notice/notice';
import { getLog } from 'src/modules/log';

const log = getLog('reactErrorBoundary');

export default class ErrorBoundary extends React.Component {
    constructor(props) {
        super(props);
        this.state = { hasError: false };
    }

    componentDidCatch(error, info) {
        this.setState({ hasError: true });

        log.error(error, info);
    }

    render() {
        if (this.state.hasError) {
            return (
                <Notice
                    message={Localization.getText('HTML5_ErrorBoundary')}
                />);
        }
        return this.props.children;
    }
}
