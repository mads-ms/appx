import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import Localization from 'src/localization';
import Icon from 'src/components/icon/icon';
import Button from 'src/components/button/button';

function StatusMessage({ type, isLift, onClose, children }) {
    const classes = classNames(`status status--${type}`, {
        'status--lift': isLift,
    });

    return (
        <div className={classes}>
            <Icon type={type === 'warning' ? 'warn' : type}/>
            <div className="status-msg">{children}</div>
            {onClose && (
                <Button
                    onTap={onClose}
                    className="status-close btn--inline btn--clear"
                    title={Localization.getText('Close')}
                >
                    <Icon type="close"/>
                </Button>
            )}
        </div>
    );
}

StatusMessage.propTypes = {
    type: PropTypes.oneOf(['success', 'warning', 'danger']),
    isLift: PropTypes.bool,
    onClose: PropTypes.func,
};

StatusMessage.defaultProps = {
    type: 'warning',
    isLift: false,
};

export default StatusMessage;
