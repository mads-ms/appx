import React from 'react';
import { shallow } from 'enzyme';
import StatusMessage from 'src/components/statusMessage/statusMessage';
import Button from 'src/components/button/button';

describe('src/components/statusMessage/statusMessage', () => {
    it('renders successfully', () => {
        const children = <span/>;
        const wrapper = shallow(<StatusMessage>{children}</StatusMessage>);
        expect(wrapper.contains(children)).toBe(true);
    });

    it('has a <Button/> component if it has an onClose prop', () => {
        const wrapper = shallow(<StatusMessage onClose={function() {}}/>);
        expect(wrapper.find(Button).length).toEqual(1);
    });

    it('does not have a <Button/> component if it does not have an onClose prop', () => {
        const wrapper = shallow(<StatusMessage/>);
        expect(wrapper.find(Button).length).toEqual(0);
    });
});
