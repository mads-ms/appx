import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';

function SheetActions({ className, children, showBorder }) {
    const classes = classNames('sheet-actions', className, {
        'sheet-actions--no-border': !showBorder,
    });
    return (
        <div className={classes}>
            {children}
        </div>
    );
}

SheetActions.propTypes = {
    className: PropTypes.string,
    showBorder: PropTypes.bool,
};

SheetActions.defaultProps = {
    showBorder: true,
};

export default SheetActions;
