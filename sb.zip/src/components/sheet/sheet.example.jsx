import React from 'react';
import Sheet from './sheet';
import SheetHeader from './sheetHeader';
import SheetBody from './sheetBody';
import SheetActions from './sheetActions';
import Button from 'src/components/button/button';
import { examplesOf } from 'src/modules/examples/utils';

export default examplesOf('Sheet')
    .add('Default', ({ action }) => (
        <Sheet>
            <SheetHeader onClose={action('close')}>Title</SheetHeader>
            <SheetBody>Body</SheetBody>
            <SheetActions>
                <Button onTap={action('action tap')}>Action</Button>
            </SheetActions>
        </Sheet>
    ))
    .add('Alt Style', ({ action }) => (
        <Sheet isAlt>
            <SheetHeader onClose={action('close')}>Title</SheetHeader>
            <SheetBody>Body</SheetBody>
            <SheetActions>
                <Button onTap={action('action tap')}>Action</Button>
            </SheetActions>
        </Sheet>
    ))
    .add('Astro Style 🚀', ({ action }) => (
        <Sheet isAstroStyle>
            <SheetHeader onClose={action('close')}>Title</SheetHeader>
            <SheetBody>Body</SheetBody>
            <SheetActions>
                <Button className="btn--astro" onTap={action('action tap')}>Action</Button>
            </SheetActions>
        </Sheet>
    ));
