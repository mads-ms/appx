import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';

function SheetBody({ className, onDomRef, children }) {
    const classes = classNames('sheet-body', className);
    return (
        <div
            className={classes}
            ref={onDomRef}
        >
            {children}
        </div>
    );
}

SheetBody.propTypes = {
    className: PropTypes.string,
    onDomRef: PropTypes.func,
};

export default SheetBody;
