import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import Button from 'src/components/button/button';
import Icon from 'src/components/icon/icon';

function SheetHeader({ className, onClose, onBack, showBorder, showClose, showBack, children }) {
    const classes = classNames('sheet-header header', className, {
        'sheet-header--no-border': !showBorder,
    });

    return (
        <header className={classes}>
            {
                showBack &&
                    <Button
                        onTap={onBack}
                        className="btn--clear btn--inline header-back tst-back"
                    >
                        <Icon type="back"/>
                    </Button>
            }
            <div className="header-title">
                {children}
            </div>
            {
                showClose &&
                    <Button
                        onTap={onClose}
                        className="js-popup-close js-card-close js-panel-close btn--clear btn--inline header-close tst-close"
                    >
                        <Icon type="close"/>
                    </Button>
            }
        </header>
    );
}

SheetHeader.propTypes = {
    className: PropTypes.string,
    onClose: PropTypes.func,
    onBack: PropTypes.func,
    showBorder: PropTypes.bool,
    showClose: PropTypes.bool,
    showBack: PropTypes.bool,
};

SheetHeader.defaultProps = {
    showBorder: true,
    showClose: true,
    showBack: false,
    onClose: _.noop,
    onBack: _.noop,
};

export default SheetHeader;
