import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';

function Sheet({ className, isAlt, isAstroStyle, isDialog, children, onDomRef }) {
    const classes = classNames('sheet',
        {
            'sheet--alt': isAlt,
            'sheet--astro': isAstroStyle,
            'sheet--dialog': isDialog,
        },
        className
    );
    return (
        <div
            className={classes}
            ref={onDomRef}
        >
            {children}
        </div>
    );
}

Sheet.propTypes = {
    className: PropTypes.string,
    isAlt: PropTypes.bool,
    isAstroStyle: PropTypes.bool,
    isDialog: PropTypes.bool,
    onDomRef: PropTypes.func,
};

Sheet.defaultProps = {
    isAlt: false,
    isAstroStyle: false,
    isDialog: false,
};

export default Sheet;
