import React from 'react';
import PropTypes from 'prop-types';
import * as numberFormat from 'src/numberFormat';
import * as instrumentQueries from 'src/modules/instruments/queries';

function FormattedPrice({ price, instrument }) {
    const format = instrumentQueries.getFormat(instrument);
    const { Pre, First, Pips, DeciPips, Post } = numberFormat.formatPriceParts(price, format);

    return <span>{Pre}{First}{Pips}{DeciPips ? <sub>{DeciPips}</sub> : Post}</span>;
}

FormattedPrice.propTypes = {
    price: PropTypes.number,
    instrument: PropTypes.object.isRequired,
};

export default FormattedPrice;
