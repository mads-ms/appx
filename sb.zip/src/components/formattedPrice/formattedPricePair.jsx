import React from 'react';
import PropTypes from 'prop-types';
import FormattedPrice from './formattedPrice';

function FormattedPricePair({ ask, bid, instrument }) {
    return (
        <span>
            <FormattedPrice price={bid} instrument={instrument}/> / <FormattedPrice price={ask} instrument={instrument}/>
        </span>
    );
}

FormattedPricePair.propTypes = {
    ask: PropTypes.number,
    bid: PropTypes.number,
    instrument: PropTypes.object.isRequired,
};

export default FormattedPricePair;
