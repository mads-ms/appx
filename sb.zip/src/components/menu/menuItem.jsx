import PropTypes from 'prop-types';
import React from 'react';
import { bindHandlers } from 'src/utils/bindHandlers';
import classNames from 'classnames';

class MenuItem extends React.Component {
    handleClick() {
        const { onClick, item } = this.props;

        onClick(item);
    }

    render() {
        const { item } = this.props;
        const { handleClick } = this;
        return (
            <li
                className="list-item tst-list-item"
                onClick={handleClick}
            >
                {item.label}
                {
                    item.hasLinkKey &&
                        <div className={classNames('tab-menu-linking-key', item.isLinking && 'tab-menu-linking-key-on')}/>
                }
            </li>
        );
    }
}

MenuItem.propTypes = {
    item: PropTypes.object.isRequired,
    onClick: PropTypes.func.isRequired,
};

export default bindHandlers(MenuItem);
