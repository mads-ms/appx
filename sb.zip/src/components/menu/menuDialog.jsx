import $ from 'jqueryAll';
import PropTypes from 'prop-types';
import React from 'react';
import MenuItemList from './menuItemList';
import Dialog from 'src/components/dialog/dialog';
import { bindHandlers } from 'src/utils/bindHandlers';

const MENU_WIDTH = 200; // px

class MenuDialog extends React.Component {
    handleDialogHide() {
        const { onHide } = this.props;
        onHide();
    }

    handleItemClick(item) {
        const { id, anchor, onHide } = this.props;
        const { onClick } = item;
        onHide();
        if (onClick) {
            onClick(id, anchor);
        }
    }

    render() {
        const { items, anchor, className } = this.props;
        const { handleDialogHide, handleItemClick } = this;

        const menuItemList = (
            <MenuItemList
                className={className}
                items={items}
                onItemClick={handleItemClick}
            />
        );

        return (
            <Dialog
                anchor={$(anchor)}
                position="bottom"
                align="left"
                width={MENU_WIDTH}
                onHide={handleDialogHide}
            >
                {menuItemList}
            </Dialog>
        );
    }
}

MenuDialog.propTypes = {
    className: PropTypes.string,
    id: PropTypes.string.isRequired,
    items: PropTypes.array.isRequired,
    anchor: PropTypes.object.isRequired,
    onHide: PropTypes.func.isRequired,
};

export default bindHandlers(MenuDialog);
