import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import MenuItem from './menuItem';
import classNames from 'classnames';

function menuItemList({ items, onItemClick, className }) {
    const menuItems = _.map(items, (item, index) => (
        <MenuItem
            key={index}
            item={item}
            onClick={onItemClick}
        />
    ));

    const classes = classNames(className, 'sheet grid grid--y');

    return (
        <div className={classes}>
            <ul className="list list--lines list--compact">
                {menuItems}
            </ul>
        </div>
    );
}

menuItemList.propTypes = {
    className: PropTypes.string,
    items: PropTypes.array.isRequired,
    onItemClick: PropTypes.func.isRequired,
};

export default menuItemList;
