import _ from 'lodash';
import React from 'react';
import Localization from 'src/localization';
import priceFx from 'test/mocks/data/prices/eurusd-single.json';
import instrumentFx from 'test/mocks/data/instruments/eurusd.json';
import priceCfdIndex from 'test/mocks/data/prices/US30I-single.json';
import instrumentCfdIndex from 'test/mocks/data/instruments/US30I.json';
import priceCfdFuture from 'test/mocks/data/prices/wheatCfdFuture-single.json';
import instrumentCfdFuture from 'test/mocks/data/instruments/wheatCfdFuture.json';
import priceCfd from 'test/mocks/data/prices/ACAxpar-single.json';
import instrumentCfd from 'test/mocks/data/instruments/ACAxpar.json';
import priceStockIndex from 'test/mocks/data/prices/NAS100I-single.json';
import instrumentStockIndex from 'test/mocks/data/instruments/NAS100I.json';
import priceStock from 'test/mocks/data/prices/AAPLxnas-single.json';
import instrumentStock from 'test/mocks/data/instruments/AAPLxnas.json';
import priceBond from 'test/mocks/data/prices/RBSGRP-single.json';
import instrumentBond from 'test/mocks/data/instruments/RBSGRP.json';
import priceFuture from 'test/mocks/data/prices/wheatFuture-single.json';
import instrumentFuture from 'test/mocks/data/instruments/wheatFuture.json';
import priceFutureSpread from 'test/mocks/data/prices/CDM7-M8-single.json';
import instrumentFutureSpread from 'test/mocks/data/instruments/CDM7-M8.json';
import PriceBar from 'src/components/priceBar/priceBar';
import { mount } from 'enzyme';

describe('src/components/priceBar/priceBar', () => {
    let wrapper;

    afterEach(() => {
        if (wrapper) {
            wrapper.unmount();
        }
        wrapper = null;
    });

    it('should render the correct price bar items for a FX instrument', () => {

        const price = priceFx._entry.data[0].Snapshot;

        wrapper = mount(
            <PriceBar
                price={price}
                instrument={instrumentFx}
            />
        );

        const labels = wrapper.find('.pricebar-label');

        expect(labels.length).toEqual(12);
        expect(labels.at(0).text()).toEqual(Localization.getText('HTML5_Bid'));
        expect(labels.at(1).text()).toEqual(Localization.getText('HTML5_Spread'));
        expect(labels.at(2).text()).toEqual(Localization.getText('HTML5_Ask'));
        expect(labels.at(3).text()).toEqual(Localization.getText('HTML5_NetChange'));
        expect(labels.at(4).text()).toEqual(Localization.getText('HTML5_PctChange'));
        expect(labels.at(5).text()).toEqual(Localization.getText('HTML5_Low'));
        expect(labels.at(6).text()).toEqual(Localization.getText('HTML5_DayRange'));
        expect(labels.at(7).text()).toEqual(Localization.getText('HTML5_High'));
        expect(labels.at(8).text()).toEqual(Localization.getText('HTML5_PrevClose'));
        expect(labels.at(9).text()).toEqual(Localization.getText('HTML5_LastUpdateLower'));
        expect(labels.at(10).text()).toEqual(Localization.getText('HTML5_BidSize'));
        expect(labels.at(11).text()).toEqual(Localization.getText('HTML5_AskSize'));
    });

    it('should render the correct price bar items for a CFD on stock index', () => {

        const price = priceCfdIndex._entry.data[0].Snapshot;

        wrapper = mount(
            <PriceBar
                price={price}
                instrument={instrumentCfdIndex}
            />
        );

        const labels = wrapper.find('.pricebar-label');

        expect(labels.length).toEqual(11);
        expect(labels.at(0).text()).toEqual(Localization.getText('HTML5_Bid'));
        expect(labels.at(1).text()).toEqual(Localization.getText('HTML5_Ask'));
        expect(labels.at(2).text()).toEqual(Localization.getText('HTML5_NetChange'));
        expect(labels.at(3).text()).toEqual(Localization.getText('HTML5_PctChange'));
        expect(labels.at(4).text()).toEqual(Localization.getText('HTML5_Open'));
        expect(labels.at(5).text()).toEqual(Localization.getText('HTML5_Low'));
        expect(labels.at(6).text()).toEqual(Localization.getText('HTML5_High'));
        expect(labels.at(7).text()).toEqual(Localization.getText('HTML5_PrevClose'));
        expect(labels.at(8).text()).toEqual(Localization.getText('HTML5_LastUpdateLower'));
        expect(labels.at(9).text()).toEqual(Localization.getText('HTML5_BidSize'));
        expect(labels.at(10).text()).toEqual(Localization.getText('HTML5_AskSize'));
    });

    it('should render the correct price bar items for a CFD on futures', () => {

        const price = priceCfdFuture._entry.data[0].Snapshot;

        wrapper = mount(
            <PriceBar
                price={price}
                instrument={instrumentCfdFuture}
            />
        );

        const labels = wrapper.find('.pricebar-label');

        expect(labels.length).toEqual(12);
        expect(labels.at(0).text()).toEqual(Localization.getText('HTML5_Bid'));
        expect(labels.at(1).text()).toEqual(Localization.getText('HTML5_Ask'));
        expect(labels.at(2).text()).toEqual(Localization.getText('HTML5_NetChange'));
        expect(labels.at(3).text()).toEqual(Localization.getText('HTML5_PctChange'));
        expect(labels.at(4).text()).toEqual(Localization.getText('HTML5_Open'));
        expect(labels.at(5).text()).toEqual(Localization.getText('HTML5_Low'));
        expect(labels.at(6).text()).toEqual(Localization.getText('HTML5_High'));
        expect(labels.at(7).text()).toEqual(Localization.getText('HTML5_ExpiryDate'));
        expect(labels.at(8).text()).toEqual(Localization.getText('HTML5_PrevClose'));
        expect(labels.at(9).text()).toEqual(Localization.getText('HTML5_LastUpdateLower'));
        expect(labels.at(10).text()).toEqual(Localization.getText('HTML5_BidSize'));
        expect(labels.at(11).text()).toEqual(Localization.getText('HTML5_AskSize'));
    });

    it('should render the correct price bar items for a CFD', () => {

        const price = priceCfd._entry.data[0].Snapshot;

        wrapper = mount(
            <PriceBar
                price={price}
                instrument={instrumentCfd}
            />
        );

        const labels = wrapper.find('.pricebar-label');

        expect(labels.length).toEqual(8);
        expect(labels.at(0).text()).toEqual(Localization.getText('HTML5_LastTraded'));
        expect(labels.at(1).text()).toEqual(Localization.getText('HTML5_NetChange'));
        expect(labels.at(2).text()).toEqual(Localization.getText('HTML5_PctChange'));
        expect(labels.at(3).text()).toEqual(Localization.getText('HTML5_Open'));
        expect(labels.at(4).text()).toEqual(Localization.getText('HTML5_Low'));
        expect(labels.at(5).text()).toEqual(Localization.getText('HTML5_High'));
        expect(labels.at(6).text()).toEqual(Localization.getText('HTML5_PrevClose'));
        expect(labels.at(7).text()).toEqual(Localization.getText('HTML5_LastUpdateLower'));
    });

    it('should render the correct price bar items for a stock index', () => {

        const price = priceStockIndex._entry.data[0].Snapshot;

        wrapper = mount(
            <PriceBar
                price={price}
                instrument={instrumentStockIndex}
            />
        );

        const labels = wrapper.find('.pricebar-label');

        expect(labels.length).toEqual(9);
        expect(labels.at(0).text()).toEqual(Localization.getText('HTML5_LastTraded'));
        expect(labels.at(1).text()).toEqual(Localization.getText('HTML5_NetChange'));
        expect(labels.at(2).text()).toEqual(Localization.getText('HTML5_PctChange'));
        expect(labels.at(3).text()).toEqual(Localization.getText('HTML5_Open'));
        expect(labels.at(4).text()).toEqual(Localization.getText('HTML5_Low'));
        expect(labels.at(5).text()).toEqual(Localization.getText('HTML5_High'));
        expect(labels.at(6).text()).toEqual(Localization.getText('HTML5_PrevClose'));
        expect(labels.at(7).text()).toEqual(Localization.getText('HTML5_Volume'));
        expect(labels.at(8).text()).toEqual(Localization.getText('HTML5_LastUpdateLower'));
    });

    it('should render the correct price bar items for a stock index where price volume is 0', () => {

        const price = priceStockIndex._entry.data[0].Snapshot;
        price.PriceInfoDetails.Volume = 0;

        wrapper = mount(
            <PriceBar
                price={price}
                instrument={instrumentStockIndex}
            />
        );

        const labels = wrapper.find('.pricebar-label');

        expect(labels.length).toEqual(8);
        for (let i = 0; i < labels.length; i++) {
            expect(labels.at(i).text()).not.toEqual(Localization.getText('HTML5_Volume'));
        }
    });

    it('should render the correct price bar items for a stock', () => {

        const price = priceStock._entry.data[0].Snapshot;

        wrapper = mount(
            <PriceBar
                price={price}
                instrument={instrumentStock}
            />
        );

        const labels = wrapper.find('.pricebar-label');

        expect(labels.length).toEqual(9);
        expect(labels.at(0).text()).toEqual(Localization.getText('HTML5_LastTraded'));
        expect(labels.at(1).text()).toEqual(Localization.getText('HTML5_NetChange'));
        expect(labels.at(2).text()).toEqual(Localization.getText('HTML5_PctChange'));
        expect(labels.at(3).text()).toEqual(Localization.getText('HTML5_Open'));
        expect(labels.at(4).text()).toEqual(Localization.getText('HTML5_Low'));
        expect(labels.at(5).text()).toEqual(Localization.getText('HTML5_High'));
        expect(labels.at(6).text()).toEqual(Localization.getText('HTML5_PrevClose'));
        expect(labels.at(7).text()).toEqual(Localization.getText('HTML5_Volume'));
        expect(labels.at(8).text()).toEqual(Localization.getText('HTML5_LastUpdateLower'));
    });

    it('should render the correct price bar items for a non-CSE (non-danish) bond', () => {

        const price = priceBond._entry.data[0].Snapshot;

        wrapper = mount(
            <PriceBar
                price={price}
                instrument={instrumentBond}
            />
        );

        const labels = wrapper.find('.pricebar-label');

        expect(labels.length).toEqual(6);
        expect(labels.at(0).text()).toEqual(Localization.getText('HTML5_Bid'));
        expect(labels.at(1).text()).toEqual(Localization.getText('HTML5_Ask'));
        expect(labels.at(2).text()).toEqual(Localization.getText('HTML5_MidYield'));
        expect(labels.at(3).text()).toEqual(Localization.getText('HTML5_NetChange'));
        expect(labels.at(4).text()).toEqual(Localization.getText('HTML5_PctChange'));
        expect(labels.at(5).text()).toEqual(Localization.getText('HTML5_PrevClose'));
    });

    it('should render the correct price bar items for a CSE (danish) bond', () => {

        const price = priceBond._entry.data[0].Snapshot;

        // simulate CSE (danish) bond to verify mid yield is not rendered
        const cseExchange = _.defaults({ ExchangeId: 'CSE_BONDS' }, instrumentBond.Exchange);
        const cseBondInstrument = _.defaults(
            { Exchange: cseExchange },
            instrumentBond
        );

        wrapper = mount(
            <PriceBar
                price={price}
                instrument={cseBondInstrument}
            />
        );

        const labels = wrapper.find('.pricebar-label');

        expect(labels.length).toEqual(5);
        expect(labels.at(0).text()).toEqual(Localization.getText('HTML5_Bid'));
        expect(labels.at(1).text()).toEqual(Localization.getText('HTML5_Ask'));
        expect(labels.at(2).text()).toEqual(Localization.getText('HTML5_NetChange'));
        expect(labels.at(3).text()).toEqual(Localization.getText('HTML5_PctChange'));
        expect(labels.at(4).text()).toEqual(Localization.getText('HTML5_PrevClose'));
    });

    it('should render the correct price bar items for a future', () => {

        const price = priceFuture._entry.data[0].Snapshot;

        wrapper = mount(
            <PriceBar
                price={price}
                instrument={instrumentFuture}
            />
        );

        const labels = wrapper.find('.pricebar-label');

        expect(labels.length).toEqual(11);
        expect(labels.at(0).text()).toEqual(Localization.getText('HTML5_LastTraded'));
        expect(labels.at(1).text()).toEqual(Localization.getText('HTML5_NetChange'));
        expect(labels.at(2).text()).toEqual(Localization.getText('HTML5_PctChange'));
        expect(labels.at(3).text()).toEqual(Localization.getText('HTML5_Open'));
        expect(labels.at(4).text()).toEqual(Localization.getText('HTML5_Low'));
        expect(labels.at(5).text()).toEqual(Localization.getText('HTML5_High'));
        expect(labels.at(6).text()).toEqual(Localization.getText('HTML5_ExpiryDate'));
        expect(labels.at(7).text()).toEqual(Localization.getText('HTML5_PrevClose'));
        expect(labels.at(8).text()).toEqual(Localization.getText('HTML5_Volume'));
        expect(labels.at(9).text()).toEqual(Localization.getText('HTML5_LotSize'));
        expect(labels.at(10).text()).toEqual(Localization.getText('HTML5_LastUpdateLower'));
    });

    it('should render the correct price bar items for a future spread', () => {

        const price = priceFutureSpread._entry.data[0].Snapshot;

        wrapper = mount(
            <PriceBar
                price={price}
                instrument={instrumentFutureSpread}
            />
        );

        const labels = wrapper.find('.pricebar-label');

        expect(labels.length).toEqual(13);
        expect(labels.at(0).text()).toEqual(Localization.getText('HTML5_Bid'));
        expect(labels.at(1).text()).toEqual(Localization.getText('HTML5_Ask'));
        expect(labels.at(2).text()).toEqual(Localization.getText('HTML5_LastTraded'));
        expect(labels.at(3).text()).toEqual(Localization.getText('HTML5_NetChange'));
        expect(labels.at(4).text()).toEqual(Localization.getText('HTML5_PctChange'));
        expect(labels.at(5).text()).toEqual(Localization.getText('HTML5_Open'));
        expect(labels.at(6).text()).toEqual(Localization.getText('HTML5_Low'));
        expect(labels.at(7).text()).toEqual(Localization.getText('HTML5_High'));
        expect(labels.at(8).text()).toEqual(Localization.getText('HTML5_ExpiryDate'));
        expect(labels.at(9).text()).toEqual(Localization.getText('HTML5_PrevClose'));
        expect(labels.at(10).text()).toEqual(Localization.getText('HTML5_Volume'));
        expect(labels.at(11).text()).toEqual(Localization.getText('HTML5_LotSize'));
        expect(labels.at(12).text()).toEqual(Localization.getText('HTML5_LastUpdateLower'));
    });

    it('should not throw error if children are provided but not price', () => {
        wrapper = mount(
            <PriceBar instrument={instrumentFx}>
                {
                    (priceBarProps) => (<div ref={priceBarProps.setItemsEl}/>)
                }
            </PriceBar>
        );

        const price = priceFx._entry.data[0].Snapshot;

        expect(() => {
            wrapper = wrapper.setProps({
                price,
            });
        }).not.toThrow();
    });
});
