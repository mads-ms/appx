// maxOffset can only be initialized once the component has mounted,
// because it is calculated with the width values of the wrapper element
// and the pannable area's element.
/* eslint-disable react/no-did-mount-set-state */

import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { UI } from 'openui';
import classNames from 'classnames';
import { bindHandlers } from 'src/utils/bindHandlers';
import * as assetTypeQueries from 'src/modules/instruments/assetType/queries';
import * as pricesQueries from 'src/modules/pricesSubscription/queries';
import Pannable from 'src/components/touchable/pannable';
import PriceBarItemsFx from './priceBarItems/priceBarItemsFx';
import PriceBarItemsCfdIndex from './priceBarItems/priceBarItemsCfdIndex';
import PriceBarItemsCfdFuture from './priceBarItems/priceBarItemsCfdFuture';
import PriceBarItemsCfd from './priceBarItems/priceBarItemsCfd';
import PriceBarItemsContractOption from './priceBarItems/priceBarItemsContractOption';
import PriceBarItemsStockIndex from './priceBarItems/priceBarItemsStockIndex';
import PriceBarItemsStock from './priceBarItems/priceBarItemsStock';
import PriceBarItemsBond from './priceBarItems/priceBarItemsBond';
import PriceBarItemsFuture from './priceBarItems/priceBarItemsFuture';
import PriceBarItemsFutureSpread from './priceBarItems/priceBarItemsFutureSpread';
import Button from 'src/components/button/button';
import Icon from 'src/components/icon/icon';

class PriceBar extends React.PureComponent {
    constructor() {
        super();

        this.state = {
            isDragging: false,
            maxOffset: null,
            offset: 0,
            offsetDelta: 0,
        };

        this.setEl = (ref) => {
            this.el = ref;
        };

        this.setItemsEl = (ref) => {
            this.itemsEl = ref;
        };

        this.setOffset = _.debounce(this.setOffset, 100);
    }

    componentDidMount() {
        // initialize maxOffset
        this.setState({
            maxOffset: this.getMaxOffset(),
        });
    }

    componentWillReceiveProps(nextProps) {
        if (this.props.resizeTimestamp !== nextProps.resizeTimestamp) {
            const { offset } = this.state;

            // update maxOffset on resize
            const maxOffset = this.getMaxOffset();

            if (offset < maxOffset) {
                this.setOffset(maxOffset);
            }

            this.setState({
                maxOffset,
            });
        }
    }

    componentDidUpdate(prevProps) {
        const { instrument, price } = this.props;
        const previousPrice = prevProps.price;

        // reset offsets when the price's instrument changes, since
        // the items' dimensions will change after they've been rendered
        //
        // if the instrument is a contract option, check if the
        // pending state of the price changed to not pending. the price data doesn't
        // come populated in the snapshot, being only available
        // in subsequent updates
        if (price && previousPrice) {
            if ((price.Uic !== previousPrice.Uic || price.AssetType !== previousPrice.AssetType) ||
                (assetTypeQueries.isContractOption(instrument) && pricesQueries.isPending(previousPrice) &&
                !pricesQueries.isPending(price))) {
                // eslint-disable-next-line react/no-did-update-set-state
                this.setState({
                    offset: 0,
                    maxOffset: this.getMaxOffset(),
                });
            }
        }
    }

    getMaxOffset() {
        return this.el.clientWidth - this.itemsEl.clientWidth;
    }

    // debounce method to make offset adjustments smoother while resizing
    setOffset(offset) {
        // offset cannot be > 0
        this.setState({
            offset: offset > 0 ? 0 : offset,
        });
    }

    handleBackTap() {
        const { offset } = this.state;
        let nextOffset = offset + this.el.clientWidth / 2;

        if (nextOffset > 0) {
            nextOffset = 0;
        }

        this.setState({
            offset: nextOffset,
        });
    }

    handleFwdTap() {
        const { offset, maxOffset } = this.state;
        let nextOffset = offset - this.el.clientWidth / 2;

        if (nextOffset < maxOffset) {
            nextOffset = maxOffset;
        }

        this.setState({
            offset: nextOffset,
        });
    }

    handlePanStart() {
        this.setState({
            isDragging: true,
        });
    }

    handlePan(evt) {
        this.setState({
            offsetDelta: evt.deltaX,
        });
    }

    handlePanEnd() {
        const { offset, maxOffset, offsetDelta } = this.state;
        let finalOffset = offset + offsetDelta;

        if (finalOffset > 0) {
            finalOffset = 0;
        }

        if (finalOffset <= maxOffset) {
            finalOffset = maxOffset;
        }

        this.setState({
            isDragging: false,
            offset: finalOffset,
            offsetDelta: 0,
        });
    }

    getPriceBarItemsComponent() {
        const { instrument } = this.props;

        if (assetTypeQueries.isFx(instrument)) {
            return PriceBarItemsFx;
        }

        if (assetTypeQueries.isCfdIndex(instrument)) {
            return PriceBarItemsCfdIndex;
        }

        if (assetTypeQueries.isCfdFuture(instrument)) {
            return PriceBarItemsCfdFuture;
        }

        if (assetTypeQueries.isCfd(instrument)) {
            return PriceBarItemsCfd;
        }

        if (assetTypeQueries.isContractOption(instrument)) {
            return PriceBarItemsContractOption;
        }

        if (assetTypeQueries.isStockIndex(instrument)) {
            return PriceBarItemsStockIndex;
        }

        if (assetTypeQueries.isStock(instrument)) {
            return PriceBarItemsStock;
        }

        if (assetTypeQueries.isBond(instrument)) {
            return PriceBarItemsBond;
        }

        if (assetTypeQueries.isFuture(instrument)) {
            return PriceBarItemsFuture;
        }

        if (assetTypeQueries.isFutureSpread(instrument)) {
            return PriceBarItemsFutureSpread;
        }
    }

    render() {
        const { isAstroStyle, price, instrument, className } = this.props;
        const { isDragging, offset, maxOffset, offsetDelta } = this.state;
        const currentOffset = offset + offsetDelta;

        const priceBarClasses = classNames('tst-pricebar pricebar', className, {
            'pricebar--astro': isAstroStyle,
        });

        // buttons
        const backBtnClasses = classNames('tst-pricebar-back pricebar-back btn--inline', {
            [UI.Class.Hide]: currentOffset >= 0,
        });

        const fwdBtnClasses = classNames('tst-pricebar-fwd pricebar-fwd btn--inline', {
            [UI.Class.Hide]: currentOffset <= maxOffset,
        });

        // price bar items
        const priceBarItemsClasses = classNames('pricebar-items', {
            [UI.Class.Dragging]: isDragging,
        });

        const priceBarItemsStyle = {
            transform: `translate3d(${currentOffset}px, 0px, 0px)`,
        };

        let content;
        if (this.props.children) {
            content = this.props.children({
                priceBarItemsClasses,
                setItemsEl: this.setItemsEl,
                priceBarItemsStyle,
            });
        } else {
            const PriceBarItems = this.getPriceBarItemsComponent();
            content = (
                <PriceBarItems
                    className={priceBarItemsClasses}
                    setRef={this.setItemsEl}
                    style={priceBarItemsStyle}
                    price={price}
                    instrument={instrument}
                />
            );
        }

        return (
            <div ref={this.setEl} className={priceBarClasses}>
                <Pannable
                    onPanStart={this.handlePanStart}
                    onPan={this.handlePan}
                    onPanEnd={this.handlePanEnd}
                >
                    {content}
                </Pannable>
                <Button onTap={this.handleBackTap} className={backBtnClasses}>
                    <Icon type="back"/>
                </Button>
                <Button onTap={this.handleFwdTap} className={fwdBtnClasses}>
                    <Icon type="fwd"/>
                </Button>
            </div>
        );
    }
}

PriceBar.propTypes = {
    isAstroStyle: PropTypes.bool,
    price: PropTypes.object,
    instrument: PropTypes.object,
    resizeTimestamp: PropTypes.number,
    children: PropTypes.func,
    className: PropTypes.string,
};

PriceBar.defaultProps = {
    isAstroStyle: false,
    resizeTimestamp: Date.now(),
};

export default bindHandlers(PriceBar);
