import React from 'react';
import PropTypes from 'prop-types';
import Localization from 'src/localization';
import DefaultItem from './defaultItem';

class PerformanceLabel extends React.Component {
    shouldComponentUpdate(nextProps) {
        return this.props.instrument.Symbol !== nextProps.instrument.Symbol ||
            this.props.instrument.CurrencyCode !== nextProps.instrument.CurrencyCode;
    }

    render() {
        const { instrument } = this.props;
        const symbol = instrument.Symbol;
        const currencyCode = instrument.CurrencyCode;

        return (
            <DefaultItem
                className="tst-pricebar-performance-label"
                label={Localization.getText('HTML5_PricePerformance')}
            >
                {symbol} ({currencyCode})
            </DefaultItem>
        );
    }
}

PerformanceLabel.propTypes = {
    instrument: PropTypes.object,
};

export default PerformanceLabel;
