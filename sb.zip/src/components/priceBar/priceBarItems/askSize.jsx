import React from 'react';
import PropTypes from 'prop-types';
import * as numberFormat from 'src/numberFormat';
import Localization from 'src/localization';
import DefaultItem from './defaultItem';

class AskSize extends React.Component {
    shouldComponentUpdate(nextProps) {
        return this.props.price.PriceInfoDetails.AskSize !== nextProps.price.PriceInfoDetails.AskSize;
    }

    render() {
        const { price } = this.props;
        const value = price.PriceInfoDetails.AskSize;
        const formattedValue = numberFormat.format(value, 0);

        return (
            <DefaultItem
                className="tst-pricebar-ask-size"
                label={Localization.getText('HTML5_AskSize')}
            >
                {formattedValue}
            </DefaultItem>
        );
    }
}

AskSize.propTypes = {
    price: PropTypes.object,
};

export default AskSize;
