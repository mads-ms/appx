import React from 'react';
import PropTypes from 'prop-types';
import Localization from 'src/localization';
import * as instrumentExchangeQueries from 'src/modules/instruments/exchanges/queries';
import DefaultItem from './defaultItem';
import FormattedPrice from 'src/components/formattedPrice/formattedPrice';

class MidYield extends React.Component {
    shouldComponentUpdate(nextProps) {
        return this.props.price.InstrumentPriceDetails.MidYield !== nextProps.price.InstrumentPriceDetails.MidYield ||
            this.props.instrument !== nextProps.instrument;
    }

    render() {
        const { price, instrument } = this.props;
        const value = price.InstrumentPriceDetails.MidYield;

        // CSE Bonds, aka danish bonds, always have a mid yield of 0,
        // so there is no point in showing it
        if (instrumentExchangeQueries.isCseBond(instrument)) {
            return null;
        }

        return (
            <DefaultItem
                className="tst-pricebar-mid-yield"
                label={Localization.getText('HTML5_MidYield')}
            >
                <FormattedPrice
                    price={value}
                    instrument={instrument}
                />
            </DefaultItem>
        );
    }
}

MidYield.propTypes = {
    price: PropTypes.object,
    instrument: PropTypes.object,
};

export default MidYield;
