import React from 'react';
import PropTypes from 'prop-types';
import Localization from 'src/localization';
import DefaultItem from './defaultItem';

class LotSize extends React.Component {
    shouldComponentUpdate(nextProps) {
        return this.props.instrument.LotSizeText !== nextProps.instrument.LotSizeText;
    }

    render() {
        const value = this.props.instrument.LotSizeText || '-';

        return (
            <DefaultItem
                className="tst-pricebar-lot-size"
                label={Localization.getText('HTML5_LotSize')}
            >
                {value}
            </DefaultItem>
        );
    }
}

LotSize.propTypes = {
    instrument: PropTypes.object,
};

export default LotSize;
