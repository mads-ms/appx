import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import High from './high';
import LastClose from './lastClose';
import LastTraded from './lastTraded';
import LastUpdate from './lastUpdate';
import Low from './low';
import NetChange from './netChange';
import Open from './open';
import PctChange from './pctChange';
import Volume from './volume';

class PriceBarItemsStockIndex extends React.PureComponent {
    render() {
        const { className, setRef, style } = this.props;
        const classes = classNames('pricebar-items', className);

        return (
            <div
                ref={setRef}
                style={style}
                className={classes}
            >
                <LastTraded {...this.props}/>
                <NetChange {...this.props}/>
                <PctChange {...this.props}/>
                <Open {...this.props}/>
                <Low {...this.props}/>
                <High {...this.props}/>
                <LastClose {...this.props}/>
                <Volume {...this.props}/>
                <LastUpdate {...this.props}/>
            </div>
        );
    }
}

PriceBarItemsStockIndex.propTypes = {
    className: PropTypes.string,
    setRef: PropTypes.func,
    style: PropTypes.object,
    price: PropTypes.object,
    instrument: PropTypes.object,
};

export default PriceBarItemsStockIndex;
