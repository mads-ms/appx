import React from 'react';
import PropTypes from 'prop-types';
import Localization from 'src/localization';
import * as numberFormat from 'src/numberFormat';
import * as pricesSubscriptionQueries from 'src/modules/pricesSubscription/queries';
import DefaultItem from './defaultItem';

class Spread extends React.Component {
    shouldComponentUpdate(nextProps) {
        return this.props.price.Quote.Bid !== nextProps.price.Quote.Bid ||
            this.props.price.Quote.Ask !== nextProps.price.Quote.Ask ||
            this.props.instrument !== nextProps.instrument;
    }

    render() {
        const { price, instrument } = this.props;
        const { Bid, Ask } = price.Quote;

        const value = pricesSubscriptionQueries.getSpread({
            instrument,
            bid: Bid,
            ask: Ask,
        });

        const formattedValue = numberFormat.format(value);

        return (
            <DefaultItem
                className="tst-pricebar-spread"
                label={Localization.getText('HTML5_Spread')}
            >
                {formattedValue}
            </DefaultItem>
        );
    }
}

Spread.propTypes = {
    price: PropTypes.object,
    instrument: PropTypes.object,
};

export default Spread;
