import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import * as numberFormat from 'src/numberFormat';
import Localization from 'src/localization';
import DefaultItem from './defaultItem';

const PERIOD_MAP = {
    '1w': { label: Localization.getText('HTML5_TimeRange_1W'), key: 'PercentChangeWeekly' },
    '1m': { label: Localization.getText('HTML5_TimeRange_1M'), key: 'PercentChange1Month' },
    '3m': { label: Localization.getText('HTML5_TimeRange_3M'), key: 'PercentChange3Months' },
    '6m': { label: Localization.getText('HTML5_TimeRange_6M'), key: 'PercentChange6Months' },
    '1y': { label: Localization.getText('HTML5_TimeRange_1Y'), key: 'PercentChange1Year' },
    '2y': { label: Localization.getText('HTML5_TimeRange_2Y'), key: 'PercentChange2Years' },
    '5y': { label: Localization.getText('HTML5_TimeRange_5Y'), key: 'PercentChange5Years' },
};

class HistoricalChange extends React.Component {
    shouldComponentUpdate(nextProps) {
        return this.props.price.HistoricalChanges !== nextProps.price.HistoricalChanges ||
            this.props.period !== nextProps.period;
    }

    render() {
        const { price, period } = this.props;
        const value = price.HistoricalChanges && price.HistoricalChanges[PERIOD_MAP[period].key];
        const formattedValue = _.isFinite(value) ? numberFormat.formatPercentage(value, 2) : '-';

        const profitClass = classNames({
            'pricebar-value--profit': value > 0,
            'pricebar-value--loss': value < 0,
        });

        return (
            <DefaultItem
                className="tst-pricebar-pct-change"
                valueClassName={profitClass}
                label={PERIOD_MAP[period].label}
            >
                {formattedValue}
            </DefaultItem>
        );
    }
}

HistoricalChange.propTypes = {
    price: PropTypes.object,
    period: PropTypes.oneOf(_.keys(PERIOD_MAP)).isRequired,
};

export default HistoricalChange;
