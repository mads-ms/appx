import React from 'react';
import PropTypes from 'prop-types';
import Localization from 'src/localization';
import DateTime from 'src/modules/dateTime';
import DefaultItem from './defaultItem';

class ExpiryDate extends React.Component {
    shouldComponentUpdate(nextProps) {
        return this.props.instrument.ExpiryDate !== nextProps.instrument.ExpiryDate;
    }

    render() {
        const { instrument } = this.props;
        const value = instrument.ExpiryDate;
        const formattedValue = DateTime.formatUserDate(DateTime.createDate(value));

        return (
            <DefaultItem
                className="tst-pricebar-expiry-date"
                label={Localization.getText('HTML5_ExpiryDate')}
            >
                {formattedValue}
            </DefaultItem>
        );
    }
}

ExpiryDate.propTypes = {
    instrument: PropTypes.object,
};

export default ExpiryDate;
