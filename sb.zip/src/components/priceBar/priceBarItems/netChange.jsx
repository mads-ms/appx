import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import Localization from 'src/localization';
import DefaultItem from './defaultItem';
import FormattedPrice from 'src/components/formattedPrice/formattedPrice';

class NetChange extends React.Component {
    shouldComponentUpdate(nextProps) {
        return this.props.price.PriceInfo.NetChange !== nextProps.price.PriceInfo.NetChange ||
            this.props.instrument !== nextProps.instrument;
    }

    render() {
        const { price, instrument } = this.props;
        const value = price.PriceInfo.NetChange;

        const profitClass = classNames({
            'pricebar-value--profit': value > 0,
            'pricebar-value--loss': value < 0,
        });

        return (
            <DefaultItem
                className="tst-pricebar-net-change"
                valueClassName={profitClass}
                label={Localization.getText('HTML5_NetChange')}
            >
                <FormattedPrice
                    price={value}
                    instrument={instrument}
                />
            </DefaultItem>
        );
    }
}

NetChange.propTypes = {
    price: PropTypes.object,
    instrument: PropTypes.object,
};

export default NetChange;
