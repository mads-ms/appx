import React from 'react';
import PropTypes from 'prop-types';
import Localization from 'src/localization';
import * as numberFormat from 'src/numberFormat';
import * as assetTypeQueries from 'src/modules/instruments/assetType/queries';
import BidAskItem from './bidAskItem';
import DefaultItem from './defaultItem';

class Bid extends React.Component {
    shouldComponentUpdate(nextProps) {
        return this.props.price.Quote.Bid !== nextProps.price.Quote.Bid ||
            this.props.instrument !== nextProps.instrument;
    }

    render() {
        const { price, instrument } = this.props;
        const value = price.Quote.Bid;

        if (assetTypeQueries.isFx(instrument)) {
            return (
                <BidAskItem
                    className="tst-pricebar-bid"
                    label={Localization.getText('HTML5_Bid')}
                    price={value}
                    instrument={instrument}
                />
            );
        }

        const formattedValue = numberFormat.formatPrice(value, instrument.Format);

        return (
            <DefaultItem
                className="tst-pricebar-bid"
                label={Localization.getText('HTML5_Bid')}
            >
                {formattedValue}
            </DefaultItem>
        );
    }
}

Bid.propTypes = {
    price: PropTypes.object,
    instrument: PropTypes.object,
};

export default Bid;
