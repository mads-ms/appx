import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';

class RangeItem extends React.PureComponent {

    render() {
        const { className, label, value } = this.props;

        const style = {
            left: `${value}%`,
        };

        return (
            <div className={classNames('pricebar-item', className)}>
                <div className="tst-pricebar-label pricebar-label">{label}</div>
                <div className="pricebar-range">
                    <div className="pricebar-rangeindicator" style={style}></div>
                </div>
            </div>
        );
    }
}

RangeItem.propTypes = {
    className: PropTypes.string,
    label: PropTypes.string.isRequired,
    value: PropTypes.number,
};

export default RangeItem;
