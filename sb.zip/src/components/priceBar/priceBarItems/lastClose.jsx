import React from 'react';
import PropTypes from 'prop-types';
import Localization from 'src/localization';
import DefaultItem from './defaultItem';
import FormattedPrice from 'src/components/formattedPrice/formattedPrice';

class LastClose extends React.Component {
    shouldComponentUpdate(nextProps) {
        return this.props.price.PriceInfoDetails.LastTraded !== nextProps.price.PriceInfoDetails.LastTraded ||
            this.props.instrument !== nextProps.instrument;
    }

    render() {
        const { price, instrument } = this.props;
        const value = price.PriceInfoDetails.LastClose;

        return (
            <DefaultItem
                className="tst-pricebar-last-close"
                label={Localization.getText('HTML5_PrevClose')}
            >
                <FormattedPrice
                    price={value}
                    instrument={instrument}
                />
            </DefaultItem>
        );
    }
}

LastClose.propTypes = {
    price: PropTypes.object,
    instrument: PropTypes.object,
};

export default LastClose;
