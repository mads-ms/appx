import React from 'react';
import PropTypes from 'prop-types';
import Localization from 'src/localization';
import DefaultItem from './defaultItem';
import FormattedPrice from 'src/components/formattedPrice/formattedPrice';

class High extends React.Component {
    shouldComponentUpdate(nextProps) {
        return this.props.price.PriceInfo.High !== nextProps.price.PriceInfo.High ||
            this.props.instrument !== nextProps.instrument;
    }

    render() {
        const { price, instrument } = this.props;
        const value = price.PriceInfo.High;

        return (
            <DefaultItem
                className="tst-pricebar-high"
                label={Localization.getText('HTML5_High')}
            >
                <FormattedPrice
                    price={value}
                    instrument={instrument}
                />
            </DefaultItem>
        );
    }
}

High.propTypes = {
    price: PropTypes.object,
    instrument: PropTypes.object,
};

export default High;
