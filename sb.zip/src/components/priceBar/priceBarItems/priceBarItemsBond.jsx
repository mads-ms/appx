import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import Ask from './ask';
import Bid from './bid';
import LastClose from './lastClose';
import MidYield from './midYield';
import NetChange from './netChange';
import PctChange from './pctChange';

class PriceBarItemsBond extends React.PureComponent {
    render() {
        const { className, setRef, style } = this.props;
        const classes = classNames('pricebar-items', className);

        return (
            <div
                ref={setRef}
                style={style}
                className={classes}
            >
                <Bid {...this.props}/>
                <Ask {...this.props}/>
                <MidYield {...this.props}/>
                <NetChange {...this.props}/>
                <PctChange {...this.props}/>
                <LastClose {...this.props}/>
            </div>
        );
    }
}

PriceBarItemsBond.propTypes = {
    className: PropTypes.string,
    setRef: PropTypes.func,
    style: PropTypes.object,
    price: PropTypes.object,
    instrument: PropTypes.object,
};

export default PriceBarItemsBond;
