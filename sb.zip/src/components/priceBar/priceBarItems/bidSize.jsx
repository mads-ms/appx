import React from 'react';
import PropTypes from 'prop-types';
import * as numberFormat from 'src/numberFormat';
import Localization from 'src/localization';
import DefaultItem from './defaultItem';

class BidSize extends React.Component {
    shouldComponentUpdate(nextProps) {
        return this.props.price.PriceInfoDetails.BidSize !== nextProps.price.PriceInfoDetails.BidSize;
    }

    render() {
        const { price } = this.props;
        const value = price.PriceInfoDetails.BidSize;
        const formattedValue = numberFormat.format(value, 0);

        return (
            <DefaultItem
                className="tst-pricebar-bid-size"
                label={Localization.getText('HTML5_BidSize')}
            >
                {formattedValue}
            </DefaultItem>
        );
    }
}

BidSize.propTypes = {
    price: PropTypes.object,
};

export default BidSize;
