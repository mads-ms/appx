import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import * as numberFormat from 'src/numberFormat';
import Localization from 'src/localization';
import DefaultItem from './defaultItem';

class PctChange extends React.Component {
    shouldComponentUpdate(nextProps) {
        return this.props.price.PriceInfo.PercentChange !== nextProps.price.PriceInfo.PercentChange;
    }

    render() {
        const { price } = this.props;
        const value = price.PriceInfo.PercentChange;
        const formattedValue = _.isFinite(value) ? numberFormat.formatPercentage(value, 2) : '-';

        const profitClass = classNames({
            'pricebar-value--profit': value > 0,
            'pricebar-value--loss': value < 0,
        });

        return (
            <DefaultItem
                className="tst-pricebar-pct-change"
                valueClassName={profitClass}
                label={Localization.getText('HTML5_PctChange')}
            >
                {formattedValue}
            </DefaultItem>
        );
    }
}

PctChange.propTypes = {
    price: PropTypes.object,
};

export default PctChange;
