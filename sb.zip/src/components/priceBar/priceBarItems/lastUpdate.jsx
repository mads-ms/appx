import React from 'react';
import PropTypes from 'prop-types';
import Localization from 'src/localization';
import DateTime from 'src/modules/dateTime';
import DefaultItem from './defaultItem';

class LastUpdate extends React.Component {
    shouldComponentUpdate(nextProps) {
        return this.props.price.LastUpdated !== nextProps.price.LastUpdated;
    }

    render() {
        const { price } = this.props;
        const value = price.LastUpdated;
        const formattedValue = DateTime.formatUserTime(DateTime.createDateTime(value));

        return (
            <DefaultItem
                className="tst-pricebar-last-update"
                label={Localization.getText('HTML5_LastUpdateLower')}
            >
                {formattedValue}
            </DefaultItem>
        );
    }
}

LastUpdate.propTypes = {
    price: PropTypes.object,
};

export default LastUpdate;
