import React from 'react';
import PropTypes from 'prop-types';
import * as numberFormat from 'src/numberFormat';
import Localization from 'src/localization';
import DefaultItem from './defaultItem';

class Volume extends React.Component {
    shouldComponentUpdate(nextProps) {
        return this.props.price.PriceInfoDetails.Volume !== nextProps.price.PriceInfoDetails.Volume;
    }

    render() {
        const { price } = this.props;
        const value = price.PriceInfoDetails.Volume;
        const formattedValue = numberFormat.format(value, 0);

        if (value === 0) {
            return false;
        }

        return (
            <DefaultItem
                className="tst-pricebar-volume"
                label={Localization.getText('HTML5_Volume')}
            >
                {formattedValue}
            </DefaultItem>
        );
    }
}

Volume.propTypes = {
    price: PropTypes.object,
};

export default Volume;
