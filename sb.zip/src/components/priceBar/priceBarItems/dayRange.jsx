import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import Localization from 'src/localization';
import * as instrumentsQueries from 'src/modules/pricesSubscription/queries';
import RangeItem from './rangeItem';

class DayRange extends React.Component {
    shouldComponentUpdate(nextProps) {
        return this.props.price.PriceInfo.High !== nextProps.price.PriceInfo.High ||
            this.props.price.PriceInfo.Low !== nextProps.price.PriceInfo.Low ||
            this.props.price.Quote.Mid !== nextProps.price.Quote.Mid;
    }

    render() {
        const { price } = this.props;
        let value = instrumentsQueries.getDayRange(price);

        // range may in some cases be < 0 or > 100, so restrict min and max values
        value = _.clamp(value, 0, 100);

        return (
            <RangeItem
                className="tst-pricebar-day-change"
                label={Localization.getText('HTML5_DayRange')}
                value={value}
            />
        );
    }
}

DayRange.propTypes = {
    price: PropTypes.object,
};

export default DayRange;
