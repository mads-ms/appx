import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import Ask from './ask';
import AskSize from './askSize';
import Bid from './bid';
import BidSize from './bidSize';
import High from './high';
import LastClose from './lastClose';
import LastUpdate from './lastUpdate';
import Low from './low';
import NetChange from './netChange';
import Open from './open';
import PctChange from './pctChange';

class PriceBarItemsContractOption extends React.PureComponent {
    render() {
        const { className, setRef, style } = this.props;
        const classes = classNames('pricebar-items', className);

        return (
            <div
                ref={setRef}
                style={style}
                className={classes}
            >
                <Bid {...this.props}/>
                <Ask {...this.props}/>
                <NetChange {...this.props}/>
                <PctChange {...this.props}/>
                <Open {...this.props}/>
                <Low {...this.props}/>
                <High {...this.props}/>
                <LastClose {...this.props}/>
                <LastUpdate {...this.props}/>
                <BidSize {...this.props}/>
                <AskSize {...this.props}/>
            </div>
        );
    }
}

PriceBarItemsContractOption.propTypes = {
    className: PropTypes.string,
    setRef: PropTypes.func,
    style: PropTypes.object,
    price: PropTypes.object,
    instrument: PropTypes.object,
};

export default PriceBarItemsContractOption;
