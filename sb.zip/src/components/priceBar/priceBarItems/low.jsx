import React from 'react';
import PropTypes from 'prop-types';
import Localization from 'src/localization';
import DefaultItem from './defaultItem';
import FormattedPrice from 'src/components/formattedPrice/formattedPrice';

class Low extends React.Component {
    shouldComponentUpdate(nextProps) {
        return this.props.price.PriceInfo.Low !== nextProps.price.PriceInfo.Low ||
            this.props.instrument !== nextProps.instrument;
    }

    render() {
        const { price, instrument } = this.props;
        const value = price.PriceInfo.Low;

        return (
            <DefaultItem
                className="tst-pricebar-low"
                label={Localization.getText('HTML5_Low')}
            >
                <FormattedPrice
                    price={value}
                    instrument={instrument}
                />
            </DefaultItem>
        );
    }
}

Low.propTypes = {
    price: PropTypes.object,
    instrument: PropTypes.object,
};

export default Low;
