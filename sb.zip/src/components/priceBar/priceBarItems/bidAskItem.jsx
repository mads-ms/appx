import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import FxPrice from 'src/components/fxPrice/fxPrice';

class BidAskItem extends React.PureComponent {

    render() {
        const { className, label, price, instrument } = this.props;

        return (
            <div className={classNames('pricebar-item', className)}>
                <div className="tst-pricebar-label pricebar-label">{label}</div>
                <div className="tst-pricebar-value pricebar-fxprice">
                    <FxPrice
                        instrument={instrument}
                        price={price}
                    />
                </div>
            </div>
        );
    }
}

BidAskItem.propTypes = {
    className: PropTypes.string,
    label: PropTypes.string.isRequired,
    price: PropTypes.number,
    instrument: PropTypes.object.isRequired,
};

export default BidAskItem;
