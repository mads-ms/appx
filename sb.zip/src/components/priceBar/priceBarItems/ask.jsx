import React from 'react';
import PropTypes from 'prop-types';
import Localization from 'src/localization';
import * as numberFormat from 'src/numberFormat';
import * as assetTypeQueries from 'src/modules/instruments/assetType/queries';
import BidAskItem from './bidAskItem';
import DefaultItem from './defaultItem';

class Ask extends React.Component {
    shouldComponentUpdate(nextProps) {
        return this.props.price.Quote.Ask !== nextProps.price.Quote.Ask ||
            this.props.instrument !== nextProps.instrument;
    }

    render() {
        const { price, instrument } = this.props;
        const value = price.Quote.Ask;

        if (assetTypeQueries.isFx(instrument)) {
            return (
                <BidAskItem
                    className="tst-pricebar-ask"
                    label={Localization.getText('HTML5_Ask')}
                    price={value}
                    instrument={instrument}
                />
            );
        }

        const formattedValue = numberFormat.formatPrice(value, instrument.Format);

        return (
            <DefaultItem
                className="tst-pricebar-ask"
                label={Localization.getText('HTML5_Ask')}
            >
                {formattedValue}
            </DefaultItem>
        );
    }
}

Ask.propTypes = {
    price: PropTypes.object,
    instrument: PropTypes.object,
};

export default Ask;
