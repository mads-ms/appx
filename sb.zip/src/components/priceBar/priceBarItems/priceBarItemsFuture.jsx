import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import ExpiryDate from './expiryDate';
import High from './high';
import LastClose from './lastClose';
import LastTraded from './lastTraded';
import LastUpdate from './lastUpdate';
import LotSize from './lotSize';
import Low from './low';
import NetChange from './netChange';
import Open from './open';
import PctChange from './pctChange';
import Volume from './volume';

class PriceBarItemsFuture extends React.PureComponent {
    render() {
        const { className, setRef, style } = this.props;
        const classes = classNames('pricebar-items', className);

        return (
            <div
                ref={setRef}
                style={style}
                className={classes}
            >
                <LastTraded {...this.props}/>
                <NetChange {...this.props}/>
                <PctChange {...this.props}/>
                <Open {...this.props}/>
                <Low {...this.props}/>
                <High {...this.props}/>
                <ExpiryDate {...this.props}/>
                <LastClose {...this.props}/>
                <Volume {...this.props}/>
                <LotSize {...this.props}/>
                <LastUpdate {...this.props}/>
            </div>
        );
    }
}

PriceBarItemsFuture.propTypes = {
    className: PropTypes.string,
    setRef: PropTypes.func,
    style: PropTypes.object,
    price: PropTypes.object,
    instrument: PropTypes.object,
};

export default PriceBarItemsFuture;
