import React from 'react';
import PropTypes from 'prop-types';
import Localization from 'src/localization';
import DefaultItem from './defaultItem';
import FormattedPrice from 'src/components/formattedPrice/formattedPrice';

class LastTraded extends React.Component {
    shouldComponentUpdate(nextProps) {
        return this.props.price.PriceInfoDetails.LastTraded !== nextProps.price.PriceInfoDetails.LastTraded ||
            this.props.instrument !== nextProps.instrument;
    }

    render() {
        const { price, instrument } = this.props;
        const value = price.PriceInfoDetails.LastTraded;

        return (
            <DefaultItem
                className="tst-pricebar-last-traded"
                label={Localization.getText('HTML5_LastTraded')}
            >
                <FormattedPrice
                    price={value}
                    instrument={instrument}
                />
            </DefaultItem>
        );
    }
}

LastTraded.propTypes = {
    price: PropTypes.object,
    instrument: PropTypes.object,
};

export default LastTraded;
