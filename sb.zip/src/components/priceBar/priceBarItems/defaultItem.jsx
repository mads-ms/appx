import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';

class DefaultItem extends React.PureComponent {

    render() {
        const { className, valueClassName, label, children } = this.props;

        return (
            <div className={classNames('pricebar-item', className)}>
                <div className="tst-pricebar-label pricebar-label">{label}</div>
                <div className={classNames('tst-pricebar-value pricebar-value', valueClassName)}>
                    {children}
                </div>
            </div>
        );
    }
}

DefaultItem.propTypes = {
    className: PropTypes.string,
    valueClassName: PropTypes.string,
    label: PropTypes.string.isRequired,
};

export default DefaultItem;
