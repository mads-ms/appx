import React from 'react';

class ProComboInputLabel extends React.PureComponent {
    render() {
        const { children } = this.props;

        return (
            <div className="procomboinput-label t-truncate tst-procomboinput-label">
                {children}
            </div>
        );
    }
}

export default ProComboInputLabel;
