import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { bindHandlers } from 'src/utils/bindHandlers';
import Touchable from 'src/components/touchable/touchable';

class Toggle extends React.PureComponent {

    handleTap() {
        const { items, value } = this.props;

        // at least two items can be toggled
        if (items.length < 2) {
            return;
        }

        this.props.onChange({
            value: items[0].value === value ? items[1].value : items[0].value,
        });
    }

    render() {
        const { children } = this.props;

        return (
            <Touchable onTap={this.handleTap}>
                {children}
            </Touchable>
        );
    }

}

Toggle.propTypes = {
    value: PropTypes.any,
    items: PropTypes.array.isRequired,
    onChange: PropTypes.func,
};

Toggle.defaultProps = {
    onChange: _.noop,
};

export default bindHandlers(Toggle);
