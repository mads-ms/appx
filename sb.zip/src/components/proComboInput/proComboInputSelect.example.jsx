import React from 'react';
import { examplesOf } from 'src/modules/examples/utils';
import ProComboInput from 'src/components/proComboInput/proComboInput';
import ProComboInputLabel from 'src/components/proComboInput/proComboInputLabel';
import ProComboInputSelect from 'src/components/proComboInput/proComboInputSelect';

const label = 'Select';
const items = [
    {
        text: 'Item #1',
        value: '1',
    },
    {
        text: 'Item #2',
        value: '2',
    },
];
const value = '1';

export default examplesOf('Pro Combo Input Select')
    .add('Default', ({ action }) => (
        <ProComboInput>
            <ProComboInputLabel>
                {label}
            </ProComboInputLabel>
            <ProComboInputSelect
                items={items}
                value={value}
                menuTitle={label}
                onChange={action('onChange')}
            />
        </ProComboInput>
    ))
    .add('Validation error', ({ action }) => {
        const validation = {
            type: 'error',
            message: 'Lorem ipsum dolor sit amet consectetur adipisicing elit',
        };

        return (
            <ProComboInput validation={validation}>
                <ProComboInputLabel>
                    {label}
                </ProComboInputLabel>
                <ProComboInputSelect
                    items={items}
                    value={value}
                    menuTitle={label}
                    onChange={action('onChange')}
                />
            </ProComboInput>
        );
    })
    .add('Disabled', ({ action }) => (
        <ProComboInput>
            <ProComboInputLabel>
                {label}
            </ProComboInputLabel>
            <ProComboInputSelect
                items={items}
                value={value}
                menuTitle={label}
                onChange={action('onChange')}
                isEnabled={false}
            />
        </ProComboInput>
    ))
    .add('Default (compact)', ({ action }) => (
        <ProComboInput isCompact>
            <ProComboInputLabel>
                {label}
            </ProComboInputLabel>
            <ProComboInputSelect
                items={items}
                value={value}
                menuTitle={label}
                onChange={action('onChange')}
            />
        </ProComboInput>
    ))
    .add('Validation error (compact)', ({ action }) => {
        const validation = {
            type: 'error',
            message: 'Lorem ipsum dolor sit amet consectetur adipisicing elit',
        };

        return (
            <ProComboInput
                validation={validation}
                isCompact
            >
                <ProComboInputLabel>
                    {label}
                </ProComboInputLabel>
                <ProComboInputSelect
                    items={items}
                    value={value}
                    menuTitle={label}
                    onChange={action('onChange')}
                />
            </ProComboInput>
        );
    })
    .add('Disabled (compact)', ({ action }) => (
        <ProComboInput
            isEnabled={false}
            isCompact
        >
            <ProComboInputLabel>
                {label}
            </ProComboInputLabel>
            <ProComboInputSelect
                items={items}
                value={value}
                menuTitle={label}
                onChange={action('onChange')}
                isEnabled={false}
            />
        </ProComboInput>
    ));
