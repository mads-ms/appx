import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import Carousel from './carousel';
import Select from './select';
import SelectedValue from './selectedValue';

class ProComboInputSelect extends React.PureComponent {
    render() {
        const {
            value,
            items,
            menuTitle,
            dialogParent,
            isEnabled,
            onChange,
        } = this.props;

        let content = (
            <SelectedValue
                value={value}
                items={items}
            />
        );

        // If only one item is present and that too selected, don't render the carousel
        if (items.length === 1 && _.find(items, { value })) {
            return content;
        }

        if (isEnabled) {
            content = (
                <Carousel
                    value={value}
                    items={items}
                    onChange={onChange}
                >
                    <Select
                        value={value}
                        items={items}
                        menuTitle={menuTitle}
                        dialogParent={dialogParent}
                        onChange={onChange}
                    >
                        {content}
                    </Select>
                </Carousel>
            );
        }

        return content;
    }
}

ProComboInputSelect.propTypes = {
    value: PropTypes.any,
    items: PropTypes.array.isRequired,
    menuTitle: PropTypes.string,
    dialogParent: PropTypes.instanceOf(HTMLElement),
    isEnabled: PropTypes.bool,
    onChange: PropTypes.func,
};

ProComboInputSelect.defaultProps = {
    isEnabled: true,
};

export default ProComboInputSelect;
