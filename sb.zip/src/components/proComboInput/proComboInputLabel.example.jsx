import React from 'react';
import { examplesOf } from 'src/modules/examples/utils';
import TooltipButton from 'src/components/tooltipDialog/tooltipButton';
import ProComboInput from './proComboInput';
import ProComboInputLabel from './proComboInputLabel';
import ProComboInputNumber from './proComboInputNumber';

export default examplesOf('Pro Combo Input Label')
    .add('Default', () => (
        <ProComboInput>
            <ProComboInputLabel>Default</ProComboInputLabel>
            <ProComboInputNumber
                value={10}
            />
        </ProComboInput>
    ))
    .add('Tooltip popup', () => (
        <ProComboInput>
            <ProComboInputLabel>
                Tooltip popup
                <TooltipButton
                    isAstroStyle
                    tooltipTitle="title"
                    tooltipText="tooltip text"
                />
            </ProComboInputLabel>
            <ProComboInputNumber
                value={10}
            />
        </ProComboInput>
    ))
    .add('Tooltip card', () => (
        <ProComboInput>
            <ProComboInputLabel>
                Tooltip card
                <TooltipButton
                    isAstroStyle
                    tooltipDialogType="card"
                    tooltipPosition="bottom"
                    tooltipTitle="title"
                    tooltipText="tooltip text"
                />
            </ProComboInputLabel>
            <ProComboInputNumber
                value={10}
            />
        </ProComboInput>
    ))
    .add('Tooltip popup (compact)', () => (
        <ProComboInput isCompact>
            <ProComboInputLabel>
                Tooltip popup
                <TooltipButton
                    isAstroStyle
                    tooltipTitle="title"
                    tooltipText="tooltip text"
                />
            </ProComboInputLabel>
            <ProComboInputNumber
                value={10}
            />
        </ProComboInput>
    ))
    .add('Tooltip card (compact)', () => (
        <ProComboInput isCompact>
            <ProComboInputLabel>
                Tooltip card
                <TooltipButton
                    isAstroStyle
                    tooltipDialogType="card"
                    tooltipPosition="bottom"
                    tooltipTitle="title"
                    tooltipText="tooltip text"
                />
            </ProComboInputLabel>
            <ProComboInputNumber
                value={10}
            />
        </ProComboInput>
    ));
