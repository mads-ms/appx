import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';

class SelectedValue extends React.PureComponent {
    render() {
        const { value, items, isAction } = this.props;
        const selectedItem = _.find(items, (item) => item.value === value);
        const valueText = selectedItem ? selectedItem.text : value;
        const className = classNames('procomboinput-value t-truncate tst-procomboinput-selected-value', {
            'procomboinput-value--action': isAction,
        });

        return (
            <div className={className}>
                {valueText}
            </div>
        );
    }
}

SelectedValue.propTypes = {
    value: PropTypes.any,
    items: PropTypes.array.isRequired,
    isAction: PropTypes.bool,
};

export default SelectedValue;
