import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { bindHandlers } from 'src/utils/bindHandlers';
import Localization from 'src/localization';
import dateTime from 'src/modules/dateTime';
import config from 'src/config';

const DEFAULT_DATE_PLACEHOLDER = '1970-01-01';
const TIME_FORMAT_IS_12_HRS = config.dateTime.pattern.shortTime === 'h:mm tt';
const EMPTY_PLACEHOLDER = TIME_FORMAT_IS_12_HRS ? Localization.getText('HTML5_EnterTime_12hrs') : Localization.getText('HTML5_EnterTime_24hrs');
const VALIDATION_24_HRS_REGEX = /^([01]?[0-9]|2[0-3]):([0-5][0-9])$/;
const VALIDATION_12_HRS_REGEX = /^(0?[0-9]|1[012]):([0-5][0-9])[\s]*(AM|PM)$/i;

class TimeInput extends React.PureComponent {
    constructor(props) {
        super(props);

        this.state = { value: this.formatValue(props.value) };

        this.setEl = (ref) => {
            this.el = ref;
        };
    }

    componentDidMount() {
        if (this.props.isFocused) {
            this.el.focus();
            this.el.setSelectionRange(0, this.el.value.length);
        }
    }

    componentWillReceiveProps({ value }) {
        const isValid = this.validateTime(value);

        // this avoids wiping invalid values.
        if (value === this.props.value || !isValid) {
            return;
        }

        this.setState({
            value: this.formatValue(value),
        });
    }

    handleKeyDown(evt) {
        switch (evt.key) {
            case 'Enter':
                evt.target.blur();
                break;
        }
    }

    handleChange() {
        this.setState({ value: this.el.value });
    }

    handleFocus() {
        const inputValue = this.el.value;

        // auto-select text
        this.el.setSelectionRange(0, inputValue.length);
        this.props.onFocus();
    }

    handleBlur() {
        const inputValue = this.el.value;
        const isValid = this.validateTime(inputValue);

        if (isValid) {
            const value = this.formatValue(inputValue);
            this.setState({ value });
            this.props.onChange({
                value: this.parseValue(inputValue),
            });
        } else {
            // Send blank string to differentiate between off state and empty on state
            this.props.onChange({ value: '' });
        }

        this.props.onBlur();
    }

    validateTime(value) {
        return Boolean(VALIDATION_24_HRS_REGEX.test(value)) || Boolean(VALIDATION_12_HRS_REGEX.test(value));
    }

    formatValue(value) {
        const isValid = this.validateTime(value);

        if (!isValid) {
            return '';
        }

        let result = value.match(VALIDATION_12_HRS_REGEX);
        let time = value;

        if (result && result.length === 4) {
            time = this.convertTo24HoursFormat(result[1], result[2], result[3]);
        } else {
            result = value.match(VALIDATION_24_HRS_REGEX);
            time = `${_.padStart(result[1], 2, '0')}:${result[2]}`;
        }

        return dateTime.formatUserTime(
            dateTime.createDateTime(`${DEFAULT_DATE_PLACEHOLDER}T${time}`),
            { showSeconds: false }
        );
    }

    parseValue(value) {
        // convert to 24 hr format
        const is24HrFormatResult = value.match(VALIDATION_24_HRS_REGEX);

        if (is24HrFormatResult) {
            return `${_.padStart(is24HrFormatResult[1], 2, '0')}:${is24HrFormatResult[2]}`;
        }

        const result = value.match(VALIDATION_12_HRS_REGEX);

        if (result && result.length === 4) {
            return this.convertTo24HoursFormat(result[1], result[2], result[3]);
        }

        return value;
    }

    convertTo24HoursFormat(hours, minutes, suffix) {
        let convertedHours = _.toUpper(suffix) === 'AM' ? parseInt(hours, 10) % 12 : (parseInt(hours, 10) % 12) + 12;
        convertedHours = _.padStart(convertedHours, 2, '0');
        return `${convertedHours}:${minutes}`;
    }

    render() {
        const { isEnabled } = this.props;
        const { value } = this.state;

        return (
            <input
                ref={this.setEl}
                type="text"
                className="procomboinput-input tst-procomboinput-time-input t-truncate"
                disabled={!isEnabled}
                value={value}
                onKeyDown={this.handleKeyDown}
                onChange={this.handleChange}
                onFocus={this.handleFocus}
                onBlur={this.handleBlur}
                placeholder={EMPTY_PLACEHOLDER}
            />
        );
    }

}

TimeInput.propTypes = {
    value: PropTypes.string,
    isFocused: PropTypes.bool,
    isEnabled: PropTypes.bool,
    onFocus: PropTypes.func,
    onBlur: PropTypes.func,
    onChange: PropTypes.func,
};

TimeInput.defaultProps = {
    isFocused: false,
    isEnabled: true,
    onFocus: _.noop,
    onBlur: _.noop,
    onChange: _.noop,
};

export default bindHandlers(TimeInput);
