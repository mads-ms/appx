import React from 'react';
import PropTypes from 'prop-types';
import Select from './select';
import InputButton from './inputButton';

class InputSelect extends React.PureComponent {
    render() {
        const {
            value,
            items,
            menuTitle,
            dialogParent,
            isShown,
            onChange,
        } = this.props;

        return (
            <Select
                value={value}
                items={items}
                menuTitle={menuTitle}
                dialogParent={dialogParent}
                onChange={onChange}
            >
                <InputButton
                    iconType="toggle"
                    isShown={isShown}
                />
            </Select>
        );
    }
}

InputSelect.propTypes = {
    value: PropTypes.any,
    items: PropTypes.array,
    menuTitle: PropTypes.string,
    dialogParent: PropTypes.instanceOf(HTMLElement),
    isShown: PropTypes.bool,
    onChange: PropTypes.func,
};

export default InputSelect;
