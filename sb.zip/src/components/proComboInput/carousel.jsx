import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { bindHandlers } from 'src/utils/bindHandlers';
import Touchable from 'src/components/touchable/touchable';
import Icon from 'src/components/icon/icon';

class Carousel extends React.PureComponent {
    handleNextTap() {
        this.selectNextValue(1);
    }

    handlePrevTap() {
        this.selectNextValue(-1);
    }

    selectNextValue(offset) {
        const { value, items } = this.props;
        const index = _.findIndex(items, (item) => item.value === value);
        const lastIndex = items.length - 1;

        let nextIndex = index + offset;
        if (nextIndex < 0) {
            nextIndex = lastIndex;
        } else if (nextIndex > lastIndex) {
            nextIndex = 0;
        }

        this.props.onChange({
            value: items[nextIndex].value,
        });
    }

    render() {
        const { children } = this.props;

        return (
            <div className="grid grid--fit-fill-fit grid--cross-center">
                <div className="grid-cell">
                    <Touchable onTap={this.handlePrevTap}>
                        <Icon className="procomboinput-icon tst-procomboinput-icon-back" type="back"/>
                    </Touchable>
                </div>
                <div className="grid-cell">
                    {children}
                </div>
                <div className="grid-cell">
                    <Touchable onTap={this.handleNextTap}>
                        <Icon className="procomboinput-icon tst-procomboinput-icon-fwd" type="fwd"/>
                    </Touchable>
                </div>
            </div>
        );
    }

}

Carousel.propTypes = {
    value: PropTypes.any,
    items: PropTypes.array.isRequired,
    onChange: PropTypes.func,
};

Carousel.defaultProps = {
    onChange: _.noop,
};

export default bindHandlers(Carousel);
