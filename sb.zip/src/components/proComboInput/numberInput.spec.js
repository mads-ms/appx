import React from 'react';
import { mount } from 'enzyme';
import NumberInput from 'src/components/proComboInput/numberInput';

describe('src/components/proComboInput/numberInput', () => {

    describe('formats a value', () => {

        it('with the default formatter', () => {
            const wrapper = mount(<NumberInput/>);

            expect(wrapper.instance().formatValue(1000)).toBe('1,000');
            expect(wrapper.instance().formatValue(1.23)).toBe('1.23');
        });

        it('with a custom formatter', () => {
            const formatter = (num) => num + 'x';

            const wrapper = mount(<NumberInput formatter={formatter}/>);

            expect(wrapper.instance().formatValue(1000)).toBe('1000x');
            expect(wrapper.instance().formatValue(1.23)).toBe('1.23x');
        });

    });

    describe('parses a value', () => {

        it('with the default parser', () => {
            const wrapper = mount(<NumberInput/>);

            expect(wrapper.instance().parseValue('1,000')).toBe(1000);
            expect(wrapper.instance().parseValue('1.23')).toBe(1.23);
        });

        it('with a custom parser', () => {
            const parser = (str) => Number(str.replace('x', ''));

            const wrapper = mount(<NumberInput parser={parser}/>);

            expect(wrapper.instance().parseValue('1000x')).toBe(1000);
            expect(wrapper.instance().parseValue('x1.23')).toBe(1.23);
        });

    });

    describe('truncates a value', () => {

        it('when the value is larger than max length', () => {
            const maxLength = 5;

            const wrapper = mount(<NumberInput maxLength={maxLength}/>);

            expect(wrapper.instance().truncateValue('123456')).toBe('12345');
        });

        it('not when the value is smaller than or equal to max length', () => {
            const maxLength = 5;

            const wrapper = mount(<NumberInput maxLength={maxLength}/>);

            expect(wrapper.instance().truncateValue('123')).toBe('123');
            expect(wrapper.instance().truncateValue('12345')).toBe('12345');
        });

    });

    describe('renders a formatted value', () => {

        it('when mounted', () => {
            const wrapper = mount(<NumberInput value={1000}/>);
            const input = wrapper.getDOMNode();

            expect(input.value).toBe('1,000');
        });

        it('when the value changes', () => {
            const wrapper = mount(<NumberInput value={1000}/>);
            const input = wrapper.getDOMNode();

            wrapper.setProps({ value: 1500 });

            expect(input.value).toBe('1,500');
        });

        it('when the formatter changes', () => {
            const wrapper = mount(<NumberInput value={1000}/>);
            const input = wrapper.getDOMNode();

            wrapper.setProps({ formatter: (value) => `$${value}` });

            expect(input.value).toBe('$1000');
        });

        it('not when the value changes while focused', () => {
            const wrapper = mount(<NumberInput value={1000}/>);
            const input = wrapper.getDOMNode();

            wrapper.simulate('focus');
            wrapper.setProps({ value: 1500 });

            expect(input.value).toBe('1,000');
        });

        it('not when the formatter changes while focused', () => {
            const wrapper = mount(<NumberInput value={1000}/>);
            const input = wrapper.getDOMNode();

            wrapper.simulate('focus');
            wrapper.setProps({ formatter: (value) => `$${value}` });

            expect(input.value).toBe('1,000');
        });
    });

    describe('calls onChange', () => {

        it('with a number when a new valid value is entered', () => {
            const value = 1000;
            const onChange = jasmine.createSpy('onChange');

            const wrapper = mount(<NumberInput value={value} onChange={onChange}/>);
            const input = wrapper.getDOMNode();

            input.value = '2,000';
            wrapper.simulate('change');

            expect(onChange).toHaveBeenCalledTimes(1);
            expect(onChange).toHaveBeenCalledWith({ value: 2000 });
        });

        it('with null when a new invalid value is entered', () => {
            const value = 1000;
            const onChange = jasmine.createSpy('onChange');

            const wrapper = mount(<NumberInput value={value} onChange={onChange}/>);
            const input = wrapper.getDOMNode();

            input.value = 'abc';
            wrapper.simulate('change');

            expect(onChange).toHaveBeenCalledTimes(1);
            expect(onChange).toHaveBeenCalledWith({ value: null });
        });

        it('when the same value is entered', () => {
            const value = 1000;
            const onChange = jasmine.createSpy('onChange');

            const wrapper = mount(<NumberInput value={value} onChange={onChange}/>);
            const input = wrapper.getDOMNode();

            input.value = '1,000';
            wrapper.simulate('change');

            expect(onChange).toHaveBeenCalledTimes(1);
            expect(onChange).toHaveBeenCalledWith({ value: 1000 });
        });

    });

    describe('calls onClear', () => {

        it('when the value is emptied', () => {
            const value = 100;
            const onClear = jasmine.createSpy('onClear');

            const wrapper = mount(<NumberInput value={value} onClear={onClear}/>);
            const input = wrapper.getDOMNode();

            input.value = '10';
            wrapper.simulate('change');

            expect(onClear).not.toHaveBeenCalled();

            input.value = '1';
            wrapper.simulate('change');

            expect(onClear).not.toHaveBeenCalled();

            input.value = '';
            wrapper.simulate('change');

            expect(onClear).toHaveBeenCalledTimes(1);
            expect(onClear).toHaveBeenCalledWith();
        });
    });

    describe('resets formatting on blur', () => {

        it('when a new value is entered', () => {
            const initialValue = 1000;

            // eslint-disable-next-line no-use-before-define
            const onChange = ({ value }) => wrapper.setProps({ value });

            const wrapper = mount(<NumberInput value={initialValue} onChange={onChange}/>);
            const input = wrapper.getDOMNode();

            expect(input.value).toBe('1,000');

            wrapper.simulate('focus');
            input.value = '2,000';
            wrapper.simulate('change');
            wrapper.simulate('blur');

            expect(input.value).toBe('2,000');
        });

        it('when the same value is entered with a different format', () => {
            const initialValue = 1000;

            // eslint-disable-next-line no-use-before-define
            const onChange = ({ value }) => wrapper.setProps({ value });

            const wrapper = mount(<NumberInput value={initialValue} onChange={onChange}/>);
            const input = wrapper.getDOMNode();

            expect(input.value).toBe('1,000');

            wrapper.simulate('focus');
            input.value = '1000';
            wrapper.simulate('change');
            wrapper.simulate('blur');

            expect(input.value).toBe('1,000');
        });

        it('when the value is emptied', () => {
            const initialValue = 1000;

            // eslint-disable-next-line no-use-before-define
            const onChange = ({ value }) => wrapper.setProps({ value });
            const formatter = (value) => value === null ? 'EMPTY' : value;

            const wrapper = mount(<NumberInput value={initialValue} onChange={onChange} formatter={formatter}/>);
            const input = wrapper.getDOMNode();

            expect(input.value).toBe('1000');

            wrapper.simulate('focus');
            input.value = '';
            wrapper.simulate('change');
            wrapper.simulate('blur');

            expect(input.value).toBe('EMPTY');
        });

        it('when the value is incremented', () => {
            const initialValue = 1000;

            // eslint-disable-next-line no-use-before-define
            const onIncrement = () => wrapper.setProps({ value: initialValue + 1 });

            const wrapper = mount(<NumberInput value={initialValue} onIncrement={onIncrement}/>);
            const input = wrapper.getDOMNode();

            expect(input.value).toBe('1,000');

            wrapper.simulate('focus');
            wrapper.simulate('keyDown', { key: 'ArrowUp' });

            expect(input.value).toBe('1,001');
        });

        it('when the value is decremented', () => {
            const initialValue = 1000;

            // eslint-disable-next-line no-use-before-define
            const onDecrement = () => wrapper.setProps({ value: initialValue - 1 });

            const wrapper = mount(<NumberInput value={initialValue} onDecrement={onDecrement}/>);
            const input = wrapper.getDOMNode();

            expect(input.value).toBe('1,000');

            wrapper.simulate('focus');
            wrapper.simulate('keyDown', { key: 'ArrowDown' });

            expect(input.value).toBe('999');
        });

        it('not while the input is focused', () => {
            const initialValue = 1000;

            // eslint-disable-next-line no-use-before-define
            const onChange = ({ value }) => wrapper.setProps({ value });

            const wrapper = mount(<NumberInput value={initialValue} onChange={onChange}/>);
            const input = wrapper.getDOMNode();

            expect(input.value).toBe('1,000');

            wrapper.simulate('focus');
            input.value = '1';
            wrapper.simulate('change');

            expect(input.value).toBe('1');
        });

        it('not when an invalid value is entered', () => {
            const initialValue = 1000;

            // eslint-disable-next-line no-use-before-define
            const onChange = ({ value }) => wrapper.setProps({ value });

            const wrapper = mount(<NumberInput value={initialValue} onChange={onChange}/>);
            const input = wrapper.getDOMNode();

            expect(input.value).toBe('1,000');

            wrapper.simulate('focus');
            input.value = 'abc';
            wrapper.simulate('change');
            wrapper.simulate('blur');

            expect(input.value).toBe('abc');
        });
    });

});
