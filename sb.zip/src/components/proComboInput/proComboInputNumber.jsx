import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { bindHandlers } from 'src/utils/bindHandlers';
import Incrementer from './incrementer';
import NumberInput from './numberInput';
import InputSelect from './inputSelect';
import InputClear from './inputClear';

class ProComboInputNumber extends React.PureComponent {
    constructor() {
        super();

        this.state = {
            isInputFocused: false,
        };
    }

    handleInputFocus() {
        this.setState({
            isInputFocused: true,
        });

        this.props.onFocus();
    }

    handleInputBlur() {
        this.setState({
            isInputFocused: false,
        });

        this.props.onBlur();
    }

    handleInputClear() {
        this.props.onClear();
    }

    render() {
        const {
            hasSelect,
            hasClear,
            placeholder,
            value,
            items,
            menuTitle,
            dialogParent,
            parser,
            formatter,
            maxLength,
            isEnabled,
            onChange,
            onIncrement,
            onDecrement,
            onClear,
        } = this.props;

        const { isInputFocused } = this.state;

        let content = (
            <NumberInput
                isEnabled={isEnabled}
                placeholder={placeholder}
                value={value}
                parser={parser}
                formatter={formatter}
                maxLength={maxLength}
                onFocus={this.handleInputFocus}
                onBlur={this.handleInputBlur}
                onClear={this.handleInputClear}
                onChange={onChange}
                onIncrement={onIncrement}
                onDecrement={onDecrement}
            />
        );

        if (isEnabled) {
            content = (
                <Incrementer
                    onIncrement={onIncrement}
                    onDecrement={onDecrement}
                >
                    {content}
                    {hasSelect &&
                        <InputSelect
                            isShown={isInputFocused}
                            items={items}
                            value={value}
                            menuTitle={menuTitle}
                            dialogParent={dialogParent}
                            onChange={onChange}
                        />
                    }
                    {hasClear &&
                        <InputClear
                            isShown={isInputFocused}
                            onClear={onClear}
                        />
                    }
                </Incrementer>
            );
        }

        return content;
    }

}

ProComboInputNumber.propTypes = {
    hasSelect: PropTypes.bool,
    hasClear: PropTypes.bool,
    value: PropTypes.number,
    placeholder: PropTypes.string,
    items: PropTypes.array,
    menuTitle: PropTypes.string,
    dialogParent: PropTypes.instanceOf(HTMLElement),
    parser: PropTypes.func,
    formatter: PropTypes.func,
    maxLength: PropTypes.number,
    isEnabled: PropTypes.bool,
    onFocus: PropTypes.func,
    onBlur: PropTypes.func,
    onChange: PropTypes.func,
    onIncrement: PropTypes.func,
    onDecrement: PropTypes.func,
    onClear: PropTypes.func,
};

ProComboInputNumber.defaultProps = {
    isEnabled: true,
    onFocus: _.noop,
    onBlur: _.noop,
    onClear: _.noop,
};

export default bindHandlers(ProComboInputNumber);
