import React from 'react';
import { shallow } from 'enzyme';
import Carousel from 'src/components/proComboInput/carousel';

describe('src/components/proComboInput/carousel', () => {
    const items = [
        {
            value: 1,
            text: 'one',
        },
        {
            value: 2,
            text: 'two',
        },
        {
            value: 3,
            text: 'three',
        },
    ];

    it('selects the next value', () => {
        const onChange = jasmine.createSpy('onChange');
        const value = 2;

        const wrapper = shallow(<Carousel value={value} items={items} onChange={onChange}/>);
        wrapper.instance().selectNextValue(1);

        expect(onChange).toHaveBeenCalledTimes(1);
        expect(onChange.calls.argsFor(0)).toEqual([{ value: 3 }]);
    });

    it('selects the previous value', () => {
        const onChange = jasmine.createSpy('onChange');
        const value = 2;

        const wrapper = shallow(<Carousel value={value} items={items} onChange={onChange}/>);
        wrapper.instance().selectNextValue(-1);

        expect(onChange).toHaveBeenCalledTimes(1);
        expect(onChange.calls.argsFor(0)).toEqual([{ value: 1 }]);
    });

    it('loops around to the first value', () => {
        const onChange = jasmine.createSpy('onChange');
        const value = 3;

        const wrapper = shallow(<Carousel value={value} items={items} onChange={onChange}/>);
        wrapper.instance().selectNextValue(1);

        expect(onChange).toHaveBeenCalledTimes(1);
        expect(onChange.calls.argsFor(0)).toEqual([{ value: 1 }]);
    });

    it('loops around to the last value', () => {
        const onChange = jasmine.createSpy('onChange');
        const value = 1;

        const wrapper = shallow(<Carousel value={value} items={items} onChange={onChange}/>);
        wrapper.instance().selectNextValue(-1);

        expect(onChange).toHaveBeenCalledTimes(1);
        expect(onChange.calls.argsFor(0)).toEqual([{ value: 3 }]);
    });
});
