import React from 'react';
import { examplesOf } from 'src/modules/examples/utils';
import ProComboInput from 'src/components/proComboInput/proComboInput';
import ProComboInputLabel from 'src/components/proComboInput/proComboInputLabel';
import ProComboInputNumber from 'src/components/proComboInput/proComboInputNumber';

const label = 'Number';
const items = [
    {
        text: '1',
        value: 1,
    },
    {
        text: '10',
        value: 10,
    },
    {
        text: '100',
        value: 100,
    },
    {
        text: '1,000',
        value: 1000,
    },
];
const value = 1;

export default examplesOf('Pro Combo Input Number')
    .add('Default', ({ action }) => (
        <ProComboInput>
            <ProComboInputLabel>
                {label}
            </ProComboInputLabel>
            <ProComboInputNumber
                items={items}
                value={value}
                menuTitle={label}
                onFocus={action('onFocus')}
                onChange={action('onChange')}
                onIncrement={action('onIncrement')}
                onDecrement={action('onDecrement')}
            />
        </ProComboInput>
    ))
    .add('Has select', ({ action }) => (
        <ProComboInput>
            <ProComboInputLabel>
                {label}
            </ProComboInputLabel>
            <ProComboInputNumber
                items={items}
                value={value}
                menuTitle={label}
                onFocus={action('onFocus')}
                onChange={action('onChange')}
                onIncrement={action('onIncrement')}
                onDecrement={action('onDecrement')}
                hasSelect
            />
        </ProComboInput>
    ))
    .add('Has clear', ({ action }) => (
        <ProComboInput>
            <ProComboInputLabel>
                {label}
            </ProComboInputLabel>
            <ProComboInputNumber
                items={items}
                value={value}
                menuTitle={label}
                onFocus={action('onFocus')}
                onChange={action('onChange')}
                onIncrement={action('onIncrement')}
                onDecrement={action('onDecrement')}
                hasClear
            />
        </ProComboInput>
    ))
    .add('Validation error', ({ action }) => {
        const validation = {
            type: 'error',
            message: 'Lorem ipsum dolor sit amet consectetur adipisicing elit',
        };

        return (
            <ProComboInput
                validation={validation}
            >
                <ProComboInputLabel>
                    {label}
                </ProComboInputLabel>
                <ProComboInputNumber
                    items={items}
                    value={value}
                    menuTitle={label}
                    onFocus={action('onFocus')}
                    onChange={action('onChange')}
                    onIncrement={action('onIncrement')}
                    onDecrement={action('onDecrement')}
                />
            </ProComboInput>
        );
    })
    .add('Disabled', ({ action }) => (
        <ProComboInput
            isEnabled={false}
        >
            <ProComboInputLabel>
                {label}
            </ProComboInputLabel>
            <ProComboInputNumber
                items={items}
                value={value}
                menuTitle={label}
                onFocus={action('onFocus')}
                onChange={action('onChange')}
                onIncrement={action('onIncrement')}
                onDecrement={action('onDecrement')}
                isEnabled={false}
            />
        </ProComboInput>
    ))
    .add('Default (compact)', ({ action }) => (
        <ProComboInput isCompact>
            <ProComboInputLabel>
                {label}
            </ProComboInputLabel>
            <ProComboInputNumber
                items={items}
                value={value}
                menuTitle={label}
                onFocus={action('onFocus')}
                onChange={action('onChange')}
                onIncrement={action('onIncrement')}
                onDecrement={action('onDecrement')}
            />
        </ProComboInput>
    ))
    .add('Has select (compact)', ({ action }) => (
        <ProComboInput isCompact>
            <ProComboInputLabel>
                {label}
            </ProComboInputLabel>
            <ProComboInputNumber
                items={items}
                value={value}
                menuTitle={label}
                onFocus={action('onFocus')}
                onChange={action('onChange')}
                onIncrement={action('onIncrement')}
                onDecrement={action('onDecrement')}
                hasSelect
            />
        </ProComboInput>
    ))
    .add('Has clear (compact)', ({ action }) => (
        <ProComboInput isCompact>
            <ProComboInputLabel>
                {label}
            </ProComboInputLabel>
            <ProComboInputNumber
                items={items}
                value={value}
                menuTitle={label}
                onFocus={action('onFocus')}
                onChange={action('onChange')}
                onIncrement={action('onIncrement')}
                onDecrement={action('onDecrement')}
                hasClear
            />
        </ProComboInput>
    ))
    .add('Validation error (compact)', ({ action }) => {
        const validation = {
            type: 'error',
            message: 'Lorem ipsum dolor sit amet consectetur adipisicing elit',
        };

        return (
            <ProComboInput
                validation={validation}
                isCompact
            >
                <ProComboInputLabel>
                    {label}
                </ProComboInputLabel>
                <ProComboInputNumber
                    items={items}
                    value={value}
                    menuTitle={label}
                    onFocus={action('onFocus')}
                    onChange={action('onChange')}
                    onIncrement={action('onIncrement')}
                    onDecrement={action('onDecrement')}
                />
            </ProComboInput>
        );
    })
    .add('Disabled (compact)', ({ action }) => (
        <ProComboInput
            isEnabled={false}
            isCompact
        >
            <ProComboInputLabel>
                {label}
            </ProComboInputLabel>
            <ProComboInputNumber
                items={items}
                value={value}
                menuTitle={label}
                onFocus={action('onFocus')}
                onChange={action('onChange')}
                onIncrement={action('onIncrement')}
                onDecrement={action('onDecrement')}
                isEnabled={false}
            />
        </ProComboInput>
    ));
