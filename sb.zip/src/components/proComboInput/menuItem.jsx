import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import { bindHandlers } from 'src/utils/bindHandlers';
import Touchable from 'src/components/touchable/touchable';

class MenuItem extends React.PureComponent {
    handleSetRef(el) {
        const { value, selectedValue } = this.props;

        if (value === selectedValue) {
            this.props.onSetSelectedDomRef(el);
        }
    }

    handleTap() {
        this.props.onSelect(this.props.value);
    }

    render() {
        const { value, text, selectedValue } = this.props;
        const classes = classNames('list-item', `tst-list-item-${value}`, {
            'is-selected': value === selectedValue,
        });

        return (
            <Touchable ref={this.handleSetRef} onTap={this.handleTap}>
                <li className={classes}>
                    {text}
                </li>
            </Touchable>
        );
    }
}

MenuItem.propTypes = {
    value: PropTypes.any.isRequired,
    text: PropTypes.string.isRequired,
    selectedValue: PropTypes.any,
    onSelect: PropTypes.func,
    onSetSelectedDomRef: PropTypes.func,
};

MenuItem.defaultProps = {
    onSelect: _.noop,
    onSetSelectedDomRef: _.noop,
};

export default bindHandlers(MenuItem);
