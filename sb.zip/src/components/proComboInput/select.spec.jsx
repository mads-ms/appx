import React from 'react';
import { shallow } from 'enzyme';
import Select from 'src/components/proComboInput/select';

describe('src/components/proComboInput/select', () => {
    it('calls onChange when a new value is selected', () => {
        const value = 1;
        const items = [];
        const onChange = jasmine.createSpy('onChange');

        const wrapper = shallow(<Select value={value} items={items} onChange={onChange}/>);
        wrapper.instance().handleMenuSelect(2);

        expect(onChange).toHaveBeenCalledTimes(1);
    });

    it('does not call onChange when a the current value is selected', () => {
        const value = 1;
        const items = [];
        const onChange = jasmine.createSpy('onChange');

        const wrapper = shallow(<Select value={value} items={items} onChange={onChange}/>);
        wrapper.instance().handleMenuSelect(1);

        expect(onChange).toHaveBeenCalledTimes(0);
    });

    it('calls onSelect when a new value is selected', () => {
        const value = 1;
        const items = [];
        const onSelect = jasmine.createSpy('onSelect');

        const wrapper = shallow(<Select value={value} items={items} onSelect={onSelect}/>);
        wrapper.instance().handleMenuSelect(2);

        expect(onSelect).toHaveBeenCalledTimes(1);
    });

    it('calls onSelect when a the current value is selected', () => {
        const value = 1;
        const items = [];
        const onSelect = jasmine.createSpy('onSelect');

        const wrapper = shallow(<Select value={value} items={items} onSelect={onSelect}/>);
        wrapper.instance().handleMenuSelect(1);

        expect(onSelect).toHaveBeenCalledTimes(1);
    });
});
