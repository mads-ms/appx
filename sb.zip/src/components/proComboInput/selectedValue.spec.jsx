import React from 'react';
import { shallow } from 'enzyme';
import SelectedValue from 'src/components/proComboInput/selectedValue';

describe('src/components/proComboInput/selectedValue', () => {
    it('renders selected item text when item found', () => {
        const value = 1;
        const items = [
            {
                value: 1,
                text: 'one',
            },
            {
                value: 2,
                text: 'two',
            },
        ];

        const wrapper = shallow(<SelectedValue value={value} items={items}/>);

        expect(wrapper.childAt(0).text()).toBe('one');
    });

    it('renders selected value when item not found', () => {
        const value = 3;
        const items = [
            {
                value: 1,
                text: 'one',
            },
            {
                value: 2,
                text: 'two',
            },
        ];

        const wrapper = shallow(<SelectedValue value={value} items={items}/>);

        expect(wrapper.childAt(0).text()).toBe('3');
    });
});
