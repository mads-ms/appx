import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { bindHandlers } from 'src/utils/bindHandlers';
import Touchable from 'src/components/touchable/touchable';
import Dialog from 'src/components/dialog/dialog';
import Menu from './menu';

class Select extends React.PureComponent {
    constructor() {
        super();

        this.state = {
            isMenuShown: false,
            isMenuDialogShowComplete: false,
        };
    }

    handleTap() {
        this.setState({
            isMenuShown: true,
        });
    }

    handleMenuShow() {
        this.setState({
            isMenuDialogShowComplete: true,
        });
    }

    handleMenuHide() {
        this.setState({
            isMenuShown: false,
            isMenuDialogShowComplete: false,
        });
    }

    handleMenuSelect(value) {
        this.setState({
            isMenuShown: false,
            isMenuDialogShowComplete: false,
        });

        this.props.onSelect({ value });

        if (value !== this.props.value) {
            this.props.onChange({ value });
        }
    }

    render() {
        const { items, value, menuTitle, dialogParent, children } = this.props;
        const { isMenuShown, isMenuDialogShowComplete } = this.state;

        return (
            <div>
                <Touchable onTap={this.handleTap}>
                    {children}
                </Touchable>
                {isMenuShown &&
                    <Dialog
                        type="card"
                        parent={dialogParent}
                        onShow={this.handleMenuShow}
                        onHide={this.handleMenuHide}
                    >
                        <Menu
                            value={value}
                            items={items}
                            title={menuTitle}
                            isParentShowComplete={isMenuDialogShowComplete}
                            onSelect={this.handleMenuSelect}
                        />
                    </Dialog>
                }
            </div>
        );
    }

}

Select.propTypes = {
    value: PropTypes.any,
    items: PropTypes.array.isRequired,
    menuTitle: PropTypes.string,
    dialogParent: PropTypes.instanceOf(HTMLElement),
    onSelect: PropTypes.func,
    onChange: PropTypes.func,
};

Select.defaultProps = {
    onSelect: _.noop,
    onChange: _.noop,
};

export default bindHandlers(Select);
