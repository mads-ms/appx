import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { bindHandlers } from 'src/utils/bindHandlers';
import Sheet from 'src/components/sheet/sheet';
import SheetHeader from 'src/components/sheet/sheetHeader';
import Setting from './setting';

class Settings extends React.PureComponent {
    handleSettingSelect({ id, value }) {
        const { settings, onSelect } = this.props;
        const setting = _.find(settings, { id });

        setting.onSelect({ value });
        onSelect();
    }

    render() {
        const { title, settings } = this.props;

        return (
            <Sheet className="dropdown-sheet grid grid--y grid--fit-all tst-settings-dialog" isAstroStyle>
                <SheetHeader className="grid-cell">
                    {title}
                </SheetHeader>
                <div className="grid-cell">
                    <div className="grid grid--scroll">
                        <div className="grid">
                            {_.map(settings, (setting) => (
                                <Setting
                                    className="grid-cell"
                                    key={setting.id}
                                    id={setting.id}
                                    value={setting.value}
                                    title={setting.title}
                                    options={setting.options}
                                    onSelect={this.handleSettingSelect}
                                />
                            ))}
                        </div>
                    </div>
                </div>
            </Sheet>
        );
    }
}

Settings.propTypes = {
    title: PropTypes.string,
    settings: PropTypes.arrayOf(
        PropTypes.shape({
            id: PropTypes.string.isRequired,
            value: PropTypes.any,
            title: PropTypes.string.isRequired,
            options: PropTypes.arrayOf(
                PropTypes.shape({
                    value: PropTypes.any.isRequired,
                    text: PropTypes.string.isRequired,
                    className: PropTypes.string,
                })
            ).isRequired,
            onSelect: PropTypes.func.isRequired,
        })
    ).isRequired,
    onSelect: PropTypes.func,
};

Settings.defaultProps = {
    onSelect: _.noop,
};

export default bindHandlers(Settings);
