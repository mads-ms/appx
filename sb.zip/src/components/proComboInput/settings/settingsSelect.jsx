import React from 'react';
import PropTypes from 'prop-types';
import { bindHandlers } from 'src/utils/bindHandlers';
import Touchable from 'src/components/touchable/touchable';
import Dialog from 'src/components/dialog/dialog';
import Settings from './settings';

class SettingsSelect extends React.PureComponent {
    constructor() {
        super();

        this.state = {
            isMenuShown: false,
        };
    }

    handleTap() {
        this.setState({
            isMenuShown: true,
        });
    }

    handleMenuHide() {
        this.setState({
            isMenuShown: false,
        });
    }

    handleMenuSelect() {
        const { settings } = this.props;

        // Don't automatically close the menu when there are multiple settings that can be changed.
        if (settings.length === 1) {
            this.setState({
                isMenuShown: false,
            });
        }
    }

    render() {
        const { settings, menuTitle, dialogParent, children } = this.props;
        const { isMenuShown } = this.state;

        return (
            <div>
                <Touchable onTap={this.handleTap}>
                    {children}
                </Touchable>
                {isMenuShown &&
                    <Dialog
                        type="card"
                        parent={dialogParent}
                        onHide={this.handleMenuHide}
                    >
                        <Settings
                            settings={settings}
                            title={menuTitle}
                            onSelect={this.handleMenuSelect}
                        />
                    </Dialog>
                }
            </div>
        );
    }

}

SettingsSelect.propTypes = {
    settings: PropTypes.arrayOf(
        PropTypes.shape({
            id: PropTypes.string.isRequired,
            value: PropTypes.any,
            title: PropTypes.string.isRequired,
            options: PropTypes.arrayOf(
                PropTypes.shape({
                    value: PropTypes.any.isRequired,
                    text: PropTypes.string.isRequired,
                    className: PropTypes.string,
                })
            ).isRequired,
            onSelect: PropTypes.func.isRequired,
        })
    ).isRequired,
    menuTitle: PropTypes.string,
    dialogParent: PropTypes.instanceOf(HTMLElement),
};

export default bindHandlers(SettingsSelect);
