import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import { bindHandlers } from 'src/utils/bindHandlers';
import SettingOption from './settingOption';

class Setting extends React.PureComponent {
    handleOptionSelect({ value }) {
        const { id, onSelect } = this.props;

        onSelect({ id, value });
    }

    render() {
        const { value, options, title, className } = this.props;
        const classes = classNames('procomboinput-setting', className);

        return (
            <div className={classes}>
                <div className="procomboinput-setting-title">
                    {title}
                </div>
                <ul className="list list--astro list--lines sep sep--astro">
                    {_.map(options, (option) => (
                        <SettingOption
                            key={option.value}
                            value={option.value}
                            text={option.text}
                            className={option.className}
                            selectedValue={value}
                            onSelect={this.handleOptionSelect}
                        />
                    ))}
                </ul>
            </div>
        );
    }
}

Setting.propTypes = {
    id: PropTypes.string.isRequired,
    value: PropTypes.any,
    title: PropTypes.string.isRequired,
    options: PropTypes.arrayOf(
        PropTypes.shape({
            value: PropTypes.any.isRequired,
            text: PropTypes.string.isRequired,
            className: PropTypes.string,
        })
    ).isRequired,
    className: PropTypes.string,
    onSelect: PropTypes.func.isRequired,
};

export default bindHandlers(Setting);
