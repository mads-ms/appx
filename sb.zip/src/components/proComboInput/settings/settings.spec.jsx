import React from 'react';
import { shallow } from 'enzyme';
import Settings from 'src/components/proComboInput/settings/settings';

describe('src/components/proComboInput/settings/settings', () => {
    it('calls the setting onSelect and onSelect prop when an option is selected', () => {
        const settingOnSelect = jasmine.createSpy('setting.onSelect');
        const onSelect = jasmine.createSpy('onSelect');
        const id = 'mock-setting';
        const value = 1;
        const settings = [{ id, title: 'a', options: [{ value, text: 'b' }], onSelect: settingOnSelect }];

        const wrapper = shallow(<Settings settings={settings} onSelect={onSelect}/>);
        wrapper.instance().handleSettingSelect({ id, value });

        expect(settingOnSelect).toHaveBeenCalledTimes(1);
        expect(settingOnSelect).toHaveBeenCalledWith({ value });
        expect(onSelect).toHaveBeenCalledTimes(1);
        expect(onSelect).toHaveBeenCalledWith();
    });
});
