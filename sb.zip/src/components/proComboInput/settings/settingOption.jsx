import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import { bindHandlers } from 'src/utils/bindHandlers';
import Touchable from 'src/components/touchable/touchable';
import RadioButton from 'src/components/radioButton/radioButton';

class SettingOption extends React.PureComponent {
    handleTap() {
        const { onSelect, value } = this.props;

        onSelect({ value });
    }

    render() {
        const { value, text, className, selectedValue } = this.props;
        const isSelected = value === selectedValue;
        const radioButtonClassNames = classNames('procomboinput-setting-option', className, {
            'procomboinput-setting-option--is-selected': isSelected,
        });

        return (
            <Touchable onTap={this.handleTap}>
                <li className="list-item">
                    <RadioButton
                        className={radioButtonClassNames}
                        value={value}
                        isChecked={isSelected}
                    >
                        {text}
                    </RadioButton>
                </li>
            </Touchable>
        );
    }
}

SettingOption.propTypes = {
    value: PropTypes.any.isRequired,
    text: PropTypes.string.isRequired,
    className: PropTypes.string,
    selectedValue: PropTypes.any,
    onSelect: PropTypes.func,
};

SettingOption.defaultProps = {
    onSelect: _.noop,
};

export default bindHandlers(SettingOption);
