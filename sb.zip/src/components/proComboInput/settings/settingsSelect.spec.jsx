import _ from 'lodash';
import React from 'react';
import { shallow } from 'enzyme';
import SettingsSelect from 'src/components/proComboInput/settings/settingsSelect';

describe('src/components/proComboInput/settings/settingsSelect', () => {
    it('hides the menu when the only setting is changed', () => {
        const settings = [
            { id: 'a', title: 'a', options: [], onSelect: _.noop },
        ];

        const wrapper = shallow(<SettingsSelect settings={settings}/>);
        wrapper.instance().handleTap();
        wrapper.instance().handleMenuSelect();

        expect(wrapper.state().isMenuShown).toEqual(false);
    });

    it('does not hide the menu when one of many settings is changed', () => {
        const settings = [
            { id: 'a', title: 'a', options: [], onSelect: _.noop },
            { id: 'b', title: 'b', options: [], onSelect: _.noop },
        ];

        const wrapper = shallow(<SettingsSelect settings={settings}/>);
        wrapper.instance().handleTap();
        wrapper.instance().handleMenuSelect();

        expect(wrapper.state().isMenuShown).toEqual(true);
    });
});
