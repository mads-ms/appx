import _ from 'lodash';
import React from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';
import { bindHandlers } from 'src/utils/bindHandlers';
import Sheet from 'src/components/sheet/sheet';
import SheetHeader from 'src/components/sheet/sheetHeader';
import MenuItem from './menuItem';

class Menu extends React.PureComponent {
    constructor() {
        super();

        this.setEl = (el) => {
            this.el = ReactDOM.findDOMNode(el);
        };
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.isParentShowComplete !== this.props.isParentShowComplete && this.selectedEl) {
            const elDimensions = this.el.getBoundingClientRect();
            const selectedElDimensions = this.selectedEl.getBoundingClientRect();
            const selectedElPosition = selectedElDimensions.top + selectedElDimensions.height / 2;

            this.el.scrollTop = (selectedElPosition - elDimensions.height / 2) - elDimensions.top;
        }
    }

    handleItemSelect(value) {
        this.props.onSelect(value);
    }

    handleSetSelectedDomRef(selectedEl) {
        this.selectedEl = ReactDOM.findDOMNode(selectedEl);
    }

    render() {
        const { value, items, title } = this.props;

        return (
            <Sheet className="dropdown-sheet tst-procomboinput-menu grid grid--y grid--fit-fill" isAstroStyle>
                <SheetHeader className="grid-cell">
                    {title}
                </SheetHeader>
                <div className="grid grid--scroll">
                    <div ref={this.setEl} className="grid-cell">
                        <ul className="list list--astro list--lines">
                            {_.map(items, (item) => (
                                <MenuItem
                                    key={item.value}
                                    selectedValue={value}
                                    onSelect={this.handleItemSelect}
                                    onSetSelectedDomRef={this.handleSetSelectedDomRef}
                                    {...item}
                                />
                            ))}
                        </ul>
                    </div>
                </div>
            </Sheet>
        );
    }
}

Menu.propTypes = {
    value: PropTypes.any,
    items: PropTypes.array.isRequired,
    title: PropTypes.string,
    isParentShowComplete: PropTypes.bool,
    onSelect: PropTypes.func,
};

Menu.defaultProps = {
    onSelect: _.noop,
};

export default bindHandlers(Menu);
