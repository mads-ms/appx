import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { bindHandlers } from 'src/utils/bindHandlers';
import Carousel from './carousel';
import TimeInput from './timeInput';
import SelectedValue from './selectedValue';
import Select from './select';

class ProComboInputTime extends React.PureComponent {
    constructor(props) {
        super(props);

        this.state = {
            isInput: this.isInput(props.selectValue),
            isFocused: false,
        };
    }

    componentWillReceiveProps(nextProps) {
        this.setState({
            isInput: this.isInput(nextProps.selectValue),
        });
    }

    handleCarouselValueChange({ value }) {
        const isInput = this.isInput(value);

        this.setState({
            isInput,
            isFocused: isInput,
        });

        this.props.onSelectValueChange({ value });
    }

    isInput(selectValue) {
        const { items } = this.props;
        const selectedItem = _.find(items, { value: selectValue });

        return Boolean(selectedItem && selectedItem.isInput);
    }

    render() {
        const {
            timeValue,
            selectValue,
            items,
            title,
            dialogParent,
            onFocus,
            onTimeValueChange,
        } = this.props;

        const {
            isInput,
            isFocused,
        } = this.state;

        const content = isInput ? (
            <TimeInput
                isEnabled
                isFocused={isFocused}
                value={timeValue}
                onFocus={onFocus}
                onChange={onTimeValueChange}
            />
        ) : (
            <Select
                value={selectValue}
                items={items}
                menuTitle={title}
                dialogParent={dialogParent}
                onSelect={this.handleCarouselValueChange}
            >
                <SelectedValue
                    value={selectValue}
                    items={items}
                />
            </Select>
        );

        return (
            <Carousel
                value={selectValue}
                items={items}
                onChange={this.handleCarouselValueChange}
            >
                {content}
            </Carousel>
        );
    }
}

ProComboInputTime.propTypes = {
    selectValue: PropTypes.string,
    timeValue: PropTypes.string,
    items: PropTypes.arrayOf(PropTypes.shape({
        value: PropTypes.string.isRequired,
        text: PropTypes.string.isRequired,
    })).isRequired,
    title: PropTypes.string,
    dialogParent: PropTypes.instanceOf(HTMLElement),
    onFocus: PropTypes.func,
    onSelectValueChange: PropTypes.func,
    onTimeValueChange: PropTypes.func,
};

ProComboInputTime.defaultProps = {
    selectValue: '',
    timeValue: '',
    title: '',
    onSelectValueChange: _.noop,
    onTimeValueChange: _.noop,
};

export default bindHandlers(ProComboInputTime);
