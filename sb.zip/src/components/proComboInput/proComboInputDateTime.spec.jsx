import React from 'react';
import { mount } from 'enzyme';
import DateTime from 'src/modules/dateTime';
import Dialog from 'src/components/dialog/dialog';
import ProComboInputDateTime from 'src/components/proComboInput/proComboInputDateTime';

describe('src/components/proComboInput/proComboInputDateTime', () => {
    const items = [
        { value: 'item-a', text: 'Item A' },
        { value: 'item-b', text: 'Item C' },
        { value: 'item-c', text: 'Item C', isDateSelect: true },
    ];
    const selectedDate = DateTime.createDate();

    let onSelectValueChange;
    let onDateValueChange;
    let selectValue;
    let dateValue;
    let input;

    beforeEach(() => {
        onSelectValueChange = jasmine.createSpy('onSelectValueChange');
        onDateValueChange = jasmine.createSpy('onDateValueChange');
        selectValue = 'item-a';
        dateValue = null;
        input = mount(
            <ProComboInputDateTime
                items={items}
                selectValue={selectValue}
                dateValue={dateValue}
                onSelectValueChange={onSelectValueChange}
                onDateValueChange={onDateValueChange}
            />
        );
    });

    it('sets the select value but not the date value when the carousel value is changed to a non-date-select value', () => {
        input.instance().handleCarouselValueChange({ value: 'item-b' });

        expect(onSelectValueChange).toHaveBeenCalledTimes(1);
        expect(onSelectValueChange).toHaveBeenCalledWith({ value: 'item-b' });
        expect(onDateValueChange).not.toHaveBeenCalled();
    });

    it('sets the select value and clears the date value when the carousel value is changed to a date-select value', () => {
        input.instance().handleCarouselValueChange({ value: 'item-c' });

        expect(onSelectValueChange).toHaveBeenCalledTimes(1);
        expect(onSelectValueChange).toHaveBeenCalledWith({ value: 'item-c' });
        expect(onDateValueChange).toHaveBeenCalledTimes(1);
        expect(onDateValueChange).toHaveBeenCalledWith({ value: null });
    });

    it('sets the select value but not the date value when a non-date-select value is selected', () => {
        input.instance().handleSelectValueSelect({ value: 'item-b' });

        expect(onSelectValueChange).toHaveBeenCalledTimes(1);
        expect(onSelectValueChange).toHaveBeenCalledWith({ value: 'item-b' });
        expect(onDateValueChange).not.toHaveBeenCalled();
    });

    it('shows the date picker when a date-select value is selected', () => {
        input.instance().handleSelectValueSelect({ value: 'item-c' });
        input.update();

        expect(onSelectValueChange).not.toHaveBeenCalled();
        expect(onDateValueChange).not.toHaveBeenCalled();
        expect(input.find(Dialog).length).toBe(1);
    });

    it('sets the select value and date value and hides the date picker when a date is selected', () => {
        input.instance().handleSelectValueSelect({ value: 'item-c' });
        input.instance().handleDateValueChange(selectedDate);
        input.update();

        expect(onSelectValueChange).toHaveBeenCalledTimes(1);
        expect(onSelectValueChange).toHaveBeenCalledWith({ value: 'item-c' });
        expect(onDateValueChange).toHaveBeenCalledTimes(1);
        expect(onDateValueChange).toHaveBeenCalledWith({ value: selectedDate.toString() });
        expect(input.find(Dialog).length).toBe(0);
    });

    it('hides the date picker when the date picker is hidden with no selection', () => {
        input.instance().handleSelectValueSelect({ value: 'item-c' });
        input.instance().handleDateTimePickerHide();
        input.update();

        expect(onSelectValueChange).not.toHaveBeenCalled();
        expect(onDateValueChange).not.toHaveBeenCalled();
        expect(input.find(Dialog).length).toBe(0);
    });

    it('renders text for a date-select selected value when no date value exists', () => {
        input.setProps(({
            selectValue: 'item-c',
        }));
        input.update();

        expect(input.find('.procomboinput-value').text()).toEqual('Item C');
    });

    it('renders date for a date-select selected value when a date value exists', () => {
        input.setProps(({
            selectValue: 'item-c',
            dateValue: selectedDate.toString(),
        }));
        input.update();

        expect(input.find('.procomboinput-value').text()).toEqual(DateTime.formatUtcDate(selectedDate));
    });
});
