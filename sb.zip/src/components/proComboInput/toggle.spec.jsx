import React from 'react';
import { shallow } from 'enzyme';
import Toggle from 'src/components/proComboInput/toggle';

describe('src/components/proComboInput/toggle', () => {

    describe('toggles the value', () => {
        const testToggle = (items) => {
            const onChange = jasmine.createSpy('onChange');
            const value = 1;
            const wrapper = shallow(<Toggle value={value} items={items} onChange={onChange}/>);

            wrapper.instance().handleTap();

            expect(onChange).toHaveBeenCalledTimes(1);
            expect(onChange.calls.argsFor(0)).toEqual([{ value: 2 }]);

            wrapper.instance().handleTap();

            expect(onChange).toHaveBeenCalledTimes(2);
            expect(onChange.calls.argsFor(1)).toEqual([{ value: 2 }]);
        };

        it('with two items', () => {
            testToggle([
                {
                    value: 1,
                    text: 'one',
                },
                {
                    value: 2,
                    text: 'two',
                },
            ]);
        });

        it('with three items', () => {
            testToggle([
                {
                    value: 1,
                    text: 'one',
                },
                {
                    value: 2,
                    text: 'two',
                },
                {
                    value: 3,
                    text: 'three',
                },
            ]);
        });
    });

    describe('does nothing', () => {
        const testToggle = (items) => {
            const onChange = jasmine.createSpy('onChange');
            const value = 1;
            const wrapper = shallow(<Toggle value={value} items={items} onChange={onChange}/>);

            wrapper.instance().handleTap();

            expect(onChange).not.toHaveBeenCalled();
        };

        it('with no items', () => {
            testToggle([]);
        });

        it('with one item', () => {
            testToggle([
                {
                    value: 1,
                    text: 'one',
                },
            ]);
        });
    });
});
