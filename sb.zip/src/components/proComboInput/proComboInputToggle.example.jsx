import React from 'react';
import { examplesOf } from 'src/modules/examples/utils';
import ProComboInput from 'src/components/proComboInput/proComboInput';
import ProComboInputLabel from 'src/components/proComboInput/proComboInputLabel';
import ProComboInputToggle from 'src/components/proComboInput/proComboInputToggle';

const label = 'Toggle';
const items = [
    {
        text: 'On',
        value: 'on',
    },
    {
        text: 'Off',
        value: 'off',
    },
];
const value = 'on';

export default examplesOf('Pro Combo Input Toggle')
    .add('Default', ({ action }) => (
        <ProComboInput>
            <ProComboInputLabel>
                {label}
            </ProComboInputLabel>
            <ProComboInputToggle
                items={items}
                value={value}
                menuTitle={label}
                onChange={action('onChange')}
            />
        </ProComboInput>
    ))
    .add('Validation error', ({ action }) => {
        const validation = {
            type: 'error',
            message: 'Lorem ipsum dolor sit amet consectetur adipisicing elit',
        };

        return (
            <ProComboInput validation={validation}>
                <ProComboInputLabel>
                    {label}
                </ProComboInputLabel>
                <ProComboInputToggle
                    items={items}
                    value={value}
                    menuTitle={label}
                    onChange={action('onChange')}
                />
            </ProComboInput>
        );
    })
    .add('Disabled', ({ action }) => (
        <ProComboInput>
            <ProComboInputLabel>
                {label}
            </ProComboInputLabel>
            <ProComboInputToggle
                items={items}
                value={value}
                onChange={action('onChange')}
                isEnabled={false}
            />
        </ProComboInput>
    ))
    .add('Default (compact)', ({ action }) => (
        <ProComboInput isCompact>
            <ProComboInputLabel>
                {label}
            </ProComboInputLabel>
            <ProComboInputToggle
                items={items}
                value={value}
                menuTitle={label}
                onChange={action('onChange')}
            />
        </ProComboInput>
    ))
    .add('Validation error (compact)', ({ action }) => {
        const validation = {
            type: 'error',
            message: 'Lorem ipsum dolor sit amet consectetur adipisicing elit',
        };

        return (
            <ProComboInput
                validation={validation}
                isCompact
            >
                <ProComboInputLabel>
                    {label}
                </ProComboInputLabel>
                <ProComboInputToggle
                    items={items}
                    value={value}
                    onChange={action('onChange')}
                />
            </ProComboInput>
        );
    })
    .add('Disabled (compact)', ({ action }) => (
        <ProComboInput
            isEnabled={false}
            isCompact
        >
            <ProComboInputLabel>
                {label}
            </ProComboInputLabel>
            <ProComboInputToggle
                items={items}
                value={value}
                onChange={action('onChange')}
                isEnabled={false}
            />
        </ProComboInput>
    ));
