import React from 'react';
import PropTypes from 'prop-types';
import Touchable from 'src/components/touchable/touchable';
import InputButton from './inputButton';

class InputClear extends React.PureComponent {
    render() {
        const { isShown, onClear } = this.props;

        return (
            <Touchable onTap={onClear}>
                <InputButton
                    iconType="delete"
                    isShown={isShown}
                />
            </Touchable>
        );
    }
}

InputClear.propTypes = {
    isShown: PropTypes.bool,
    onClear: PropTypes.func,
};

export default InputClear;
