import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { bindHandlers } from 'src/utils/bindHandlers';
import Touchable from 'src/components/touchable/touchable';
import Icon from 'src/components/icon/icon';

class Incrementer extends React.PureComponent {

    handleIncrementTap() {
        this.props.onIncrement();
    }

    handleDecrementTap() {
        this.props.onDecrement();
    }

    render() {
        const { children } = this.props;

        return (
            <div className="grid grid--fit-fill-fit grid--cross-center">
                <div className="grid-cell">
                    <Touchable onTap={this.handleDecrementTap}>
                        <Icon className="procomboinput-icon tst-procomboinput-icon-decrement" type="toggleclose"/>
                    </Touchable>
                </div>
                <div className="grid-cell">
                    {children}
                </div>
                <div className="grid-cell">
                    <Touchable onTap={this.handleIncrementTap}>
                        <Icon className="procomboinput-icon tst-procomboinput-icon-increment" type="add"/>
                    </Touchable>
                </div>
            </div>
        );
    }

}

Incrementer.propTypes = {
    onIncrement: PropTypes.func,
    onDecrement: PropTypes.func,
};

Incrementer.defaultProps = {
    onIncrement: _.noop,
    onDecrement: _.noop,
};

export default bindHandlers(Incrementer);
