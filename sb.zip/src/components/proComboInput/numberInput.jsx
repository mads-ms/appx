import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { bindHandlers } from 'src/utils/bindHandlers';
import * as numberFormat from 'src/numberFormat';

class NumberInput extends React.PureComponent {
    constructor(props) {
        super(props);

        this.state = {
            value: this.formatValue(props.value),
        };

        this.isFocused = false;
        this.lastKey = null;

        this.setEl = (ref) => {
            this.el = ref;
        };
    }

    componentWillReceiveProps(nextProps) {
        const { isFocused, lastKey } = this;

        // avoid formatting the value while it's being edited...
        // ...unless it's incrementing or decrementing
        if (
            isFocused &&
            (lastKey !== 'ArrowUp') &&
            (lastKey !== 'ArrowDown')
        ) {
            return;
        }

        // when not focused, only update the state from props when the value or formatter changes.
        // this avoids wiping invalid values.
        if (this.props.value === nextProps.value &&
            this.props.formatter === nextProps.formatter) {
            return;
        }

        this.setState({
            value: this.formatValue(nextProps.value, nextProps),
        });
    }

    handleKeyDown(evt) {
        switch (evt.key) {
            case 'Enter':
                evt.target.blur();
                break;

            case 'ArrowUp':
                // prevent cursor jumping
                evt.preventDefault();
                this.props.onIncrement();
                break;

            case 'ArrowDown':
                // prevent cursor jumping
                evt.preventDefault();
                this.props.onDecrement();
                break;
        }

        // store the last key on this rather than this.state since it must be
        // synchronous in order to be available in componentWillReceiveProps
        this.lastKey = evt.key;
    }

    handleChange(evt) {
        const inputValue = this.truncateValue(evt.target.value);
        let value = this.parseValue(inputValue);

        // convert NaN values to null for JSON compatibility,
        // esp. for serialization of saga actions in pro...
        if (isNaN(value)) {
            value = null;
        }

        this.setState({
            value: inputValue,
        });

        this.props.onChange({ value });

        if (inputValue === '') {
            this.props.onClear();
        }
    }

    handleFocus() {
        // auto-select text
        this.el.setSelectionRange(0, this.el.value.length);

        this.isFocused = true;

        this.props.onFocus();
    }

    handleBlur() {
        this.isFocused = false;

        // always reset formatting of valid values and empty values
        // - invalid user input values are kept so they can be corrected
        // but empty values may have special formatting
        if (_.isFinite(this.props.value) || this.state.value === '') {
            this.setState({
                value: this.formatValue(this.props.value),
            });
        }

        this.props.onBlur();
    }

    truncateValue(value) {
        const { maxLength } = this.props;

        return (value.length > maxLength) ?
            value.substring(0, maxLength) :
            value;
    }

    parseValue(value, props = this.props) {
        return props.parser(value);
    }

    formatValue(value, props = this.props) {
        return props.formatter(value);
    }

    render() {
        const { isEnabled, placeholder } = this.props;
        const { value } = this.state;

        return (
            <input
                ref={this.setEl}
                type="text"
                className="procomboinput-input tst-procomboinput-number-input t-truncate"
                disabled={!isEnabled}
                placeholder={placeholder}
                value={value}
                onKeyDown={this.handleKeyDown}
                onChange={this.handleChange}
                onFocus={this.handleFocus}
                onBlur={this.handleBlur}
            />
        );
    }

}

NumberInput.propTypes = {
    value: PropTypes.number,
    placeholder: PropTypes.string,
    parser: PropTypes.func,
    formatter: PropTypes.func,
    maxLength: PropTypes.number,
    isEnabled: PropTypes.bool,
    onFocus: PropTypes.func,
    onBlur: PropTypes.func,
    onClear: PropTypes.func,
    onChange: PropTypes.func,
    onIncrement: PropTypes.func,
    onDecrement: PropTypes.func,
};

NumberInput.defaultProps = {
    isEnabled: true,
    parser: numberFormat.parse,
    formatter: numberFormat.format,
    onFocus: _.noop,
    onBlur: _.noop,
    onClear: _.noop,
    onChange: _.noop,
    onIncrement: _.noop,
    onDecrement: _.noop,
};

export default bindHandlers(NumberInput);
