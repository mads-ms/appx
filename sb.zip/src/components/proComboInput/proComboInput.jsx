import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import Validation from 'src/modules/validation/validation';

class ProComboInput extends React.PureComponent {
    getClasses(validationClasses) {
        const {
            isEnabled,
            isHighlighted,
            isFirstSibling,
            isSecondSibling,
            isCompact,
        } = this.props;

        return classNames('procomboinput tst-procomboinput grid grid--cross-center', validationClasses, {
            'is-disabled': !isEnabled,
            'is-highlighted': isHighlighted,
            'procomboinput-sibling procomboinput-sibling--first': isFirstSibling,
            'procomboinput-sibling procomboinput-sibling--second': isSecondSibling,
            'procomboinput--compact': isCompact,
        });
    }

    render() {
        const { validation, children } = this.props;

        return (
            <Validation {...validation}>
                {({ validationClasses, validationMessage }) => [
                    <div key="procomboinput" className={this.getClasses(validationClasses)}>
                        {_.map(React.Children.toArray(children), (child, index) => (
                            <div key={index} className="grid-cell">
                                {child}
                            </div>
                        ))}
                    </div>,
                    React.cloneElement(validationMessage, { key: 'validation' }),
                ]}
            </Validation>
        );
    }
}

ProComboInput.propTypes = {
    validation: PropTypes.shape({
        type: PropTypes.string,
        message: PropTypes.string,
    }),
    isEnabled: PropTypes.bool,
    isHighlighted: PropTypes.bool,
    isFirstSibling: PropTypes.bool,
    isSecondSibling: PropTypes.bool,
    isCompact: PropTypes.bool,
};

ProComboInput.defaultProps = {
    validation: {},
    isEnabled: true,
    isFirstSibling: false,
    isSecondSibling: false,
    isCompact: false,
};

export default ProComboInput;
