import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { bindHandlers } from 'src/utils/bindHandlers';
import DateTime from 'src/modules/dateTime';
import Touchable from 'src/components/touchable/touchable';
import Dialog from 'src/components/dialog/dialog';
import DateTimePicker from 'src/components/dateTimePicker/dateTimePicker';
import Carousel from './carousel';
import Select from './select';
import SelectedValue from './selectedValue';

class ProComboDateTimePicker extends React.PureComponent {
    constructor() {
        super();

        this.state = {
            pendingSelectValue: null,
            isDatePickerShown: false,
        };
    }

    handleCarouselValueChange({ value }) {
        const { onSelectValueChange, onDateValueChange } = this.props;

        onSelectValueChange({ value });

        if (this.isDateSelect(value)) {
            onDateValueChange({ value: null });
        }
    }

    handleSelectValueSelect({ value }) {
        const { onSelectValueChange } = this.props;

        if (this.isDateSelect(value)) {
            // Don't set the select value immediately; we want to easily revert to the current value
            // if the date picker is closed without a selection.
            this.setState({
                pendingSelectValue: value,
                isDatePickerShown: true,
            });
        } else {
            onSelectValueChange({ value });
        }
    }

    handleDateSelectTap() {
        const { selectValue } = this.props;

        this.setState({
            pendingSelectValue: selectValue,
            isDatePickerShown: true,
        });
    }

    handleDateValueChange(date) {
        const { pendingSelectValue } = this.state;
        const { onSelectValueChange, onDateValueChange } = this.props;
        const dateValue = date.toString();

        onSelectValueChange({ value: pendingSelectValue });
        onDateValueChange({ value: dateValue });

        this.handleDateTimePickerHide();
    }

    handleDateTimePickerHide() {
        this.setState({
            pendingSelectValue: null,
            isDatePickerShown: false,
        });
    }

    getSelectedValueItems() {
        const { items, dateValue, selectValue, isAppendSelectedDateValue } = this.props;

        return _.map(items, (item) => {
            const { isDateSelect, text, selectedText, value } = item;
            let valueText = selectedText || text;

            if (isDateSelect) {
                // For items that select a date, show the current date value.
                return {
                    text: dateValue ?
                        DateTime.formatUtcDate(DateTime.createDate(dateValue)) :
                        valueText,
                    value,
                };
            } else if (item.value === selectValue) {
                if (isAppendSelectedDateValue) {
                    valueText = `${valueText} (${DateTime.formatUtcDate(DateTime.createDate(dateValue))})`;
                }

                return _.defaults({
                    text: valueText,
                }, item);
            }

            return item;
        });
    }

    getValueItems() {
        const { items, isAppendDateValue } = this.props;

        return isAppendDateValue ?
            _.map(items, (item) => {
                const { text, date } = item;
                return date ?
                    _.defaults({ text: `${text} (${DateTime.formatUtcDate(DateTime.createDate(date))})` }, item) :
                    item;
            }) :
            items;
    }

    isDateSelect(selectValue) {
        const { items } = this.props;
        const selectedItem = _.find(items, { value: selectValue });

        return Boolean(selectedItem && selectedItem.isDateSelect);
    }

    getFirstEnabledDate() {
        const { minDate, disabledDates } = this.props;

        if (disabledDates) {
            let date = DateTime.createDate(minDate);
            const disabledDateTimes = _.map(disabledDates, (disabledDate) => DateTime.createDate(disabledDate));

            // eslint-disable-next-line no-loop-func
            while (_.some(disabledDateTimes, (disabledDateTime) => date.isSameDay(disabledDateTime))) {
                date = DateTime.addDays(date, 1);
            }

            return date.toString();
        }

        return minDate;
    }

    render() {
        const { isDatePickerShown } = this.state;
        const {
            title,
            selectValue,
            dateValue,
            minDate,
            maxDate,
            disabledDates,
            disabledDays,
            dialogParent,
            isEnabled,
        } = this.props;
        const isDateSelect = this.isDateSelect(selectValue);
        const firstEnabledDate = this.getFirstEnabledDate();

        let content = (
            <SelectedValue
                value={selectValue}
                items={this.getSelectedValueItems()}
                isAction={isDateSelect && !dateValue}
            />
        );

        if (isEnabled) {
            const items = this.getValueItems();

            if (isDateSelect) {
                content = (
                    <Touchable onTap={this.handleDateSelectTap}>
                        {content}
                    </Touchable>
                );
            } else {
                content = (
                    <Select
                        value={selectValue}
                        items={items}
                        menuTitle={title}
                        dialogParent={dialogParent}
                        onSelect={this.handleSelectValueSelect}
                    >
                        {content}
                    </Select>
                );
            }

            if (items.length > 1) {
                content = (
                    <Carousel
                        value={selectValue}
                        items={items}
                        onChange={this.handleCarouselValueChange}
                    >
                        {content}
                    </Carousel>
                );
            }
        }

        return (
            <div>
                {content}
                {isDatePickerShown &&
                    <Dialog
                        type="card"
                        parent={dialogParent}
                        onHide={this.handleDateTimePickerHide}
                    >
                        <DateTimePicker
                            label={title}
                            value={dateValue || firstEnabledDate}
                            minDate={minDate && DateTime.createDate(minDate)}
                            maxDate={maxDate && DateTime.createDate(maxDate)}
                            disabledDates={_.map(disabledDates, DateTime.createDate)}
                            disabledDays={disabledDays}
                            showHeader
                            showDate
                            onChange={this.handleDateValueChange}
                        />
                    </Dialog>
                }
            </div>
        );
    }
}

ProComboDateTimePicker.propTypes = {
    title: PropTypes.string,
    items: PropTypes.array.isRequired,
    selectValue: PropTypes.string,
    dateValue: PropTypes.string,
    minDate: PropTypes.string,
    maxDate: PropTypes.string,
    disabledDates: PropTypes.arrayOf(PropTypes.string),
    disabledDays: PropTypes.arrayOf(PropTypes.number),
    dialogParent: PropTypes.instanceOf(HTMLElement),
    isEnabled: PropTypes.bool,
    isAppendSelectedDateValue: PropTypes.bool,
    isAppendDateValue: PropTypes.bool,
    onSelectValueChange: PropTypes.func,
    onDateValueChange: PropTypes.func,
};

ProComboDateTimePicker.defaultProps = {
    isEnabled: true,
    onSelectValueChange: _.noop,
    onDateValueChange: _.noop,
};

export default bindHandlers(ProComboDateTimePicker);
