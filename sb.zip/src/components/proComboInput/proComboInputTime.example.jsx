import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { examplesOf } from 'src/modules/examples/utils';
import { bindHandlers } from 'src/utils/bindHandlers';
import ProComboInputTime from './proComboInputTime';
import ProComboInput from './proComboInput';
import ProComboInputLabel from './proComboInputLabel';

const prefilledTimeItems = [
    {
        value: 'off',
        text: 'End of trading',
    },
    {
        value: '12:00',
        text: '12:00 PM',
    },
    {
        value: '13:00',
        text: '1:00 PM',
    },
    {
        value: 'SelectTime',
        isInput: true,
        text: 'Select time',
    },
];

const timeItems = [
    {
        value: 'off',
        text: 'Start of trading',
    },
    {
        value: 'SelectTime',
        isInput: true,
        text: 'Select time',
    },
];

class ProComboInputTimeExample extends React.PureComponent {
    constructor() {
        super();

        this.state = {
            value: null,
        };
    }

    handleSelectValueChange({ value }) {
        let updatedValue = value;

        if (value === 'off') {
            updatedValue = null;
        } else if (value === 'SelectTime') {
            updatedValue = '';
        }

        this.setState({
            value: updatedValue,
        });

        this.props.action('select value change')(updatedValue);
    }

    handleTimeValueChange({ value }) {
        this.setState({
            value,
        });

        this.props.action('time value change')(value);
    }

    render() {
        const { value } = this.state;
        const {
            items,
            isCompact,
        } = this.props;

        let selectValue = value;

        if (selectValue === null) {
            selectValue = 'off';
        } else if (!_.find(items, { value: selectValue })) {
            selectValue = 'SelectTime';
        }

        return (
            <ProComboInput isCompact={isCompact}>
                <ProComboInputLabel>
                    Time input
                </ProComboInputLabel>
                <ProComboInputTime
                    selectValue={selectValue}
                    timeValue={value}
                    items={items}
                    title="Time Input"
                    onSelectValueChange={this.handleSelectValueChange}
                    onTimeValueChange={this.handleTimeValueChange}
                />
            </ProComboInput>
        );
    }
}

ProComboInputTimeExample.propTypes = {
    items: PropTypes.array.isRequired,
    action: PropTypes.func.isRequired,
    isCompact: PropTypes.func,
};

ProComboInputTimeExample.defaultProps = {
    isCompact: false,
};

const InputComponent = bindHandlers(ProComboInputTimeExample);

export default examplesOf('Pro Combo Input Time')
    .add('Time input and off', ({ action }) => (
        <InputComponent
            action={action}
            items={timeItems}
        />
    ))
    .add('Prefilled values', ({ action }) => (
        <InputComponent
            action={action}
            items={prefilledTimeItems}
        />
    ))
    .add('Time input and off (compact)', ({ action }) => (
        <InputComponent
            isCompact
            action={action}
            items={timeItems}
        />
    ))
    .add('Prefilled values (compact)', ({ action }) => (
        <InputComponent
            isCompact
            action={action}
            items={prefilledTimeItems}
        />
    ));
