import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import Icon from 'src/components/icon/icon';

const ACTIVATE_DELAY = 200; // ms

class InputButton extends React.PureComponent {

    constructor() {
        super();

        this.activateTimeout = null;
        this.deactivateTimeout = null;

        this.state = {
            isActive: false,
        };
    }

    componentWillReceiveProps(nextProps) {
        const { isShown } = this.props;

        if (!isShown && nextProps.isShown) {

            // delay activation to avoid initial tap when focusing the input
            this.activateTimeout = setTimeout(() => {
                this.setState({
                    isActive: true,
                });
            }, ACTIVATE_DELAY);

        } else if (isShown && !nextProps.isShown) {

            // delay deactivation to allow the button to be tapped
            this.deactivateTimeout = setTimeout(() => {
                this.setState({
                    isActive: false,
                });
            }, ACTIVATE_DELAY);

        }
    }

    componentWillUnmount() {
        clearTimeout(this.activateTimeout);
        clearTimeout(this.deactivateTimeout);
    }

    render() {
        const { iconType, isShown } = this.props;
        const { isActive } = this.state;

        const classes = classNames('procomboinput-icon procomboinput-icon--input tst-procomboinput-icon--input', {
            'is-shown': isShown,
            'is-inert': !isActive,
        });

        return (
            <Icon className={classes} type={iconType}/>
        );
    }

}

InputButton.propTypes = {
    iconType: PropTypes.string.isRequired,
    isShown: PropTypes.bool,
};

export default InputButton;
