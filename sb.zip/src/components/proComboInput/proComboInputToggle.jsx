import React from 'react';
import PropTypes from 'prop-types';
import Carousel from './carousel';
import Toggle from './toggle';
import SelectedValue from './selectedValue';

class ProComboInputToggle extends React.PureComponent {
    render() {
        const {
            value,
            items,
            isEnabled,
            onChange,
        } = this.props;

        let content = (
            <SelectedValue
                value={value}
                items={items}
            />
        );

        if (isEnabled) {
            content = (
                <Carousel
                    value={value}
                    items={items}
                    onChange={onChange}
                >
                    <Toggle
                        value={value}
                        items={items}
                        onChange={onChange}
                    >
                        {content}
                    </Toggle>
                </Carousel>
            );
        }

        return content;
    }
}

ProComboInputToggle.propTypes = {
    value: PropTypes.any,
    items: PropTypes.array.isRequired,
    isEnabled: PropTypes.bool,
    onChange: PropTypes.func,
};

ProComboInputToggle.defaultProps = {
    isEnabled: true,
};

export default ProComboInputToggle;
