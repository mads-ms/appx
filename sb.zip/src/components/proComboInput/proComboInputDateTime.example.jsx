import React from 'react';
import { examplesOf } from 'src/modules/examples/utils';
import ProComboInput from 'src/components/proComboInput/proComboInput';
import ProComboInputLabel from 'src/components/proComboInput/proComboInputLabel';
import ProComboInputDateTime from 'src/components/proComboInput/proComboInputDateTime';

const label = 'Date and time';
const items = [
    {
        value: 'select-date',
        text: 'Select date',
        isDateSelect: true,
    },
];
const value = 'select-date';

export default examplesOf('Pro Combo Input Date Time')
    .add('Default', ({ action }) => (
        <ProComboInput>
            <ProComboInputLabel>
                {label}
            </ProComboInputLabel>
            <ProComboInputDateTime
                title={label}
                items={items}
                selectValue={value}
                dateValue={null}
                onSelectValueChange={action('onSelectValueChange')}
                onDateValueChange={action('onDateValueChange')}
            />
        </ProComboInput>
    ))
    .add('Validation error', ({ action }) => {
        const validation = {
            type: 'error',
            message: 'Lorem ipsum dolor sit amet consectetur adipisicing elit',
        };

        return (
            <ProComboInput
                validation={validation}
            >
                <ProComboInputLabel>
                    {label}
                </ProComboInputLabel>
                <ProComboInputDateTime
                    title={label}
                    items={items}
                    selectValue={value}
                    dateValue={null}
                    onSelectValueChange={action('onSelectValueChange')}
                    onDateValueChange={action('onDateValueChange')}
                />
            </ProComboInput>
        );
    })
    .add('Disabled', ({ action }) => (
        <ProComboInput
            isEnabled={false}
        >
            <ProComboInputLabel>
                {label}
            </ProComboInputLabel>
            <ProComboInputDateTime
                isEnabled={false}
                title={label}
                items={items}
                selectValue={value}
                dateValue={null}
                onSelectValueChange={action('onSelectValueChange')}
                onDateValueChange={action('onDateValueChange')}
            />
        </ProComboInput>
    ))
    .add('Default (compact)', ({ action }) => (
        <ProComboInput isCompact>
            <ProComboInputLabel>
                {label}
            </ProComboInputLabel>
            <ProComboInputDateTime
                title={label}
                items={items}
                selectValue={value}
                dateValue={null}
                onSelectValueChange={action('onSelectValueChange')}
                onDateValueChange={action('onDateValueChange')}
            />
        </ProComboInput>
    ))
    .add('Validation error (compact)', ({ action }) => {
        const validation = {
            type: 'error',
            message: 'Lorem ipsum dolor sit amet consectetur adipisicing elit',
        };

        return (
            <ProComboInput
                validation={validation}
                isCompact
            >
                <ProComboInputLabel>
                    {label}
                </ProComboInputLabel>
                <ProComboInputDateTime
                    title={label}
                    items={items}
                    selectValue={value}
                    dateValue={null}
                    onSelectValueChange={action('onSelectValueChange')}
                    onDateValueChange={action('onDateValueChange')}
                />
            </ProComboInput>
        );
    })
    .add('Disabled (compact)', ({ action }) => (
        <ProComboInput
            isEnabled={false}
            isCompact
        >
            <ProComboInputLabel>
                {label}
            </ProComboInputLabel>
            <ProComboInputDateTime
                title={label}
                items={items}
                selectValue={value}
                dateValue={null}
                onSelectValueChange={action('onSelectValueChange')}
                onDateValueChange={action('onDateValueChange')}
                isEnabled={false}
            />
        </ProComboInput>
    ));
