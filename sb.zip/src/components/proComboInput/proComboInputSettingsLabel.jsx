import React from 'react';
import PropTypes from 'prop-types';
import SettingsSelect from './settings/settingsSelect';
import ProComboInputLabel from './proComboInputLabel';

class ProComboInputSettingsLabel extends React.PureComponent {
    render() {
        const {
            settings,
            label,
            dialogParent,
            isEnabled,
        } = this.props;

        return isEnabled ? (
            <SettingsSelect
                settings={settings}
                menuTitle={label}
                dialogParent={dialogParent}
            >
                <span className="procomboinput-settings-label tst-procomboinput-settings-label">
                    {label}
                </span>
            </SettingsSelect>
        ) : (
            <ProComboInputLabel>
                {label}
            </ProComboInputLabel>
        );
    }
}

ProComboInputSettingsLabel.propTypes = {
    settings: PropTypes.arrayOf(
        PropTypes.shape({
            id: PropTypes.string.isRequired,
            value: PropTypes.any,
            title: PropTypes.string.isRequired,
            options: PropTypes.arrayOf(
                PropTypes.shape({
                    value: PropTypes.any.isRequired,
                    text: PropTypes.string.isRequired,
                    className: PropTypes.string,
                })
            ).isRequired,
            onSelect: PropTypes.func.isRequired,
        })
    ).isRequired,
    label: PropTypes.string,
    dialogParent: PropTypes.instanceOf(HTMLElement),
    isEnabled: PropTypes.bool,
};

ProComboInputSettingsLabel.defaultProps = {
    isEnabled: true,
};

export default ProComboInputSettingsLabel;
