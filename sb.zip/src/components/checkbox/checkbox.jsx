import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import Touchable from 'src/components/touchable/touchable';
import Icon from 'src/components/icon/icon';

/**
 * Simple react component that encapsulates GO's custom checkbox.
 *
 * The checkbox's checked status is purely controlled by the isChecked prop.
 */
function Checkbox(props) {
    const { children, isChecked, isEnabled, onChange, className } = props;

    const iconClassName = classNames('checkbox-icon', {
        'checked': isChecked,
        'disabled': !isEnabled,
    });
    const divClassName = classNames('checkbox', className);

    return (
        <Touchable
            onTap={onChange}
            isEnabled={isEnabled}
        >
            <div className={divClassName}>
                <Icon
                    type="tick"
                    className={iconClassName}
                />
                {

                // Explicit space added for backwards compatibility with OpenCSS and all Spine views
                // that render a spare white space. Remove once everything is moved to React.
                }
                {' '}{children}
            </div>
        </Touchable>
    );
}

Checkbox.propTypes = {
    className: PropTypes.string,
    isChecked: PropTypes.bool,
    isEnabled: PropTypes.bool,
    onChange: PropTypes.func,
};

Checkbox.defaultProps = {
    isEnabled: true,
    onChange: _.noop,
};

export default Checkbox;
