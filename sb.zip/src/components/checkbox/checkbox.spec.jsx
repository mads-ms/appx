import React from 'react';
import { shallow } from 'enzyme';
import Checkbox from 'src/components/checkbox/checkbox';

describe('src/components/checkbox/checkbox', () => {
    it('renders successfully', () => {
        const children = <span/>;
        const wrapper = shallow(<Checkbox>{children}</Checkbox>);

        expect(wrapper.contains(children)).toBe(true);
    });

    it('is unchecked and enabled by default', () => {
        const wrapper = shallow(<Checkbox/>);

        expect(wrapper.find('.checked').length).toEqual(0);
        expect(wrapper.find('.disabled').length).toEqual(0);
    });

    it('is checked when isChecked is true', () => {
        const wrapper = shallow(<Checkbox isChecked/>);

        expect(wrapper.find('.checked').length).toEqual(1);
    });

    it('is disabled when isDisabled is true', () => {
        const wrapper = shallow(<Checkbox isEnabled={false}/>);

        expect(wrapper.find('.disabled').length).toEqual(1);
    });

    it('has a spare whitespace for compatibility with OpenCSS specs and Spine component', () => {
        const wrapper = shallow(<Checkbox>{'Test'}</Checkbox>);

        expect(wrapper.find('.checkbox').text()).toEqual('<Icon /> Test');
    });
});
