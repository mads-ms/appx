import React from 'react';
import { mount } from 'enzyme';
import GraphBar from 'src/components/graphBar/graphBar';

describe('src/components/graphBar/graphBar', () => {
    it('renders graphBar with default values', () => {
        const testProps = {
            isHeat: true,
            isSkinny: false,
            isMedium: false,
            pct: 0,
        };
        const wrapper = mount(<GraphBar {...testProps}/>);

        expect(wrapper.find('.graph').length).toEqual(1);
        expect(wrapper.find('.graph').prop('className')).toEqual('graph graph--fixedwidth graph--heat');
        expect(wrapper.find('.graph-bar').prop('style').width).toEqual('100%');
    });

    it('shows width as a whole number when pct is in decimals', () => {
        const testProps = {
            isHeat: true,
            isSkinny: false,
            isMedium: false,
            pct: 0.12,
        };
        const wrapper = mount(<GraphBar {...testProps}/>);

        expect(wrapper.find('.graph-bar').prop('style').width).toEqual('99%');
    });

    it('shows 0 width if pct is greater than 100', () => {
        const testProps = {
            isHeat: true,
            isSkinny: false,
            isMedium: false,
            pct: 101.1,
        };
        const wrapper = mount(<GraphBar {...testProps}/>);

        expect(wrapper.find('.graph-bar').prop('style').width).toEqual('0%');
    });

    it('shows adds class graph--skinny when isSkinny true', () => {
        const testProps = {
            isHeat: false,
            isSkinny: true,
            isMedium: false,
            pct: 0,
        };
        const wrapper = mount(<GraphBar {...testProps}/>);

        expect(wrapper.find('.graph').prop('className')).toEqual('graph graph--fixedwidth graph--skinny');
    });

    it('shows adds class graph--medium when isSkinny true', () => {
        const testProps = {
            isHeat: false,
            isSkinny: false,
            isMedium: true,
            pct: 0,
        };
        const wrapper = mount(<GraphBar {...testProps}/>);

        expect(wrapper.find('.graph').prop('className')).toEqual('graph graph--fixedwidth graph--medium');
    });
});
