import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';

const GraphBar = (props) => {

    const {
        isHeat,
        isSkinny,
        isMedium,
        pct,
    } = props;

    const className = classNames('graph graph--fixedwidth', {
        'graph--heat': isHeat,
        'graph--skinny': isSkinny,
        'graph--medium': isMedium,
    });

    // Math.ceil is used to make progress bar prominent for smaller values of pct
    const width = `${Math.max(0, 100 - Math.ceil(pct))}%`;

    return (
        <span className={className}>
            <span className="graph-bar" style={{ width }}/>
        </span>
    );
};

GraphBar.propTypes = {
    isHeat: PropTypes.bool,
    isSkinny: PropTypes.bool,
    isMedium: PropTypes.bool,
    pct: PropTypes.number,
};

GraphBar.defaultProps = {
    isHeat: true,
    isSkinny: false,
    isMedium: false,
    pct: 0,
};

export default GraphBar;
