import React from 'react';
import { shallow } from 'enzyme';
import Sparkline from './sparkline';

// svg points are in the format: "x1,y1 x2,y2 x3,y3"
// expect three data points to be:
// - bottom left (with padding)
// - middle
// - top right (with padding)

describe('src/components/sparkline/sparkline', () => {
    it('renders no data points', () => {
        const data = [];
        const width = 100;
        const height = 100;

        const wrapper = shallow(<Sparkline data={data} width={width} height={height}/>);

        const polyline = wrapper.find('polyline');
        expect(polyline.length).toBe(1);

        const points = polyline.prop('points');
        expect(points.length).toBe(0);
    });

    it('renders a single data point', () => {
        const data = [1];
        const width = 100;
        const height = 100;

        const wrapper = shallow(<Sparkline data={data} width={width} height={height}/>);

        const polyline = wrapper.find('polyline');
        expect(polyline.length).toBe(1);
        expect(polyline.prop('points')).toBe('1,50 99,50');
    });

    it('renders multiple same data points', () => {
        const data = [1, 1, 1];
        const width = 100;
        const height = 100;

        const wrapper = shallow(<Sparkline data={data} width={width} height={height}/>);

        const polyline = wrapper.find('polyline');
        expect(polyline.length).toBe(1);
        expect(polyline.prop('points')).toBe('1,50 99,50');
    });

    it('renders multiple positive data points', () => {
        const data = [1, 2, 3];
        const width = 100;
        const height = 100;

        const wrapper = shallow(<Sparkline data={data} width={width} height={height}/>);

        const polyline = wrapper.find('polyline');
        expect(polyline.length).toBe(1);
        expect(polyline.prop('points')).toBe('1,99 50,50 99,1');
    });

    it('renders multiple positive and negative data points', () => {
        const data = [1, -2, 2];
        const width = 100;
        const height = 100;

        const wrapper = shallow(<Sparkline data={data} width={width} height={height}/>);

        const polyline = wrapper.find('polyline');
        expect(polyline.length).toBe(1);
        expect(polyline.prop('points')).toBe('1,25.5 50,99 99,1');
    });
});
