import _ from 'lodash';
import React from 'react';
import Sparkline from './sparkline';
import { examplesOf } from 'src/modules/examples/utils';

export default examplesOf('Sparkline', 'sparkline')
    .add('Linear', () => (
        <Sparkline data={[1, 2, 3, 4, 5]} width={200} height={50}/>
    ))
    .add('Flat', () => (
        <Sparkline data={[1, 1, 1, 2, 3]} width={200} height={50}/>
    ))
    .add('Single Point', () => (
        <Sparkline data={[1]} width={200} height={50}/>
    ))
    .add('Random', () => (
        <Sparkline data={_.times(20, Math.random)} width={200} height={50}/>
    ));
