import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';

// allow extra space to avoid cropping the line
const PADDING = 1;

class Sparkline extends React.PureComponent {
    getDataPoints() {
        const { data, width, height } = this.props;

        // not enough data points to display
        if (!data.length) {
            return '';
        }

        const max = _.max(data);
        const min = _.min(data);

        // all data points are the same, render a flat line
        if (max === min) {
            const x1 = PADDING;
            const x2 = width - PADDING;
            const y = height / 2;
            return `${x1},${y} ${x2},${y}`;
        }

        const xScale = (width - PADDING * 2) / (data.length - 1);
        const yScale = (height - PADDING * 2) / (max - min);

        return _.map(data, (datum, i) => {
            const x = i * xScale + PADDING;
            const y = height - ((datum - min) * yScale + PADDING);
            return `${x},${y}`;
        }).join(' ');
    }

    render() {
        const { width, height } = this.props;

        return (
            <svg className="sparkline" width={width} height={height} xmlns="http://www.w3.org/2000/svg">
                <polyline points={this.getDataPoints()}/>
            </svg>
        );
    }
}

Sparkline.propTypes = {
    data: PropTypes.arrayOf(PropTypes.number).isRequired,
    width: PropTypes.number.isRequired,
    height: PropTypes.number.isRequired,
};

export default Sparkline;
