import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import ReactGridHeaderItem from './reactGridHeaderItem';

const HEADER_CLASS = 'reactgrid-header';
const TST_HEADER_CLASS = 'tst-grid-header';

class ReactGridHeaderRows extends React.PureComponent {

    getHeaderStyles() {
        const {
            headerHeight,
            headerLineHeight,
        } = this.props;

        return {
            height: headerHeight,
            lineHeight: `${headerLineHeight}px`,
            position: 'relative',
            width: '100%',
        };
    }

    render() {
        const {
            headerClass,
            cellClass,
            visibleColumns,
            sort,
            children,
            onHeaderSort,
        } = this.props;

        // Use index for key to prevent unmounting node from dom
        const headers = _.map(visibleColumns, (column, index) => (
            <ReactGridHeaderItem
                key={index}
                column={column}
                cellClass={cellClass}
                sort={sort}
                onHeaderSort={onHeaderSort}
            />
        ));

        let content = headers;

        if (children) {
            content = React.cloneElement(React.Children.only(children), { headers });
        }

        const classes = classNames(
            HEADER_CLASS,
            TST_HEADER_CLASS,
            headerClass
        );

        return (
            <div className="grid-cell g--fit">
                <header
                    className={classes}
                    style={this.getHeaderStyles()}
                >
                    {content}
                </header>
            </div>
        );
    }
}

ReactGridHeaderRows.propTypes = {
    headerClass: PropTypes.string,
    headerHeight: PropTypes.number.isRequired,
    headerLineHeight: PropTypes.number,
    cellClass: PropTypes.string,
    visibleColumns: PropTypes.array.isRequired,
    sort: PropTypes.object,
    onHeaderSort: PropTypes.func,
};

export default ReactGridHeaderRows;
