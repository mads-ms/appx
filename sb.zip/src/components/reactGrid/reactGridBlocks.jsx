import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import TemplateHelper from 'src/spine/templateHelper';
import Localization from 'src/localization';
import Icon from 'src/components/icon/icon';
import classNames from 'classnames';
import Enums from 'src/spine/enums';
import Touchable from 'src/components/touchable/touchable';

export { default as ActionButton } from 'src/components/reactGrid/blocks/actionButton';
export { default as InstrumentLabel } from 'src/components/reactGrid/blocks/instrumentLabel';
export { default as IdentifiedLabel } from 'src/components/reactGrid/blocks/identifiedLabel';
export { default as IntervalLabel } from 'src/components/reactGrid/blocks/intervalLabel';
export { default as PriceLabel } from 'src/components/reactGrid/blocks/priceLabel';
export { default as ProfitLabel } from 'src/components/reactGrid/blocks/profitLabel';

export function SortHandle({ className, onTouchStart, onTouchEnd }) {
    return (
        <Touchable onTouchStart={onTouchStart} onTouchEnd={onTouchEnd}>
            {/* btn and btn--clear styles are used here for the sake of code reusability;
               <button> is not used here as SortHandle doesn't require or represent button's behavior */}
            <div key="sort" className={classNames(className, 'reactgrid-sortbtn btn btn--clear')}>
                <Icon type="sort"/>
            </div>
        </Touchable>
    );
}

SortHandle.propTypes = {
    className: PropTypes.string,
    onTouchStart: PropTypes.func,
    onTouchEnd: PropTypes.func,
};

export function IconHigh() {
    return (<Icon type="high" size="small"/>);
}

export function IconLow() {
    return (<Icon type="low" size="small"/>);
}

function getColumnTitleTestClass(title) {
    return title ? 'tst-' + title.trim().replace(' ', '-') : '';
}

export function HeaderInstrument(column) {
    const sortIcons = !column.isNotSortable && [' ', <IconHigh key="icon-high"/>, <IconLow key="icon-low"/>];

    return (
        <div data-sortdir={column.sortDataValue}>
            <p>
                {Localization.getText('HTML5_Instrument')}
                {sortIcons}
            </p>
        </div>
    );
}

HeaderInstrument.propTypes = {
    column: PropTypes.object.isRequired,
};

export function HeaderInstrumentDbl(column) {
    const sortIcons = !column.isNotSortable && [<IconHigh key="icon-high"/>, <IconLow key="icon-low"/>];

    return (
        <div data-sortdir={column.sortDataValue}>
            <p>
                {column.primaryTitle || Localization.getText('HTML5_Instrument')}
                {sortIcons}
            </p>
            <p className="beta">{column.secondaryTitle || Localization.getText('HTML5_Description')}</p>
        </div>
    );
}

HeaderInstrumentDbl.propTypes = {
    column: PropTypes.object.isRequired,
};

export function Header(props) {
    const { className, isNotSortable, primaryTitle, secondaryTitle, sortDataValue, isSortAlignEnd, unitsLabel } = props;
    const sortButtons = isNotSortable ? [] : [<IconHigh key="icon-high"/>, <IconLow key="icon-low"/>];

    const headerElements = isSortAlignEnd ? [primaryTitle, ...sortButtons] : [...sortButtons, primaryTitle];
    const primaryTitleTestClass = getColumnTitleTestClass(primaryTitle);
    const secondaryTitleTestClass = getColumnTitleTestClass(secondaryTitle);

    return (
        <div
            className={classNames('col-header', className)}
            data-sortable={!isNotSortable}
            data-sortdir={sortDataValue}
            data-align-end={isSortAlignEnd}
        >
            {primaryTitle &&
                <p className={primaryTitleTestClass}>
                    {headerElements}
                    {unitsLabel && <span className="units"> ({unitsLabel})</span>}
                </p>
            }
            {secondaryTitle &&
                <p className={classNames('beta', secondaryTitleTestClass)}>{secondaryTitle}</p>
            }
            {!primaryTitle && !secondaryTitle &&
                <p>&nbsp;</p>
            }
        </div>
    );
}

Header.propTypes = {
    className: PropTypes.string,
    isNotSortable: PropTypes.bool,
    isSortAlignEnd: PropTypes.bool,
    sortDataValue: PropTypes.string,
    primaryTitle: PropTypes.string,
    secondaryTitle: PropTypes.string,
    unitsLabel: PropTypes.string,
};

Header.defaultProps = {
    isNotSortable: false,
    sortDataValue: '',
};

export function HeaderEmpty() {
    return (
        <noscript/>
    );
}

export function HeaderTooltip({ primaryTitle, secondaryTitle }) {
    return secondaryTitle ? (
        <div>
            <p>{primaryTitle}</p>
            <p>{secondaryTitle}</p>
        </div>
    ) : (
        <p>{primaryTitle}</p>
    );
}

HeaderTooltip.propTypes = {
    primaryTitle: PropTypes.string,
    secondaryTitle: PropTypes.string,
};

export function AlphaBeta({ value, title, betaTitle, className, betaValue, dataValue = null, betaDataValue = null, column }) {
    const primaryTitleTestClass = getColumnTitleTestClass(column.primaryTitle);
    const secondaryTitleTestClass = getColumnTitleTestClass(column.secondaryTitle);

    const hasAlphaValue = Boolean(value || _.isNumber(value));

    const alphaEl = (
        <p title={title} className={primaryTitleTestClass}>
            {
                hasAlphaValue &&
                    <span data-profit={dataValue}>{value}</span>
            }
        </p>);
    const betaEl = betaValue && (
        <p title={betaTitle} className={classNames('beta', secondaryTitleTestClass)}>
            <span data-profit={betaDataValue}>{betaValue}</span>
        </p>
    );

    if (className || betaEl) {
        return (
            <div className={className}>
                {alphaEl}
                {betaEl}
            </div>
        );
    }

    return alphaEl;
}

AlphaBeta.propTypes = {
    betaDataValue: PropTypes.string,
    betaValue: PropTypes.string,
    className: PropTypes.string,
    dataValue: PropTypes.string.isRequired,
    title: PropTypes.string,
    betaTitle: PropTypes.string,
    value: PropTypes.string.isRequired,
    column: PropTypes.object.isRequired,
};

export function DelayBeta({ value, betaValue = null, priceType, isPlaceholder }) {
    let delayIcon = null;

    if (isPlaceholder) {
        // Render sample icon to keep spacing and hide it
        delayIcon = <Icon type="delay" className="is-hidden"/>;
    }

    if (priceType === Enums.PriceAccessType.Delayed || priceType === Enums.PriceAccessType.NoAccess) {
        const delayIconClass = TemplateHelper.getDelayIconClass(priceType);

        // TemplateHelper.getDelayIconClass is legacy and actually maps to "price status"
        //  - Thus icon class don't map 1:1 with these, so need further mapping
        const delayIconType = delayIconClass === 'delayed' ? 'delay' : delayIconClass;
        delayIcon = <Icon type={delayIconType}/>;
    }

    const title = TemplateHelper.getDelayInfoText(priceType, value, true);

    return (
        <div title={isPlaceholder ? '' : title}>
            {delayIcon || (<p></p>)}
            {betaValue && (<p className="beta">{betaValue}</p>)}
        </div>
    );
}

DelayBeta.propTypes = {
    betaValue: PropTypes.string,
    priceType: PropTypes.number.isRequired,
    value: PropTypes.number.isRequired,
    isPlaceholder: PropTypes.bool,
};

DelayBeta.defaultProps = {
    betaValue: '',
    isPlaceholder: false,
};
