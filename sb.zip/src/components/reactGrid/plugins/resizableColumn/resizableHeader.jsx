import PropTypes from 'prop-types';
import React from 'react';
import { bindHandlers } from 'src/utils/bindHandlers';
import Pannable from 'src/components/touchable/pannable';
import Touchable from 'src/components/touchable/touchable';
import * as constants from './constants';

class ResizableHeader extends React.PureComponent {

    handleMouseEnter(evt) {
        this.props.onMouseEnter(evt, this.props);
    }

    handleMouseLeave(evt) {
        this.props.onMouseLeave(evt);
    }

    handlePanStart(evt) {
        this.props.onPanStart(evt, this.props);
    }

    handlePan(evt) {
        this.props.onPan(evt, this.props);
    }

    handlePanEnd(evt) {
        this.props.onPanEnd(evt);
    }

    render() {
        const { width, offset } = this.props.column;

        // position splitter at end of column
        const leftOffset = width + offset - constants.SPLITTER_HANDLE_WIDTH;

        // splitter-handle styles
        const styles = {
            transform: `translate3d(${leftOffset}px, 0, 0)`,
        };

        // <Pannable/> doesn't expose all the event extensions required for the
        // resize UX, especially :hover and :active feedback, so <Touchable/>
        // is used to capture this input.
        return (
            <div>
                {this.props.children}
                <Pannable
                    directionSupport="horizontal"
                    threshold={0}
                    onPan={this.handlePan}
                    onPanEnd={this.handlePanEnd}
                    ref={this.setEl}
                >
                    <Touchable
                        onTouch={this.handlePanStart}
                        onPressUp={this.handlePanEnd}
                        onMouseEnter={this.handleMouseEnter}
                        onMouseLeave={this.handleMouseLeave}
                    >
                        <div className={constants.SPLITTER_HANDLE_CLASS} style={styles}/>
                    </Touchable>
                </Pannable>
            </div>
        );
    }
}

ResizableHeader.propTypes = {
    column: PropTypes.object.isRequired,
    onMouseEnter: PropTypes.func.isRequired,
    onMouseLeave: PropTypes.func.isRequired,
    onPanStart: PropTypes.func.isRequired,
    onPan: PropTypes.func.isRequired,
    onPanEnd: PropTypes.func.isRequired,
};

export default bindHandlers(ResizableHeader);
