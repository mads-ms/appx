/**
 * <ReactGrid/> Resizable column plugin unit tests
 */
import $ from 'jqueryAll';
import React from 'react';
import ReactGrid from 'src/components/reactGrid/reactGrid';
import ResizableColumnPlugin from 'src/components/reactGrid/plugins/resizableColumn/resizableColumnPlugin';
import ResizableHeader from 'src/components/reactGrid/plugins/resizableColumn/resizableHeader';
import { SPLITTER_HANDLE_CLASS } from 'src/components/reactGrid/plugins/resizableColumn/constants';
import { createCols } from '../../reactGridSpecHelper';
import { mount } from 'enzyme';

describe('src/components/reactGrid/plugins/resizableColumn', () => {
    describe('ResizableColumnPlugin', () => {
        // assertion state
        let resizeData;
        let wrapper;
        let handleResizeStart;
        let handleResizeEnd;
        let handleResize;

        // controlled state setup before each test
        let defaultProps;
        let colDescriptor;

        beforeEach(() => {
            resizeData = null;
            handleResizeStart = jasmine.createSpy();
            handleResizeEnd = jasmine.createSpy();
            handleResize = jasmine.createSpy().and.callFake((evt) => {
                resizeData = evt;
            });

            defaultProps = {
                isHeader: true,
                width: 500,
                height: 100,
                rowHeight: 20,
                headerHeight: 30,
            };

            colDescriptor = createCols(['foo'],
                {
                    'foo': {
                        'width': 150,
                        'minWidth': 100,
                        'maxWidth': 200,
                        'isResizable': true,
                    },
                }
            );
        });

        afterEach(() => {
            wrapper.unmount();
        });

        it('renders successfully', () => {
            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    {...defaultProps}
                >
                    <ResizableColumnPlugin
                        onResize={handleResize}
                        onResizeStart={handleResizeStart}
                        onResizeEnd={handleResizeEnd}
                    />
                </ReactGrid>
            );

            expect(wrapper.find(ResizableHeader).length).toEqual(1);
            expect(wrapper.find(`.${SPLITTER_HANDLE_CLASS}`).length).toEqual(1);

            // assert plugin respects default (or cached) column width
            const cellNodes = wrapper.find('.reactgrid-header .reactgrid-cell');
            expect($(cellNodes.at(0).getDOMNode()).width()).toEqual(150);
        });

        it('prevents resizing if not configured', () => {
            colDescriptor[0].isResizable = false;

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    {...defaultProps}
                >
                    <ResizableColumnPlugin
                        onResize={handleResize}
                        onResizeStart={handleResizeStart}
                        onResizeEnd={handleResizeEnd}
                    />
                </ReactGrid>
            );

            expect(wrapper.find(ResizableHeader).length).toEqual(0);
            expect(wrapper.find(`.${SPLITTER_HANDLE_CLASS}`).length).toEqual(0);
        });

        it('clamps column to minimum size if specified', () => {
            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    {...defaultProps}
                >
                    <ResizableColumnPlugin
                        onResize={handleResize}
                        onResizeStart={handleResizeStart}
                        onResizeEnd={handleResizeEnd}
                    />
                </ReactGrid>
            );

            // exercise
            const plugin = wrapper.find(ResizableColumnPlugin);

            // simulate pan start directly - hammer is not working with simulate
            colDescriptor[0].offset = 0;
            plugin.instance().handleSplitterPanStart({}, { column: colDescriptor[0] });
            plugin.instance().handleSplitterPan({ deltaX: -100 });

            // consumers have to roundtrip the width back into the grid to apply
            // it, so just ensure that the emitted data is correct
            expect(resizeData.columnId).toEqual('foo');
            expect(resizeData.width).toEqual(100);
        });

        it('clamps column to maximum size if specified', () => {
            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    {...defaultProps}
                >
                    <ResizableColumnPlugin
                        onResize={handleResize}
                        onResizeStart={handleResizeStart}
                        onResizeEnd={handleResizeEnd}
                    />
                </ReactGrid>
            );

            // exercise
            const plugin = wrapper.find(ResizableColumnPlugin);

            // simulate pan start directly - hammer is not working with simulate
            colDescriptor[0].offset = 0;
            plugin.instance().handleSplitterPanStart({}, { column: colDescriptor[0] });
            plugin.instance().handleSplitterPan({ deltaX: 100 });

            // consumers have to roundtrip the width back into the grid to apply
            // it, so just ensure that the emitted data is correct
            expect(resizeData.columnId).toEqual('foo');
            expect(resizeData.width).toEqual(200);
        });

        it('clamps column to maximum size possible within container', () => {
            defaultProps.width = 175;

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    {...defaultProps}
                >
                    <ResizableColumnPlugin
                        onResize={handleResize}
                        onResizeStart={handleResizeStart}
                        onResizeEnd={handleResizeEnd}
                    />
                </ReactGrid>
            );

            // exercise
            const plugin = wrapper.find(ResizableColumnPlugin);

            // simulate pan start directly - hammer is not working with simulate
            colDescriptor[0].offset = 0;
            plugin.instance().handleSplitterPanStart({}, { column: colDescriptor[0] });
            plugin.instance().handleSplitterPan({ deltaX: 100 });

            // consumers have to roundtrip the width back into the grid to apply
            // it, so just ensure that the emitted data is correct
            expect(resizeData.columnId).toEqual('foo');
            expect(resizeData.width).toEqual(174); // accommodate culling margin error
        });

        it('emits updated column width when within min/max bounds', () => {
            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    {...defaultProps}
                >
                    <ResizableColumnPlugin
                        onResize={handleResize}
                        onResizeStart={handleResizeStart}
                        onResizeEnd={handleResizeEnd}
                    />
                </ReactGrid>
            );

            // exercise
            const plugin = wrapper.find(ResizableColumnPlugin);

            // simulate pan start directly - hammer is not working with simulate
            colDescriptor[0].offset = 0;
            plugin.instance().handleSplitterPanStart({}, { column: colDescriptor[0] });
            plugin.instance().handleSplitterPan({ deltaX: -10 });

            // consumers have to roundtrip the width back into the grid to apply
            // it, so just ensure that the emitted data is correct
            expect(resizeData.columnId).toEqual('foo');
            expect(resizeData.width).toEqual(140);
        });
    });
});
