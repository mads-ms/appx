import PropTypes from 'prop-types';
import React from 'react';
import _ from 'lodash';
import config from 'src/config';
import * as pluginsConstants from '../constants';
import ResizableHeader from './resizableHeader';
import classNames from 'classnames';
import * as constants from './constants';
import { bindHandlers } from 'src/utils/bindHandlers';
import { UI, detect } from 'openui';

// mitigate off-by-one errors in ReactGrid's column culling algorithm
const CULLING_ERROR_MARGIN = 1;

class ResizableColumnPlugin extends React.PureComponent {
    constructor() {
        super();

        this.state = {
            activeColumn: null,
            leftOffset: 0,
            isPanning: false,
            isHover: false,
            newWidth: null,
        };

        this.prevDelta = 0;
    }

    handleSplitterMouseEnter(evt, header) {
        const { width, offset } = header.column;

        this.setState({
            leftOffset: width + offset,
            isHover: true,
        });
    }

    handleSplitterMouseLeave() {
        this.setState({
            isHover: false,
        });
    }

    handleSplitterPanStart(evt, header) {
        const { column } = header;
        const { width, offset } = column;

        this.props.onResizeStart(column.id);

        this.setState({
            activeColumn: column,
            leftOffset: width + offset,
            isPanning: true,
        });
    }

    handleSplitterPan(evt) {
        const { resizeMode } = this.props;
        const { deltaX } = evt;
        const {
            leftOffset,
            activeColumn,
        } = this.state;

        const headerWidth = this.props.width;
        const { id } = activeColumn;
        const columnOffset = activeColumn.offset;
        const columnWidth = activeColumn.width;
        const columnMinWidth = activeColumn.minWidth;
        const columnMaxWidth = activeColumn.maxWidth;

        // compute distance to edge in scenario user wants to resize the column
        // flush to edge of the grid
        const distanceToEdge = (headerWidth - CULLING_ERROR_MARGIN) - (columnOffset + columnWidth);

        // compute column resize bounds
        const minWidth = columnMinWidth || constants.DEFAULT_COL_MIN_WIDTH;
        const minDelta = minWidth - columnWidth;
        const maxWidth = Math.min(columnMaxWidth, columnWidth + distanceToEdge);
        const maxDelta = maxWidth - columnWidth;
        const newWidth = columnWidth + deltaX;

        if (newWidth >= minWidth && newWidth <= maxWidth) {
            if (resizeMode === constants.LIVE_PREVIEW) {
                this.props.onResize({
                    columnId: id,
                    width: newWidth,
                });
            }

            this.setState({
                newWidth,
                leftOffset: leftOffset + (deltaX - this.prevDelta),
            });

            this.prevDelta = deltaX;

        // clamp minsize of column and pin splitter
        } else if (deltaX < minDelta && this.prevDelta !== minDelta) {
            if (resizeMode === constants.LIVE_PREVIEW) {
                this.props.onResize({
                    columnId: id,
                    width: minWidth,
                });
            }

            this.setState({
                newWidth: minWidth,
                leftOffset: columnOffset + minWidth,
            });

            this.prevDelta = minDelta;

        // clamp maxsize of column and pin splitter
        } else if (deltaX > maxDelta && this.prevDelta !== maxDelta) {
            if (resizeMode === constants.LIVE_PREVIEW) {
                this.props.onResize({
                    columnId: id,
                    width: maxWidth,
                });
            }

            this.setState({
                newWidth: maxWidth,
                leftOffset: columnOffset + maxWidth,
            });

            this.prevDelta = maxDelta;
        }
    }

    handleSplitterPanEnd() {
        if (this.props.resizeMode === constants.SNAP_PREVIEW) {
            this.props.onResize({
                columnId: this.state.activeColumn.id,
                width: this.state.newWidth,
            });
        }

        this.props.onResizeEnd();

        this.setState({
            newWidth: null,
            activeColumn: null,
            isPanning: false,
        });

        this.prevDelta = 0;
    }

    getResizableHeaders() {
        const { headers } = this.props;
        const { isPanning, activeColumn } = this.state;

        return _.map(headers, (header, idx) => {
            const column = this.props.visibleColumns[idx];

            // suppress other resizable columns when panning
            // this prevents the col-resize cursor appearing when panning
            // above non-active columns
            if (column && (!isPanning && column.isResizable) || (isPanning && activeColumn.id === column.id)) {
                return (
                    <ResizableHeader
                        key={column.id}
                        column={column}
                        onMouseEnter={this.handleSplitterMouseEnter}
                        onMouseLeave={this.handleSplitterMouseLeave}
                        onPanStart={this.handleSplitterPanStart}
                        onPan={this.handleSplitterPan}
                        onPanEnd={this.handleSplitterPanEnd}
                    >
                        {header}
                    </ResizableHeader>
                );
            }

            return header;
        });
    }

    render() {
        const {
            headers,
            height,
            nextPlugin,
        } = this.props;

        const {
            isPanning,
            isHover,
            leftOffset,
        } = this.state;

        const resizableHeaders = headers.length ? this.getResizableHeaders() : headers;
        let content = resizableHeaders;

        if (nextPlugin) {
            content = React.cloneElement(nextPlugin, { headers: resizableHeaders });
        }

        // splitter styles
        const styles = {
            height,
            transform: `translate3d(${leftOffset}px, 0, 0)`,
        };

        const classes = classNames(constants.SPLITTER_CLASS, {
            [UI.Class.Active]: isPanning || isHover,
        });

        return [
            content,
            <div key="sticker" className={classes} style={styles}/>,
        ];
    }
}

ResizableColumnPlugin.propTypes = {
    isEnabled: PropTypes.bool,
    type: PropTypes.string,
    nextPlugin: PropTypes.element,
    visibleColumns: PropTypes.array,
    headers: PropTypes.array,
    height: PropTypes.number,
    width: PropTypes.number,

    // resize preview type: slow browsers (ie11) cannot handle realtime resizing
    //                      so provide an option to only emit the new column size
    //                      when a user ends the resize interaction.
    resizeMode: PropTypes.oneOf([constants.LIVE_PREVIEW, constants.SNAP_PREVIEW]),
    onResizeStart: PropTypes.func,
    onResize: PropTypes.func,
    onResizeEnd: PropTypes.func,
};

ResizableColumnPlugin.defaultProps = {
    isEnabled: config.isDesktopApp,
    type: pluginsConstants.HEADER_PLUGIN_TYPE,
    height: 0,
    resizeMode: detect.os.ie11 ? constants.SNAP_PREVIEW : constants.LIVE_PREVIEW,
    onResizeStart: _.noop,
    onResize: _.noop,
    onResizeEnd: _.noop,
};

export default bindHandlers(ResizableColumnPlugin);
