export const DEFAULT_COL_MIN_WIDTH = 50;

export const SNAP_PREVIEW = 'snap';
export const LIVE_PREVIEW = 'live';

export const SPLITTER_CLASS = 'reactgrid-splitter';
export const SPLITTER_HANDLE_CLASS = 'reactgrid-splitter-handle';
export const SPLITTER_HANDLE_WIDTH = 8;
