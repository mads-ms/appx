import React from 'react';
import ReactGrid from 'src/components/reactGrid/reactGrid';
import ReactGridRow from 'src/components/reactGrid/reactGridRow';
import LinkedGridRowPlugin from 'src/components/reactGrid/plugins/linkedRow/linkedGridRowPlugin';
import { createCols } from '../../reactGridSpecHelper';
import { mount } from 'enzyme';

describe('src/components/reactGrid/plugins/linkedRow', () => {
    describe('LinkedGridRowPlugin', () => {

        const CUSTOM_ROW_CLASS = 'row-class';
        const rowDescriptor = [
            {
                id: 'A',
                data: {},
                isNotSortable: true,
                isRootExcluded: true,
                isGroup: true,
                rows: [
                    { id: 'AA', data: {}, isRelated: true },
                    { id: 'BB', data: {}, isRelated: true },
                ],
            },
            { id: 'B', data: {} },
            { id: 'C', data: {} },
        ];

        const colDescriptor = createCols(['foo']);

        let wrapper;
        let defaultProps;

        beforeEach(() => {

            defaultProps = {
                isHeader: false,
                width: 500,
                height: 500,
                rowHeight: 20,
                headerHeight: 30,
                rowClass: CUSTOM_ROW_CLASS,
                isGrouping: true,
                keepGroupsExpanded: true,
                rows: rowDescriptor,
                cols: colDescriptor,
            };
        });

        afterEach(() => {
            wrapper.unmount();
        });

        afterAll(() => {
        });

        it('renders without linked rows', () => {
            wrapper = mount(
                <ReactGrid
                    {...defaultProps}
                >
                    <LinkedGridRowPlugin
                        onGetLinkingInfo={() => ({ linkMode: 0, linkType: null })}
                    />
                </ReactGrid>
            );

            expect(wrapper.find(ReactGridRow).length).toEqual(4);
            expect(wrapper.find(`div.${CUSTOM_ROW_CLASS}`).length).toEqual(4);
            expect(wrapper.find('.reactgrid-row--link-first').length).toEqual(0);
            expect(wrapper.find('.reactgrid-row--link-second').length).toEqual(0);
            expect(wrapper.find('.reactgrid-row--link-fx').length).toEqual(0);
        });

        it('renders linked rows', () => {

            const getLinkMode = ({ rowInfo }) => {
                if (!rowInfo.isRelated) {
                    return 0;
                }

                if (rowInfo.childIndex === 0) {
                    return 1;
                }

                return 2;
            };

            wrapper = mount(
                <ReactGrid
                    {...defaultProps}
                >
                    <LinkedGridRowPlugin
                        onGetLinkingInfo={
                            (row) =>
                                ({
                                    linkMode: getLinkMode(row),
                                    linkType: 'fx',
                                })
                        }
                    />
                </ReactGrid>
            );

            expect(wrapper.find(ReactGridRow).length).toEqual(4);
            expect(wrapper.find(`div.${CUSTOM_ROW_CLASS}`).length).toEqual(4);
            expect(wrapper.find('.reactgrid-row--link-first').length).toEqual(1);
            expect(wrapper.find('.reactgrid-row--link-second').length).toEqual(1);
            expect(wrapper.find('.reactgrid-row--link-fx').length).toEqual(2);
        });

        it('renders linked rows with custom class', () => {

            const getLinkMode = ({ rowInfo }) => {
                if (!rowInfo.isRelated) {
                    return 0;
                }

                if (rowInfo.childIndex === 0) {
                    return 1;
                }

                return 2;
            };

            wrapper = mount(
                <ReactGrid
                    {...defaultProps}
                >
                    <LinkedGridRowPlugin
                        rowClassName="custom-linked"
                        onGetLinkingInfo={
                            (row) =>
                                ({
                                    linkMode: getLinkMode(row),
                                    linkType: 'fx',
                                })
                        }
                    />
                </ReactGrid>
            );

            expect(wrapper.find(ReactGridRow).length).toEqual(4);
            expect(wrapper.find(`div.${CUSTOM_ROW_CLASS}`).length).toEqual(4);
            expect(wrapper.find('.custom-linked-first').length).toEqual(1);
            expect(wrapper.find('.custom-linked-second').length).toEqual(1);
            expect(wrapper.find('.custom-linked-fx').length).toEqual(2);
        });
    });
});
