import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import * as pluginsConstants from '../constants';

class LinkedGridRowPlugin extends React.PureComponent {
    constructor(props) {
        super(props);

        this.state = {
            rowInfos: this.getRowInfos(props),
        };
    }

    componentWillReceiveProps(nextProps) {
        this.setState({
            rowInfos: this.getRowInfos(nextProps),
        });
    }

    getRowInfos(props) {
        const { rowClassName, rowsData, onGetLinkingInfo } = props;

        return _.reduce(rowsData, (result, row) => {
            const { rowId, rowInfo } = row;

            const { linkMode, linkType } = onGetLinkingInfo(row);
            const hasLinkType = Boolean(linkType);

            const className = classNames(
                rowInfo.className,
                {
                    [rowClassName + '-first']: (linkMode === 1) && hasLinkType,
                    [rowClassName + '-second']: (linkMode === 2) && hasLinkType,
                    [rowClassName + '-' + linkType]: linkMode && hasLinkType,
                }
            );

            result[rowId] = _.defaults({ className }, rowInfo);
            return result;
        }, {});
    }

    render() {
        const {
            rows,
            nextPlugin,
            rowsData,
        } = this.props;

        const linkedRows = _.map(rows, (row, rowIndex) => {
            const rowData = rowsData[rowIndex];
            const rowInfo = this.state.rowInfos[rowData.rowId];

            // replace row info on row
            return React.cloneElement(row, { rowInfo });
        });

        let content = linkedRows;

        if (nextPlugin) {
            content = React.cloneElement(nextPlugin, { rows: linkedRows });
        }

        return content;
    }
}

LinkedGridRowPlugin.propTypes = {
    isEnabled: PropTypes.bool,
    type: PropTypes.string,
    nextPlugin: PropTypes.element,
    rowsData: PropTypes.array,
    rows: PropTypes.array,
    rowClassName: PropTypes.string,
    onGetLinkingInfo: PropTypes.func.isRequired,
};

LinkedGridRowPlugin.defaultProps = {
    isEnabled: true,
    type: pluginsConstants.ROW_PLUGIN_TYPE,
    rowClassName: 'reactgrid-row--link',
};

export default LinkedGridRowPlugin;
