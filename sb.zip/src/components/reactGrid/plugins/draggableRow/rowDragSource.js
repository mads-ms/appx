/**
 * Implements the drag source contract.
 */
export const dragSource = {
    beginDrag(props) {
        return props;
    },

    endDrag() {
        return null;
    },

    canDrag(props) {
        const {
            isDraggable,
            canDragFunction,
        } = props;

        // Accepting drag basing on item
        if (isDraggable && canDragFunction) {
            return canDragFunction(props);
        }

        return isDraggable;
    },
};

/**
 * Specifies the props to inject into Grid Row.
 */
export function collect(connect, monitor) {
    return {
        connectDragSource: connect.dragSource(),
        isDragging: monitor.isDragging(),
    };
}
