import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import DraggableGridRow from './dragableGridRow';
import { DropTarget } from 'react-dnd';
import { bindHandlers } from 'src/utils/bindHandlers';
import { copyDefaultProps } from 'src/utils/copyDefaultProps';
import { dropTarget, collect } from './rowsDropTarget';
import { DragDropItemTypes } from './constants';
import * as pluginsConstants from '../constants';

class DraggableGridRowPlugin extends React.PureComponent {

    constructor(props) {
        super(props);

        this.state = {
            dragInfo: {},
            currentRow: null,
        };

        this.setEl = (ref) => {
            this.el = ref;
        };
    }

    handleRowPress(evt, row) {
        this.setState({
            currentRow: row,
        });
    }

    handleRowPressUp() {
        this.setState({
            currentRow: null,
        });
    }

    handleRowDragBegin(row) {
        this.setState({
            currentRow: row,
        });
        this.props.onRowDragBegin(row);
    }

    handleRowDragEnd(row) {
        this.setState({
            currentRow: null,
        });
        this.props.onRowDragEnd(row);
    }

    getRowIsDraggable(row, currentRow) {
        const {
            isDragEnabled,
            dragAfterPress,
        } = this.props;

        if (!isDragEnabled) {
            return false;
        }

        if (dragAfterPress && !currentRow) {
            return false;
        }

        // Backward compatibility
        return !row.rowInfo.isNotSortable;
    }

    getDragAndDropRowOffsets(rows, dragRow, dragInfo) {

        // Not in drag & drop mode
        if (!dragRow) {
            return rows;
        }

        const hoverIndex = dragInfo.hoverRowIndex;

        const calcRowOffset = (row) => {
            if (row.id === dragRow.rowId) {
                return _.defaults({ localOffset: dragInfo.y - row.topOffset }, row);
            } else if (row.rowIndex <= hoverIndex && dragRow.rowIndex < row.rowIndex) {
                return _.defaults({ localOffset: -dragRow.height }, row);
            } else if (row.rowIndex >= hoverIndex && dragRow.rowIndex > row.rowIndex) {
                return _.defaults({ localOffset: dragRow.height }, row);
            }

            return row;
        };

        return _.map(rows, calcRowOffset);
    }

    handleRowDrop(row, source, target) {
        const draggedRow = _.find(this.props.allRows, (rowItem) => rowItem.id === row.rowId);

        // Dragging external row
        this.props.onRowDrop(draggedRow, source, target);

        // Dragging internal row
        if (draggedRow) {
            const sortedRows = _.clone(this.props.allRows);
            sortedRows.splice(source, 1);
            sortedRows.splice(target, 0, draggedRow);

            this.props.onRowsReorder(sortedRows, draggedRow);
        }
    }

    render() {
        const {
            rows,
            nextPlugin,
            dragRow,
            rowsData,
            dropContextIds,
            connectDropTarget,
        } = this.props;

        const { dragInfo, currentRow } = this.state;

        const draggedRowsData = this.getDragAndDropRowOffsets(rowsData, dragRow, dragInfo);

        const draggableRows = _.map(rows, (row, rowIndex) => {
            const rowData = draggedRowsData[rowIndex];
            const { rowInfo } = rowData;

            if (rowInfo.isDivider || rowInfo.isGroup) {
                return row;
            }

            const isActive = Boolean(currentRow && currentRow.rowId === rowData.rowId);
            const isRowDraggable = this.getRowIsDraggable(rowData, currentRow);

            return (
                <DraggableGridRow
                    key={rowIndex}
                    isActive={isActive}
                    dropContextIds={dropContextIds}
                    isDraggable={isRowDraggable}
                    onPress={this.handleRowPress}
                    onPressUp={this.handleRowPressUp}
                    onDragBegin={this.handleRowDragBegin}
                    onDragEnd={this.handleRowDragEnd}
                    {...rowData}
                >
                    {row}
                </DraggableGridRow>
            );
        });

        let content = draggableRows;

        if (nextPlugin) {
            content = React.cloneElement(nextPlugin, { rows: draggableRows });
        }

        return connectDropTarget(
            <div ref={this.setEl} style={{ height: '100%' }}>
                {content}
            </div>
        );
    }
}

DraggableGridRowPlugin.propTypes = {
    isEnabled: PropTypes.bool,
    type: PropTypes.string,
    nextPlugin: PropTypes.element,
    rowsData: PropTypes.array,
    rows: PropTypes.array,
    allRows: PropTypes.array,
    dragAfterPress: PropTypes.bool,
    dragRow: PropTypes.object,
    dropContextIds: PropTypes.string,
    isDragEnabled: PropTypes.bool,
    isDropEnabled: PropTypes.bool,
    canDragFunction: PropTypes.func,
    canDropFunction: PropTypes.func,
    connectDropTarget: PropTypes.func,
    onRowDragBegin: PropTypes.func,
    onRowDragEnd: PropTypes.func,
    onRowsReorder: PropTypes.func,
    onRowDrop: PropTypes.func,
};

DraggableGridRowPlugin.defaultProps = {
    isEnabled: true,
    type: pluginsConstants.ROW_PLUGIN_TYPE,
    isDragEnabled: true,
    isDropEnabled: true,
    dragAfterPress: false,
    onRowDragBegin: _.noop,
    onRowDragEnd: _.noop,
    onRowsReorder: _.noop,
    onRowDrop: _.noop,
};

export default copyDefaultProps(
    DropTarget(DragDropItemTypes.ROW, dropTarget, collect)(bindHandlers(DraggableGridRowPlugin)),
    DraggableGridRowPlugin.defaultProps
);
