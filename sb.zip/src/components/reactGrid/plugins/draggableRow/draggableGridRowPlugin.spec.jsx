import React from 'react';
import ReactGrid from 'src/components/reactGrid/reactGrid';
import _ from 'lodash';
import { wrapInTestContext } from 'test/mocks/dragDropHelper';
import { createCols, createRows } from '../../reactGridSpecHelper';
import DraggableGridRowPlugin from 'src/components/reactGrid/plugins/draggableRow/dragableGridRowPlugin';
import DraggableGridRow from 'src/components/reactGrid/plugins/draggableRow/dragableGridRow';
import { mount } from 'enzyme';

describe('src/components/reactGrid/plugins/draggableRow', () => {
    describe('DraggableGridRowPlugin', () => {

        let wrapper;
        let defaultProps;

        beforeEach(() => {
            defaultProps = {
                isHeader: false,
                width: 501,
                height: 100,
                rowHeight: 20,
                headerHeight: 30,
            };
        });

        afterEach(() => {
            wrapper.unmount();
        });

        it('drag rows successfully in standard case', () => {
            // 5 rows outside of the viewport
            const rowDescriptor = createRows(10);
            const colDescriptor = createCols(['foo']);
            const WrappedGrid = wrapInTestContext(ReactGrid);

            let dragBeginRow = null;
            let dragEndRow = null;
            let rowReorderRows = null;
            let rowReorderRow = null;

            const handleRowDragBegin = jasmine.createSpy().and.callFake((draggedRow) => {
                dragBeginRow = draggedRow;
            });

            const handleRowDragEnd = jasmine.createSpy().and.callFake((draggedRow) => {
                dragEndRow = draggedRow;
            });

            const handleRowsReorder = jasmine.createSpy().and.callFake((rows, draggedRow) => {
                rowReorderRows = rows;
                rowReorderRow = draggedRow;
            });

            wrapper = mount(
                <WrappedGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}
                    cullRatio={0}
                    {...defaultProps}
                >
                    <DraggableGridRowPlugin
                        onRowDragBegin={handleRowDragBegin}
                        onRowsReorder={handleRowsReorder}
                        onRowDragEnd={handleRowDragEnd}
                    />
                </WrappedGrid>
            );

            const manager = wrapper.at(0).instance().getManager();
            const backend = manager.getBackend();

            const draggableRow = wrapper.find(DraggableGridRow).at(0).instance();
            const target = wrapper.find(DraggableGridRowPlugin).at(0).instance();

            // Start drag ans replace first item with second
            backend.simulateBeginDrag([draggableRow.getHandlerId()],
                {
                    clientOffset: { x: 0, y: 0 },
                    getSourceClientOffset: () => ({ x: 0, y: 40 }),
                    publishSource: false,
                });

            backend.simulatePublishDragSource();

            backend.simulateHover([target.getHandlerId()], {
                clientOffset: { x: 0, y: 0 },
            });

            backend.simulateDrop();
            backend.simulateEndDrag();

            expect(dragBeginRow.id).toEqual('0');

            expect(dragEndRow.id).toEqual('0');

            expect(rowReorderRow.id).toEqual('0');

            expect(rowReorderRows.length).toEqual(10);
            expect(_.map(rowReorderRows, 'id')).toEqual(['1', '2', '0', '3', '4', '5', '6', '7', '8', '9']);
        });
    });
});
