export const DragDropItemTypes = {
    ROW: 'row',
    COLUMN: 'column',
};
