import _ from 'lodash';
import * as renderUtils from '../../reactGridRendererUtils';

/**
 * Implements the drag target contract.
 */
export const dropTarget = {
    drop(props, monitor, component) {
        const sourceRowIndex = component.props.dragRow.rowIndex;
        const targetRowIndex = component.state.dragInfo.hoverRowIndex;

        component.setState({
            dragInfo: {},
            dragRow: null,
        });

        if (sourceRowIndex !== targetRowIndex) {
            component.handleRowDrop(monitor.getItem(), sourceRowIndex, targetRowIndex);
        }
    },

    hover(props, monitor, component) {
        const { scrollBodyEl } = component.props;

        if (!scrollBodyEl) {
            return;
        }

        const item = monitor.getItem();

        if (!item) {
            return;
        }

        // Get bounds of dragged element
        const hoverBoundingRect = scrollBodyEl.getBoundingClientRect();

        // Determine mouse position
        const clientOffset = monitor.getSourceClientOffset();

        if (!clientOffset) {
            return;
        }

        // Get pixels to the top
        const hoverClientY = clientOffset.y - hoverBoundingRect.top;

        // Increase offset by half of dragged item height (half of rowHeight)
        // to calculate hover index based on the vertical middle of item
        const itemOffset = hoverClientY + item.rowInfo.height * 0.5;

        // Find row index
        const hoverRowIndex = renderUtils.findRowIndexByOffset(itemOffset, props.allRows);

        component.setState({
            dragInfo: {
                y: hoverClientY,
                hoverRowIndex,
            },
        });
    },

    canDrop(props, monitor) {
        const {
            canDropFunction,
            isDropEnabled,
            dropContextIds,
        } = props;

        const item = monitor.getItem();

        // Case when we can drag rows outside only
        if (!isDropEnabled) {
            return false;
        }

        // Accepting drop basing on custom item condition
        if (canDropFunction) {
            return canDropFunction(item);
        }

        // Accepting drop basing on dropContextIds - pairing grids wit the same items
        if (dropContextIds) {
            const itemDropContextIds = item.dropContextIds;
            const supportedDropContextIds = _.intersection(_.split(dropContextIds, ','), _.split(itemDropContextIds, ','));

            return supportedDropContextIds.length > 0;
        }

        return true;
    },
};

/**
 * Specifies the props to inject into your component.
 */
export function collect(connect, monitor) {
    return {
        connectDropTarget: connect.dropTarget(),
        dragRow: monitor.getItem(),
    };
}
