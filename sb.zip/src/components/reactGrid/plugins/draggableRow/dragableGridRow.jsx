import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import { DragSource } from 'react-dnd';
import classNames from 'classnames';
import { bindHandlers } from 'src/utils/bindHandlers';
import Touchable from 'src/components/touchable/touchable';
import { dragSource, collect } from './rowDragSource';
import { DragDropItemTypes } from './constants';

class DraggableGridRow extends React.PureComponent {

    componentDidUpdate(prevProps) {
        const {
            isDragging,
            onDragBegin,
            onDragEnd,
        } = this.props;

        if (isDragging !== prevProps.isDragging) {
            if (prevProps.isDragging) {
                onDragEnd(this.props);
            } else {
                onDragBegin(this.props);
            }
        }
    }

    handlePress(evt) {
        this.props.onPress(evt, this.props);
    }

    handlePressUp(evt) {
        this.props.onPressUp(evt, this.props);
    }

    render() {
        const {
            localOffset,
            rowId,
            rowInfo,
            rowData,
            isDraggable,
        } = this.props;

        const {
            connectDragSource,
            isActive,
        } = this.props;

        // Modify wrapper styles
        const style = {
            transform: `translate3d(0, ${localOffset || 0}px, 0)`,

            // Styles cleanup is required here
            background: 'none',
            border: 'none',
            position: 'relative',
            zIndex: isActive ? 1 : 0,
        };

        const className = classNames({
            'reactgrid-row': true,
            'is-draggable': isDraggable,
            'is-active': isActive,
        });

        // Modify child props and pass to next plugin
        const childrenProps = {
            rowId,
            rowData,
            rowInfo: _.defaults({ isDragging: isActive }, rowInfo),
        };

        const row = React.cloneElement(React.Children.only(this.props.children), childrenProps);

        return connectDragSource(
            <div className={className} style={style}>
                <Touchable
                    onPress={this.handlePress}
                    onPressUp={this.handlePressUp}
                >
                    {row}
                </Touchable>
            </div>
        );
    }
}

DraggableGridRow.propTypes = {
    rowId: PropTypes.string,
    rowInfo: PropTypes.object,
    rowData: PropTypes.object,
    row: PropTypes.element,
    localOffset: PropTypes.number,
    connectDragSource: PropTypes.func.isRequired,
    isDragging: PropTypes.bool.isRequired,
    isDraggable: PropTypes.bool,
    dropContextIds: PropTypes.string,
    isActive: PropTypes.bool,
    onDragBegin: PropTypes.func,
    onDragEnd: PropTypes.func,
    onPress: PropTypes.func,
    onPressUp: PropTypes.func,
};

DraggableGridRow.defaultProps = {
    isActive: false,
    isDraggable: true,
    onDragBegin: _.noop,
    onDragEnd: _.noop,
    onPress: _.noop,
    onPressUp: _.noop,
};

export default DragSource(DragDropItemTypes.ROW, dragSource, collect)(bindHandlers(DraggableGridRow));
