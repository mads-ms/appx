import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import { bindHandlers } from 'src/utils/bindHandlers';
import SwipeMenu from 'src/components/swipeMenu/swipeMenu';
import SwipeableGridRow from './swipeableGridRow';
import * as pluginsConstants from '../constants';

const MIN_SWIPE_DISTANCE = 100;
const MIN_SWIPE_VELOCITY = 0.5;

class SwipeableGridRowPlugin extends React.PureComponent {

    constructor() {
        super();

        this.state = {
            rowLeft: 0,
            row: null,
        };

        this.windowListener = null;
    }

    componentWillReceiveProps(nextProps) {

        // Hide on resize
        if (this.props.width !== nextProps.width) {
            this.hideSwipeMenu();
        }
    }

    showSwipeMenu() {
        this.setState({
            rowLeft: -this.props.width,
        });
    }

    hideSwipeMenu() {
        this.setState({
            rowLeft: 0,
            row: null,
        });

        this.props.onSwipeMenuHide();
    }

    handleRowPanStart(evt, row) {
        this.setState({
            row,
        });
    }

    handleRowPan(evt) {
        const rowLeft = Math.min(evt.deltaX, 0);

        this.setState({
            rowLeft,
        });
    }

    handleRowPanEnd(evt) {
        const deltaX = Math.abs(evt.deltaX);
        const velocityX = Math.abs(evt.velocityX);

        // make sure the gesture is moving left/right far enough and fast enough to open
        if ((deltaX < MIN_SWIPE_DISTANCE) && (velocityX < MIN_SWIPE_VELOCITY)) {
            this.hideSwipeMenu();
        } else {
            this.showSwipeMenu();
        }
    }

    handleSwipeMenuHide() {
        this.hideSwipeMenu();
    }

    handleSwipeMenuMoreAction() {
        this.props.onShowMore(this.state.row);
    }

    render() {
        const {
            rows,
            nextPlugin,
            rowsData,
            featureArea,
            width,
            rowHeight,
            actionsData,
            onGetActionsData,
            children,
        } = this.props;

        const swipeableRows = _.map(rows, (row, rowIndex) => {
            const rowData = rowsData[rowIndex];
            const rowId = _.get(this.state, 'row.rowId');
            let nextRowData = rowData;

            // Other plugins can pass mutated rowInfo data as property. ie. linkedGridRowPlugin
            if (row.props.rowInfo) {
                nextRowData = _.defaults({
                    rowInfo: row.props.rowInfo,
                }, rowData);
            }

            const rowInfo = nextRowData.rowInfo;

            if (rowInfo.isDivider || rowInfo.isGroup) {
                return row;
            }

            const isSwiping = (nextRowData.rowId === rowId);

            const menu = (isSwiping &&
                <SwipeMenu
                    actionsData={actionsData || nextRowData}
                    onGetActionsData={onGetActionsData}
                    featureArea={featureArea}
                    width={width}
                    height={rowHeight}
                    onHide={this.handleSwipeMenuHide}
                    onShowMore={this.handleSwipeMenuMoreAction}
                >
                    {children}
                </SwipeMenu>
            );

            return (
                <SwipeableGridRow
                    key={row.key}
                    left={isSwiping ? this.state.rowLeft : 0}
                    onPanStart={this.handleRowPanStart}
                    onPan={this.handleRowPan}
                    onPanEnd={this.handleRowPanEnd}
                    onPanCancel={this.handleSwipeMenuHide}
                    menu={menu}
                    {...nextRowData}
                >
                    {row}
                </SwipeableGridRow>
            );
        });

        let content = swipeableRows;

        if (nextPlugin) {
            content = React.cloneElement(nextPlugin, { rows: swipeableRows });
        }
        return content;
    }
}

SwipeableGridRowPlugin.propTypes = {
    isEnabled: PropTypes.bool,
    type: PropTypes.string,
    nextPlugin: PropTypes.element,
    rowsData: PropTypes.array,
    rows: PropTypes.array,
    featureArea: PropTypes.string,
    actionsData: PropTypes.object,
    onGetActionsData: PropTypes.func,
    width: PropTypes.number,
    rowHeight: PropTypes.number,
    onShowMore: PropTypes.func,
    onSwipeMenuHide: PropTypes.func,
};

SwipeableGridRowPlugin.defaultProps = {
    isEnabled: true,
    type: pluginsConstants.ROW_PLUGIN_TYPE,
    onShowMore: _.noop,
    onGetActionsData: _.noop,
    onSwipeMenuHide: _.noop,
};

export default bindHandlers(SwipeableGridRowPlugin);
