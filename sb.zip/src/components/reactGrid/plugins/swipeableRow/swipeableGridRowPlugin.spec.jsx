import React from 'react';
import ReactGrid from 'src/components/reactGrid/reactGrid';
import SwipeMenu from 'src/components/swipeMenu/swipeMenu';
import SwipeMenuItem from 'src/components/swipeMenu/swipeMenuItem';
import SwipeableGridRowPlugin from 'src/components/reactGrid/plugins/swipeableRow/swipeableGridRowPlugin';
import LinkedGridRowPlugin from 'src/components/reactGrid/plugins/linkedRow/linkedGridRowPlugin';
import { MenuItems } from 'src/components/contextMenu';
import { createCols } from '../../reactGridSpecHelper';
import { mount } from 'enzyme';

describe('src/components/reactGrid/plugins/swipeableRow', () => {
    describe('SwipeableGridRowPlugin', () => {

        let wrapper;
        let defaultProps;

        beforeEach(() => {

            defaultProps = {
                isHeader: false,
                width: 501,
                height: 100,
                rowHeight: 20,
                headerHeight: 30,
            };
        });

        afterEach(() => {
            wrapper.unmount();
        });

        it('renders successfully', () => {
            const rowDescriptor = [
                { id: 'A', data: {} },
                { id: 'B', data: {} },
            ];

            const colDescriptor = createCols(['foo']);
            const action1 = { id: 'trade', label: 'Trade' };
            const action2 = { id: 'alertadd', label: 'Alert Add' };
            const action3 = { id: 'alertedit', label: 'Alert Edit', isAllowed: () => false };

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}
                    {...defaultProps}
                >
                    <SwipeableGridRowPlugin
                        onGetActionsData={() => ({})}
                    >
                        <MenuItems>
                            <SwipeMenuItem action={action1}/>
                            <SwipeMenuItem action={action2}/>
                            <SwipeMenuItem action={action3}/>
                        </MenuItems>
                    </SwipeableGridRowPlugin>
                </ReactGrid>
            );

            const rows = wrapper.find(SwipeableGridRowPlugin).instance();

            // simulate pan start directly. Hammer is not working with simulate
            rows.handleRowPanStart({}, { rowId: 'A' });
            wrapper.update();

            expect(wrapper.find(SwipeMenu).length).toEqual(1);
            expect(wrapper.find(SwipeMenuItem).length).toEqual(2);
            expect(wrapper.find('.swipemenu').length).toEqual(1);
            expect(wrapper.find('.swipemenu').find('button').length).toEqual(2);
        });

        /**
         * Testing if preceding rowInfo mutations are taken into consideration inside swipeablePlugin.
         * Example case is having both Swipeable and Linking plugins. Linking plugin mutates row info by changing classNames.
         * This needs to be reflected by Swipeable plugin.
         */
        it('renders respecting preceding plugin rowInfo', () => {
            const rowDescriptor = [
                { id: 'A', data: {} },
                { id: 'B', data: {} },
            ];

            const colDescriptor = createCols(['foo']);
            const action1 = { id: 'trade', label: 'Trade' };
            const action2 = { id: 'alertadd', label: 'Alert Add' };
            const action3 = { id: 'alertedit', label: 'Alert Edit', isAllowed: () => false };

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}
                    {...defaultProps}
                >
                    <SwipeableGridRowPlugin
                        onGetActionsData={() => ({})}
                    >
                        <MenuItems>
                            <SwipeMenuItem action={action1}/>
                            <SwipeMenuItem action={action2}/>
                            <SwipeMenuItem action={action3}/>
                        </MenuItems>
                    </SwipeableGridRowPlugin>
                    <LinkedGridRowPlugin
                        onGetLinkingInfo={() => ({ linkType: 'fx', linkMode: 1 })}
                    />
                </ReactGrid>
            );

            expect(wrapper.find('.reactgrid-row--link-fx').length).toBe(2);
        });
    });
});
