import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import { bindHandlers } from 'src/utils/bindHandlers';
import Pannable from 'src/components/touchable/pannable';
import classNames from 'classnames';

class SwipeableGridRow extends React.PureComponent {

    handlePanStart(evt) {
        if (this.checkPanCancel(evt)) {
            return;
        }

        this.props.onPanStart(evt, this.props);
    }

    handlePan(evt) {
        if (this.checkPanCancel(evt)) {
            return;
        }

        this.props.onPan(evt, this.props);
    }

    handlePanEnd(evt) {
        if (this.checkPanCancel(evt)) {
            return;
        }

        this.props.onPanEnd(evt, this.props);
    }

    checkPanCancel(evt) {
        const { rowInfo } = this.props;
        const { isDragging } = rowInfo;
        const { srcEvent } = evt;

        const result = isDragging || (srcEvent && srcEvent.type === 'pointercancel');

        if (result) {
            this.props.onPanCancel();
        }

        return result;
    }

    render() {
        const {
            rowId,
            rowInfo,
            rowData,
            left,
            menu,
        } = this.props;

        // Modify wrapper styles
        const style = {
            // Styles cleanup is required here
            background: 'none',
            border: 'none',
            position: 'relative',
            zIndex: 0,
        };

        const innerStyle = {
            transform: `translate3d(${left}px, 0, 0)`,
        };

        const { isDragging } = rowInfo;

        const className = classNames({
            'reactgrid-row': true,
            'is-pannable': !isDragging,
        });

        // Modify child props and pass to next plugin
        const childrenProps = {
            rowId,
            rowData,
            rowInfo,
        };

        const row = React.cloneElement(React.Children.only(this.props.children), childrenProps);

        return (
            <div className={className} style={style}>
                {menu}
                <Pannable
                    directionSupport="left"
                    onPanStart={this.handlePanStart}
                    onPan={this.handlePan}
                    onPanEnd={this.handlePanEnd}
                >
                    <div style={innerStyle}>
                        {row}
                    </div>
                </Pannable>
            </div>
        );
    }
}

SwipeableGridRow.propTypes = {
    rowId: PropTypes.string,
    rowInfo: PropTypes.object,
    rowData: PropTypes.object,
    row: PropTypes.element,
    left: PropTypes.number,
    onPanStart: PropTypes.func,
    onPan: PropTypes.func,
    onPanEnd: PropTypes.func,
    onPanCancel: PropTypes.func,
    menu: PropTypes.any,
};

SwipeableGridRow.defaultProps = {
    left: 0,
    onPanStart: _.noop,
    onPan: _.noop,
    onPanEnd: _.noop,
    onPanCancel: _.noop,
};

export default bindHandlers(SwipeableGridRow);
