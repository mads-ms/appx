export const ROW_PLUGIN_TYPE = 'row';
export const COLUMN_PLUGIN_TYPE = 'column';
export const HEADER_PLUGIN_TYPE = 'header';

