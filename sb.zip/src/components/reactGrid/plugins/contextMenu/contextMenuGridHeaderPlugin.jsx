import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import { ContextMenu, MenuTarget } from 'src/components/contextMenu';

class ContextMenuGridHeaderPlugin extends React.PureComponent {

    render() {
        const {
            visibleColumns,
            headers,
            nextPlugin,
            isScrolling,
            triggerEvent,
            shouldPreventDefault,
            shouldStopPropagation,
            children,
        } = this.props;

        const contextMenuHeaders = isScrolling ? headers : _.map(headers, (header, headerIndex) => (
            <ContextMenu
                key={headerIndex}
                triggerEvent={triggerEvent}
                shouldPreventDefault={shouldPreventDefault}
                shouldStopPropagation={shouldStopPropagation}
                isEnabled={!isScrolling}
                actionsData={{ column: visibleColumns[headerIndex] }}
                onGetActionsData={this.props.onGetActionsData}
            >
                {children}
                <MenuTarget>
                    {header}
                </MenuTarget>
            </ContextMenu>
        ));

        let content = contextMenuHeaders;

        if (nextPlugin) {
            content = React.cloneElement(nextPlugin, { headers: contextMenuHeaders });
        }

        return content;
    }
}

ContextMenuGridHeaderPlugin.propTypes = {
    isEnabled: PropTypes.bool,
    isScrolling: PropTypes.bool,
    isDisplayedWhenNoActions: PropTypes.bool,
    type: PropTypes.string,
    nextPlugin: PropTypes.element,
    visibleColumns: PropTypes.array,
    headers: PropTypes.array,
    triggerEvent: PropTypes.string,
    shouldPreventDefault: PropTypes.bool,
    shouldStopPropagation: PropTypes.bool,
    onGetActionsData: PropTypes.func,
};

ContextMenuGridHeaderPlugin.defaultProps = {
    isEnabled: true,
    type: 'header',
    onGetActionsData: _.noop,
    isDisplayedWhenNoActions: false,
};

export default ContextMenuGridHeaderPlugin;
