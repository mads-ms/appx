import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import { ContextMenu, MenuTarget } from 'src/components/contextMenu';
import * as pluginsConstants from '../constants';

class ContextMenuGridRowPlugin extends React.PureComponent {

    render() {
        const {
            rows,
            rowsData,
            actionsData,
            onGetActionsData,
            triggerEvent,
            shouldPreventDefault,
            shouldStopPropagation,
            nextPlugin,
            isScrolling,
            isDisplayedWhenNoActions,
            isEnabled,
            children,
        } = this.props;

        const contextMenuRows = isScrolling ? rows : _.map(rows, (row, rowIndex) => {
            const rowData = rowsData[rowIndex];

            return (
                <ContextMenu
                    key={rowIndex}
                    isEnabled={isEnabled && !row.props.isDivider}
                    triggerEvent={triggerEvent}
                    shouldPreventDefault={shouldPreventDefault}
                    shouldStopPropagation={shouldStopPropagation}
                    actionsData={actionsData || rowData}
                    onGetActionsData={onGetActionsData}
                    menuItems={children}
                    isDisplayedWhenNoActions={isDisplayedWhenNoActions}
                >
                    {children}
                    <MenuTarget>
                        {row}
                    </MenuTarget>
                </ContextMenu>
            );
        });

        let content = contextMenuRows;

        if (nextPlugin) {
            content = React.cloneElement(nextPlugin, { rows: contextMenuRows });
        }

        return content;
    }
}

ContextMenuGridRowPlugin.propTypes = {
    isEnabled: PropTypes.bool,
    isScrolling: PropTypes.bool,
    nextPlugin: PropTypes.element,
    type: PropTypes.string,
    rows: PropTypes.array,
    rowsData: PropTypes.array,
    actions: PropTypes.arrayOf(PropTypes.string),
    actionsData: PropTypes.object,
    menuItems: PropTypes.object,
    isDisplayedWhenNoActions: PropTypes.bool,
    triggerEvent: PropTypes.string,
    shouldPreventDefault: PropTypes.bool,
    shouldStopPropagation: PropTypes.bool,
    onGetActionsData: PropTypes.func,
};

ContextMenuGridRowPlugin.defaultProps = {
    isEnabled: true,
    type: pluginsConstants.ROW_PLUGIN_TYPE,
    actions: [],
    onGetActionsData: _.noop,
    isDisplayedWhenNoActions: false,
};

export default ContextMenuGridRowPlugin;
