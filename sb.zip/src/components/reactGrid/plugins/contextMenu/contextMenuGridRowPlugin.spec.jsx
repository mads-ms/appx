import React from 'react';
import ReactGrid from 'src/components/reactGrid/reactGrid';
import ContextMenuGridRowPlugin from 'src/components/reactGrid/plugins/contextMenu/contextMenuGridRowPlugin';
import { ContextMenu, ContextMenuItem, MenuItems } from 'src/components/contextMenu';
import { createCols } from '../../reactGridSpecHelper';
import { mount } from 'enzyme';

describe('src/components/reactGrid/plugins/contextMenu', () => {
    describe('ContextMenuGridRowPlugin', () => {

        let wrapper;
        let defaultProps;

        beforeEach(() => {

            defaultProps = {
                isHeader: false,
                width: 501,
                height: 100,
                rowHeight: 20,
                headerHeight: 30,
            };
        });

        afterEach(() => {
            wrapper.unmount();
        });

        it('renders successfully', () => {
            const rowDescriptor = [
                { id: 'A', data: {} },
                { id: 'B', data: {} },
            ];

            const colDescriptor = createCols(['foo']);
            const action1 = { id: 'trade', label: 'Trade' };

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}
                    {...defaultProps}
                >
                    <ContextMenuGridRowPlugin
                        onGetActionsData={() => ({})}
                    >
                        <MenuItems>
                            <ContextMenuItem action={action1}/>
                        </MenuItems>
                    </ContextMenuGridRowPlugin>
                </ReactGrid>
            );

            expect(wrapper.find(ContextMenu).length).toEqual(2);
        });
    });
});
