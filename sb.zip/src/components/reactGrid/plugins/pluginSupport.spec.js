/**
 * <ReactGrid/> plugin support unit tests
 */
import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { mount } from 'enzyme';
import PluginSupport from 'src/components/reactGrid/plugins/pluginSupport';
import * as pluginsConstants from 'src/components/reactGrid/plugins/constants';

class SamplePlugin extends React.PureComponent {

    render() {
        const {
            sampleProp,
            nextPlugin,
        } = this.props;

        let content = sampleProp;

        if (nextPlugin) {
            content = React.cloneElement(nextPlugin, { sampleProp });
        }

        return (<div>
            {content}
        </div>);
    }

}

SamplePlugin.propTypes = {
    isEnabled: PropTypes.bool,
    type: PropTypes.string,
    nextPlugin: PropTypes.element,
    sampleProp: PropTypes.number,
};

SamplePlugin.defaultProps = {
    isEnabled: true,
    type: pluginsConstants.ROW_PLUGIN_TYPE,
};

describe('src/components/plugins', () => {
    describe('PluginSupport', () => {

        let wrapper;
        let activePlugins;
        let pluginsCallback;

        beforeEach(() => {
            pluginsCallback = jasmine.createSpy('pluginCallback').and.callFake((plugins) => {
                activePlugins = plugins;

                let rowsPlugin = null;

                _.forEach(plugins, (plugin) => {
                    rowsPlugin = React.cloneElement(plugin, _.defaults(
                        { nextPlugin: rowsPlugin }
                    ));
                });

                return (<div>
                    {rowsPlugin}
                </div>);
            });
        });

        it('should filter plugins by type', () => {

            const plugins = [
                <SamplePlugin key="1" sampleProp={1}/>,
                <SamplePlugin key="2" sampleProp={2}/>,
                <SamplePlugin key="3" sampleProp={3}/>,
                <SamplePlugin key="4" sampleProp={4} type={pluginsConstants.HEADER_PLUGIN_TYPE}/>,
            ];

            wrapper = mount(
                <PluginSupport
                    type={pluginsConstants.ROW_PLUGIN_TYPE}
                    plugins={plugins}>
                    {pluginsCallback}
                </PluginSupport>
            );

            expect(activePlugins.length).toEqual(3);

            wrapper.unmount();
        });

        it('should filter disabled plugins', () => {

            const plugins = [
                <SamplePlugin key="1" sampleProp={1}/>,
                <SamplePlugin key="2" sampleProp={2}/>,
                <SamplePlugin key="3" sampleProp={3}/>,
                <SamplePlugin key="4" sampleProp={4} isEnabled={false}/>,
            ];

            wrapper = mount(
                <PluginSupport
                    type={pluginsConstants.ROW_PLUGIN_TYPE}
                    plugins={plugins}>
                    {pluginsCallback}
                </PluginSupport>
            );

            expect(activePlugins.length).toEqual(3);

            wrapper.unmount();
        });

        it('should not call callback if props did not changed', () => {

            const plugins = [
                <SamplePlugin key="1" sampleProp={1}/>,
                <SamplePlugin key="2" sampleProp={2}/>,
                <SamplePlugin key="3" sampleProp={3}/>,
            ];

            wrapper = mount(
                <PluginSupport
                    type={pluginsConstants.ROW_PLUGIN_TYPE}
                    plugins={plugins}>
                    {pluginsCallback}
                </PluginSupport>
            );

            expect(pluginsCallback).toHaveBeenCalledTimes(1);
            expect(activePlugins.length).toEqual(3);

            let nextPlugins = _.clone(plugins);
            wrapper.setProps({
                plugins: nextPlugins,
            });

            expect(pluginsCallback).toHaveBeenCalledTimes(1);

            nextPlugins = [
                <SamplePlugin key="1" sampleProp={1}/>,
                <SamplePlugin key="2" sampleProp={2}/>,
                <SamplePlugin key="3" sampleProp={10}/>,
            ];

            wrapper.setProps({
                plugins: nextPlugins,
            });

            expect(pluginsCallback).toHaveBeenCalledTimes(2);

            wrapper.unmount();
        });
    });
});

