import PropTypes from 'prop-types';
import React from 'react';
import _ from 'lodash';
import shallowEqual from 'react-redux/lib/utils/shallowEqual';

class PluginSupport extends React.Component {

    shouldComponentUpdate(nextProps) {
        const {
            plugins,
            type,
            children,
        } = this.props;

        if (type !== nextProps.type) {
            return true;
        }

        if (children !== nextProps.children) {
            return true;
        }

        const currentPlugins = this.getActivePlugins(plugins, type);
        const nextPlugins = this.getActivePlugins(nextProps.plugins, type);

        if (Boolean(currentPlugins) !== Boolean(nextPlugins)) {
            return true;
        }

        if (_.size(currentPlugins) !== _.size(nextPlugins)) {
            return true;
        }

        // compare plugin props
        return _.some(currentPlugins, (currentPlugin, index) => {
            const nextPlugin = nextPlugins[index];

            return !shallowEqual(currentPlugin.props, nextPlugin.props);
        });
    }

    getActivePlugins(plugins, type) {
        return _.filter(React.Children.toArray(plugins),
            (plugin) => plugin.props.isEnabled && plugin.props.type === type);
    }

    render() {
        const {
            plugins,
            type,
            children,
        } = this.props;

        const activePlugins = this.getActivePlugins(plugins, type);

        return children(_.values(activePlugins));
    }
}

PluginSupport.propTypes = {
    type: PropTypes.string,
    plugins: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
};

export default PluginSupport;
