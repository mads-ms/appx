/**
 * <ReactGrid/> column picker plugin unit tests
 */
import React from 'react';
import ReactGrid from 'src/components/reactGrid/reactGrid';
import ColumnPickerHeaderPlugin from 'src/components/reactGrid/plugins/columnPickerHeader/columnPickerHeaderPlugin';
import ColumnPickerHeader from 'src/components/reactGrid/blocks/columnPickerHeader';
import { tap } from 'test/mocks/touchableHelper';
import { createCols, createRows } from '../../reactGridSpecHelper';
import { mount } from 'enzyme';
import { ActionButton } from 'src/components/reactGrid/reactGridBlocks';
import Header from 'src/components/reactGrid/blocks/defaultHeaderRenderer';

describe('src/components/reactGrid/plugins/columnPickerHeader', () => {
    describe('ColumnPickerHeaderPlugin', () => {

        let wrapper;
        let defaultProps;
        let handleColumnPickerOpen;

        beforeEach(() => {

            defaultProps = {
                isHeader: true,
                width: 200,
                height: 100,
                rowHeight: 20,
                headerHeight: 30,
            };

            handleColumnPickerOpen = jasmine.createSpy('handleColumnPickerOpen');
        });

        afterEach(() => {
            wrapper.unmount();
        });

        it('should render old column picker button', () => {
            const rowDescriptor = createRows(2);
            const colDescriptor = createCols(['a', 'b', 'c']);

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}
                    {...defaultProps}
                >
                    <ColumnPickerHeaderPlugin
                        onColumnPickerOpen={handleColumnPickerOpen}
                    />
                </ReactGrid>
            );

            expect(wrapper.find(ActionButton).length).toEqual(1);

            tap(wrapper.find('.actionbtn'));

            expect(handleColumnPickerOpen).toHaveBeenCalledTimes(1);

            wrapper.setProps({
                width: 301,
            });
            wrapper.update();

            expect(wrapper.find(ActionButton).length).toEqual(0);
        });

        it('should render new column picker button', () => {
            const rowDescriptor = createRows(2);
            const colDescriptor = createCols(['a', 'b', 'c'], {
                a: { sort: { id: 'a-sort' }, className: 'a-column' },
                b: { sort: { id: 'b-sort' }, className: 'b-column', header: Header },
                c: { sort: { id: 'c-sort' }, className: 'c-column' },
            });

            const handleHeaderSort = jasmine.createSpy('handleHeaderSort');

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}
                    onHeaderSort={handleHeaderSort}
                    {...defaultProps}
                >
                    <ColumnPickerHeaderPlugin
                        onColumnPickerOpen={handleColumnPickerOpen}
                    />
                </ReactGrid>
            );

            expect(wrapper.find(ColumnPickerHeader).length).toEqual(1);

            tap(wrapper.find('.actionbtn'));

            expect(handleColumnPickerOpen).toHaveBeenCalledTimes(1);
            expect(handleHeaderSort).toHaveBeenCalledTimes(0);

            wrapper.setProps({
                width: 301,
            });
            wrapper.update();

            expect(wrapper.find(ColumnPickerHeader).length).toEqual(0);
            expect(wrapper.find(Header).length).toEqual(1);

            tap(wrapper.find('.b-column'));

            expect(handleHeaderSort).toHaveBeenCalledTimes(1);
        });
    });
});
