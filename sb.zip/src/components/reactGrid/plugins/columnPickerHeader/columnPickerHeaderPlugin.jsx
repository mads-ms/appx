import PropTypes from 'prop-types';
import React from 'react';
import _ from 'lodash';
import { bindHandlers } from 'src/utils/bindHandlers';
import ColumnPickerMiniButton from 'src/components/columnPickerMini/columnPickerMiniButton';
import ColumnPickerHeader from 'src/components/reactGrid/blocks/columnPickerHeader';
import * as pluginsConstants from '../constants';

class ColumnPickerHeaderPlugin extends React.PureComponent {

    handleColumnPickerOpen({ evt }) {

        // disable sorting
        evt.preventDefault();

        this.props.onColumnPickerOpen();
    }

    render() {
        const {
            columns,
            visibleColumns,
            headers,
            nextPlugin,
        } = this.props;

        let nextHeaders = headers;

        if (nextHeaders.length > 0 && columns.length > visibleColumns.length) {

            const lastColumn = _.clone(_.last(visibleColumns));
            lastColumn.onTap = this.handleColumnPickerOpen;

            if (lastColumn.sort) {
                lastColumn.header = (<ColumnPickerHeader
                    column={lastColumn}
                />);
            } else {
                lastColumn.header = () => ColumnPickerMiniButton({
                    column: lastColumn,
                    sortDataValue: lastColumn.sortDataValue,
                });
            }

            nextHeaders = _.clone(nextHeaders);
            let lastHeader = _.last(headers);
            lastHeader = React.cloneElement(lastHeader, { column: lastColumn });

            nextHeaders[nextHeaders.length - 1] = lastHeader;
        }

        let content = nextHeaders;

        if (nextPlugin) {
            content = React.cloneElement(nextPlugin, { headers: nextHeaders });
        }

        return content;
    }
}

ColumnPickerHeaderPlugin.propTypes = {
    isEnabled: PropTypes.bool,
    type: PropTypes.string,
    nextPlugin: PropTypes.element,
    columns: PropTypes.array,
    visibleColumns: PropTypes.array,
    headers: PropTypes.array,
    onColumnPickerOpen: PropTypes.func,
};

ColumnPickerHeaderPlugin.defaultProps = {
    isEnabled: true,
    type: pluginsConstants.HEADER_PLUGIN_TYPE,
    columns: [],
    visibleColumns: [],
};

export default bindHandlers(ColumnPickerHeaderPlugin);
