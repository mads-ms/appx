import PropTypes from 'prop-types';

export default PropTypes.oneOfType([

    // grouping path
    PropTypes.string,

    // array of grouping paths
    PropTypes.arrayOf(PropTypes.string),

    // array of grouping fields
    PropTypes.arrayOf(PropTypes.shape({

        // grouping path
        path: PropTypes.string,

        // columns to be rendered on group row
        sectionColumns: PropTypes.arrayOf(PropTypes.string),

        // custom grouping function
        // Example:
        // const myCustomGroupingFunction = (row, groupingField, level) => _.get(row, groupingField.name);
        groupingFunction: PropTypes.func,

        // custom callback to create group parent
        // Example:
        // export const myCroupingObjectFunction = (name, rows, level) => {
        //    return {
        //       id: name,
        //       sectionHeader: name ' (' + _.size(rows) + ')',
        //       rows,
        //       level,
        //    }
        // }
        groupingObjectFunction: PropTypes.func,

        // indicate if we should skip parent in grouping result
        isRootExcluded: PropTypes.bool,

        // indicate if groups should be expanded by default, ignored when keepGroupsExpanded is set on grid
        isExpanded: PropTypes.bool,

        // when true group can not be collapsed/expanded by user and it is expanded by default
        isStatic: PropTypes.bool,

        // when true group is treated as divider
        isDivider: PropTypes.bool,

        // template used to render groups row
        template: PropTypes.oneOfType([PropTypes.func, PropTypes.object]),

        // sort definition
        sort: PropTypes.shape({

            // custom sort compare function
            // Example:
            // cont myCustomSortCompareFunction = (a, b, direction, sortProperties) => {
            //   if(a === b){
            //      return 0;
            //   }
            //   return a > b ? 1 : -1;
            // }
            compareFunction: PropTypes.func,

            fields: PropTypes.oneOfType([

                // single sort path
                PropTypes.string,

                // array of sort paths
                PropTypes.arrayOf(PropTypes.string),

                // sort fields
                PropTypes.arrayOf(PropTypes.shape({

                    // sort path
                    path: PropTypes.string.isRequired,

                    // sort direction
                    // 1 - asc
                    // 0 - initial order
                    // -1 - desc
                    direction: PropTypes.number,

                    // custom sort compare function
                    // Example:
                    // cont myCustomSortCompareFunction = (a, b, direction, sortProperties) => {
                    //   if(a === b){
                    //      return 0;
                    //   }
                    //   return a > b ? 1 : -1;
                    // }
                    compareFunction: PropTypes.func,
                })),
            ]),
        }),
    })),
]);
