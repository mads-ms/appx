import PropTypes from 'prop-types';

// list of row IDs || descriptors - consumers need to meet this interface.
//  - For flat lists an Array of String IDs is expected:
//    [{String}, ...], e.g. ['1', '2', '3', ...]
//  - For hierchical groups (i.e. parent row and sub-rows) are described as
//    descriptors. There is support for N levels (row grouping is recursive).
//  - An optional divider can be associated with a grouping.
//  - Dividers can also have columns rendered aligned to associated content.
//
//  Example:
//  [
//      {
//          id: '1',
//          isExpanded: false,
//          rows: ['1:1', '1:2', '1:3', ...],
//          sectionHeader: 'Group 1',
//          sectionColumns: ['foo'], // passes rowId '1' to foo cell template
//          isCustom: true, // render row template on full row space without cells
//      },
//      ...
//  ]
export default PropTypes.arrayOf(
    PropTypes.oneOfType([PropTypes.string, PropTypes.shape({
        id: PropTypes.string,
        data: PropTypes.object,
        isExpanded: PropTypes.bool,
        isNotSortable: PropTypes.bool,
        height: PropTypes.number,
        sectionHeader: PropTypes.string,
        sectionColumns: PropTypes.arrayOf(PropTypes.string),
        rows: PropTypes.oneOfType([
            PropTypes.arrayOf(PropTypes.object),
            PropTypes.arrayOf(PropTypes.string),
        ]),
        template: PropTypes.oneOfType([PropTypes.func, PropTypes.object]),
        isCustom: PropTypes.bool,
    })])
).isRequired;
