import PropTypes from 'prop-types';

// list of column descriptors - consumers should meet this interface. Special properties:
//  - template: Function({rowId: {String}, rowData: {Hash}, canUpdate: {Boolean})
//  - header: Function() returning content (and/or onTap binding to sort)

export default PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.string.isRequired,

    // priority of column for culling - lower "rank" => higher priority.
    priority: PropTypes.number,

    // should the column be considered for rendering
    isEnabled: PropTypes.bool,

    // pin the column to the start of the row
    isFixedStart: PropTypes.bool,

    // pin the column to the end of the row
    isFixedEnd: PropTypes.bool,

    // width of the column in pixels
    width: PropTypes.number,

    // minimum width of the column in pixels
    minWidth: PropTypes.number,

    // maximum width of the column in pixels
    maxWidth: PropTypes.number,

    // align contents of the column
    align: PropTypes.oneOf(['none', 'start', 'center', 'end']),

    // apply the cell fit CSS class
    isCellFit: PropTypes.bool,

    // suppress DnD behaviours on row
    isNotSortable: PropTypes.bool,

    // header cellRender function/component
    header: PropTypes.oneOfType([PropTypes.func, PropTypes.object]),

    // header tooltip function/component
    headerTooltip: PropTypes.func,

    // handler for onTap of header
    onHeaderTap: PropTypes.func,

    // content cellRender function/component
    template: PropTypes.oneOfType([PropTypes.func, PropTypes.object]),

    // sort definition
    sort: PropTypes.shape({

        // id of sort
        id: PropTypes.string.isRequired,

        // custom sort compare function
        // Example:
        // cont myCustomSortCompareFunction = (a, b, direction, sortProperties) => {
        //   if(a === b){
        //      return 0;
        //   }
        //   return a > b ? 1 : -1;
        // }
        compareFunction: PropTypes.func,

        fields: PropTypes.oneOfType([

            // single sort path
            PropTypes.string,

            // array of sort paths
            PropTypes.arrayOf(PropTypes.string),

            // sort fields
            PropTypes.arrayOf(PropTypes.shape({

                // sort path
                path: PropTypes.string.isRequired,

                // sort direction
                // 1 - asc
                // 0 - initial order
                // -1 - desc
                direction: PropTypes.number,

                // custom sort compare function
                // Example:
                // cont myCustomSortCompareFunction = (a, b, direction, sortProperties) => {
                //   if(a === b){
                //      return 0;
                //   }
                //   return a > b ? 1 : -1;
                // }
                compareFunction: PropTypes.func,
            })),
        ]),
    }),
}));
