import config from 'src/config';

export const DIVIDER_HEIGHT = config.isDesktopApp ? 18 : 20;
export const DIVIDER_LINEHEIGHT = DIVIDER_HEIGHT;

export const SINGLE_ROW_HEIGHT = config.isDesktopApp ? 24 : 26;
export const DOUBLE_ROW_HEIGHT = config.isDesktopApp ? 37 : 39;
export const COMPACT_ROW_HEIGHT = 21;

export const SINGLE_HEADER_HEIGHT = SINGLE_ROW_HEIGHT;
export const DOUBLE_HEADER_HEIGHT = DOUBLE_ROW_HEIGHT;
export const COMPACT_HEADER_HEIGHT = 17;

export const SINGLE_HEADER_LINEHEIGHT = SINGLE_HEADER_HEIGHT;
export const DOUBLE_HEADER_LINEHEIGHT = config.isDesktopApp ? 20 : 21;
export const COMPACT_HEADER_LINEHEIGHT = COMPACT_HEADER_HEIGHT;

export const SINGLE_ROW_LINEHEIGHT = SINGLE_ROW_HEIGHT;
export const DOUBLE_ROW_LINEHEIGHT = config.isDesktopApp ? 20 : 21;
export const COMPACT_ROW_LINEHEIGHT = COMPACT_ROW_HEIGHT;

export const HEADER_HEIGHT = config.isDesktopApp ? SINGLE_HEADER_HEIGHT : DOUBLE_HEADER_HEIGHT;
export const ROW_HEIGHT = config.isDesktopApp ? SINGLE_ROW_HEIGHT : DOUBLE_ROW_HEIGHT;
export const HEADER_LINEHEIGHT = config.isDesktopApp ? SINGLE_HEADER_LINEHEIGHT : DOUBLE_HEADER_LINEHEIGHT;
export const ROW_LINEHEIGHT = config.isDesktopApp ? SINGLE_ROW_LINEHEIGHT : DOUBLE_ROW_LINEHEIGHT;

// Columns constants

export const EXPAND_COLUMN_ID = 'expand';
export const DEFAULT_COL_PRIORITY = 1;
export const FIXED_COL_PRIORITY = 0;
export const CELL_FIRST_CHILD_CLASS = 'reactgrid-cell--first-child';
export const CELL_LAST_CHILD_CLASS = 'reactgrid-cell--last-child';
export const TEXT_START_CLASS = 't-start';
export const TEXT_CENTER_CLASS = 't-center';
export const TEXT_END_CLASS = 't-end';
export const CELL_FIT_CLASS = 'reactgrid-cell--fit';

