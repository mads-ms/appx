/* eslint max-lines: "off" */
/**
 * The <ReactGridRow/> Component is internal to <ReactGrid> and should not be
 * accessed directly. It supervises an individual Row within the ScrollView, and
 * is responsible for laying out its child cells according to the current state
 * of the Component.
 *
 * It also supervises whether cell content can update (by passing the external
 * template function for each column a `canUpdate` Boolean).
 */
import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import Touchable from 'src/components/touchable/touchable';
import ReactGridCell from './reactGridCell';
import { bindHandlers } from 'src/utils/bindHandlers';
import { createRenderer } from 'src/components/reactGrid/reactGridRendererUtils';

const ROW_CLASS = 'reactgrid-row';
const DIVIDER_CLASS = 'reactgrid-divider';

const TST_ROW_CLASS = 'tst-grid-row';
const TST_DIVIDER_CLASS = 'tst-grid-divider';

class ReactGridRow extends React.PureComponent {

    /**
     * Obtains row styles for positioning a row correctly along the X and Y axes
     * within the ScrollView.
     *
     * @returns {Object} - Style hash
     */
    getRowStyles() {
        const {
            height,
            lineHeight,
            width,
            isSticky,
            rowStyleFunction,
        } = this.props;

        const customStyles = rowStyleFunction ? (rowStyleFunction(this.props) || {}) : {};

        return _.defaults({
            zIndex: isSticky ? 1 : 0,
            width,
            height,
            lineHeight: `${lineHeight}px`,
            position: 'relative',
        }, customStyles);
    }

    handlePress(evt) {
        this.props.onRowPress(evt, this.props);
    }

    handleTap(evt) {
        this.props.onSelect(evt, this.props);
    }

    handleDoubleTap(evt) {
        this.props.onDoubleTap(evt, this.props);
    }

    handleRowTap(evt) {
        this.props.onRowTap(evt, this.props);
    }

    renderRowContent() {
        const {
            rowId,
            rowInfo,
            rowData,
            isGrouping,
            columns,
            isRtl,
        } = this.props;

        if (!rowInfo || !rowInfo.template) {
            return false;
        }

        const { isSectioned, isCustom } = rowInfo;

        // Dividers review will change manual offset manipulation
        const offset = isGrouping && _.size(columns) && !isSectioned && !isCustom ? columns[0].width : 0;

        const style = {
            position: 'absolute',
            top: 0,
            bottom: 0,
            left: isRtl ? 0 : offset,
            right: isRtl ? offset : 0,
        };

        const content = createRenderer(rowInfo.template, { rowId, rowData, rowInfo });

        return (
            <Touchable onTap={this.handleRowTap}>
                <div className="reactgrid-row-content" style={style}>
                    {content}
                </div>
            </Touchable>
        );
    }

    renderCells() {
        const {
            columns,
            rowId,
            rowInfo,
            rowData,
            canUpdate,
            cellClass,
            index,
        } = this.props;

        if (!rowInfo) {
            return false;
        }

        const { isDivider, isCustom, sectionColumns } = rowInfo;

        return _.map(columns, (column) => {
            if ((isDivider && !_.includes(sectionColumns, column.id)) || !column.template || isCustom === true) {
                return false;
            }

            const rendererProps = _.assign({ column, rowId, rowData, rowInfo, canUpdate }, column.templateProps);
            const cellElement = createRenderer(column.template, rendererProps);

            if (_.isNull(cellElement)) {
                return false;
            }

            return (
                <ReactGridCell
                    key={`c_${column.id}_${index}`}
                    column={column}
                    cellClass={cellClass}
                >
                    {cellElement}
                </ReactGridCell>
            );
        });
    }

    render() {
        const {
            canAnimate,
            isSelected,
            className,
            rowInfo,
        } = this.props;

        const isDivider = rowInfo ? rowInfo.isDivider : false;

        const rowProps = {
            className: classNames(
                className,
                {
                    [ROW_CLASS]: !isDivider,
                    [DIVIDER_CLASS]: isDivider,
                    [TST_ROW_CLASS]: !isDivider,
                    [TST_DIVIDER_CLASS]: isDivider,
                    'is-animate': canAnimate,
                    'is-selected': isSelected,
                },
                rowInfo.className
            ),
            style: this.getRowStyles(),
        };

        const touchableProps = {
            onTap: this.handleTap,
            onDoubleTap: this.handleDoubleTap,
            onPress: this.handlePress,
        };

        if (isDivider) {
            return (
                <div {...rowProps}>
                    {this.renderCells()}
                    {this.renderRowContent()}
                </div>
            );
        }

        return (
            <Touchable {...touchableProps}>
                <div {...rowProps}>
                    {this.renderCells()}
                    {this.renderRowContent()}
                </div>
            </Touchable>
        );
    }
}

ReactGridRow.propTypes = {
    canAnimate: PropTypes.bool,
    canUpdate: PropTypes.bool,
    cellClass: PropTypes.string,
    className: PropTypes.string,
    columns: PropTypes.arrayOf(PropTypes.object),
    height: PropTypes.number,
    lineHeight: PropTypes.number,
    width: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    index: PropTypes.number,
    rowStyleFunction: PropTypes.func,
    isRtl: PropTypes.bool.isRequired,
    isGrouping: PropTypes.bool,
    isDivider: PropTypes.bool,
    isSelected: PropTypes.bool,
    isSticky: PropTypes.bool,
    onDoubleTap: PropTypes.func,
    onSelect: PropTypes.func,
    rowData: PropTypes.object,
    rowInfo: PropTypes.object,
    rowId: PropTypes.string,
    onRowTap: PropTypes.func,
    onRowPress: PropTypes.func,
};

ReactGridRow.defaultProps = {
    className: '',
    canAnimate: false,
    canUpdate: true,
    isDivider: false,
    isGrouping: false,
    isSticky: false,
    height: 0,
    width: '100%',
    rowStyleFunction: _.noop,
    onDoubleTap: _.noop,
    onSelect: _.noop,
    onRowPress: _.noop,
    onRowTap: _.noop,
};

export default bindHandlers(ReactGridRow);
