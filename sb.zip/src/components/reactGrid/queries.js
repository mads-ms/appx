import * as constants from './constants';
import config from 'src/config';
import Enums from 'src/spine/enums';

export const isSingleMode = (displayMode) => Boolean(displayMode === Enums.RowDisplayMode.Single);

/**
 * Returns row height
 * @param displayMode - Double or Single display mode
 * @param isCompact - Indicates if we should support compact style for a grid (new feel and look for a grid).
 * @return {Number} - The row height.
 */
export const getRowHeight = (displayMode, isCompact) => {
    if (config.isProApp && isCompact) {
        return constants.COMPACT_ROW_HEIGHT;
    }

    return isSingleMode(displayMode) ? constants.SINGLE_ROW_HEIGHT : constants.DOUBLE_ROW_HEIGHT;
};

/**
 * Returns header height
 * @param displayMode - Double or Single display mode
 * @param isCompact - Indicates if we should support compact style for a grid (new feel and look for a grid).
 * @return {Number} - The header height.
 */
export const getHeaderHeight = (displayMode, isCompact) => {
    if (config.isProApp && isCompact) {
        return constants.COMPACT_HEADER_HEIGHT;
    }

    return isSingleMode(displayMode) ? constants.SINGLE_HEADER_HEIGHT : constants.DOUBLE_HEADER_HEIGHT;
};

/**
 * Returns header line height
 * @param displayMode - Double or Single display mode
 * @param isCompact - Indicates if we should support compact style for a grid (new feel and look for a grid).
 * @return {Number} - The header line height.
 */
export const getHeaderLineHeight = (displayMode, isCompact) => {
    if (config.isProApp && isCompact) {
        return constants.COMPACT_HEADER_LINEHEIGHT;
    }

    return isSingleMode(displayMode) ? constants.SINGLE_HEADER_LINEHEIGHT : constants.DOUBLE_HEADER_LINEHEIGHT;
};

/**
 * Returns row line height
 * @param displayMode - Double or Single display mode
 * @param isCompact - Indicates if we should support compact style for a grid (new feel and look for a grid).
 * @return {Number} - The row line height.
 */
export const getRowLineHeight = (displayMode, isCompact) => {
    if (config.isProApp && isCompact) {
        return constants.COMPACT_ROW_LINEHEIGHT;
    }
    return isSingleMode(displayMode) ? constants.SINGLE_ROW_LINEHEIGHT : constants.DOUBLE_ROW_LINEHEIGHT;
};

