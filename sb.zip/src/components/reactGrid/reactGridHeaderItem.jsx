import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import Tooltip from 'src/components/tooltip/tooltip';
import Touchable from 'src/components/touchable/touchable';
import { bindHandlers } from 'src/utils/bindHandlers';
import { getIsColumnSortable } from 'src/components/reactGrid/reactGridSortUtils';
import { createRenderer } from 'src/components/reactGrid/reactGridRendererUtils';

const CELL_CLASS = 'reactgrid-cell';

class ReactGridHeaderItem extends React.PureComponent {
    handleTap(evt) {
        if (evt.defaultPrevented) {
            return;
        }

        const { column, onHeaderSort } = this.props;

        if (column.onHeaderTap) {
            column.onHeaderTap(column.id);
        }

        if (getIsColumnSortable(column)) {
            onHeaderSort(column);
        }
    }

    render() {
        const {
            column,
            cellClass,
            sort,
        } = this.props;

        let header = createRenderer(column.header, { column, sort });

        if (header && column.headerTooltip) {
            const tooltip = createRenderer(column.headerTooltip, { column, sort });
            header = (
                <Tooltip content={tooltip} onTap={this.handleTap}>
                    {header}
                </Tooltip>
            );
        } else if (header && (column.onHeaderTap || column.sort)) {
            header = (
                <Touchable onTap={this.handleTap}>
                    {header}
                </Touchable>
            );
        }

        return (
            <div
                className={classNames(cellClass, CELL_CLASS, column.classes)}
                style={column.styles}
            >
                {header}
            </div>
        );
    }
}

ReactGridHeaderItem.propTypes = {
    cellClass: PropTypes.string,
    column: PropTypes.object.isRequired,
    sort: PropTypes.object,
    onHeaderSort: PropTypes.func,
};

export default bindHandlers(ReactGridHeaderItem);
