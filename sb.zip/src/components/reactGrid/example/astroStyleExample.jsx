import PropTypes from 'prop-types';
import React from 'react';
import _ from 'lodash';
import ReactGrid from '../reactGrid';
import DataGenerator from './dataGenerator';
import { bindHandlers } from 'src/utils/bindHandlers';
import Enums from 'src/spine/enums';
import Dropdown from 'src/components/dropdown/dropdown';
import DropdownItem from 'src/components/dropdown/dropdownItem';
import * as gridConstants from 'src/components/reactGrid/constants';

class AstroStyleExample extends React.PureComponent {

    constructor(props) {
        super(props);

        this.state = {
            sort: null,
            displayMode: Enums.RowDisplayMode.Single,
        };
    }

    handleDisplayModeChange(value) {
        this.setState({
            displayMode: value,
        });
    }

    handleGetPropertyValue(propertyName, rowId) {
        if (propertyName === 'property0') {
            return 'Instrument' + rowId;
        }

        if (propertyName === 'property1') {
            return 'Currency' + _.random(1, 5);
        }
    }

    handleHeaderSort(sort) {
        this.setState({
            sort,
        });
    }

    render() {
        const {
            sort,
            displayMode,
        } = this.state;

        return (
            <div className="grid grid--y grid--fit-fill">
                <div className="grid-cell toolbar g--fit">
                    <div className="grid--x grid grid--series">
                        <div className="grid-cell g--fit">
                            Display mode:
                        </div>
                        <div className="grid-cell g--fit">
                            <Dropdown
                                value={displayMode}
                                onChange={this.handleDisplayModeChange}
                            >
                                <DropdownItem value={Enums.RowDisplayMode.Single}>Single</DropdownItem>
                            </Dropdown>
                        </div>
                    </div>
                </div>
                <DataGenerator
                    staticProperties={['property0', 'property1']}
                    columnsCount={10}
                    rowsCount={50}
                    updateInterval={-1}
                    onGetPropertyValue={this.handleGetPropertyValue}
                    sortableColumns
                >
                    {
                        ({ rows, cols }) =>
                            (
                                <ReactGrid
                                    rows={rows}
                                    cols={cols}
                                    sort={sort}
                                    headerHeight={gridConstants.COMPACT_HEADER_HEIGHT}
                                    headerLineHeight={gridConstants.COMPACT_HEADER_LINEHEIGHT}
                                    rowHeight={gridConstants.COMPACT_ROW_HEIGHT}
                                    rowLineHeight={gridConstants.COMPACT_ROW_LINEHEIGHT}
                                    className="reactgrid--astro"
                                    resizeTimestamp={this.props.resizeTimestamp}
                                    onHeaderSort={this.handleHeaderSort}
                                />
                            )
                    }
                </DataGenerator>
            </div>
        );
    }
}

AstroStyleExample.propTypes = {
    resizeTimestamp: PropTypes.number,
    action: PropTypes.func,
};

export default bindHandlers(AstroStyleExample);
