import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import ReactGrid from '../reactGrid';
import ContextMenuGridRowPlugin from '../plugins/contextMenu/contextMenuGridRowPlugin';
import ContextMenuGridHeaderPlugin from '../plugins/contextMenu/contextMenuGridHeaderPlugin';
import { ContextMenuItem, MenuItems } from 'src/components/contextMenu';
import DataGenerator from './dataGenerator';
import { bindHandlers } from 'src/utils/bindHandlers';
import DropDown from 'src/components/dropdown/dropdown';
import DropdownItem from 'src/components/dropdown/dropdownItem';
import { supportedEvents } from 'src/components/touchable/touchable';

class ContextMenuPluginExample extends React.PureComponent {

    constructor(props) {
        super(props);

        this.state = {
            sort: null,
            selectedRow: null,
            headerTriggerEvent: 'tap',
            rowTriggerEvent: 'tap',
        };
    }

    handleGetPropertyValue(propertyName, rowId) {
        if (propertyName === 'property0') {
            return 'Instrument' + rowId;
        }

        if (propertyName === 'property1') {
            return 'Currency' + _.random(1, 5);
        }

        if (propertyName === 'property2') {
            return 'AssetType' + _.random(1, 5);
        }

        if (propertyName === 'property3') {
            return 'Sector' + _.random(1, 5);
        }
    }

    handleHeaderSort(sort) {
        this.setState({
            sort,
        });
    }

    handleHeaderGetActionData(/* column, target */) {
        // return actions data
    }

    handleRowGetActionData(/* row, target */) {
        // return actions data
    }

    handleHeaderTriggerEventChange(value) {
        this.setState({
            headerTriggerEvent: value,
        });
    }

    handleRowTriggerEventChange(value) {
        this.setState({
            rowTriggerEvent: value,
        });
    }

    handleRowSelect(evt, { rowId }) {
        this.setState({
            selectedRow: rowId,
        });
    }

    render() {
        const {
            sort,
            selectedRow,
            headerTriggerEvent,
            rowTriggerEvent,
        } = this.state;

        const stopHeaderPropagation = !_.includes(['touchStart', 'touchEnd'], headerTriggerEvent);
        const stopRowPropagation = !_.includes(['touchStart', 'touchEnd'], rowTriggerEvent);

        return (
            <div className="grid grid--y grid--fit-fill">
                <pre>{`
Right click on the headers and rows. You should see context menu working with row selection on phone / tablet.
                `}
                </pre>
                <div className="grid-cell toolbar g--fit">
                    <div className="grid--x grid grid--cross-center grid--series">
                        <div className="grid-cell g--fit">
                            Header trigger event:
                        </div>
                        <div className="grid-cell g--fit">
                            <DropDown
                                value={headerTriggerEvent}
                                onChange={this.handleHeaderTriggerEventChange}
                            >
                                {_.map(supportedEvents, (item) =>
                                    (<DropdownItem
                                        key={item}
                                        value={item}>
                                        {item}
                                    </DropdownItem>)
                                )}
                            </DropDown>
                        </div>
                        <div className="grid-cell g--fit">
                            Row trigger event:
                        </div>
                        <div className="grid-cell g--fit">
                            <DropDown
                                value={rowTriggerEvent}
                                onChange={this.handleRowTriggerEventChange}
                            >
                                {_.map(supportedEvents, (item) =>
                                    (<DropdownItem
                                        key={item}
                                        value={item}>
                                        {item}
                                    </DropdownItem>)
                                )}
                            </DropDown>
                        </div>
                    </div>
                </div>
                <DataGenerator
                    staticProperties={['property0', 'property1', 'property2', 'property3']}
                    onGetPropertyValue={this.handleGetPropertyValue}
                    updateInterval={-1}
                    sortableColumns
                >
                    {
                        ({ rows, cols }) =>
                            (<ReactGrid
                                rows={rows}
                                cols={cols}
                                sort={sort}
                                selectedRow={selectedRow}
                                resizeTimestamp={this.props.resizeTimestamp}
                                onHeaderSort={this.handleHeaderSort}
                                onRowSelect={this.handleRowSelect}
                            >
                                <ContextMenuGridHeaderPlugin
                                    triggerEvent={headerTriggerEvent}
                                    shouldStopPropagation={stopHeaderPropagation}
                                    onGetActionsData={this.handleHeaderGetActionData}
                                >
                                    <MenuItems>
                                        <ContextMenuItem
                                            action={{ id: '1', label: 'Header action', performAction: _.noop }}/>
                                    </MenuItems>
                                </ContextMenuGridHeaderPlugin>
                                <ContextMenuGridRowPlugin
                                    triggerEvent={rowTriggerEvent}
                                    shouldStopPropagation={stopRowPropagation}
                                    onGetActionsData={this.handleRowGetActionData}
                                >
                                    <MenuItems>
                                        <ContextMenuItem
                                            action={{ id: '1', label: 'Row action action', performAction: _.noop }}/>
                                    </MenuItems>
                                </ContextMenuGridRowPlugin>
                            </ReactGrid>)
                    }
                </DataGenerator>
            </div>
        );
    }

}

ContextMenuPluginExample.propTypes = {
    resizeTimestamp: PropTypes.number,
};

export default bindHandlers(ContextMenuPluginExample);

