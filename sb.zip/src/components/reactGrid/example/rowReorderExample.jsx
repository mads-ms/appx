import PropTypes from 'prop-types';
import React from 'react';
import _ from 'lodash';
import ReactGrid from '../reactGrid';
import DataGenerator from './dataGenerator';
import { bindHandlers } from 'src/utils/bindHandlers';
import CheckBox from 'src/components/checkbox/checkbox';
import DraggableGridRowPlugin from 'src/components/reactGrid/plugins/draggableRow/dragableGridRowPlugin';

class RowReorderExample extends React.PureComponent {

    constructor(props) {
        super(props);

        this.state = {
            sort: null,
            isDraggingEnabled: true,
            dragAfterPress: false,
            orderedRowsIds: null,
        };

        this.rowCompareFunction = this.rowCompareFunction.bind(this);
    }

    rowCompareFunction(rowA, rowB) {
        const { orderedRowsIds } = this.state;

        const rowAIndex = _.indexOf(orderedRowsIds, rowA.id);
        const rowBIndex = _.indexOf(orderedRowsIds, rowB.id);

        if (rowAIndex === rowBIndex) {
            return 0;
        }

        return rowAIndex > rowBIndex ? 1 : -1;
    }

    handleGetPropertyValue(propertyName, rowId) {
        if (propertyName === 'property0') {
            return 'Instrument' + rowId;
        }

        if (propertyName === 'property1') {
            return 'Currency' + _.random(1, 5);
        }
    }

    handleRowDragBegin() {
        this.props.action('row drag begin')();
    }

    handleGridRowsReorder(rows) {
        this.props.action('rows reorder')();

        const orderedRowsIds = _.map(rows, 'id');

        // change sort to maintain user order, remove header sort
        const sort = {
            compareFunction: this.rowCompareFunction,
        };

        this.setState({ orderedRowsIds, sort });
    }

    handleRowDragEnd() {
        this.props.action('drag end')();
    }

    handleDragAfterPressChange() {
        this.setState({
            dragAfterPress: !this.state.dragAfterPress,
        });
    }

    handleIsDraggingEnabledChange() {
        this.setState({
            isDraggingEnabled: !this.state.isDraggingEnabled,
        });
    }

    handleHeaderSort(sort) {
        this.setState({
            sort,
        });
    }

    render() {
        const {
            sort,
            isDraggingEnabled,
            dragAfterPress,
        } = this.state;

        return (
            <div className="grid grid--y grid--fit-fill">
                <div className="grid-cell toolbar g--fit">
                    <div className="grid--x grid grid--series">
                        <div className="grid-cell g--fit">
                            <CheckBox
                                isChecked={isDraggingEnabled}
                                onChange={this.handleIsDraggingEnabledChange}
                                className="tst-plugin-enabled"
                            >
                                Dragging enabled
                            </CheckBox>
                            <CheckBox
                                isChecked={dragAfterPress}
                                onChange={this.handleDragAfterPressChange}
                                className="tst-drag-after-press"
                            >
                                Drag after press
                            </CheckBox>
                        </div>
                    </div>
                </div>
                <DataGenerator
                    staticProperties={['property0', 'property1']}
                    columnsCount={10}
                    rowsCount={50}
                    updateInterval={-1}
                    onGetPropertyValue={this.handleGetPropertyValue}
                    sortableColumns
                >
                    {
                        ({ rows, cols }) =>
                            (<ReactGrid
                                rows={rows}
                                cols={cols}
                                sort={sort}
                                resizeTimestamp={this.props.resizeTimestamp}
                                onHeaderSort={this.handleHeaderSort}
                            >
                                <DraggableGridRowPlugin
                                    isEnabled={isDraggingEnabled}
                                    dragAfterPress={dragAfterPress}
                                    onRowsReorder={this.handleGridRowsReorder}
                                    onRowDragBegin={this.handleRowDragBegin}
                                    onRowDragEnd={this.handleRowDragEnd}
                                />
                            </ReactGrid>)
                    }
                </DataGenerator>
            </div>
        );
    }
}

RowReorderExample.propTypes = {
    resizeTimestamp: PropTypes.number,
    action: PropTypes.func,
};

export default bindHandlers(RowReorderExample);
