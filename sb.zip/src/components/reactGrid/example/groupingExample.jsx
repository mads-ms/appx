import PropTypes from 'prop-types';
import React from 'react';
import _ from 'lodash';
import ReactGrid from '../reactGrid';
import DataGenerator from './dataGenerator';
import { bindHandlers } from 'src/utils/bindHandlers';
import DropDown from 'src/components/dropdown/dropdown';
import DropdownItem from 'src/components/dropdown/dropdownItem';
import CheckBox from 'src/components/checkbox/checkbox';
import * as groupingUtils from 'src/components/reactGrid/reactGridGroupingUtils';

const groupings = [
    {
        name: 'Sector (single prop)',
        groupingDefinition: 'data.property3',
        generateChildren: false,
        isSectioned: true,
        isGrouping: false,
    },
    {
        name: 'Sector static sections no expand (single prop)',
        groupingDefinition: [{
            path: 'data.property3',
            groupingObjectFunction: groupingUtils.groupingCountObjectFunction,
            isStatic: true,
        }],
        generateChildren: false,
        isSectioned: true,
        isGrouping: false,
    },
    {
        name: 'Sector no groups (single prop)',
        groupingDefinition: [{
            path: 'data.property3',
            isRootExcluded: true,
            sort: { fields: ['data.property3'] },
        }],
        generateChildren: false,
        isSectioned: false,
        isGrouping: true,
    },
    {
        name: 'AssetType and Sector (multiple props)',
        groupingDefinition: ['data.property2', 'data.property3'],
        generateChildren: false,
        isSectioned: true,
        isGrouping: false,
    },
    {
        name: 'AssetType and Sector custom grouping function (single props)',
        groupingDefinition: [{
            groupingFunction: (row) => _.get(row, 'data.property2') + '-' + _.get(row, 'data.property3'),
        }],
        generateChildren: false,
        isSectioned: true,
        isGrouping: false,
    },
    {
        name: 'Ticking value with sort descending and count header (single prop)',
        groupingDefinition: [{
            path: 'data.property4',
            groupingObjectFunction: groupingUtils.groupingCountObjectFunction,
            sort: {
                fields: [{ path: 'data.property4', direction: -1 }],
            },
        }],
        generateChildren: false,
        isSectioned: true,
        isGrouping: false,
    },
    {
        name: 'Section by Sector, groups by AssetType (single prop)',
        groupingDefinition: [
            {
                path: 'data.property3',
                isSectioned: true,
            },
        ],
        generateChildren: true,
        isSectioned: true,
        isGrouping: true,
    },
];

class GroupingExample extends React.PureComponent {

    constructor(props) {
        super(props);

        this.state = {
            selectedGrouping: groupings[0],
            expandedGroups: {},
            keepGroupsExpanded: true,
            rememberExpanded: true,
            sort: null,
        };
    }

    handleGetPropertyValue(propertyName, rowId) {
        if (propertyName === 'property0') {
            return 'Instrument' + rowId;
        }

        if (propertyName === 'property1') {
            return 'Currency' + _.random(1, 5);
        }

        if (propertyName === 'property2') {
            return 'AssetType' + _.random(1, 5);
        }

        if (propertyName === 'property3') {
            return 'Sector' + _.random(1, 5);
        }
    }

    handleKeepGroupsExpandedChange() {
        this.setState({
            keepGroupsExpanded: !this.state.keepGroupsExpanded,
        });
    }

    handleRememberExpandedChange() {
        this.setState({
            rememberExpanded: !this.state.rememberExpanded,
        });
    }

    handleGroupingChange(name) {
        this.setState({
            selectedGrouping: _.find(groupings, { name }),
        });
    }

    handleSectionExpand(evt, { rowId, isExpanded }) {
        const { expandedGroups } = this.state;
        expandedGroups[rowId] = !isExpanded;

        window.expandedGroups = expandedGroups;

        this.setState({
            expandedGroups: _.clone(expandedGroups),
        });
    }

    handleHeaderSort(sort) {
        this.setState({
            sort,
        });
    }

    render() {
        const {
            selectedGrouping,
            expandedGroups,
            keepGroupsExpanded,
            rememberExpanded,
            sort,
        } = this.state;

        return (
            <div className="grid grid--y grid--fit-fill">
                <div className="grid-cell toolbar">
                    <DropDown
                        value={selectedGrouping.name}
                        onChange={this.handleGroupingChange}
                    >
                        {_.map(groupings, (item) =>
                            (<DropdownItem
                                key={item.name}
                                value={item.name}>
                                {item.name}
                            </DropdownItem>)
                        )}
                    </DropDown>
                </div>
                <div className="grid-cell toolbar g--fit">
                    <CheckBox
                        isChecked={keepGroupsExpanded}
                        onChange={this.handleKeepGroupsExpandedChange}
                    >
                        Keep groups expanded
                    </CheckBox>
                    <CheckBox
                        isChecked={rememberExpanded}
                        onChange={this.handleRememberExpandedChange}
                    >
                        Remember expanded
                    </CheckBox>
                </div>
                <DataGenerator
                    staticProperties={['property0', 'property1', 'property2', 'property3']}
                    onGetPropertyValue={this.handleGetPropertyValue}
                    generateChildren={selectedGrouping.generateChildren}
                    sortableColumns
                >
                    {
                        ({ rows, cols }) =>
                            (<ReactGrid
                                rows={rows}
                                cols={cols}
                                sort={sort}
                                resizeTimestamp={this.props.resizeTimestamp}
                                onHeaderSort={this.handleHeaderSort}
                                expandedGroups={rememberExpanded ? expandedGroups : null}
                                isSectioned={selectedGrouping.isSectioned}
                                isGrouping={selectedGrouping.isGrouping}
                                grouping={selectedGrouping.groupingDefinition}
                                keepGroupsExpanded={keepGroupsExpanded}
                                onSectionExpand={this.handleSectionExpand}
                                onRowExpand={this.handleSectionExpand}
                            />)
                    }
                </DataGenerator>
            </div>
        );
    }

}

GroupingExample.propTypes = {
    resizeTimestamp: PropTypes.number,
};

export default bindHandlers(GroupingExample);
