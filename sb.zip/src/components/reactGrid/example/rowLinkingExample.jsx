/* eslint react/prop-types: "off" */
import React from 'react';
import PropTypes from 'prop-types';
import ReactGrid from '../reactGrid';
import _ from 'lodash';
import Header from 'src/components/reactGrid/blocks/defaultHeaderRenderer';
import InstrumentHeader from 'src/components/reactGrid/blocks/instrumentHeader';
import InstrumentRenderer from 'src/components/reactGrid/blocks/instrumentRenderer';
import InstrumentDoubleRenderer from 'src/components/reactGrid/blocks/instrumentDoubleRenderer';
import InstrumentHeaderDouble from 'src/components/reactGrid/blocks/instrumentHeaderDouble';
import Dropdown from 'src/components/dropdown/dropdown';
import DropdownItem from 'src/components/dropdown/dropdownItem';
import Enums from 'src/spine/enums';
import LinkedGridRowPlugin from 'src/components/reactGrid/plugins/linkedRow/linkedGridRowPlugin';
import * as instrumentUtils from 'src/modules/instruments/utils';
import * as instrumentsQueries from 'src/modules/instruments/queries';
import * as assetTypeQueries from 'src/modules/instruments/assetType/queries';
import { bindHandlers } from 'src/utils/bindHandlers';
import * as gridQueries from 'src/components/reactGrid/queries';
import CheckBox from 'src/components/checkbox/checkbox';

const getInstrumentName = ({ rowData }) => {
    const { instrument } = rowData;
    return instrumentsQueries.getName(instrument);
};

const createRow = (index, assetType, rows = null, isChild = false, isRelated = false) => {
    const key = String(index);
    const info = (isChild ? 'Child ' : '') + (isRelated ? 'Related ' : '');
    return {
        id: key,
        data: {
            instrument: {
                AssetType: assetType,
                Description: 'Instrument Description ' + info + key,
                isTradable: true,
                Symbol: 'Symbol ' + info + key,
                Uic: index,
                id: 'instrument_' + key,
                Format: { StrikeDecimals: {} },
                StrikePrice: {},
            },
            order: {
                price: _.random(1, 100),
            },
            isGroup: Boolean(rows && rows.length > 0),
            rows,
        },
        isRelated,
    };
};

const addInstrumentType = (row, instrumentType) => {
    row.data.instrument.InstrumentType = instrumentType;

    return row;
};

const createRelatedOrderRow = (index, rowA, rowB) => ({
    id: String(index),

    // sort by first related order, or calculate summary
    data: rowA.data,

    // group related orders together
    isGroup: true,

    // exclude related orders dummy parent
    isRootExcluded: true,

    // Prevent from sorting
    isNotSortable: true,

    // add rows to the group
    rows: [
        rowA,
        rowB,
    ],
});

const createRows = () => [
    createRow(0, 'FxSpot'),
    createRow(1, 'FxSpot'),
    createRow(2, 'FxSpot',
        [
            createRow(3, 'FxSpot', null, true),
            createRelatedOrderRow(
                4,
                createRow(5, 'FxSpot', null, true, true),
                createRow(6, 'FxSpot', null, true, true)
            ),
            createRow(7, 'FxSpot', null, true),
        ]
    ),
    createRow(8, 'FxSpot'),
    createRow(9, 'FxSpot'),
    createRow(10, 'FxSpot'),
    createRow(11, 'FxSpot'),
    createRow(12, 'Stock'),
    createRelatedOrderRow(
        13,
        createRow(14, 'Stock', null, true, true),
        createRow(15, 'Stock', null, true, true)
    ),
    createRow(16, 'Stock'),
    createRelatedOrderRow(
        17,
        addInstrumentType(createRow(18, 'FuturesOption', null, true, true), Enums.InstrumentType.ContractOptionsAll),
        addInstrumentType(createRow(19, 'FuturesOption', null, true, true), Enums.InstrumentType.ContractOptionsAll)
    ),
];

const getSingleColumns = () =>
    [
        {
            id: 'instrument',
            priority: 1,
            minWidth: 100,
            maxWidth: Number.MAX_VALUE,
            align: 'start',
            header: InstrumentHeader,
            template: ({ rowData }) => <InstrumentRenderer {...rowData}/>,
            sort: { id: 'instrument' },
            itemToLabel: getInstrumentName,
        },
        {
            id: 'price',
            minWidth: 100,
            maxWidth: Number.MAX_VALUE,
            primaryTitle: 'Price',
            align: 'start',
            header: Header,
            sort: { id: 'price' },
            itemToLabel: ({ rowData }) => rowData.order.price,
        },
    ];

const getDoubleColumns = () =>
    [
        {
            id: 'instrument',
            priority: 1,
            minWidth: 100,
            maxWidth: Number.MAX_VALUE,
            align: 'start',
            header: InstrumentHeaderDouble,
            template: InstrumentDoubleRenderer,
            sort: { id: 'instrument' },
            itemToLabel: getInstrumentName,
        },
        {
            id: 'price',
            minWidth: 100,
            maxWidth: Number.MAX_VALUE,
            primaryTitle: 'Price',
            align: 'start',
            header: Header,
            sort: { id: 'price' },
            itemToLabel: ({ rowData }) => rowData.order.price,
        },
    ];

const grouping = [{
    groupingFunction: (row) => assetTypeQueries.getAssetTypeName(row.data.instrument),
    groupingObjectFunction: (name, rows, level) => {
        const rowCount = _.size(rows);
        return {
            sectionHeader: `${name} (${rowCount})`,
            rows,
            rowCount,
            level,
        };
    },
}];

class InstrumentLinkingExample extends React.PureComponent {

    constructor(props) {
        super(props);

        this.state = {
            sort: null,
            rows: createRows(),
            columns: getSingleColumns(),
            expandedGroups: {},
            displayMode: Enums.RowDisplayMode.Single,
            isPluginEnabled: true,
            isGroupingEnabled: true,
        };
    }

    getLinkMode({ rowInfo }) {
        if (!rowInfo.isRelated) {
            return 0;
        }

        if (rowInfo.childIndex === 0) {
            return 1;
        }

        return 2;
    }

    handleDisplayModeChange(value) {
        const columns = (value === Enums.RowDisplayMode.Single) ?
            getSingleColumns() : getDoubleColumns();

        this.setState({
            displayMode: value,
            columns,
        });
    }

    handleSectionExpand(evt, { rowId, isExpanded }) {
        const { expandedGroups } = this.state;
        expandedGroups[rowId] = !isExpanded;

        window.expandedGroups = expandedGroups;

        this.setState({
            expandedGroups: _.clone(expandedGroups),
        });
    }

    handleGetLinkingInfo(row) {
        const { rowData } = row;
        const linkMode = this.getLinkMode(row);
        const linkType = instrumentUtils.getInstrumentGroupClassName(rowData.instrument);

        return { linkMode, linkType };
    }

    handleHeaderSort(sort) {
        this.setState({
            sort,
        });
    }

    handleRowReflow(rowIds, rows) {
        this.props.action('rows in view')(rows);
    }

    handleIsPluginEnabledChange() {
        this.setState({
            isPluginEnabled: !this.state.isPluginEnabled,
        });
    }

    handleIsGroupingEnabledChange() {
        this.setState({
            isGroupingEnabled: !this.state.isGroupingEnabled,
        });
    }

    render() {
        const {
            sort,
            displayMode,
            isPluginEnabled,
            isGroupingEnabled,
            expandedGroups,
            rows,
            columns,
        } = this.state;

        return (
            <div className="grid grid--y grid--fit-fill tst-instrumentlinking">
                <div className="grid--x grid grid--cross-center grid--series">
                    <div className="grid-cell g--fit">
                        <CheckBox
                            isChecked={isPluginEnabled}
                            onChange={this.handleIsPluginEnabledChange}
                            className="tst-plugin-enabled"
                        >
                            Plugin enabled
                        </CheckBox>
                    </div>
                    <div className="grid-cell g--fit">
                        <CheckBox
                            isChecked={isGroupingEnabled}
                            onChange={this.handleIsGroupingEnabledChange}
                            className="tst-grouping-enabled"
                        >
                            Grouping enabled
                        </CheckBox>
                    </div>
                    <div className="grid-cell g--fit">
                        DisplayMode:
                    </div>
                    <div className="grid-cell g--fit">
                        <Dropdown
                            value={displayMode}
                            onChange={this.handleDisplayModeChange}
                        >
                            <DropdownItem value={Enums.RowDisplayMode.Single}>Single</DropdownItem>
                            <DropdownItem value={Enums.RowDisplayMode.Double}>Double</DropdownItem>
                        </Dropdown>
                    </div>
                </div>
                <ReactGrid
                    rows={rows}
                    cols={columns}
                    sort={sort}
                    onRowReflow={this.handleRowReflow}
                    isSectioned={isGroupingEnabled}
                    isGrouping={isGroupingEnabled}
                    grouping={isGroupingEnabled ? grouping : null}
                    expandedGroups={expandedGroups}
                    keepGroupsExpanded
                    headerHeight={gridQueries.getHeaderHeight(displayMode)}
                    headerLineHeight={gridQueries.getHeaderLineHeight(displayMode)}
                    rowHeight={gridQueries.getRowHeight(displayMode)}
                    rowLineHeight={gridQueries.getRowLineHeight(displayMode)}
                    resizeTimestamp={this.props.resizeTimestamp}
                    onHeaderSort={this.handleHeaderSort}
                    onSectionExpand={this.handleSectionExpand}
                    onRowExpand={this.handleSectionExpand}
                >
                    <LinkedGridRowPlugin
                        isEnabled={isPluginEnabled}
                        onGetLinkingInfo={this.handleGetLinkingInfo}
                    />
                </ReactGrid>
            </div>
        );
    }
}

InstrumentLinkingExample.propTypes = {
    resizeTimestamp: PropTypes.number,
    action: PropTypes.func,
};

export default bindHandlers(InstrumentLinkingExample);
