import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import ReactGrid from '../reactGrid';
import * as constants from '../constants';
import DataGenerator from './dataGenerator';
import { bindHandlers } from 'src/utils/bindHandlers';
import NumberInput from 'src/components/proComboInput/numberInput';
import Toolbar from 'src/modules/examples/example/toolbar';
import PerfMeasure from 'src/modules/examples/perf/perfMeasure';
import { UI } from 'openui';

class PerfScrollExample extends React.PureComponent {

    constructor(props) {
        super(props);

        this.state = {
            sort: null,
            scrollStep: 1,
            scrollOffset: 0,
        };

        this.hasRaf = true;
    }

    componentDidMount() {
        UI.nextTick(() => this.handleRaf());
    }

    componentWillUnmount() {
        this.hasRaf = false;
    }

    handleRaf() {
        if (!this.hasRaf) {
            return;
        }

        const { scrollOffset, scrollStep } = this.state;
        const { rowCount } = this.props;
        const nextScrollOffset = (scrollOffset + scrollStep) % (rowCount * constants.ROW_HEIGHT);

        this.setState({
            scrollOffset: nextScrollOffset,
        });

        UI.nextTick(() => this.handleRaf());
    }

    handleGetPropertyValue(propertyName, rowId) {
        if (propertyName === 'property0') {
            return 'Instrument' + rowId;
        }

        if (propertyName === 'property1') {
            return 'Currency' + _.random(1, 5);
        }
    }

    handleColumnsCountChange({ value }) {
        this.setState({
            scrollStep: value,
        });
    }

    handleHeaderSort(sort) {
        this.setState({
            sort,
        });
    }

    render() {
        const {
            sort,
            scrollStep,
            scrollOffset,
        } = this.state;

        const { target, columnCount, rowCount } = this.props;

        return (
            <div className="grid grid--y grid--fit-fill">
                <div className="grid-cell g--fit">
                    <Toolbar target={target}>
                        Scroll step:
                        <NumberInput
                            value={scrollStep}
                            onChange={this.handleColumnsCountChange}
                        />
                    </Toolbar>
                </div>
                <DataGenerator
                    staticProperties={['property0', 'property1']}
                    columnsCount={columnCount}
                    rowsCount={rowCount}
                    updateInterval={-1}
                    onGetPropertyValue={this.handleGetPropertyValue}
                    sortableColumns
                >
                    {
                        ({ rows, cols }) =>
                            (
                                <PerfMeasure target={target}>
                                    <ReactGrid
                                        rows={rows}
                                        cols={cols}
                                        sort={sort}
                                        scrollOffset={scrollOffset}
                                        resizeTimestamp={this.props.resizeTimestamp}
                                        onHeaderSort={this.handleHeaderSort}
                                    />
                                </PerfMeasure>
                            )
                    }
                </DataGenerator>
            </div>
        );
    }
}

PerfScrollExample.propTypes = {
    resizeTimestamp: PropTypes.number,
    target: PropTypes.string,
    columnCount: PropTypes.number,
    rowCount: PropTypes.number,
};

PerfScrollExample.defaultProps = {
    columnCount: 10,
    rowCount: 200,
};

export default bindHandlers(PerfScrollExample);
