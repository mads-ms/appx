import PropTypes from 'prop-types';
import React from 'react';
import _ from 'lodash';
import ReactGrid from '../reactGrid';
import DataGenerator from './dataGenerator';
import { bindHandlers } from 'src/utils/bindHandlers';
import CheckBox from 'src/components/checkbox/checkbox';
import ColumnPickerHeaderPlugin from 'src/components/reactGrid/plugins/columnPickerHeader/columnPickerHeaderPlugin';

class ColumnPickerHeaderExample extends React.PureComponent {

    constructor(props) {
        super(props);

        this.state = {
            sort: null,
            isColumnPickerEnabled: true,
        };
    }

    handleGetPropertyValue(propertyName, rowId) {
        if (propertyName === 'property0') {
            return 'Instrument' + rowId;
        }

        if (propertyName === 'property1') {
            return 'Currency' + _.random(1, 5);
        }
    }

    handleColumnPickerOpen() {
        this.props.action('column picker to be opened')();
    }

    handleIsDraggingEnabledChange() {
        this.setState({
            isColumnPickerEnabled: !this.state.isColumnPickerEnabled,
        });
    }

    handleHeaderSort(sort) {
        this.setState({
            sort,
        });
    }

    render() {
        const {
            sort,
            isColumnPickerEnabled,
        } = this.state;

        return (
            <div className="grid grid--y grid--fit-fill">
                <div className="grid-cell toolbar g--fit">
                    <div className="grid--x grid grid--series">
                        <div className="grid-cell g--fit">
                            <CheckBox
                                isChecked={isColumnPickerEnabled}
                                onChange={this.handleIsDraggingEnabledChange}
                            >
                                Column picker header enabled
                            </CheckBox>
                        </div>
                    </div>
                </div>
                <DataGenerator
                    staticProperties={['property0', 'property1']}
                    columnsCount={10}
                    rowsCount={50}
                    updateInterval={-1}
                    onGetPropertyValue={this.handleGetPropertyValue}
                    sortableColumns
                >
                    {
                        ({ rows, cols }) =>
                            (<ReactGrid
                                rows={rows}
                                cols={cols}
                                sort={sort}
                                width={100}
                                resizeTimestamp={this.props.resizeTimestamp}
                                onHeaderSort={this.handleHeaderSort}
                            >
                                <ColumnPickerHeaderPlugin
                                    isEnabled={isColumnPickerEnabled}
                                    onColumnPickerOpen={this.handleColumnPickerOpen}
                                />
                            </ReactGrid>)
                    }
                </DataGenerator>
            </div>
        );
    }
}

ColumnPickerHeaderExample.propTypes = {
    resizeTimestamp: PropTypes.number,
    action: PropTypes.func,
};

export default bindHandlers(ColumnPickerHeaderExample);
