import PropTypes from 'prop-types';
import React from 'react';
import _ from 'lodash';
import Header from 'src/components/reactGrid/blocks/defaultHeaderRenderer';

class DataGenerator extends React.PureComponent {

    constructor(props) {
        super(props);

        this.interval = null;
    }

    componentWillMount() {
        const {
            updateInterval,
            columnsCount,
            rowsCount,
            sortableColumns,
            generateChildren,
            childrenRowsCount,
        } = this.props;

        this.setState({
            rows: this.getRows(columnsCount, rowsCount, generateChildren, childrenRowsCount),
            cols: this.getColumns(columnsCount, sortableColumns),
        });

        this.setUpdateInterval(updateInterval);
    }

    componentWillReceiveProps(nextProps) {
        const nextState = {};

        const {
            rowsCount,
            columnsCount,
            updateInterval,
            sortableColumns,
            generateChildren,
            childrenRowsCount,
        } = nextProps;

        if (columnsCount !== this.props.columnsCount ||
            rowsCount !== this.props.rowsCount ||
            generateChildren !== this.props.generateChildren ||
            childrenRowsCount !== this.props.childrenRowsCount) {

            nextState.rows = this.getRows(columnsCount, rowsCount, generateChildren, childrenRowsCount);
        }

        if (columnsCount !== this.props.columnsCount) {
            nextState.cols = this.getColumns(columnsCount, sortableColumns);
        }

        if (updateInterval !== this.props.updateInterval) {
            this.setUpdateInterval(updateInterval);
        }

        if (!_.isEmpty(nextState)) {
            this.setState(nextState);
        }
    }

    componentWillUnmount() {
        this.clearUpdateInterval();
    }

    getColumns(columnsCount, sortableColumns) {

        return _.chain()
            .range(columnsCount)
            .map((index) => {
                const id = `column${index}`;
                const dataField = `property${index}`;
                const sort = sortableColumns ? {
                    id: dataField,
                    fields: ['data.' + dataField],
                } : null;

                return {
                    id,
                    primaryTitle: _.upperFirst(id),
                    header: Header,
                    minWidth: 100,
                    maxWidth: Number.MAX_VALUE,
                    template: ({ rowData }) => <div>{_.get(rowData, dataField)}</div>,
                    width: 150,
                    sort,
                };
            })
            .value();
    }

    getRows(columnsCount, rowsCount, generateChildren, childrenRowsCount, idPrefix = '') {

        return _.chain()
            .range(rowsCount)
            .map((index) => {
                const id = idPrefix + String(index);

                const props = _.chain()
                    .range(columnsCount)
                    .reduce((preview, current) => {
                        const propertyName = `property${current}`;
                        preview[propertyName] = this.getPropertyValue(propertyName, id);
                        return preview;
                    }, {})
                    .value();

                let children = [];

                if (generateChildren) {
                    children = this.getRows(columnsCount, childrenRowsCount, false, 0, 'Child');
                }

                const item = _.defaults({ id, rows: children }, props);
                return { id, data: item };
            })
            .value();
    }

    getPropertyValue(propertyName, rowId) {
        const { onGetPropertyValue } = this.props;
        let value = null;

        if (onGetPropertyValue) {
            value = onGetPropertyValue(propertyName, rowId);
        }

        return value || _.random(100);
    }

    updateRows() {
        const { updateRowsRatio, updatePropertyRatio, staticProperties } = this.props;
        const { rows } = this.state;

        if (rows.length === 0) {
            return;
        }

        const rowsMap = _.keyBy(rows, 'id');
        const rowProperties = _.chain(rows[0].data)
            .keys()
            .shuffle()
            .reject((key) => {
                if (key === 'id' || key === 'rows') {
                    return true;
                }

                return _.includes(staticProperties, key);
            })
            .value();

        if (rowProperties.length === 0) {
            return;
        }

        const rowsIds = _.chain(rows)
            .map('id')
            .shuffle()
            .value();

        const rowsToUpdate = rowsIds.slice(0, Math.ceil(updateRowsRatio * rowsIds.length));

        _.forEach(rowsToUpdate, (rowId) => {
            const propertiesToUpdate = rowProperties.slice(0, Math.ceil(updatePropertyRatio * rowProperties.length));

            const rowData = _.clone(rows[rowId].data);

            _.forEach(propertiesToUpdate, (propertyName) => {
                rowData[propertyName] = this.getPropertyValue(propertyName, rowId);
            });

            rowsMap[rowId] = _.defaults({
                id: rowId,
                data: rowData,
            }, rowsMap[rowId]);
        });

        this.setState({
            rows: _.values(rowsMap),
        });
    }

    clearUpdateInterval() {
        if (this.interval) {
            clearInterval(this.interval);
        }
    }

    setUpdateInterval(updateInterval) {

        this.clearUpdateInterval();

        if (updateInterval !== -1) {
            this.interval = setInterval(this.updateRows.bind(this), updateInterval);
        }
    }

    render() {
        const { children } = this.props;
        const { rows, cols } = this.state;

        return children({ rows, cols });
    }
}

DataGenerator.propTypes = {
    updateInterval: PropTypes.number,
    updateRowsRatio: PropTypes.number,
    updatePropertyRatio: PropTypes.number,
    staticProperties: PropTypes.array,
    columnsCount: PropTypes.number,
    childrenRowsCount: PropTypes.number,
    rowsCount: PropTypes.number,
    sortableColumns: PropTypes.bool,
    generateChildren: PropTypes.bool,
    onGetPropertyValue: PropTypes.func,
};

DataGenerator.defaultProps = {
    staticProperties: [],

    // Maximum that human eye can notice on screen
    updateInterval: 250,
    updateRowsRatio: 0.5,
    updatePropertyRatio: 0.5,
    columnsCount: 5,
    rowsCount: 20,
    childrenRowsCount: 5,
    sortableColumns: false,
    generateChildren: false,
};

export default DataGenerator;
