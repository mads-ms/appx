import PropTypes from 'prop-types';
import React from 'react';
import _ from 'lodash';
import ReactGrid from '../reactGrid';
import ResizableColumnPlugin from '../plugins/resizableColumn/resizableColumnPlugin';
import * as resizableColumnConstants from '../plugins/resizableColumn/constants';
import { bindHandlers } from 'src/utils/bindHandlers';
import NumberInput from 'src/components/proComboInput/numberInput';
import Header from 'src/components/reactGrid/blocks/defaultHeaderRenderer';
import CheckBox from 'src/components/checkbox/checkbox';

class ResizableColumnExample extends React.PureComponent {

    constructor(props) {
        super(props);

        this.state = {
            sort: null,
            rowsCount: 100,
            columnCount: 5,
            columnWidths: {},
            resizeColumnId: null,
            isResizingEnabled: true,
            isLivePreview: true,
        };
    }

    /**
     * Generate static column definitions
     */
    getColumns(columnsCount) {
        return _.chain()
            .range(columnsCount)
            .map((index) => {
                const id = `column${index}`;
                const dataField = `property${index}`;
                const sort = {
                    id: dataField,
                    fields: ['data.' + dataField],
                };

                return {
                    id,
                    primaryTitle: _.upperFirst(id),
                    header: Header,
                    minWidth: 100,
                    maxWidth: 200,
                    template: ({ rowData }) => <div>{_.get(rowData, dataField)}</div>,
                    width: 150,
                    sort,

                    // MUST be set to enable resizing
                    isResizable: true,
                };
            })
            .value();
    }

    /**
     * Generate (grouped) rows - ordinarily provided by selector
     */
    getRows(columnsCount, rowsCount) {
        return _.chain()
            .range(rowsCount)
            .map((index) => {
                const id = String(index);

                const props = _.chain()
                    .range(columnsCount)
                    .reduce((preview, current) => {
                        const propertyName = `property${current}`;
                        preview[propertyName] = this.getPropertyValue(propertyName, id, current);
                        return preview;
                    }, {})
                    .value();

                const children = [];

                const item = _.defaults({ id, rows: children }, props);
                return { id, data: item };
            })
            .value();
    }

    /**
     * Generate static values for rowData
     */
    getPropertyValue(propertyName, rowId, current) {
        if (propertyName === 'property0') {
            return 'Instrument' + rowId;
        }

        if (propertyName === 'property1') {
            return 'Currency' + Math.ceil(rowId / 5);
        }

        return current * rowId;
    }

    handleRowsCountChange({ value }) {
        this.setState({
            rowsCount: value,
        });
    }

    handleColumnsCountChange({ value }) {
        this.setState({
            columnCount: value,
        });
    }

    handleHeaderSort(sort) {
        this.setState({
            sort,
        });
    }

    handleIsResizingEnabledChange() {
        this.setState({
            isResizingEnabled: !this.state.isResizingEnabled,
        });
    }

    handleIsLivePreviewChange() {
        this.setState({
            isLivePreview: !this.state.isLivePreview,
        });
    }

    // roundtrip column resizing data into grid

    handleResize(resizeData) {
        const { columnId, width } = resizeData;

        this.setState({
            columnWidths: _.defaults({ [columnId]: width }, this.state.columnWidths),
        });
    }

    handleResizeStart(columnId) {
        this.setState({
            resizeColumnId: columnId,
        });
    }

    handleResizeEnd() {
        this.setState({
            resizeColumnId: null,
        });
    }

    render() {
        const {
            sort,
            rowsCount,
            columnCount,
            isResizingEnabled,
            isLivePreview,
            columnWidths,
            resizeColumnId,
        } = this.state;

        const columns = _.map(this.getColumns(columnCount), (column) => {
            const colInfo = {};

            // simulate how a consumer might update the default width with
            // a persisted value and/or the resized one
            // TBD: static colInfo prop
            if (columnWidths[column.id]) {
                colInfo.width = columnWidths[column.id];
            }

            // simulate how a consumer might add a hook to grid-cells for styling
            // a resized column
            // TBD: internalize this into ReactGrid
            if (column.id === resizeColumnId) {
                colInfo.classes = 'is-resizing';
            }

            // treat columns as statically declared, so never directly modify the
            // original. Ideally this will go away when the grid supports passing-in
            // column overrides in the form of a colInfo (and rowInfo) hash
            return _.isEmpty(colInfo) ? column : _.defaults(colInfo, column);
        });

        // the component has defaults for different UAs - this is simply for
        // demo purposes
        const resizeMode = isLivePreview ?
            resizableColumnConstants.LIVE_PREVIEW :
            resizableColumnConstants.SNAP_PREVIEW;

        return (
            <div className="grid grid--y grid--fit-fill tst-colresizeexample">
                <div className="grid-cell toolbar">
                    <div className="grid grid--series grid--fit-all">
                        <div className="grid-cell">
                            Rows count:
                        </div>
                        <div className="grid-cell">
                            <NumberInput
                                value={rowsCount}
                                onChange={this.handleRowsCountChange}
                            />
                        </div>
                        <div className="grid-cell">
                            Column count:
                        </div>
                        <div className="grid-cell">
                            <NumberInput
                                value={columnCount}
                                onChange={this.handleColumnsCountChange}
                            />
                        </div>
                        <div className="grid-cell">
                            <CheckBox
                                isChecked={isResizingEnabled}
                                onChange={this.handleIsResizingEnabledChange}
                            >
                                Resizing enabled
                            </CheckBox>
                        </div>
                        <div className="grid-cell">
                            <CheckBox
                                isChecked={isLivePreview}
                                onChange={this.handleIsLivePreviewChange}
                            >
                                Live Resize
                            </CheckBox>
                        </div>
                    </div>
                </div>
                <ReactGrid
                    rows={this.getRows(columnCount, rowsCount)}
                    cols={columns}
                    sort={sort}
                    resizeTimestamp={this.props.resizeTimestamp}
                    onHeaderSort={this.handleHeaderSort}
                >
                    <ResizableColumnPlugin
                        isEnabled={isResizingEnabled}
                        resizeMode={resizeMode}
                        onResize={this.handleResize}
                        onResizeStart={this.handleResizeStart}
                        onResizeEnd={this.handleResizeEnd}
                    />
                </ReactGrid>
            </div>
        );
    }
}

ResizableColumnExample.propTypes = {
    resizeTimestamp: PropTypes.number,
};

export default bindHandlers(ResizableColumnExample);
