/* eslint react/prop-types: "off" */
import React from 'react';
import PropTypes from 'prop-types';
import ReactGrid from '../reactGrid';
import _ from 'lodash';
import Header from 'src/components/reactGrid/blocks/defaultHeaderRenderer';
import InstrumentHeader from 'src/components/reactGrid/blocks/instrumentHeader';
import InstrumentRenderer from 'src/components/reactGrid/blocks/instrumentRenderer';
import * as instrumentsQueries from 'src/modules/instruments/queries';
import * as assetTypeQueries from 'src/modules/instruments/assetType/queries';
import { bindHandlers } from 'src/utils/bindHandlers';

const getInstrumentName = ({ rowData }) => {
    const { instrument } = rowData;
    return instrumentsQueries.getName(instrument);
};

const createRow = (index, assetType, rows = null, isChild = false, template = null) => {
    const key = String(index);
    const info = (isChild ? 'Child ' : '');
    return {
        id: key,
        data: {
            instrument: {
                AssetType: assetType,
                Description: 'Instrument Description ' + info + key,
                isTradable: true,
                Symbol: 'Symbol ' + info + key,
                Uic: index,
                id: 'instrument_' + key,
            },
            order: {
                price: _.random(1, 100),
            },
            isGroup: Boolean(rows && rows.length > 0),
            rows,
        },
        template,
        isCustom: (template !== null),
    };
};

const createRows = () => [
    createRow(2, 'FxSpot',
        [
            createRow(3, 'FxSpot', null, true, 'Loading children...'),
        ]
    ),
    createRow(2, 'FxSpot',
        [
            createRow(3, 'FxSpot', null, true, 'No children available...'),
        ]
    ),
];

const getSingleColumns = () =>
    [
        {
            id: 'instrument',
            priority: 1,
            minWidth: 100,
            maxWidth: Number.MAX_VALUE,
            align: 'start',
            header: InstrumentHeader,
            template: ({ rowData }) => <InstrumentRenderer {...rowData}/>,
            sort: { id: 'instrument' },
            itemToLabel: getInstrumentName,
            isFixedStart: true,
        },
        {
            id: 'price',
            minWidth: 100,
            maxWidth: Number.MAX_VALUE,
            primaryTitle: 'Price',
            align: 'start',
            header: Header,
            sort: { id: 'price' },
            itemToLabel: ({ rowData }) => rowData.order.price,
        },
    ];

const grouping = [{
    groupingFunction: (row) => assetTypeQueries.getAssetTypeName(row.data.instrument),
    groupingObjectFunction: (name, rows, level) => {
        const rowCount = _.size(rows);
        return {
            sectionHeader: `${name} (${rowCount})`,
            rows,
            rowCount,
            level,
        };
    },
}];

class CustomGroupExample extends React.PureComponent {

    constructor(props) {
        super(props);

        this.state = {
            sort: null,
            rows: createRows(),
            columns: getSingleColumns(),
            expandedGroups: {},
        };
    }

    handleSectionExpand(evt, { rowId, isExpanded }) {
        const { expandedGroups } = this.state;
        expandedGroups[rowId] = !isExpanded;

        window.expandedGroups = expandedGroups;

        this.setState({
            expandedGroups: _.clone(expandedGroups),
        });
    }

    handleHeaderSort(sort) {
        this.setState({
            sort,
        });
    }

    render() {
        const {
            sort,
            expandedGroups,
            rows,
            columns,
        } = this.state;

        return (
            <ReactGrid
                rows={rows}
                cols={columns}
                sort={sort}
                isSectioned
                isGrouping
                grouping={grouping}
                expandedGroups={expandedGroups}
                keepGroupsExpanded
                resizeTimestamp={this.props.resizeTimestamp}
                onHeaderSort={this.handleHeaderSort}
                onSectionExpand={this.handleSectionExpand}
                onRowExpand={this.handleSectionExpand}/>
        );
    }
}

CustomGroupExample.propTypes = {
    resizeTimestamp: PropTypes.number,
};

export default bindHandlers(CustomGroupExample);
