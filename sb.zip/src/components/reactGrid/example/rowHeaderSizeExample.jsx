import PropTypes from 'prop-types';
import React from 'react';
import _ from 'lodash';
import ReactGrid from '../reactGrid';
import DataGenerator from './dataGenerator';
import { bindHandlers } from 'src/utils/bindHandlers';
import Enums from 'src/spine/enums';
import Dropdown from 'src/components/dropdown/dropdown';
import DropdownItem from 'src/components/dropdown/dropdownItem';
import * as gridQueries from 'src/components/reactGrid/queries';

class RowHeaderSizeExample extends React.PureComponent {

    constructor(props) {
        super(props);

        this.state = {
            sort: null,
            headerDisplayMode: Enums.RowDisplayMode.Single,
            rowDisplayMode: Enums.RowDisplayMode.Single,
        };
    }

    handleHeaderDisplayChange(value) {
        this.setState({
            headerDisplayMode: value,
        });
    }

    handleRowDisplayChange(value) {
        this.setState({
            rowDisplayMode: value,
        });
    }

    handleGetPropertyValue(propertyName, rowId) {
        if (propertyName === 'property0') {
            return 'Instrument' + rowId;
        }

        if (propertyName === 'property1') {
            return 'Currency' + _.random(1, 5);
        }
    }

    handleHeaderSort(sort) {
        this.setState({
            sort,
        });
    }

    render() {
        const {
            sort,
            headerDisplayMode,
            rowDisplayMode,
        } = this.state;

        return (
            <div className="grid grid--y grid--fit-fill">
                <div className="grid-cell toolbar g--fit">
                    <div className="grid--x grid grid--series">
                        <div className="grid-cell g--fit">
                            Header Display Mode:
                        </div>
                        <div className="grid-cell g--fit">
                            <Dropdown
                                value={headerDisplayMode}
                                onChange={this.handleHeaderDisplayChange}
                            >
                                <DropdownItem value={Enums.RowDisplayMode.Single}>Single</DropdownItem>
                                <DropdownItem value={Enums.RowDisplayMode.Double}>Double</DropdownItem>
                            </Dropdown>
                        </div>
                        <div className="grid-cell g--fit">
                            Row Display Mode:
                        </div>
                        <div className="grid-cell g--fit">
                            <Dropdown
                                value={rowDisplayMode}
                                onChange={this.handleRowDisplayChange}
                            >
                                <DropdownItem value={Enums.RowDisplayMode.Single}>Single</DropdownItem>
                                <DropdownItem value={Enums.RowDisplayMode.Double}>Double</DropdownItem>
                            </Dropdown>
                        </div>
                    </div>
                </div>
                <DataGenerator
                    staticProperties={['property0', 'property1']}
                    columnsCount={10}
                    rowsCount={50}
                    updateInterval={-1}
                    onGetPropertyValue={this.handleGetPropertyValue}
                    sortableColumns
                >
                    {
                        ({ rows, cols }) =>
                            (<ReactGrid
                                rows={rows}
                                cols={cols}
                                sort={sort}
                                headerHeight={gridQueries.getHeaderHeight(headerDisplayMode)}
                                headerLineHeight={gridQueries.getHeaderLineHeight(headerDisplayMode)}
                                rowHeight={gridQueries.getRowHeight(rowDisplayMode)}
                                rowLineHeight={gridQueries.getRowLineHeight(rowDisplayMode)}
                                resizeTimestamp={this.props.resizeTimestamp}
                                onHeaderSort={this.handleHeaderSort}
                            />)
                    }
                </DataGenerator>
            </div>
        );
    }
}

RowHeaderSizeExample.propTypes = {
    resizeTimestamp: PropTypes.number,
    action: PropTypes.func,
};

export default bindHandlers(RowHeaderSizeExample);

