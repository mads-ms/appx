import React from 'react';
import { examplesOf } from 'src/modules/examples/utils';
import GroupingExample from './groupingExample';
import PerfExample from './perfExample';
import PerfScrollExample from './perfScrollExample';
import ResizableColumnExample from './resizableColumnExample';
import DragExample from './rowReorderExample';
import ColumnPickerHeader from './columnPickerHeaderExample';
import ContextMenuPluginExample from './contextMenuPluginExample';
import AstroStyle from './astroStyleExample';
import RowHeaderSize from './rowHeaderSizeExample';
import CustomGroup from './customGroupExample';
import RowLinking from './rowLinkingExample';

export default examplesOf('ReactGrid', 'react-grid')
    .add('Grouping', ({ resizeTimestamp }) => (
        <GroupingExample resizeTimestamp={resizeTimestamp}/>
    ), 'grouping')
    .add('Perf', ({ resizeTimestamp, target }) => (
        <PerfExample resizeTimestamp={resizeTimestamp} target={target}/>
    ), 'perf')
    .add('Perf scroll', ({ resizeTimestamp, target }) => (
        <PerfScrollExample resizeTimestamp={resizeTimestamp} target={target}/>
    ), 'perf-scroll')
    .add('Column Resizing', ({ resizeTimestamp }) => (
        <ResizableColumnExample resizeTimestamp={resizeTimestamp}/>
    ), 'col-resize')
    .add('Row reorder', ({ resizeTimestamp, action }) => (
        <DragExample resizeTimestamp={resizeTimestamp} action={action}/>
    ), 'reorder')
    .add('Context Menu plugin', ({ resizeTimestamp }) => (
        <ContextMenuPluginExample resizeTimestamp={resizeTimestamp}/>
    ), 'context-menu')
    .add('Column picker header', ({ resizeTimestamp, action }) => (
        <ColumnPickerHeader resizeTimestamp={resizeTimestamp} action={action}/>
    ), 'column-picker-header')
    .add('Row / Header height', ({ resizeTimestamp, action }) => (
        <RowHeaderSize resizeTimestamp={resizeTimestamp} action={action}/>
    ), 'row-header-height')
    .add('Row linking', ({ resizeTimestamp, action }) => (
        <RowLinking resizeTimestamp={resizeTimestamp} action={action}/>
    ), 'row-linking')
    .add('Custom group content', ({ resizeTimestamp }) => (
        <CustomGroup resizeTimestamp={resizeTimestamp}/>
    ), 'custom-group')
    .add('Astro Style 🚀', ({ resizeTimestamp, action }) => (
        <AstroStyle resizeTimestamp={resizeTimestamp} action={action}/>
    ), 'astro-style');
