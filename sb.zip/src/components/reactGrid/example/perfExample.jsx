import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import ReactGrid from '../reactGrid';
import DataGenerator from './dataGenerator';
import { bindHandlers } from 'src/utils/bindHandlers';
import NumberInput from 'src/components/proComboInput/numberInput';
import Toolbar from 'src/modules/examples/example/toolbar';
import PerfMeasure from 'src/modules/examples/perf/perfMeasure';

class PerfExample extends React.PureComponent {

    constructor(props) {
        super(props);

        this.state = {
            sort: null,
            rowsCount: 20,
            columnCount: 5,
            updateInterval: 250,
            updateRowsRatio: 0.5,
            updatePropertyRatio: 0.5,
        };
    }

    handleGetPropertyValue(propertyName, rowId) {
        if (propertyName === 'property0') {
            return 'Instrument' + rowId;
        }

        if (propertyName === 'property1') {
            return 'Currency' + _.random(1, 5);
        }
    }

    handleIntervalChange({ value }) {
        this.setState({
            updateInterval: value,
        });
    }

    handleRowsRatioChange({ value }) {
        this.setState({
            updateRowsRatio: value,
        });
    }

    handlePropRatioChange({ value }) {
        this.setState({
            updatePropertyRatio: value,
        });
    }

    handleRowsCountChange({ value }) {
        this.setState({
            rowsCount: value,
        });
    }

    handleColumnsCountChange({ value }) {
        this.setState({
            columnCount: value,
        });
    }

    handleHeaderSort(sort) {
        this.setState({
            sort,
        });
    }

    render() {
        const {
            sort,
            updateInterval,
            updateRowsRatio,
            updatePropertyRatio,
            rowsCount,
            columnCount,
        } = this.state;

        const { target } = this.props;

        return (
            <div className="grid grid--y grid--fit-fill">
                <div className="grid-cell g--fit">
                    <Toolbar target={target}>
                        Update interval:
                        <NumberInput
                            value={updateInterval}
                            onChange={this.handleIntervalChange}
                        />
                        Update row ratio:
                        <NumberInput
                            value={updateRowsRatio}
                            onChange={this.handleRowsRatioChange}
                        />
                        Update properties ratio:
                        <NumberInput
                            value={updatePropertyRatio}
                            onChange={this.handlePropRatioChange}
                        />
                        Rows count:
                        <NumberInput
                            value={rowsCount}
                            onChange={this.handleRowsCountChange}
                        />
                        Column count:
                        <NumberInput
                            value={columnCount}
                            onChange={this.handleColumnsCountChange}
                        />
                    </Toolbar>
                </div>
                <DataGenerator
                    staticProperties={['property0', 'property1']}
                    updatePropertyRatio={updatePropertyRatio}
                    columnsCount={columnCount}
                    rowsCount={rowsCount}
                    updateInterval={updateInterval}
                    updateRowsRatio={updateRowsRatio}
                    onGetPropertyValue={this.handleGetPropertyValue}
                    sortableColumns
                >
                    {
                        ({ rows, cols }) =>
                            (
                                <PerfMeasure target={target}>
                                    <ReactGrid
                                        rows={rows}
                                        cols={cols}
                                        sort={sort}
                                        resizeTimestamp={this.props.resizeTimestamp}
                                        onHeaderSort={this.handleHeaderSort}
                                    />
                                </PerfMeasure>
                            )
                    }
                </DataGenerator>
            </div>
        );
    }
}

PerfExample.propTypes = {
    resizeTimestamp: PropTypes.number,
    target: PropTypes.string,
};

export default bindHandlers(PerfExample);
