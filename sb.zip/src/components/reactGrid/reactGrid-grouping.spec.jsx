/**
 * <ReactGrid/> grouping of rows unit tests
 */
import $ from 'jqueryAll';
import React from 'react';
import ReactGrid from 'src/components/reactGrid/reactGrid';
import { createCols } from './reactGridSpecHelper';
import { mount } from 'enzyme';
import ExpandButton from 'src/components/reactGrid/blocks/expandButton';

describe('src/components/reactGrid', () => {

    // assertion state
    let cols;
    let rows;
    let wrapper;

    // controlled state setup before each test
    let defaultProps;

    beforeEach(() => {
        cols = [];
        rows = [];

        defaultProps = {
            isHeader: false,
            width: 501,
            height: 100,
            rowHeight: 20,
            headerHeight: 30,
        };
    });

    afterEach(() => {
        wrapper.unmount();
    });

    describe('grouping', () => {

        it('should render a [2x1] datagrid in correct row order using objects', () => {
            const rowDescriptor = [{ id: '1' }, { id: '2' }];
            const colDescriptor = createCols(['foo']);

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}

                    // capture internal state reporting
                    onColReflow={(evt) => {
                        cols = evt;
                    }}
                    onRowReflow={(evt) => {
                        rows = evt;
                    }}

                    {...defaultProps}
                />
            );

            expect(cols.length).toEqual(1);
            expect(cols).toEqual(['foo']);
            expect(rows.length).toEqual(2);
            expect(rows).toEqual(['1', '2']);

            // assert rendering
            expect(wrapper.find('.reactgrid-row').length).toEqual(2);
            expect(wrapper.find('.reactgrid-cell').length).toEqual(2);
            expect(wrapper.find('.reactgrid-header').length).toEqual(0);

        });

        it('should render a [3x1] hierarchical datagrid in correct row order', () => {
            const rowDescriptor = [
                { id: '1', isExpanded: true, rows: [{ id: '1_1' }] },
                { id: '2', isExpanded: false, rows: [{ id: '2_1' }] },
            ];
            const colDescriptor = createCols(['foo']);

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}
                    isGrouping

                    // capture internal state reporting
                    onColReflow={(evt) => {
                        cols = evt;
                    }}
                    onRowReflow={(evt) => {
                        rows = evt;
                    }}

                    {...defaultProps}
                />
            );

            expect(cols.length).toEqual(2);
            expect(cols).toEqual(['expand', 'foo']);
            expect(rows.length).toEqual(3);
            expect(rows).toEqual(['1', '1_1', '2']);

            // assert rendering
            expect(wrapper.find('.reactgrid-row').length).toEqual(3);
            expect(wrapper.find('.reactgrid-cell').length).toEqual(6);
            expect(wrapper.find('.reactgrid-header').length).toEqual(0);
        });

        it('should render rows with different heights', () => {
            const rowDescriptor = [
                { id: '1', isExpanded: true, height: 20, template: () => 'group1', rows: [{ id: '1_1', height: 40 }] },
                { id: '2', isExpanded: false, height: 20, template: () => 'group2', rows: [{ id: '2_1', height: 40 }] },
            ];
            const colDescriptor = createCols(['foo']);

            delete defaultProps.rowHeight;

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}
                    isGrouping

                    // capture internal state reporting
                    onColReflow={(evt) => {
                        cols = evt;
                    }}
                    onRowReflow={(evt) => {
                        rows = evt;
                    }}

                    {...defaultProps}
                />
            );

            const rowNodes = wrapper.find('.reactgrid-row');

            expect($(rowNodes.at(0).getDOMNode()).height()).toEqual(20);
            expect($(rowNodes.at(1).getDOMNode()).height()).toEqual(40);
        });

        it('should render rows with text content', () => {
            const rowDescriptor = [
                { id: '1', isExpanded: true, template: () => 'group1', rows: [{ id: '1_1' }] },
                { id: '2', isExpanded: false, template: () => 'group2', rows: [{ id: '2_1' }] },
            ];
            const colDescriptor = createCols(['foo']);

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}
                    isGrouping

                    // capture internal state reporting
                    onColReflow={(evt) => {
                        cols = evt;
                    }}
                    onRowReflow={(evt) => {
                        rows = evt;
                    }}

                    {...defaultProps}
                />
            );

            expect(cols.length).toEqual(2);
            expect(cols).toEqual(['expand', 'foo']);
            expect(rows.length).toEqual(3);
            expect(rows).toEqual(['1', '1_1', '2']);

            const contentNodes = wrapper.find('.reactgrid-row-content');
            expect(contentNodes.length).toEqual(2);
            expect($(contentNodes.at(0).getDOMNode()).text()).toEqual('group1');
            expect($(contentNodes.at(1).getDOMNode()).text()).toEqual('group2');
        });

        it('should render rows and skip excluded parent', () => {
            const rowDescriptor = [
                {
                    id: '1',
                    isGroup: true,
                    isRootExcluded: true,
                    isExpanded: true,
                    template: () => 'group1',
                    rows: [{ id: '1_1', template: () => 'child1_1' }],
                },
                {
                    id: '2',
                    isExpanded: true,
                    template: () => 'group2',
                    rows: [{ id: '2_1', template: () => 'child2_1' }],
                },
            ];

            const colDescriptor = createCols(['foo']);

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}
                    isSectioned

                    // capture internal state reporting
                    onColReflow={(evt) => {
                        cols = evt;
                    }}
                    onRowReflow={(evt) => {
                        rows = evt;
                    }}

                    {...defaultProps}
                />
            );

            expect(rows.length).toEqual(3);
            expect(rows).toEqual(['1_1', '2', '2_1']);

            const contentNodes = wrapper.find('.reactgrid-row-content');
            expect(contentNodes.length).toEqual(3);

            expect(contentNodes.at(0).text()).toEqual('child1_1');
            expect(contentNodes.at(1).text()).toEqual('group2');
            expect(contentNodes.at(2).text()).toEqual('child2_1');

        });

        describe('Grouping and sorting', () => {

            let rowDescriptor;
            let colDescriptor;

            beforeEach(() => {
                colDescriptor = createCols(
                    ['foo'],
                    {
                        foo: { sort: { id: 'a', fields: 'data.propA' } },
                    }
                );
            });

            it('should sort group children', () => {

                rowDescriptor = [
                    {
                        id: '1',
                        data: { id: '1', propA: 10 },
                        rows: [
                            { id: '2', data: { propA: 20 } },
                            { id: '3', data: { propA: 10 } },
                        ],
                    },
                    {
                        id: '4',
                        data: { id: '4', propA: 5 },
                    },
                ];

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        keepGroupsExpanded
                        sort={{ id: 'a' }}

                        // capture internal state reporting
                        onColReflow={(evt) => {
                            cols = evt;
                        }}
                        onRowReflow={(evt) => {
                            rows = evt;
                        }}

                        {...defaultProps}
                    />
                );

                expect(cols.length).toEqual(1);
                expect(cols).toEqual(['foo']);

                expect(rows.length).toEqual(4);

                expect(rows[0]).toEqual('4');
                expect(rows[1]).toEqual('1');
                expect(rows[2]).toEqual('3');
                expect(rows[3]).toEqual('2');
            });

            it('should sort group children when parent excluded', () => {

                rowDescriptor = [
                    {
                        id: '1',
                        data: { id: '1', propA: 10 },
                        rows: [
                            { id: '2', data: { propA: 20 } },
                            { id: '3', data: { propA: 10 } },
                        ],
                        isRootExcluded: true,
                    },
                    {
                        id: '4',
                        data: { id: '4', propA: 5 },
                    },
                ];

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        keepGroupsExpanded
                        sort={{ id: 'a' }}

                        // capture internal state reporting
                        onColReflow={(evt) => {
                            cols = evt;
                        }}
                        onRowReflow={(evt) => {
                            rows = evt;
                        }}

                        {...defaultProps}
                    />
                );

                expect(cols.length).toEqual(1);
                expect(cols).toEqual(['foo']);

                expect(rows.length).toEqual(3);

                expect(rows[0]).toEqual('4');
                expect(rows[1]).toEqual('3');
                expect(rows[2]).toEqual('2');
            });

            it('should skip sorting for not sortable children groups', () => {

                rowDescriptor = [
                    {
                        id: '1',
                        data: { id: '1', propA: 10 },
                        rows: [
                            { id: '2', data: { propA: 20 } },
                            { id: '3', data: { propA: 10 } },
                        ],
                        isNotSortable: true,
                    },
                    {
                        id: '4',
                        data: { id: '4', propA: 5 },
                    },
                ];

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        keepGroupsExpanded
                        sort={{ id: 'a' }}

                        // capture internal state reporting
                        onColReflow={(evt) => {
                            cols = evt;
                        }}
                        onRowReflow={(evt) => {
                            rows = evt;
                        }}

                        {...defaultProps}
                    />
                );

                expect(cols.length).toEqual(1);
                expect(cols).toEqual(['foo']);

                expect(rows.length).toEqual(4);

                expect(rows[0]).toEqual('4');
                expect(rows[1]).toEqual('1');
                expect(rows[2]).toEqual('2');
                expect(rows[3]).toEqual('3');

            });

            it('should skip sorting for not sortable children groups when parent excluded', () => {

                rowDescriptor = [
                    {
                        id: '1',
                        data: { id: '1', propA: 10 },
                        rows: [
                            { id: '2', data: { propA: 20 } },
                            { id: '3', data: { propA: 10 } },
                        ],
                        isNotSortable: true,
                        isRootExcluded: true,
                    },
                    {
                        id: '4',
                        data: { id: '4', propA: 5 },
                    },
                ];

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        keepGroupsExpanded
                        sort={{ id: 'a' }}

                        // capture internal state reporting
                        onColReflow={(evt) => {
                            cols = evt;
                        }}
                        onRowReflow={(evt) => {
                            rows = evt;
                        }}

                        {...defaultProps}
                    />
                );

                expect(cols.length).toEqual(1);
                expect(cols).toEqual(['foo']);

                expect(rows.length).toEqual(3);

                expect(rows[0]).toEqual('4');
                expect(rows[1]).toEqual('2');
                expect(rows[2]).toEqual('3');
            });
        });

        describe('Expand button', () => {

            it('should correctly show expand button', () => {
                const rowDescriptor = [
                    { id: '1', isExpanded: true, rows: [{ id: '1_1' }] },
                    { id: '2', isExpanded: false, rows: [{ id: '2_1' }] },
                ];
                const colDescriptor = createCols(['foo']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isGrouping
                        {...defaultProps}
                    />
                );

                expect(wrapper.find('.reactgrid-row').find(ExpandButton).length).toEqual(3);
            });

            it('should correctly show expand button with fixed columns', () => {
                const rowDescriptor = [
                    { id: '1', isExpanded: true, rows: [{ id: '1_1' }] },
                    { id: '2', isExpanded: false, rows: [{ id: '2_1' }] },
                ];
                const colDescriptor = createCols(['foo']);
                colDescriptor[0].isFixedStart = true;

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isGrouping
                        {...defaultProps}
                    />
                );

                expect(
                    wrapper.find('.reactgrid-row')
                        .first()
                        .childAt(0)
                        .find(ExpandButton).length
                ).toEqual(1);
            });

            it('should correctly hide and show expand buttons again', () => {
                const rowDescriptor = [
                    { id: '1', isExpanded: true, rows: [{ id: '1_1' }] },
                    { id: '2', isExpanded: false, rows: [{ id: '2_1' }] },
                ];
                const colDescriptor = createCols(['foo']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        {...defaultProps}
                    />
                );

                expect(wrapper.find('.reactgrid-row').find(ExpandButton).length).toEqual(0);

                wrapper.setProps({ isGrouping: true });
                wrapper.update();

                expect(wrapper.find('.reactgrid-row').find(ExpandButton).length).toEqual(3);
            });
        });

        describe('Custom divider', () => {

            it('should render rows with custom divider', () => {
                const rowDescriptor = [
                    {
                        id: '1',
                        isExpanded: true,
                        template: () => 'group1',
                        rows: [{
                            id: '1_1',
                            template: () => 'child1_1',
                            isCustom: true,
                        }],
                    },
                ];

                const colDescriptor = createCols(['foo'], {
                    'foo': {
                        template: () => (<div>Cell content</div>),
                    },
                });

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isGrouping

                        {...defaultProps}
                    />
                );

                function assertions() {
                    const childRow = wrapper.find('.reactgrid-row').at(1);

                    expect(childRow.find('.reactgrid-cell').length).toEqual(0);
                }

                assertions();
            });

            it('should render custom divider without left offset', () => {
                const rowDescriptor = [
                    {
                        id: '1',
                        isExpanded: true,
                        template: () => 'group1',
                        rows: [{
                            id: '1_1',
                            template: () => 'child1_1',
                            isCustom: true,
                        }],
                    },
                ];

                const colDescriptor = createCols(['foo'], {
                    'foo': {
                        template: () => (<div>Cell content</div>),
                        width: 100,
                        isFixedStart: true,
                    },
                });

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isGrouping

                        {...defaultProps}
                    />
                );

                const childRow = wrapper.find('.reactgrid-row-content').at(1);

                expect(childRow.prop('style').left).toEqual(0);
            });

        });
    });
});
