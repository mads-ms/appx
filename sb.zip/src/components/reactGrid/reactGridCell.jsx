import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';

const REACTGRID_CELL_CLASS = 'reactgrid-cell';
const TST_CELL_ITEM_CLASS = 'tst-grid-col-item';

class ReactGridCell extends React.PureComponent {
    render() {
        const { styles } = this.props.column;

        const classes = classNames(
            REACTGRID_CELL_CLASS,
            TST_CELL_ITEM_CLASS,
            this.props.cellClass,
            this.props.column.classes
        );

        return (
            <div
                className={classes}
                style={styles}
            >
                {this.props.children}
            </div>
        );
    }
}

ReactGridCell.propTypes = {
    column: PropTypes.object.isRequired,
    cellClass: PropTypes.string,
};

export default ReactGridCell;
