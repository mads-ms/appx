import _ from 'lodash';
import * as sortUtils from './reactGridSortUtils';

/**
 * Normalize grouping definition
 * @param {Object} config - grouping definition
 * @returns {*} grouping to group by
 */
export const getGrouping = (config) => {
    if (_.isString(config)) {
        return [{ path: config }];
    }

    if (_.isArray(config)) {
        return _.map(config, (field) => {
            if (_.isObject(field) && field.sort) {
                const sort = sortUtils.getSort(field);
                return _.defaults({ sort }, field);
            }

            if (_.isString(field)) {
                return { path: field };
            }

            return field;
        });
    }

    return null;
};

/**
 * Check if rows should be grouped
 * @param {Boolean} isGrouping - flag from grid
 * @param {Object} grouping - grouping configuration
 * @returns {Boolean} true if rows should be grouped
 */
export const getIsGroupingSupported = (isGrouping, grouping) => isGrouping && !_.isEmpty(grouping);

/**
 * Check if groups should be expanded
 * @param groupName - group name
 * @param openGroups - open groups state
 * @param shouldExpandGroup - should we expand groups by default
 * @returns true if groups should be expanded
 */
export const getIsGroupExpanded = (groupName, openGroups, shouldExpandGroup = false) =>
    _.get(openGroups, groupName, shouldExpandGroup);

/**
 * Get grouping key for row
 * @param row - row to be grouped
 * @param groupingField - grouping field config
 * @returns {String} - grouping key for row
 */
export const defaultGroupingFunction = (row, groupingField) => String(_.get(row, groupingField.path));

/**
 * Creates grouping object containing group pros and children rows
 * @param {String} name - name fo the group
 * @param {Array<Object>} rows - group child rows
 * @param {Number} level - grouping level
 * @return {Object} - grouping object
 */
export const defaultGroupingObjectFunction = (name, rows, level) => ({
    id: name,
    sectionHeader: name,
    rows,
    level,
});

/**
 * Creates grouping object containing group pros and children rows, rows count included in header
 * @param {String} name - name fo the group
 * @param {Array<Object>} rows - group child rows
 * @param {Number} level - grouping level
 * @return {Object} - grouping object
 */
export const groupingCountObjectFunction = (name, rows, level) => {
    const groupingObject = defaultGroupingObjectFunction(name, rows, level);
    groupingObject.sectionHeader = name + ' (' + _.size(rows) + ')';
    return groupingObject;
};

export const replaceGroup = (data, items, replaceIndex) => _.concat(data.slice(0, replaceIndex), items, data.slice(replaceIndex + 1));

/**
 * @param {Object} grouping - grouping definition
 * @param {Array<Object>} groupsIndex - array of groups
 */
export const updateAndSortGroups = (grouping, groupsIndex) => {
    _.forEach(groupsIndex, (groupRow) => {
        const currentGroupingField = grouping[groupRow.level];

        if (currentGroupingField) {
            // update group properties
            const groupingObjectFunction = currentGroupingField.groupingObjectFunction || defaultGroupingObjectFunction;

            _.assign(groupRow, groupingObjectFunction(groupRow.id, groupRow.rows, groupRow.level));
        }

        // sort grouped rows
        const nextGroupingField = grouping[groupRow.level + 1];
        if (nextGroupingField && nextGroupingField.sort) {
            sortUtils.sort(groupRow.rows, nextGroupingField.sort, sortUtils.DEFAULT_SORT_DIRECTION);
        }
    });
};

/**
 * Grouping function for grid rows
 * @param {Array<Object>} rows - rows to be grouped
 * @param {Object} grouping - grouping configuration
 * @param {Object} expandedGroups - expanded groups state
 * @param {Object} keepGroupsExpanded - flag to open groups by default
 * @returns {Array} - Array of grouped rows
 */
export const group = (rows, grouping, expandedGroups = {}, keepGroupsExpanded = false) => {

    const groupingSize = _.size(grouping);
    const root = { rows: [], level: -1 };
    const parentLookup = { root };
    const groupsIndex = [root];

    _.forEach(rows, (row) => {

        // normalize row
        row = _.isObject(row) ? row : { id: row };

        let path = 'root';
        let parent = root;
        let children = root.rows;
        let parentPath;

        // perform rows grouping
        _.forEach(grouping, (groupingField, level) => {
            const groupingFunction = groupingField.groupingFunction || defaultGroupingFunction;
            const groupName = groupingFunction(row, groupingField, level);

            // update insert localization
            parentPath = path;
            path += groupName;
            parent = parentLookup[path];

            if (!parent) {
                const shouldExpandGroup = keepGroupsExpanded || groupingField.isExpanded;
                const isExpanded = getIsGroupExpanded(groupName, expandedGroups, shouldExpandGroup);

                // create group object
                parent = {
                    id: groupName,
                    parent: parentPath,
                    [groupingField.path]: groupName,
                    isExpanded,
                    level,
                    rows: [],
                    isSectioned: _.isNil(groupingField.isSectioned) ? true : groupingField.isSectioned,
                    isRootExcluded: groupingField.isRootExcluded,
                    template: groupingField.template,
                    sectionColumns: groupingField.sectionColumns,
                    isStatic: groupingField.isStatic,
                    isGroup: true,
                };

                groupsIndex.push(parent);
                parentLookup[path] = parent;
                children.push(parent);
            }

            // update children we should insert into
            children = parent.rows;

            if (level === groupingSize - 1) {
                children.push(row);
            }
        });

    });

    // perform groups update
    updateAndSortGroups(grouping, groupsIndex);

    return root.rows;
};

/**
 * Temporary solution to check if given batch of rows is a group.
 * Required to skip second sorting of groups in getRowOffsets.
 * @param {Array} rows - List of rows.
 */
export const isRowsGroup = (rows) => {
    const first = _.head(rows);
    if (!first) {
        return false;
    }

    if (first.isSectioned) {
        return true;
    }

    return first.isGroup && !first.isRootExcluded;
};
