import _ from 'lodash';

// Sort in asc direction by default
export const DEFAULT_SORT_DIRECTION = 1;

/**
 * Migrate old sort properties to new one
 * @param {Object} gridSort - legacy sort config
 * @return {Object} sort definition
 */
export const getNormalizedSort = (gridSort) => {
    if (_.isNil(gridSort) || _.isEmpty(gridSort)) {
        return null;
    }

    let { id, direction } = gridSort;

    if (_.has(gridSort, 'sortKey')) {
        id = gridSort.sortKey;
    }

    if (_.has(gridSort, 'isHighLow')) {
        direction = gridSort.isHighLow ? -1 : 1;
    }

    return {
        id,
        direction: direction || DEFAULT_SORT_DIRECTION,
    };
};

/**
 * Normalize sort definition
 * @param {Object} config - sort definition
 * @returns {*} sort to sort on
 */
export const getSort = (config) => {

    if (!(config && config.sort)) {
        return null;
    }

    const sort = config.sort;

    if (_.isString(sort.fields)) {
        return _.defaults({
            fields: [{ path: sort.fields }],
        }, sort);
    }

    if (_.isArray(sort.fields)) {
        const fields = _.map(sort.fields, (field) => {
            if (_.isString(field)) {
                return { path: field };
            }
            return field;
        });

        return _.defaults({
            fields,
        }, sort);
    }

    return sort;
};

/**
 * Calculate next sort direction basing on current sort direction
 * Flow should be 1 -> -1 -> 0 -> 1
 * @param {Number} direction - current direction
 * @param {Number} mode - sort mode
 * @returns {Number} next direction
 */
export const getNextSortDirection = (direction, mode = 0) => {
    if (mode === 0) {
        return direction * -1;
    }

    if (direction === 0) {
        return 1;
    }

    if (direction === -1) {
        return 0;
    }

    return -1;
};

/**
 * Get next sort based on existing values from sort and column.
 * @param {Object} sort - existing sort object
 * @param {Object} col - column definition
 * @return {{id, direction: *}} - Next sort object
 */
export const getNextSort = (sort, col) => {
    const { id, direction, mode } = sort || {};
    const nextSortId = col.sort.id;

    let nextDirection;

    if (id === nextSortId) {
        nextDirection = getNextSortDirection(direction, mode);
    } else {
        nextDirection = DEFAULT_SORT_DIRECTION;
    }

    return {
        id: nextSortId,
        direction: nextDirection,
    };
};

/**
 * Find column to sort on
 * @param {Object} gridSort - grid sort
 * @param {Array<Object>} columns - possible columns
 * @returns {null} column matching grid sort id
 */
export const getSortedColumn = (gridSort, columns) => {
    if (!gridSort) {
        return null;
    }
    return _.find(columns, { sort: { id: gridSort.id } });
};

/**
 * Check if column is sortable
 * @param {Object} column - grid column
 * @returns {Boolean} - true if column has sort
 */
export const getIsColumnSortable = (column) => Boolean(column && column.sort);

/**
 * @param {Object} column
 * @param {Object} gridSort
 * @return {*} - current sort data value
 */
export const getColumnSortDataValue = (column, gridSort) => {
    if (!getIsColumnSortable(column) || !gridSort || column.sort.id !== gridSort.id || gridSort.direction === 0) {
        return '-';
    }

    if (gridSort.direction === -1) {
        return 'low';
    }

    return 'high';
};

/**
 * Check if we should sort data basing on column and grid sort
 * @param {Object} gridSort - grid sort
 * @param {Object} sortedColumn - column to sort by
 * @returns {boolean} - true if sort should be applied
 */
export const getIsSortSupported = (gridSort, sortedColumn) => {
    const isColumnSortable = getIsColumnSortable(sortedColumn);

    if (!gridSort || gridSort.direction === 0) {
        return false;
    }

    if (!isColumnSortable && _.isFunction(gridSort.compareFunction)) {
        return true;
    }

    return isColumnSortable;
};

/**
 * Compares values
 * @param {Object} aValue - row to compare
 * @param {Object} bValue - row to compare
 * @returns {number} -1 0 1
 */
export const compare = (aValue, bValue) => {
    const aStringValue = _.trim(aValue);
    const bStringValue = _.trim(bValue);

    if (aStringValue === bStringValue) {
        return 0;
    }

    const aNumberValue = Number(aValue);
    const bNumberValue = Number(bValue);

    if (!isNaN(aNumberValue) && !isNaN(bNumberValue)) {
        return aNumberValue > bNumberValue ? 1 : -1;
    }

    return aValue > bValue ? 1 : -1;
};

/**
 * Default sort compare function
 * @param {Object} rowA - row to compare
 * @param {Object} rowB - row to compare
 * @param {Object} path - property to compare
 * @returns {number} Result of compare function
 */
export const defaultCompareFunction = (rowA, rowB, path) => compare(_.get(rowA, path), _.get(rowB, path));

/**
 * Sort data in place using sort definition
 * @param {Array} rows - rows to be sorted in place
 * @param {Object} config - sort definition
 * @param {Number} direction - sort direction
 */
export const sort = (rows, config, direction, column) => {

    if (config.compareFunction) {
        rows.sort((rowA, rowB) => direction * config.compareFunction(rowA, rowB, direction));
        return;
    }

    if (config.fields) {
        rows.sort((rowA, rowB) => {
            let result = 0;

            _.forEach(config.fields, (sortField) => {
                const sortFieldCompareFunction = sortField.compareFunction || defaultCompareFunction;
                const sortFieldDirection = sortField.direction || DEFAULT_SORT_DIRECTION;

                result = sortFieldCompareFunction(rowA, rowB, sortField.path) * sortFieldDirection;
                return result === 0;
            });

            return direction * result;
        });
        return;
    }

    if (column.itemToLabel) {
        rows.sort((rowA, rowB) => {

            // itemToLabel should get { rowInfo, rowData } the same like renderer but it requires refactoring
            // http://tfs:8080/tfs/DefaultCollection/TP/_workitems?id=797756
            const rowDataA = { rowData: _.get(rowA, 'data', rowA), rowInfo: { column } };
            const rowDataB = { rowData: _.get(rowB, 'data', rowB), rowInfo: { column } };
            const [primaryLabelFunction, secondaryLabelFunction] = column.itemToLabel;
            let result = compare(primaryLabelFunction(rowDataA), primaryLabelFunction(rowDataB));

            if (result === 0 && secondaryLabelFunction) {
                result = compare(secondaryLabelFunction(rowDataA), secondaryLabelFunction(rowDataB));
            }

            return direction * result;
        });
    }
};

/**
 * @param {Array<Object>} rows - rows to sort
 * @param {Object} gridSort - grid sort definition
 * @param {Object} columnSort - column sort definition
 * @return Array<Object> - sorted rows
 */
export const sortRows = (rows, gridSort, columnSort, column) => {
    // create copy of array
    const sortedRows = rows.concat();
    const gridSortDirection = gridSort.direction || DEFAULT_SORT_DIRECTION;

    if (columnSort) {
        sort(sortedRows, columnSort, gridSortDirection, column);
    } else if (gridSort.compareFunction) {
        sortedRows.sort((rowA, rowB) => gridSortDirection * gridSort.compareFunction(rowA, rowB, gridSortDirection));
    }

    return sortedRows;
};
