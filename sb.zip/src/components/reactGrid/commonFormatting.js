/**
 * Returns value for "data-profit" attribute (dataValue/betaDataValue fields)
 *  - Used by OpenCSS to colorise values based on P/L
 */
export function getChangeDataValue(val, defaultValue = '0') {
    if (val == null || val === 0) {
        return defaultValue;
    }
    return val < 0 ? '-ve' : '+ve';
}
