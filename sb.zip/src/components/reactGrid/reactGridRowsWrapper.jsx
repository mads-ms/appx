import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import ReactGridRow from './reactGridRow';

/**
 * This is basic wrapper over grid rows, To become <ReactGridRows>.
 */
class ReactGridRowsWrapper extends React.PureComponent {

    render() {
        const {
            rowsData,
            children,
            columns,
            cellClass,
            rowClass,
            isScrolling,
            canAnimateRows,
            isGrouping,
            rowStyleFunction,
            onRowTap,
            onDoubleTap,
            onRowPress,
            onSelect,
        } = this.props;

        // Use index for key to prevent unmounting node from dom
        const rows = _.map(rowsData, (row, index) => (
            <ReactGridRow
                key={index}
                columns={columns}
                className={rowClass}
                cellClass={cellClass}
                canAnimate={canAnimateRows}
                isDivider={row.rowInfo.isDivider}
                rowStyleFunction={rowStyleFunction}
                onDoubleTap={onDoubleTap}
                onSelect={onSelect}
                canUpdate={!isScrolling}
                isGrouping={isGrouping}
                onRowTap={onRowTap}
                onRowPress={onRowPress}
                {...row}
            />
        ));

        let content = rows;

        if (children) {
            content = React.cloneElement(React.Children.only(children), { rows });
        }

        return content;
    }
}

ReactGridRowsWrapper.propTypes = {
    rowsData: PropTypes.array,
    children: PropTypes.element,
    columns: PropTypes.array,
    cellClass: PropTypes.string,
    rowClass: PropTypes.string,
    isScrolling: PropTypes.bool,
    canAnimateRows: PropTypes.bool,
    isGrouping: PropTypes.bool,
    rowStyleFunction: PropTypes.func,
    onRowTap: PropTypes.func,
    onDoubleTap: PropTypes.func,
    onRowPress: PropTypes.func,
    onSelect: PropTypes.func,
};

ReactGridRowsWrapper.defaultProps = {
    onRowTap: _.noop,
    onDoubleTap: _.noop,
    onRowPress: _.noop,
    onSelect: _.noop,
};

export default ReactGridRowsWrapper;
