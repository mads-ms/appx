import PropTypes from 'prop-types';
import React from 'react';
import _ from 'lodash';
import ReactGridHeaderRows from './reactGridHeaderRows';
import { bindHandlers } from 'src/utils/bindHandlers';
import * as sortUtils from './reactGridSortUtils';

class ReactGridHeader extends React.PureComponent {

    handleHeaderSort(col) {
        const { sort } = this.props;
        this.props.onHeaderSort(sortUtils.getNextSort(sort, col));
    }

    render() {
        const {
            headerClass,
            headerHeight,
            headerLineHeight,
            cellClass,
            columns,
            visibleColumns,
            sort,
            width,
            height,
            children,
        } = this.props;

        const plugins = React.Children.toArray(children);

        const pluginProps = {
            headerHeight,
            width,
            height,
            columns,
            visibleColumns,
            sort,
        };

        let headerPlugin = null;

        _.forEach(plugins, (plugin) => {
            headerPlugin = React.cloneElement(plugin, _.defaults(
                { nextPlugin: headerPlugin },
                pluginProps
            ));
        });

        return (
            <ReactGridHeaderRows
                headerClass={headerClass}
                headerHeight={headerHeight}
                headerLineHeight={headerLineHeight}
                cellClass={cellClass}
                visibleColumns={visibleColumns}
                sort={sort}
                onHeaderSort={this.handleHeaderSort}
            >
                {headerPlugin}
            </ReactGridHeaderRows>
        );
    }
}

ReactGridHeader.propTypes = {
    headerClass: PropTypes.string,
    headerHeight: PropTypes.number.isRequired,
    height: PropTypes.number,
    headerLineHeight: PropTypes.number,
    width: PropTypes.number,
    cellClass: PropTypes.string,
    columns: PropTypes.array.isRequired,
    visibleColumns: PropTypes.array.isRequired,
    sort: PropTypes.object,
    onHeaderSort: PropTypes.func,
};

export default bindHandlers(ReactGridHeader);
