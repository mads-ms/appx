import _ from 'lodash';
import * as groupingUtils from 'src/components/reactGrid/reactGridGroupingUtils';

describe('src/components/reactGrid/reactGridGroupingUtils', () => {

    describe('getGrouping()', () => {

        it('should return grouping config', () => {
            let grouping = {};

            expect(groupingUtils.getGrouping(grouping)).toBeFalsy();

            grouping = 'a';
            expect(groupingUtils.getGrouping(grouping)).toEqual([{ path: 'a' }]);

            grouping = ['a', 'b'];
            expect(groupingUtils.getGrouping(grouping)).toEqual([{ path: 'a' }, { path: 'b' }]);

            grouping = [
                {
                    path: 'a.a',
                },
                {
                    path: 'a.b',
                },
            ];
            expect(groupingUtils.getGrouping(grouping)).toEqual(grouping);

            grouping = [{ path: 'a', sort: { fields: ['a'] } }];
            expect(groupingUtils.getGrouping(grouping)).toEqual([{
                path: 'a',
                sort: { fields: [{ path: 'a' }] },
            }]);
        });
    });

    describe('getIsGroupingSupported()', () => {

        it('should support grouping', () => {
            expect(groupingUtils.getIsGroupingSupported(true, [{ path: 'A' }])).toBe(true);
        });

        it('should not support grouping', () => {
            expect(groupingUtils.getIsGroupingSupported(true, [])).toBe(false);
            expect(groupingUtils.getIsGroupingSupported(false, [])).toBe(false);
            expect(groupingUtils.getIsGroupingSupported(true)).toBe(false);
        });
    });

    describe('getIsGroupExpanded()', () => {

        let expandedGroups;

        beforeEach(() => {
            expandedGroups = {};
        });

        it('should be expanded', () => {
            expandedGroups.A = true;
            expect(groupingUtils.getIsGroupExpanded('A', expandedGroups)).toBe(true);

            delete expandedGroups.A;
            expect(groupingUtils.getIsGroupExpanded('A', expandedGroups, true)).toBe(true);

        });

        it('should be collapsed', () => {
            expect(groupingUtils.getIsGroupExpanded('A', expandedGroups)).toBe(false);

            expandedGroups.A = false;
            expect(groupingUtils.getIsGroupExpanded('A', expandedGroups)).toBe(false);
        });
    });

    describe('defaultGroupingFunction()', () => {

        it('should return grouping key', () => {
            expect(groupingUtils.defaultGroupingFunction({ A: 'GroupA' }, { path: 'A' })).toEqual('GroupA');
            expect(groupingUtils.defaultGroupingFunction({ A: 'GroupB' }, { path: 'A' })).toEqual('GroupB');
            expect(groupingUtils.defaultGroupingFunction({ A: 'GroupB' }, { path: 'B' })).toEqual('undefined');
        });

    });

    describe('defaultGroupingObjectFunction()', () => {

        it('should return default grouping object', () => {
            expect(groupingUtils.defaultGroupingObjectFunction('A', [{ id: 1 }], 0)).toEqual({
                id: 'A',
                sectionHeader: 'A',
                rows: [{ id: 1 }],
                level: 0,
            });
        });

    });

    describe('groupingCountObjectFunction()', () => {

        it('should return grouping object with counts', () => {
            expect(groupingUtils.groupingCountObjectFunction('A', [{ id: 1 }], 0)).toEqual({
                id: 'A',
                sectionHeader: 'A (1)',
                rows: [{ id: 1 }],
                level: 0,
            });
        });

    });

    describe('replaceGroup()', () => {

        it('replace group with rows', () => {
            expect(groupingUtils.replaceGroup(['A', 'B', 'C'], ['E', 'F'], 0)).toEqual(['E', 'F', 'B', 'C']);
            expect(groupingUtils.replaceGroup(['A', 'B', 'C'], ['E', 'F'], 1)).toEqual(['A', 'E', 'F', 'C']);
            expect(groupingUtils.replaceGroup(['A', 'B', 'C'], ['E', 'F'], 2)).toEqual(['A', 'B', 'E', 'F']);
        });
    });

    describe('group()', () => {

        let data;
        let grouping;

        beforeEach(() => {

            grouping = [];

            data = [
                { id: 0, propA: 'A', propB: 10 },
                { id: 1, propA: 'A', propB: 10 },
                { id: 2, propA: 'C', propB: 30 },
                { id: 3, propA: 'C', propB: 20 },
                { id: 4, propA: 'C', propB: 20 },
                { id: 5, propA: 'B', propB: 20 },
            ];
        });

        describe('single level grouping', () => {

            let groupingField;

            beforeEach(() => {
                groupingField = {
                    path: 'propA',
                };
                grouping.push(groupingField);
            });

            it('should group rows with single grouping field', () => {

                const result = groupingUtils.group(data, grouping);
                expect(result.length).toEqual(3);

                expect(result[0]).toEqual(jasmine.objectContaining({ id: 'A', level: 0, isGroup: true }));
                expect(result[1]).toEqual(jasmine.objectContaining({ id: 'C', level: 0, isGroup: true }));
                expect(result[2]).toEqual(jasmine.objectContaining({ id: 'B', level: 0, isGroup: true }));

                expect(result[0].rows.length).toEqual(2);
                expect(result[1].rows.length).toEqual(3);
                expect(result[2].rows.length).toEqual(1);
            });

            it('should sort grouped rows with single grouping field', () => {

                groupingField.sort = { fields: [{ path: 'propA' }] };

                const result = groupingUtils.group(data, grouping);
                expect(result[0]).toEqual(jasmine.objectContaining({ id: 'A' }));
                expect(result[1]).toEqual(jasmine.objectContaining({ id: 'B' }));
                expect(result[2]).toEqual(jasmine.objectContaining({ id: 'C' }));
            });

            it('should use custom groupingFunction()', () => {

                groupingField.groupingFunction = (row) => row.propA + row.propB;

                const result = groupingUtils.group(data, grouping);
                expect(result.length).toEqual(4);

                expect(result[0]).toEqual(jasmine.objectContaining({ id: 'A10' }));
                expect(result[1]).toEqual(jasmine.objectContaining({ id: 'C30' }));
                expect(result[2]).toEqual(jasmine.objectContaining({ id: 'C20' }));
                expect(result[3]).toEqual(jasmine.objectContaining({ id: 'B20' }));

                expect(result[0].rows.length).toEqual(2);
                expect(result[1].rows.length).toEqual(1);
                expect(result[2].rows.length).toEqual(2);
                expect(result[3].rows.length).toEqual(1);
            });
        });

        describe('multi level grouping', () => {
            let groupingFieldA;
            let groupingFieldB;

            beforeEach(() => {
                groupingFieldA = {
                    path: 'propA',
                };

                groupingFieldB = {
                    path: 'propB',
                };

                grouping.push(groupingFieldA);
                grouping.push(groupingFieldB);
            });

            it('should group rows with multiple grouping fields', () => {

                const result = groupingUtils.group(data, grouping);
                expect(result.length).toEqual(3);

                expect(result[0]).toEqual(jasmine.objectContaining({ id: 'A', level: 0, isGroup: true }));
                expect(result[1]).toEqual(jasmine.objectContaining({ id: 'C', level: 0, isGroup: true }));
                expect(result[2]).toEqual(jasmine.objectContaining({ id: 'B', level: 0, isGroup: true }));

                expect(result[0].rows.length).toEqual(1);
                expect(result[0].rows[0].rows.length).toEqual(2);

                expect(result[1].rows.length).toEqual(2);
                expect(result[1].rows[0].rows.length).toEqual(1);
                expect(result[1].rows[1].rows.length).toEqual(2);

                expect(result[2].rows.length).toEqual(1);
                expect(result[2].rows[0].rows.length).toEqual(1);
            });

            it('should sort grouped rows with multiple grouping fields', () => {

                groupingFieldA.sort = { fields: [{ path: 'propA' }] };
                groupingFieldB.sort = { fields: [{ path: 'propB' }] };

                const result = groupingUtils.group(data, grouping);
                expect(result.length).toEqual(3);

                expect(result[0]).toEqual(jasmine.objectContaining({ id: 'A' }));
                expect(result[1]).toEqual(jasmine.objectContaining({ id: 'B' }));
                expect(result[2]).toEqual(jasmine.objectContaining({ id: 'C' }));

                expect(result[2].rows.length).toEqual(2);
                expect(result[2].rows[0]).toEqual(jasmine.objectContaining({ id: '20' }));
                expect(result[2].rows[1]).toEqual(jasmine.objectContaining({ id: '30' }));
            });

            it('should use custom groupingObjectFunction()', () => {

                groupingFieldA.sort = { fields: [{ path: 'propA' }] };
                groupingFieldB.sort = { fields: [{ path: 'summary' }] };
                groupingFieldB.groupingObjectFunction = (name, rows, level) => ({
                    id: name,
                    sectionHeader: name,
                    rows,
                    level,

                    // calculate sum of children rows
                    summary: _.sumBy(rows, 'propB'),
                });

                const result = groupingUtils.group(data, grouping);
                expect(result.length).toEqual(3);

                expect(result[0]).toEqual(jasmine.objectContaining({ id: 'A' }));
                expect(result[1]).toEqual(jasmine.objectContaining({ id: 'B' }));
                expect(result[2]).toEqual(jasmine.objectContaining({ id: 'C' }));

                expect(result[2].rows.length).toEqual(2);
                expect(result[2].rows[0]).toEqual(jasmine.objectContaining({ id: '30', summary: 30 }));
                expect(result[2].rows[1]).toEqual(jasmine.objectContaining({ id: '20', summary: 40 }));
            });
        });

        describe('isRowsGroup()', () => {
            it('should detect group rows', () => {
                expect(groupingUtils.isRowsGroup([{ isGroup: true }, { isGroup: true }])).toBeTruthy();
            });

            it('should not detect group rows', () => {
                expect(groupingUtils.isRowsGroup([])).toBeFalsy();
                expect(groupingUtils.isRowsGroup([{ isGroup: false }, { isGroup: true }])).toBeFalsy();
                expect(groupingUtils.isRowsGroup([{ isGroup: false }, { isGroup: false }])).toBeFalsy();
            });

            it('should not detect group rows whenever first item has root excluded', () => {
                expect(groupingUtils.isRowsGroup([{ isGroup: true, isRootExcluded: true }, { isGroup: false }])).toBeFalsy();
            });

            it('should detect group rows whenever first item has root isSectioned', () => {
                expect(groupingUtils.isRowsGroup([{ isGroup: true, isRootExcluded: true, isSectioned: true }, { isGroup: true }])).toBeTruthy();
            });
        });
    });
});
