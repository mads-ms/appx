import PropTypes from 'prop-types';
import React from 'react';
import { shallow } from 'enzyme';
import * as rendererUtils from 'src/components/reactGrid/reactGridRendererUtils';

class ItemRenderer extends React.PureComponent {

    render() {

        const { label, value } = this.props;

        return (<p>{label} - {value}</p>);
    }
}

ItemRenderer.propTypes = {
    label: PropTypes.string,
    value: PropTypes.number,
};

describe('src/components/reactGrid/reactGridRendererUtils', () => {

    describe('createRenderer()', () => {

        const assertRenderer = (renderer, label, value) => {
            const wrapper = shallow(renderer);
            expect(wrapper.contains(<p>{label} - {value}</p>)).toEqual(true);
        };

        let renderer;

        it('should create inline renderer ', () => {

            renderer = rendererUtils.createRenderer(<ItemRenderer/>, { label: 'A', value: 10 });
            assertRenderer(renderer, 'A', 10);

            renderer = rendererUtils.createRenderer(<ItemRenderer label="A"/>, { value: 10 });
            assertRenderer(renderer, 'A', 10);
        });

        it('should create class based renderer ', () => {

            renderer = rendererUtils.createRenderer(ItemRenderer, { label: 'A', value: 10 });
            assertRenderer(renderer, 'A', 10);
        });

        it('should create callback based renderer ', () => {

            const callback = (props) => <ItemRenderer {...props}/>;

            renderer = rendererUtils.createRenderer(callback(), { label: 'A', value: 10 });
            assertRenderer(renderer, 'A', 10);
        });

        it('should create plain renderer ', () => {

            renderer = rendererUtils.createRenderer('test', {});
            expect(renderer).toEqual('test');
        });

    });

    describe('get test classes from id', () => {
        const columnId = 'tstColumnId';
        const column = { id: columnId };

        it('should return test class for getPrimaryItemTestClass', () => {
            const testClass = rendererUtils.getPrimaryItemTestClass(column);
            expect(testClass).toEqual(`tst-col-item-${columnId}`);
        });

        it('should return test class for getSecondaryItemTestClass', () => {
            const testClass = rendererUtils.getSecondaryItemTestClass(column);
            expect(testClass).toEqual(`tst-col-item-secondary-${columnId}`);
        });

        it('should return test class for getPrimaryHeaderTestClass', () => {
            const testClass = rendererUtils.getPrimaryHeaderTestClass(column);
            expect(testClass).toEqual(`tst-col-header-${columnId}`);
        });

        it('should return test class for getSecondaryHeaderTestClass', () => {
            const testClass = rendererUtils.getSecondaryHeaderTestClass(column);
            expect(testClass).toEqual(`tst-col-header-secondary-${columnId}`);
        });
    });

    describe('get test classes from tstId', () => {
        const columnId = 'columnId';
        const tstId = 'tstColumnId';

        it('should return test class for getPrimaryItemTestClass', () => {
            const column = { id: columnId, tstId };
            const testClass = rendererUtils.getPrimaryItemTestClass(column);
            expect(testClass).toEqual(`tst-col-item-${tstId}`);
        });

        it('should return test class for getSecondaryItemTestClass', () => {
            const column = { id: columnId, tstSecondaryId: tstId };
            const testClass = rendererUtils.getSecondaryItemTestClass(column);
            expect(testClass).toEqual(`tst-col-item-${tstId}`);
        });

        it('should return test class for getPrimaryHeaderTestClass', () => {
            const column = { id: columnId, tstId };
            const testClass = rendererUtils.getPrimaryHeaderTestClass(column);
            expect(testClass).toEqual(`tst-col-header-${tstId}`);
        });

        it('should return test class for getSecondaryHeaderTestClass', () => {
            const column = { id: columnId, tstSecondaryId: tstId };
            const testClass = rendererUtils.getSecondaryHeaderTestClass(column);
            expect(testClass).toEqual(`tst-col-header-${tstId}`);
        });
    });
});
