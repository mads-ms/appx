/* eslint max-lines: "off" */
/**
 * The <ReactGridRows/> Component is internal to <ReactGrid> and should not be
 * accessed directly. It supervises the ScrollView within which rows are
 * rendered, and is responsible for rendering the correct rows to users
 * depending on the scroll position. To become <ReactGridRows>.
 */
import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import { UI } from 'openui';
import ReactGridRow from './reactGridRow';
import ReactGridDivider from './reactGridDivider';
import _ from 'lodash';
import { bindHandlers } from 'src/utils/bindHandlers';
import ReactGridRowsWrapper from './reactGridRowsWrapper';
import * as sortUtils from './reactGridSortUtils';
import * as groupingUtils from './reactGridGroupingUtils';
import * as renderUtils from './reactGridRendererUtils';
import shallowEqual from 'react-redux/lib/utils/shallowEqual';

class ReactGridRows extends React.Component {
    constructor() {
        super();

        this.scrollDistance = 0;
        this.scrollTop = 0;
        this.state = {
            scrollHeight: 0,
            isScrolling: false,
        };

        this.handleScrollEnd = _.debounce(this.handleScrollEnd, 300);

        this.setScrollableEl = (ref) => {
            this.scrollableEl = ref;
        };

        this.setScrollBodyEl = (ref) => {
            this.scrollBodyEl = ref;
        };

        this.isScrollScheduled = false;
    }

    componentWillMount() {
        this.setState(this.getDefaultState(this.props));
    }

    componentDidMount() {
        if (this.props.scrollOffset > 0) {
            this.scrollableEl.scrollTop = this.props.scrollOffset;
        }
        this.verifyScroll();
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.scrollOffset !== this.props.scrollOffset &&
            nextProps.scrollOffset !== this.scrollableEl.scrollTop) {
            this.scrollableEl.scrollTop = nextProps.scrollOffset;
        }

        this.setState(this.getDefaultState(nextProps));
    }

    // optimization reduces number of renders for rows until such time
    // it's needed to remove/append a row or update column appearance.
    // - This doesn't optimise cell-content updates which are regulated
    //   by the `canUpdate` property passed to the column template
    //   function.
    // eslint-disable-next-line complexity
    shouldComponentUpdate(nextProps, nextState) {
        return nextProps.selectedRow !== this.props.selectedRow ||
            nextProps.columns !== this.props.columns ||
            nextProps.children !== this.props.children ||
            nextProps.isScrollingDisabled !== this.props.isScrollingDisabled ||
            nextProps.expandedGroups !== this.props.expandedGroups ||
            nextProps.keepGroupsExpanded !== this.props.keepGroupsExpanded ||
            nextProps.scrollLeft !== this.props.scrollLeft ||
            nextProps.scrollRight !== this.props.scrollRight ||
            nextProps.rowHeight !== this.props.rowHeight ||
            nextProps.dividerHeight !== this.props.dividerHeight ||
            nextProps.dividerLineHeight !== this.props.dividerLineHeight ||
            nextProps.rowHeight !== this.props.rowHeight ||
            nextProps.rowLineHeight !== this.props.rowLineHeight ||
            nextState.isScrolling !== this.state.isScrolling ||
            nextState.rowsToRender !== this.state.rowsToRender ||
            nextState.stickyRowIndex !== this.state.stickyRowIndex ||
            nextState.stickyRowOffset !== this.state.stickyRowOffset ||
            nextState.isStickyRowHidden !== this.state.isStickyRowHidden ||

            // Check composition based props
            !shallowEqual(nextProps.sort, this.props.sort) ||
            !shallowEqual(nextProps.grouping, this.props.grouping);
    }

    componentDidUpdate(prevProps, prevState) {
        this.verifyScroll();
        this.verifyReflow(prevProps, prevState);
    }

    /**
     * Obtains a divider row React element bound to a specific section (parent row)
     */
    getDividerContent(rowInfo) {
        const {
            id,
            title,
            isExpanded,
            isStatic,
            sectionHeader,
            className,
        } = rowInfo;

        return (
            <ReactGridDivider
                id={id}
                title={title}
                isExpanded={isExpanded}
                isStatic={isStatic}
                sectionHeader={sectionHeader}
                className={className}
                onTap={this.props.onDividerTap}
            />
        );
    }

    /**
     * Computes Y offsets for all rendered rows, taking into
     * consideration expanded and collapsed groupings.
     */
    getRowOffsets(props) {
        const {
            columns,
            sort,
            grouping,
            expandedGroups,
            keepGroupsExpanded,
            isGrouping,
            isSectioned,
        } = props;

        const sortedColumn = sortUtils.getSortedColumn(sort, columns);
        const isSortSupported = sortUtils.getIsSortSupported(sort, sortedColumn);
        const isGroupingSupported = groupingUtils.getIsGroupingSupported(isGrouping || isSectioned, grouping);

        let topOffset = 0;
        let index = 0;
        let minRowHeight = props.height;

        // recursively iterate rows to calculate scrollHeight
        const getExpandedRows = (rows, level = 0, parentRow) => {

            // sort rows on given level
            if (isSortSupported && !groupingUtils.isRowsGroup(rows) && !(parentRow && parentRow.isNotSortable === true)) {
                const columnSort = sortUtils.getSort(sortedColumn);
                rows = sortUtils.sortRows(rows, sort, columnSort, sortedColumn);
            }

            return _.chain(rows)

            // generate rows as objects if plain ids are passed
                .map((row) => _.isObject(row) ? row : { id: row })
                .flatMap((rowInfo, childIndex) => {

                    const isDivider = this.props.isSectioned && Boolean(level === 0 || rowInfo.isSectioned);

                    const template = rowInfo.template ||
                        (isDivider ? this.getDividerContent(rowInfo) : null);

                    const height = this.getRowHeight(props, rowInfo, isDivider);
                    const lineHeight = this.getRowLineHeight(props, rowInfo, isDivider);

                    const row = _.defaults({
                        level,
                        topOffset,
                        index,
                        childIndex,
                        height,
                        lineHeight,
                        template,
                        isDivider,
                    }, rowInfo);

                    // this will be moved away when dividers support will be reviewed
                    const isParentExcluded = row.isRootExcluded;
                    let isRowExpanded = row.isExpanded;

                    if (isParentExcluded) {
                        isRowExpanded = true;
                    }

                    if (_.isNil(isRowExpanded)) {
                        isRowExpanded = groupingUtils.getIsGroupExpanded(rowInfo.id, expandedGroups, keepGroupsExpanded);
                    }

                    row.isExpanded = isRowExpanded;

                    // This should be moved out when row info cleanup will be done
                    const childrenRows = rowInfo.rows || _.get(rowInfo, 'data.rows', []) || [];
                    const result = [];

                    // if we are grouping with parent excluded remove parent row
                    if (!isParentExcluded) {
                        result.push(row);

                        topOffset += height;
                        minRowHeight = Math.min(minRowHeight, height);
                        index++;
                    }

                    // append children if row is expanded, avoid calling getExpandedRows if not required
                    if (row.isExpanded && childrenRows.length > 0) {
                        return _.concat(result, getExpandedRows(row.isExpanded ? childrenRows : [], level + 1, row));
                    }

                    return result;
                })
                .value();
        };

        let rows = props.rows;
        if (isGroupingSupported) {
            const groupingConfig = groupingUtils.getGrouping(grouping);
            rows = groupingUtils.group(
                rows,
                groupingConfig,
                expandedGroups,
                keepGroupsExpanded
            );
        }

        // flatten list of all expanded rows
        rows = getExpandedRows(rows);

        return {
            minRowHeight,
            rows,
            scrollHeight: topOffset,
        };
    }

    getRowHeight(props, rowInfo, isDivider) {
        if (rowInfo.height) {
            return rowInfo.height;
        }

        return isDivider ? props.dividerHeight : props.rowHeight;
    }

    getRowLineHeight(props, rowInfo, isDivider) {
        if (rowInfo.lineHeight) {
            return rowInfo.lineHeight;
        }

        return isDivider ? props.dividerLineHeight : props.rowLineHeight;
    }

    /**
     * Obtains the IDs of rows deemed currently in view (including buffer clusters)
     */
    getRowsToRender(props, rows = this.state.rows, scrollTop = this.scrollTop) {
        const { height } = props;
        const cullSize = Math.floor(this.props.cullRatio * height);
        const minOffset = scrollTop - cullSize;
        const maxOffset = scrollTop + height + cullSize - 1;
        const minIndex = renderUtils.findRowIndexByOffset(minOffset, rows);
        const maxIndex = renderUtils.findRowIndexByOffset(maxOffset, rows) + 1;

        return _.slice(rows, minIndex, maxIndex);
    }

    /**
     * High-level accessor to collate properties relating to the row state
     */
    getRowState(props) {
        if (!this.state.rows ||
            props.sort !== this.props.sort ||
            props.rows !== this.props.rows ||
            props.columns !== this.props.columns ||
            props.height !== this.props.height ||
            props.grouping !== this.props.grouping ||
            props.columns !== this.props.columns ||
            props.expandedGroups !== this.props.expandedGroups ||
            props.rowHeight !== this.props.rowHeight ||
            props.rowLineHeight !== this.props.rowLineHeight ||
            props.dividerHeight !== this.props.dividerHeight ||
            props.dividerLineHeight !== this.props.dividerLineHeight
        ) {
            const {
                scrollHeight,
                rows,
                minRowHeight,
            } = this.getRowOffsets(props);

            let rowsToRender = rows;

            if (!this.props.isHeightFill) {
                rowsToRender = this.getRowsToRender(props, rows, this.scrollTop);
            }

            const headerRows = _.filter(rows, {
                level: 0,
            });

            return {
                scrollHeight,
                rows,
                headerRows,
                minRowHeight,
                rowsToRender,
            };
        }

        return false;
    }

    /**
     * Helper to compute the nextState for rows and React DnD
     */
    getDefaultState(props) {
        const { dragRow } = props;
        const state = this.state;
        const scrollTop = this.scrollTop;
        const dragInfo = dragRow ? state.dragInfo : {};
        const rowInfo = this.getRowState(props);

        const nextState = {
            dragRow,
            dragInfo,
            scrollTop,
        };

        // Use the first row for the sticky row on initial render
        if (props.isStickyGrouping && rowInfo && rowInfo.headerRows && this.scrollTop === 0) {
            nextState.stickyRowIndex = renderUtils.findRowIndexByOffset(0, rowInfo.headerRows);
            nextState.isStickyRowHidden = false;
        }

        return _.defaults(nextState, rowInfo);
    }

    verifyScroll() {
        // Resolves issue when scroll position is reset to 0 in ui whenever we switch from Alerts to Watchlist (which don't cause remount).
        if (this.scrollableEl && this.state.isScrolling === false && this.scrollTop !== this.scrollableEl.scrollTop) {
            this.handleScrollBegin();
        }
    }

    verifyReflow(prevProps, prevState) {
        if (this.state.rowsToRender !== prevState.rowsToRender) {
            const rowsIds = _.map(this.state.rowsToRender, 'id');
            this.handleRowReflow(rowsIds, this.state.rowsToRender);
        }
    }

    /**
     * Returns the row which should be used for the sticky row.
     *
     * @param  {Number} scrollTop
     * @return {Object}
     */
    getStickyRow(scrollTop) {
        const index = renderUtils.findRowIndexByOffset(scrollTop, this.state.headerRows);

        return {
            index,
            stickyRow: this.state.headerRows[index],
        };
    }

    handleScrollBegin() {
        // Ensures only one scroll callback per frame
        if (!this.isScrollScheduled) {
            this.isScrollScheduled = true;
            UI.nextTick(this.handleScroll);
        }
    }

    handleScroll() {
        if (!this.scrollableEl) {
            // Skip when there's no scrollableEl in the next UI tick
            this.isScrollScheduled = false;
            return;
        }

        const nextState = {};
        const { onScrollStart, onScroll } = this.props;
        const { rows, isScrolling, minRowHeight } = this.state;
        const scrollTop = this.scrollableEl.scrollTop;

        if (!isScrolling) {
            nextState.isScrolling = true;
            onScrollStart();
        }

        // increment scrollDistance with scroll delta
        this.scrollDistance += this.scrollTop - scrollTop;
        this.scrollTop = scrollTop;

        // Calculate new rows only if scroll reaches row height
        if (Math.abs(this.scrollDistance) >= minRowHeight) {
            this.scrollDistance = 0;
            nextState.isScrolling = true;
            nextState.rowsToRender = this.getRowsToRender(this.props, rows, scrollTop);
        }

        if (this.props.isStickyGrouping) {
            const { index, stickyRow } = this.getStickyRow(scrollTop);
            const nextStickyRow = this.state.headerRows[index + 1];

            nextState.stickyRowIndex = index;

            // There may not always be a next sticky row. In that case fall back
            // to 0.
            const distanceToNextRow = nextStickyRow ? (nextStickyRow.topOffset - scrollTop) : 0;

            // If the scrollTop is negative, don't show the sticky header. This
            // is noticeable in Safari with its bouncing effect at the end of
            // scrolling.
            nextState.isStickyRowHidden = distanceToNextRow > 0 && distanceToNextRow - stickyRow.height < 0;
            nextState.stickyRowOffset = nextStickyRow ? nextStickyRow.topOffset - stickyRow.height : 0;
        }

        this.setState(nextState);

        onScroll();

        // debounced method only invoked after last scroll evt in sequence
        this.handleScrollEnd();

        this.isScrollScheduled = false;
    }

    handleScrollEnd() {
        this.setState({ isScrolling: false });
        if (this.scrollableEl && this.props.onScrollEnd) {
            this.props.onScrollEnd(this.scrollableEl.scrollTop);
        }
    }

    handleRowReflow(rowsIds, rows) {
        if (!this.props.onRowReflow) {
            return;
        }

        this.props.onRowReflow(rowsIds, rows);
    }

    handleRowSelect(evt, row) {
        if (evt.defaultPrevented) {
            return;
        }

        this.props.onRowSelect(evt, row);
    }

    handleRowDoubleTap(evt, row) {
        if (evt.defaultPrevented) {
            return;
        }

        this.props.onRowDoubleTap(evt, row);
    }

    canAnimateRows() {
        return !this.state.isScrolling;
    }

    getRowProps(rowsToRender, index) {
        const rowInfo = rowsToRender[index];

        if (!rowInfo) {
            return null;
        }

        // for groupings insert reference to child on 'data' object passed to cell renderers.
        // this will disappear once groupBy is supported internally within ReactGrid.
        const rowData = rowInfo.data || {};

        if (rowInfo.rows) {
            rowData.rows = rowInfo.rows;
        }

        return {
            index,
            id: rowInfo.id,
            rowId: rowInfo.id,
            rowIndex: rowInfo.index,
            rowData,
            rowInfo,
            topOffset: rowInfo.topOffset,
            localOffset: rowInfo.localOffset,
            height: rowInfo.height,
            lineHeight: rowInfo.lineHeight,
            width: this.props.isWidthFill ? '100%' : this.props.width,
            isRtl: this.props.isRtl,
            isSelected: this.props.selectedRow === rowInfo.id,
            isScrolling: this.state.isScrolling,
        };
    }

    getScrollBodyStyles() {
        const styles = {
            overflow: 'hidden',
            width: this.props.isWidthFill ? '100%' : this.props.width,
            height: this.state.scrollHeight,
        };

        styles.transform = 'translateZ(0px)';

        return styles;
    }

    getRowWrapperOffset() {
        return _.get(this.state.rowsToRender, '0.topOffset', 0);
    }

    getRowWrapperStyles() {
        const { isScrolling } = this.state;

        // translates rows into view as user scrolls
        const offset = this.getRowWrapperOffset();

        return {
            overflow: 'hidden',
            position: 'absolute',
            top: '0',
            height: '100%',
            width: this.props.isWidthFill ? '100%' : this.props.width,
            transform: `translate3d(0, ${offset}px, 0)`,
            pointerEvents: isScrolling ? 'none' : 'auto',
        };
    }

    /**
     * Returns container style that will ensure it's child will not affect parent height (in this case scroll container).
     * @return {Object}
     */
    getRowContainerStyles() {
        return {
            position: 'absolute',
            top: 0,
            width: this.props.isWidthFill ? '100%' : this.props.width,
            height: Math.max(this.state.scrollHeight, this.props.height),
            overflow: 'hidden',
        };
    }

    /**
     * Returns a faux sticky row to give the illusion of that the sticky rows
     * push each other.
     *
     * @return {Object}
     */
    getPreviousStickyRow() {
        if (!this.props.isStickyGrouping || !this.state.isStickyRowHidden) {
            return [];
        }
        const { headerRows, stickyRowIndex, stickyRowOffset } = this.state;
        const stickyRow = _.defaults({
            rowId: 'previousStickyRow',
            topOffset: stickyRowOffset,
            isSticky: true,
        }, this.getRowProps(headerRows, stickyRowIndex));

        return [stickyRow];
    }

    renderStickyRow(canAnimateRows) {

        // If the scrollTop is negative, don't show the sticky header. This
        // is noticeable in Safari with its bouncing effect at the end of
        // scrolling.
        if (this.state.isStickyRowHidden || this.scrollTop <= 0) {
            return false;
        }

        const { scrollLeft, scrollRight } = this.props;
        const { headerRows, stickyRowIndex } = this.state;

        const row = _.defaults({
            topOffset: 0,
        }, this.getRowProps(headerRows, stickyRowIndex));

        return (
            <div
                className="reactgrid-stickyrow"
                style={{
                    left: scrollLeft,
                    right: scrollRight,
                }}
            >
                <ReactGridRow
                    columns={this.props.columns}
                    cellClass={this.props.cellClass}
                    canAnimate={canAnimateRows}
                    onSelect={this.handleRowSelect}
                    canUpdate={!this.state.isScrolling}
                    isGrouping={this.props.isGrouping}
                    onRowTap={this.props.onRowTap}
                    {...row}
                />
            </div>
        );
    }

    render() {
        const { isScrolling, rows } = this.state;
        const { children, rowHeight, width } = this.props;

        const rowsToRender = this.state.rowsToRender;

        // cached for perf outside row _.map fn
        const canAnimateRows = this.canAnimateRows();

        // get rows data
        const rowsData = _.chain(rowsToRender)
            .map((row, index) => this.getRowProps(rowsToRender, index))
            .reject(_.isNull)
            .concat(this.getPreviousStickyRow())
            .value();

        const plugins = React.Children.toArray(children);

        const pluginProps = {
            width,
            rowHeight,
            scrollBodyEl: this.scrollBodyEl,
            rowsData,
            isScrolling,
            allRows: rows,
        };

        let rowsPlugin = null;

        _.forEach(plugins, (plugin) => {
            rowsPlugin = React.cloneElement(plugin, _.defaults(
                { nextPlugin: rowsPlugin },
                pluginProps
            ));
        });

        const content = (
            <div className={classNames('grid', this.props.isHeightFill ? 'g--fit' : 'grid--scroll')}>
                <div
                    ref={this.setScrollableEl}
                    className="reactgrid-rows tst-grid-rows grid-cell"
                    onScroll={this.handleScrollBegin}
                    style={{ position: 'relative', overflowY: this.props.isScrollingDisabled ? 'hidden' : '' }}
                >
                    <div
                        className="reactgrid-scrollbody"
                        ref={this.setScrollBodyEl}
                        style={this.getScrollBodyStyles()}
                    >
                    </div>
                    <div style={this.getRowContainerStyles()}>
                        <div style={this.getRowWrapperStyles()}>
                            <ReactGridRowsWrapper
                                columns={this.props.columns}
                                cellClass={this.props.cellClass}
                                rowClass={this.props.rowClass}
                                canAnimate={canAnimateRows}
                                isGrouping={this.props.isGrouping}
                                rowsData={rowsData}
                                rowStyleFunction={this.props.rowStyleFunction}
                                onDoubleTap={this.handleRowDoubleTap}
                                onSelect={this.handleRowSelect}
                                canUpdate={!isScrolling}
                                onRowTap={this.props.onRowTap}
                                onRowPress={this.props.onRowPress}
                            >
                                {rowsPlugin}
                            </ReactGridRowsWrapper>
                        </div>
                    </div>
                </div>
            </div>
        );

        if (!this.props.isStickyGrouping) {
            return content;
        }

        return (
            <div className="grid">
                {content}
                {this.renderStickyRow(canAnimateRows)}
            </div>
        );
    }
}

ReactGridRows.propTypes = {
    cellClass: PropTypes.string,
    sort: PropTypes.object,
    grouping: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.arrayOf(PropTypes.string),
        PropTypes.arrayOf(PropTypes.object)]),
    expandedGroups: PropTypes.object,
    keepGroupsExpanded: PropTypes.bool,
    columns: PropTypes.arrayOf(PropTypes.object),
    cullRatio: PropTypes.number,
    height: PropTypes.number,
    width: PropTypes.number,
    scrollLeft: PropTypes.number,
    scrollRight: PropTypes.number,
    isRtl: PropTypes.bool.isRequired,
    isGrouping: PropTypes.bool,
    isSectioned: PropTypes.bool,
    isStickyGrouping: PropTypes.bool,
    isHeightFill: PropTypes.bool,
    isWidthFill: PropTypes.bool,
    isMenuShown: PropTypes.bool,
    isScrollingDisabled: PropTypes.bool,
    offsets: PropTypes.array,
    onRowTap: PropTypes.func,
    onRowPress: PropTypes.func,
    onRowDoubleTap: PropTypes.func,
    onRowReflow: PropTypes.func,
    onRowSelect: PropTypes.func,
    onRowTouchStart: PropTypes.func,
    onScroll: PropTypes.func,
    onScrollStart: PropTypes.func,
    onScrollEnd: PropTypes.func,
    onDividerTap: PropTypes.func,
    rowClass: PropTypes.string,
    rowHeight: PropTypes.number.isRequired,
    rowLineHeight: PropTypes.number,
    rowStyleFunction: PropTypes.func,
    dividerHeight: PropTypes.number.isRequired,
    dividerLineHeight: PropTypes.number,
    rows: PropTypes.arrayOf(
        PropTypes.oneOfType([PropTypes.string, PropTypes.object])
    ),
    selectedRow: PropTypes.string,
    scrollOffset: PropTypes.number,
};

ReactGridRows.defaultProps = {
    cullRatio: 0.5,
    isHeightFill: false,
    isWidthFill: true,
    height: 0,
    isMenuShown: false,
    onScroll: _.noop,
    onScrollStart: _.noop,
    onScrollEnd: _.noop,
    onRowDoubleTap: _.noop,
    onRowReflow: _.noop,
    onRowSelect: _.noop,
    onRowTap: _.noop,
    onRowPress: _.noop,
    onRowTouchStart: _.noop,
    onDividerTap: _.noop,
    rows: [],
    keepGroupsExpanded: false,
    expandedGroups: {},
};

export default bindHandlers(ReactGridRows);
