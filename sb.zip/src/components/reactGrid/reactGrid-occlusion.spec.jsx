/**
 * <ReactGrid/> occlusion unit tests
 */

import React from 'react';
import ReactGrid from 'src/components/reactGrid/reactGrid';
import { createCols, createRows } from './reactGridSpecHelper';
import { mount } from 'enzyme';

describe('src/components/reactGrid', () => {

    /**
     * Developer note: The following tests use the cullRatio prop of
     * <ReactGrid> to control exactly how many rows should be occluded
     * when the component renders. In practice you would be unlikely to
     * pass a value of 0 as some "buffer" is useful for a seamless scrolling
     * experience.
     */
    describe('occlusion', () => {
        // assertion state
        let cols;
        let rows;
        let handleColReflow;
        let handleRowReflow;
        let wrapper;

        // controlled state setup before each test
        let defaultProps;

        beforeEach(() => {
            cols = [];
            rows = [];

            defaultProps = {
                isHeader: false,
                width: 501,
                height: 100,
                rowHeight: 20,
                headerHeight: 30,
            };

            handleColReflow = jasmine.createSpy().and.callFake((evt) => {
                cols = evt;
            });
            handleRowReflow = jasmine.createSpy().and.callFake((evt) => {
                rows = evt;
            });
        });

        afterEach(() => {
            wrapper.unmount();
        });

        describe('rows', () => {
            it('should NOT cull any rows from a [5x1] datagrid when all rows viewable', () => {
                const rowDescriptor = createRows(5);
                const colDescriptor = createCols(['foo']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        // => up to 5 rows of 20px rendered
                        cullRatio={0}

                        // all 5 rows of 20px viewable
                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(rows.length).toEqual(5);
                    expect(rows).toEqual(['0', '1', '2', '3', '4']);

                    // assert rendering
                    const cellNodes = wrapper.find('.reactgrid-cell');
                    expect(cellNodes.length).toEqual(5);
                }

                assertions();
            });

            it('should NOT cull any rows from a [5x1] datagrid when cull ratio is 1', () => {
                const rowDescriptor = createRows(5);
                const colDescriptor = createCols(['foo']);

                // only 3 rows of 20px viewable
                defaultProps.height = 60;

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        // up to 9 rows of 20px rendered
                        cullRatio={1}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state (visible with 1 potential partial row reported)
                    expect(rows.length).toEqual(5);
                    expect(rows).toEqual(['0', '1', '2', '3', '4']);

                    // assert rendering
                    const cellNodes = wrapper.find('.reactgrid-cell');
                    expect(cellNodes.length).toEqual(5);
                }

                assertions();
            });

            it('should cull LAST TWO rows from a [5x1] datagrid when cull ratio is 0', () => {
                const rowDescriptor = createRows(5);
                const colDescriptor = createCols(['foo']);

                // only 3 rows of 20px viewable
                defaultProps.height = 60;

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        // up to 3 rows of 20px rendered
                        cullRatio={0}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state (visible with no potential partial rows reported)
                    expect(rows.length).toEqual(3);
                    expect(rows).toEqual(['0', '1', '2']);

                    // assert rendering
                    const cellNodes = wrapper.find('.reactgrid-cell');
                    expect(cellNodes.length).toEqual(3);
                }

                assertions();
            });
        });

        describe('cols', () => {
            it('should NOT cull any cols from a [1x5] datagrid when all rows viewable', () => {
                const rowDescriptor = createRows(1);
                const colDescriptor = createCols(['foo', 'bar', 'baz', 'qwux', 'qwix']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        // all 5 cols of 100px viewable
                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols.length).toEqual(5);
                    expect(cols).toEqual(['foo', 'bar', 'baz', 'qwux', 'qwix']);

                    // assert rendering
                    const cellNodes = wrapper.find('.reactgrid-cell');
                    expect(cellNodes.length).toEqual(5);
                }

                assertions();
            });

            it('should cull LAST two cols from a [1x5] datagrid', () => {
                const rowDescriptor = createRows(1);
                const colDescriptor = createCols(['foo', 'bar', 'baz', 'qwux', 'qwix']);

                // only 3 cols of 100px viewable
                defaultProps.width = 301;

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols.length).toEqual(3);
                    expect(cols).toEqual(['foo', 'bar', 'baz']);

                    // assert rendering
                    const cellNodes = wrapper.find('.reactgrid-cell');
                    expect(cellNodes.length).toEqual(3);

                }

                assertions();
            });

            it('should NOT cull always fixed start column in [1x5] datagrid', () => {
                const rowDescriptor = createRows(1);
                const colDescriptor = createCols(['foo', 'bar', 'baz', 'qwux', 'qwix'], {
                    'qwix': {
                        isFixedStart: true,
                    },
                });

                // only 3 cols of 100px viewable
                defaultProps.width = 301;

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols.length).toEqual(3);
                    expect(cols).toEqual(['qwix', 'foo', 'bar']);

                    // assert rendering
                    const cellNodes = wrapper.find('.reactgrid-cell');
                    expect(cellNodes.length).toEqual(3);

                }

                assertions();
            });

            it('should NOT cull always fixed start columns in [1x5] datagrid', () => {
                const rowDescriptor = createRows(1);
                const colDescriptor = createCols(['foo', 'bar', 'baz', 'qwux', 'qwix'], {
                    'bar': {
                        isFixedStart: true,
                    },
                    'qwix': {
                        isFixedStart: true,
                    },
                });

                // only 3 cols of 100px viewable
                defaultProps.width = 301;

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols.length).toEqual(3);
                    expect(cols).toEqual(['bar', 'qwix', 'foo']);

                    // assert rendering
                    const cellNodes = wrapper.find('.reactgrid-cell');
                    expect(cellNodes.length).toEqual(3);

                }

                assertions();
            });

            it('should NOT cull always fixed end column in [1x5] datagrid', () => {
                const rowDescriptor = createRows(1);
                const colDescriptor = createCols(['foo', 'bar', 'baz', 'qwux', 'qwix'], {
                    'qwix': {
                        isFixedEnd: true,
                    },
                });

                // only 3 cols of 100px viewable
                defaultProps.width = 301;

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols.length).toEqual(3);
                    expect(cols).toEqual(['foo', 'bar', 'qwix']);

                    // assert rendering
                    const cellNodes = wrapper.find('.reactgrid-cell');
                    expect(cellNodes.length).toEqual(3);

                }

                assertions();
            });

            it('should NOT cull always fixed end columns in [1x5] datagrid', () => {
                const rowDescriptor = createRows(1);
                const colDescriptor = createCols(['foo', 'bar', 'baz', 'qwux', 'qwix'], {
                    'baz': {
                        isFixedEnd: true,
                    },
                    'qwix': {
                        isFixedEnd: true,
                    },
                });

                // only 3 cols of 100px viewable
                defaultProps.width = 301;

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols.length).toEqual(3);
                    expect(cols).toEqual(['foo', 'baz', 'qwix']);

                    // assert rendering
                    const cellNodes = wrapper.find('.reactgrid-cell');
                    expect(cellNodes.length).toEqual(3);

                }

                assertions();
            });

            it('should NOT cull lower priority col in [1x5] datagrid if space', () => {
                const rowDescriptor = createRows(1);
                const colDescriptor = createCols(['foo', 'bar', 'baz', 'qwux', 'qwix'], {
                    'baz': {
                        priority: 1,
                    },
                });

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols.length).toEqual(5);
                    expect(cols).toEqual(['foo', 'bar', 'baz', 'qwux', 'qwix']);

                    // assert rendering
                    const cellNodes = wrapper.find('.reactgrid-cell');
                    expect(cellNodes.length).toEqual(5);
                }

                assertions();
            });

            it('should cull lower priority col in [1x5] datagrid', () => {
                const rowDescriptor = createRows(1);
                const colDescriptor = createCols(['foo', 'bar', 'baz', 'qwux', 'qwix'], {
                    'baz': {
                        priority: 2,
                    },
                });

                // only 4 cols of 100px viewable
                defaultProps.width = 401;

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols.length).toEqual(4);
                    expect(cols).toEqual(['foo', 'bar', 'qwux', 'qwix']);

                    // assert rendering
                    const cellNodes = wrapper.find('.reactgrid-cell');
                    expect(cellNodes.length).toEqual(4);
                }

                assertions();
            });

            it('should cull only lowest priority col in [1x5] datagrid when no room at all', () => {
                const rowDescriptor = createRows(1);
                const colDescriptor = createCols(['foo', 'bar', 'baz', 'qwux', 'qwix'], {
                    'foo': {
                        priority: 3,
                    },
                    'bar': {
                        priority: 5,
                    },
                    'baz': {
                        priority: 2,
                    },
                    'qwix': {
                        priority: 4,
                    },
                });

                // only 4 cols of 100px viewable
                defaultProps.width = 401;

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols.length).toEqual(4);
                    expect(cols).toEqual(['foo', 'baz', 'qwux', 'qwix']);

                    // assert rendering
                    const cellNodes = wrapper.find('.reactgrid-cell');
                    expect(cellNodes.length).toEqual(4);
                }

                assertions();
            });

            // asserts different culling logic from above unit test.
            it('should cull only lowest priority col in [1x5] datagrid when only partial room', () => {
                const rowDescriptor = createRows(1);
                const colDescriptor = createCols(['foo', 'bar', 'baz', 'qwux', 'qwix'], {
                    'foo': {
                        priority: 3,
                    },
                    'bar': {
                        priority: 5,
                    },
                    'baz': {
                        priority: 2,
                    },
                    'qwix': {
                        priority: 4,
                    },
                });

                // only 4 cols of 100px viewable
                defaultProps.width = 450;

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols.length).toEqual(4);
                    expect(cols).toEqual(['foo', 'baz', 'qwux', 'qwix']);

                    // assert rendering
                    const cellNodes = wrapper.find('.reactgrid-cell');
                    expect(cellNodes.length).toEqual(4);
                }

                assertions();
            });

            it('should cull both lower priority cols in [1x5] datagrid', () => {
                const rowDescriptor = createRows(1);
                const colDescriptor = createCols(['foo', 'bar', 'baz', 'qwux', 'qwix'], {
                    'bar': {
                        priority: 3,
                    },
                    'baz': {
                        priority: 2,
                    },
                });

                // only 4 cols of 100px viewable
                defaultProps.width = 301;

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols.length).toEqual(3);
                    expect(cols).toEqual(['foo', 'qwux', 'qwix']);

                    // assert rendering
                    const cellNodes = wrapper.find('.reactgrid-cell');
                    expect(cellNodes.length).toEqual(3);
                }

                assertions();
            });

        });

        describe('resize', () => {
            it('should cull LAST 2 rows from a [5x1] datagrid after reducing its height', () => {
                const rowDescriptor = createRows(5);
                const colDescriptor = createCols(['foo']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        cullRatio={0}

                        // all 5 rows of 20px and 5 cols of 100px viewable
                        {...defaultProps}
                    />
                );

                function assertions() {
                    expect(rows.length).toEqual(3);
                    expect(rows).toEqual(['0', '1', '2']);

                    // assert rendering
                    const cellNodes = wrapper.find('.reactgrid-cell');
                    expect(cellNodes.length).toEqual(3);
                }

                wrapper.setProps({
                    height: 60,
                });
                wrapper.update();

                assertions();
            });

            it('should cull LAST 2 cols from a [1x5] datagrid after reducing its width', () => {
                const rowDescriptor = createRows(1);
                const colDescriptor = createCols(['foo', 'bar', 'baz', 'qwux', 'qwix']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        // all 5 rows of 20px and 5 cols of 100px viewable
                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols.length).toEqual(3);
                    expect(cols).toEqual(['foo', 'bar', 'baz']);

                    // assert rendering
                    const cellNodes = wrapper.find('.reactgrid-cell');
                    expect(cellNodes.length).toEqual(3);
                }

                wrapper.setProps({
                    width: 301,
                });
                wrapper.update();

                assertions();
            });

            it('should cull LAST 2 rows AND 2 cols from a [5x5] datagrid after updating its size', () => {
                const rowDescriptor = createRows(5);
                const colDescriptor = createCols(['foo', 'bar', 'baz', 'qwux', 'qwix']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        cullRatio={0}

                        // all 5 rows of 20px and 5 cols of 100px viewable
                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols.length).toEqual(3);
                    expect(cols).toEqual(['foo', 'bar', 'baz']);
                    expect(rows.length).toEqual(3);
                    expect(rows).toEqual(['0', '1', '2']);

                    // assert rendering
                    const cellNodes = wrapper.find('.reactgrid-cell');
                    expect(cellNodes.length).toEqual(9);
                }

                wrapper.setProps({
                    height: 60,
                    width: 351, // account for scrollbars
                });
                wrapper.update();

                assertions();
            });
        });
    });
});
