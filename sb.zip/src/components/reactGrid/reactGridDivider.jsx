import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import Icon from 'src/components/icon/icon';
import Button from 'src/components/button/button';
import Touchable from 'src/components/touchable/touchable';
import Localization from 'src/localization';
import { bindHandlers } from 'src/utils/bindHandlers';

class ReactGridDivider extends React.Component {

    handleTap(evt) {
        const {
            isStatic,
            onTap,
        } = this.props;

        if (isStatic) {
            return;
        }

        onTap(evt, this.props);
    }

    render() {
        const {
            isExpanded,
            isStatic,
            sectionHeader,
            className,
        } = this.props;

        const title = this.props.title || (isExpanded ?
            Localization.getText('HTML5_CollapseThisGroup') :
            Localization.getText('HTML5_ExpandThisGroup'));

        let button = false;

        if (!isStatic) {
            button = (
                <Button className="btn--link">
                    <Icon title={title} type={isExpanded ? 'toggleclose' : 'toggleopen'}/>
                </Button>
            );
        }

        return (
            <Touchable onTap={this.handleTap}>
                <div className={classNames('grid grid--fit-all', { 'grid--seriessm': isStatic }, className)}>
                    <div className="grid-cell">{button}</div>
                    <div className="grid-cell">{sectionHeader}</div>
                </div>
            </Touchable>
        );
    }
}

ReactGridDivider.propTypes = {
    id: PropTypes.string.isRequired,
    level: PropTypes.number,
    title: PropTypes.string,
    isExpanded: PropTypes.bool.isRequired,
    isStatic: PropTypes.bool,
    sectionHeader: PropTypes.string.isRequired,
    className: PropTypes.string,
    onTap: PropTypes.func,
};

ReactGridDivider.defaultProps = {
    title: '',
    onTap: _.noop,
    isStatic: false,
};

export default bindHandlers(ReactGridDivider);
