import _ from 'lodash';

/**
 * Factory to generate column descriptors
 * @param ids {Array} - List of column keys
 * @param optn {Hash} - Column descriptor overrides, keyed by column
 *
 * @example
 *  createCols(['foo', 'bar'], {
 *      'bar': {
 *          isEnabled: false
 *      }
 *  });
 */
export function createCols(ids, optn) {
    return _.map(ids, (id) => _.assign({ id }, {
        width: 100,
        header: _.noop,
        template: _.noop,
    }, (optn && optn[id] || {})));
}

/**
 * Factory to generate row descriptors.
 *
 * Proxies _.range, so refer to https://lodash.com/docs#range for docs.
 */
export function createRows(...args) {
    return _.map(_.range(...args), String);
}

export function createRowsAsObjects(...args) {
    return _.map(_.range(...args), (id) => ({ id: String(id) }));
}
