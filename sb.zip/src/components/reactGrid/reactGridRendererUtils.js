import _ from 'lodash';
import React from 'react';

export const getPrimaryHeaderTestClass = (column) => column ? `tst-col-header-${column.tstId || column.id}` : '';

export const getSecondaryHeaderTestClass = (column) => {
    if (!column) {
        return '';
    }
    return column.tstSecondaryId ? `tst-col-header-${column.tstSecondaryId}` : `tst-col-header-secondary-${column.id}`;
};

export const getPrimaryItemTestClass = (column) => column ? `tst-col-item-${column.tstId || column.id}` : '';

export const getSecondaryItemTestClass = (column) => {
    if (!column) {
        return '';
    }
    return column.tstSecondaryId ? `tst-col-item-${column.tstSecondaryId}` : `tst-col-item-secondary-${column.id}`;
};

export const createRenderer = (template, props) => {

    // React inline component
    if (React.isValidElement(template)) {
        return React.cloneElement(template, props);
    }

    // React component class
    const prototype = _.get(template, 'prototype', {});
    if (prototype.isPureReactComponent || prototype.isReactComponent) {
        return React.createElement(template, props);
    }

    // Callback
    if (_.isFunction(template)) {
        return template(props);
    }

    return template;
};

export const findRowIndexByOffset = (offset, rows) => {
    // delta index
    let deli = rows.length - 1;

    // base to add the delta index
    let base = 0;

    while (deli > 0 && rows[base + deli].topOffset > offset) {
        // bitwise operator used for performance reason instead of Math.floor
        // http://rocha.la/JavaScript-bitwise-operators-in-practice
        deli = ~~(deli / 2);
        if (rows[base + deli].topOffset < offset) {
            base += deli;
        }
    }

    return base + deli;
};
