/**
 * <ReactGrid/> verify scroll tests
 */

import $ from 'jqueryAll';
import _ from 'lodash';
import React from 'react';
import ReactGrid from 'src/components/reactGrid/reactGrid';
import ReactGridRows from 'src/components/reactGrid/reactGridRows';
import { createCols, createRows } from './reactGridSpecHelper';
import { mount } from 'enzyme';

describe('src/components/reactGrid', () => {
    const SCROLL_STYLES = '.grid,.grid-cell{height:inherit;} .reactgrid-rows{overflow-y:auto;}';

    const $fixture = $('<div id="fixture"></div>');
    $(document.body).append($fixture);

    let defaultProps;
    let wrapper;

    beforeEach(() => {
        $fixture.empty();

        defaultProps = {
            isHeader: false,
            width: 501,
            height: 100,
            rowHeight: 20,
            headerHeight: 30,
        };
    });

    afterEach(() => {
        wrapper.unmount();
    });

    afterAll(() => {
        $fixture.remove();
    });

    describe('verifyScroll', () => {
        it('should skip scroll handler during scrolling, even if scrollTop differs', () => {
            const handleScrollStart = jasmine.createSpy('handleScrollStart');
            const rowDescriptor = createRows(5);
            const colDescriptor = createCols(['foo']);

            wrapper = mount((
                <div style={{ height: 61 }}>
                    <style>{SCROLL_STYLES}</style>
                    <ReactGrid
                        rows={rowDescriptor}
                        cols={colDescriptor}
                        cullRatio={0} // up to 3 rows of 20px rendered
                        onScrollStart={handleScrollStart}
                        {...defaultProps}
                    />
                </div>
            ), {
                attachTo: $fixture[0],
            });

            const rows = wrapper.find(ReactGridRows);
            const gridRowsInstance = rows.first().instance();
            const gridRowsNode = rows.first().getDOMNode();

            gridRowsNode.scrollTop = 0;
            gridRowsInstance.setState({ isScrolling: true });

            expect(handleScrollStart).not.toHaveBeenCalled();

            // simulate scrolling
            gridRowsNode.scrollTop = 20;
            gridRowsInstance.setState({ isScrolling: true });

            expect(handleScrollStart).not.toHaveBeenCalled();
        });

        it('should skip scroll handler when scrollTop is the same and not scrolling', () => {
            const handleScrollStart = jasmine.createSpy('handleScrollStart');
            const rowDescriptor = createRows(5);
            const colDescriptor = createCols(['foo']);

            wrapper = mount((
                <div style={{ height: 61 }}>
                    <style>{SCROLL_STYLES}</style>
                    <ReactGrid
                        rows={rowDescriptor}
                        cols={colDescriptor}
                        cullRatio={0} // up to 3 rows of 20px rendered
                        onScrollStart={handleScrollStart}
                        {...defaultProps}
                    />
                </div>
            ), {
                attachTo: $fixture[0],
            });

            const rows = wrapper.find(ReactGridRows);
            const gridRowsInstance = rows.first().instance();
            const gridRowsNode = rows.first().getDOMNode();

            gridRowsNode.scrollTop = 0;
            gridRowsInstance.setState({ isScrolling: false });

            expect(handleScrollStart).not.toHaveBeenCalled();
        });

        it('should invoke scroll handler when scrollTop Differs and not scrolling', (done) => {
            const handleScrollStart = jasmine.createSpy('handleScrollStart');
            const rowDescriptor = createRows(5);
            const colDescriptor = createCols(['foo']);

            wrapper = mount((
                <div style={{ height: 61 }}>
                    <style>{SCROLL_STYLES}</style>
                    <ReactGrid
                        rows={rowDescriptor}
                        cols={colDescriptor}
                        cullRatio={0} // up to 3 rows of 20px rendered
                        onScrollStart={handleScrollStart}
                        {...defaultProps}
                    />
                </div>
            ), {
                attachTo: $fixture[0],
            });

            // simulate scrolling
            const scrollableEl = wrapper.find('.reactgrid-rows').getDOMNode();
            scrollableEl.scrollTop = 10;

            // assert post-scroll state in a timeout to ensure it has been recalculated
            // setTimeout must be used instead of jasmine.clock as native scroll doesn't
            // rely on the browser's setTimeout method.
            setTimeout(function() {
                expect(handleScrollStart).toHaveBeenCalled();
                done();
            }, 500);
        });

        it('should not recalculate rows to render if scollDistance < minRowHeight', (done) => {
            let rows = [];
            const rowDescriptor = createRows(5);
            const colDescriptor = createCols(['foo']);

            const handleRowReflow = jasmine.createSpy().and.callFake((evt) => {
                rows = evt;
            });

            wrapper = mount((
                <div style={{ height: 61 }}>
                    <style>{SCROLL_STYLES}</style>
                    <ReactGrid
                        rows={rowDescriptor}
                        cols={colDescriptor}
                        cullRatio={0} // up to 3 rows of 20px rendered
                        onRowReflow={handleRowReflow}
                        {...defaultProps}
                    />
                </div>
            ), {
                attachTo: $fixture[0],
            });

            // assert state
            expect(rows.length).toEqual(3);
            expect(rows).toEqual(['0', '1', '2']);

            // assert rendering
            let cellNodes = wrapper.find('.reactgrid-cell');
            expect(cellNodes.length).toEqual(3);

            // simulate scrolling
            const scrollableEl = wrapper.find('.reactgrid-rows').getDOMNode();
            scrollableEl.scrollTop = 10;

            // assert post-scroll state in a timeout to ensure it has been recalculated
            // setTimeout must be used instead of jasmine.clock as native scroll doesn't
            // rely on the browser's setTimeout method.
            setTimeout(function() {
                // assert state
                expect(rows).toEqual(['0', '1', '2']);

                // assert rendering
                cellNodes = wrapper.find('.reactgrid-cell');
                expect(cellNodes.length).toEqual(3);
                done();
            }, 500);
        });

        it('should recalculate rows to render if scollDistance > minRowHeight', (done) => {
            let rows = [];
            const rowDescriptor = createRows(5);
            const colDescriptor = createCols(['foo']);

            const handleRowReflow = jasmine.createSpy().and.callFake((evt) => {
                rows = evt;
            });

            wrapper = mount((
                <div style={{ height: 61 }}>
                    <style>{SCROLL_STYLES}</style>
                    <ReactGrid
                        rows={rowDescriptor}
                        cols={colDescriptor}
                        cullRatio={0} // up to 3 rows of 20px rendered
                        onRowReflow={handleRowReflow}
                        {...defaultProps}
                    />
                </div>
            ), {
                attachTo: $fixture[0],
            });

            // assert state
            expect(rows.length).toEqual(3);
            expect(rows).toEqual(['0', '1', '2']);

            // assert rendering
            let cellNodes = wrapper.find('.reactgrid-cell');
            expect(cellNodes.length).toEqual(3);

            // simulate scrolling
            const scrollableEl = wrapper.find('.reactgrid-rows').getDOMNode();
            scrollableEl.scrollTop = 20;

            // assert post-scroll state in a timeout to ensure it has been recalculated
            // setTimeout must be used instead of jasmine.clock as native scroll doesn't
            // rely on the browser's setTimeout method.
            setTimeout(function() {
                // assert state
                expect(_.union(rows, ['1', '2', '3'])).toEqual(rows);

                // assert rendering
                cellNodes = wrapper.find('.reactgrid-cell');
                expect(cellNodes.length).toEqual(3);
                done();
            }, 500);
        });
    });
});
