import _ from 'lodash';
import DefaultHeaderRenderer from './blocks/defaultHeaderRenderer';
import DefaultCellRenderer from './blocks/defaultCellRenderer';

export default {
    minWidth: 0,
    maxWidth: 0,
    align: 'none',
    isCellFit: false,
    isEnabled: true,
    header: DefaultHeaderRenderer,
    template: DefaultCellRenderer,
    onHeaderTap: _.noop,
    onHeaderSort: _.noop,

    // Optional tst id which is used instead of column.id
    tstId: null,

    // Optional secondary tst id which is used instead of column.id for secondary items (if present).
    tstSecondaryId: null,
};
