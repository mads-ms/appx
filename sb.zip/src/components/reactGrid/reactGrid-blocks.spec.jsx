import React from 'react';
import { mount } from 'enzyme';
import { DelayBeta } from 'src/components/reactGrid/reactGridBlocks';
import Enums from 'src/spine/enums';

describe('src/components/reactGrid/reactGridBlocks', () => {
    let wrapper;

    afterEach(function() {
        wrapper.unmount();
    });

    describe('<DelayBeta />', () => {
        it('renders successfully with icon', () => {
            const testProps = {
                column: {},
                priceType: Enums.PriceAccessType.Delayed,
            };

            wrapper = mount(<DelayBeta {...testProps}/>);
            expect(wrapper.find('.icon').length).toEqual(1);
            expect(wrapper.find('.icon--delay').length).toEqual(1);
        });

        it('renders successfully without icon', () => {
            const testProps = {
                column: {},
                priceType: null,
            };

            wrapper = mount(<DelayBeta {...testProps}/>);

            expect(wrapper.find('.icon').length).toEqual(0);
        });

        it('renders successfully with price type and placeholder', () => {
            const testProps = {
                column: {},
                priceType: Enums.PriceAccessType.NoAccess,
                isPlaceholder: true,
            };

            wrapper = mount(<DelayBeta {...testProps}/>);

            expect(wrapper.find('.is-hidden').length).toEqual(0);
            expect(wrapper.find('.icon').length).toEqual(1);
            expect(wrapper.find('.icon--noprice').length).toEqual(1);
        });

        it('renders successfully without price type and placeholder', () => {
            const testProps = {
                column: {},
                priceType: null,
                isPlaceholder: true,
            };

            wrapper = mount(<DelayBeta {...testProps}/>);

            expect(wrapper.find('i.is-hidden').length).toEqual(1);
            expect(wrapper.find('i.icon').length).toEqual(1);
            expect(wrapper.find('i.icon--delay').length).toEqual(1);
        });
    });
});
