import _ from 'lodash';
import * as constants from './constants';

// assign base column priorities for culling if not supplied by consumer
export function assignColumnPriorities(cols) {
    _.forEach(cols, (col) => {
        if (!col.priority) {
            col.priority = (col.isFixedEnd || col.isFixedStart) ?
                constants.FIXED_COL_PRIORITY :
                constants.DEFAULT_COL_PRIORITY;
        }
    });

    return cols;
}

// Compute column offsets based on column width, relative to aligned edge.
// Used to layout cells next to each other.
export function assignLtrColumnOffsets(cols) {
    let sum = 0;

    _.forEach(cols, (col) => {
        col.offset = Math.round(sum);
        sum += (col.width || col.minWidth || 0);
    });

    return cols;
}

// Compute column offsets based on column width, relative to a central column.
//  - Column order is determined to proximity to the central column, rather than
//    aligned edge (i.e. LTR/RTL).
//  - Initial column ordering of a,b,c,center,d,e,f will be rendered:
//    c,b,a,center,d,e,f.
export function assignCenterColumnOffsets(cols, width, centerColumnId) {
    const centerX = width / 2;
    const centerIndex = _.indexOf(_.map(cols, 'id'), centerColumnId);

    if (centerIndex < 0) {
        return assignLtrColumnOffsets(cols);
    }

    // generate vanilla offsets for columns either side of the central column
    const centerColumn = cols[centerIndex];
    const leftSide = _.reverse(_.slice(cols, 0, centerIndex));
    const rightSide = _.slice(cols, centerIndex + 1);

    const leftSideRelativeOffsets = assignLtrColumnOffsets(leftSide);
    const rightSideRelativeOffsets = assignLtrColumnOffsets(rightSide);

    // recompute offsets in relation to center column
    //  - reverse() for left-hand side makes source order correct
    centerColumn.offset = Math.round(centerX - centerColumn.width / 2);
    const leftSideOffsets = _.reverse(_.map(leftSideRelativeOffsets, (col) => _.set(col, 'offset', centerColumn.offset - col.offset - col.width)));
    const rightSideOffsets = _.map(rightSideRelativeOffsets, (col) => _.set(col, 'offset', centerColumn.offset + centerColumn.width + col.offset));

    const allOffsets = _.concat(leftSideOffsets, centerColumn, rightSideOffsets);
    const offsetsWithExpandAligned = _.map(allOffsets, (col) => col.id === constants.EXPAND_COLUMN_ID ? _.set(col, 'offset', 0) : col);

    return offsetsWithExpandAligned;
}

export function isFlexColumn(col) {
    return Boolean(col.maxWidth) && !col.width;
}

export function getAggregatedColumnWidth(cols) {
    return _.sum(_.map(cols, (col) => col.minWidth || col.width));
}

// assign any remaining space for showing columns to flexcolumn
export function assignFlexColumnWidths(cols, width) {
    const allVisibleColumnsWidth = getAggregatedColumnWidth(cols);
    const flexColumns = _.filter(cols, isFlexColumn);
    const remainingWidth = (width - allVisibleColumnsWidth) / Math.max(flexColumns.length, 1);

    _.forEach(flexColumns, (col) => {
        col.width = Math.min(col.minWidth + remainingWidth, col.maxWidth);
    });

    return cols;
}
