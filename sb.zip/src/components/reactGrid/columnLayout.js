import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import * as columnUtils from './reactGridColumnUtils';
import * as constants from './constants';
import defaultColumn from './reactGridDefaultColumn';

/**
 * Encapsulated Column layout generation.
 */
class ColumnLayout extends React.PureComponent {
    constructor() {
        super();

        this.state = {
            columns: [],
        };
    }

    componentDidMount() {
        this.setColumns(this.props);
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.isRtl !== this.props.isRtl ||
            nextProps.isGrouping !== this.props.isGrouping ||
            nextProps.width !== this.props.width ||
            nextProps.columns !== this.props.columns) {

            this.setColumns(nextProps);
        }
    }

    componentWillUpdate(nextProps, nextState) {
        this.verifyColReflow(this.state.columns, nextState.columns, nextProps.onVisibleColumnsChange);
    }

    setColumns(props) {
        const columns = this.getColumns(props, props.width - 1);
        this.props.onColumnsChange(columns);
        this.setState({ columns });
    }

    /**
     * Obtains a column descriptor for <ExpandButton/>.
     */
    getExpandColumn() {
        return {
            id: constants.EXPAND_COLUMN_ID,
            width: 25,
            isEnabled: true,
            align: 'center',
            isAlwaysVisible: true,
            template: this.props.expandButtonTemplate,
        };
    }

    /**
     * Obtains column styles for laying out cells depending on the component
     * phase and runtime.
     *
     * @param column {Object} - Column descriptor
     * @returns {Object} - Style hash
     */
    getColumnStyles(column) {
        // Absolute positioning:
        // - Used for some UAs (e.g. iOS) as they cannot handle painting translated cells
        //   when scrolling fast (flickering at edges).
        // - Required as empty cells are not rendered. That is, rows can be partial
        //   in nature (e.g. summaries in dividers), but the cell still needs to
        //   line-up in the correct column.
        const direction = this.props.isRtl ? 'right' : 'left';

        return {
            position: 'absolute',
            top: 0,
            [direction]: column.offset,
            width: column.width || 'auto',
            height: '100%',
            overflow: 'hidden',
        };
    }

    /**
     * Obtains a hash keyed by class name with Boolean values for render().
     *
     * @param   {Object} col
     * @returns {Object} Class name object for render
     */
    getColumnClasses(col) {
        return {
            [constants.TEXT_END_CLASS]: Boolean(col.align === 'end'),
            [constants.TEXT_START_CLASS]: Boolean(col.align === 'start'),
            [constants.TEXT_CENTER_CLASS]: Boolean(col.align === 'center'),
            [constants.CELL_FIT_CLASS]: Boolean(col.isCellFit),
            [constants.CELL_FIRST_CHILD_CLASS]: Boolean(col.isFirstChild),
            [constants.CELL_LAST_CHILD_CLASS]: Boolean(col.isLastChild),
            [col.classes]: Boolean(col.classes),
            ['tst-sort-' + col.sortKey]: Boolean(col.sortKey),
        };
    }

    /**
     * Pins columns to the start and end of a row if specified by the consumer.
     *
     * @param props {Object} - React instance property hash
     * @param columns {Array} - Array of column descriptors
     * @param width {Number} - Available width in pixels
     *
     * @returns {Array} - Augmented array of columns
     */
    getSortedColumns(props, columns, width) {
        const { isGrouping, centerColumnId } = props;
        const assignColumnOffsets = centerColumnId ? columnUtils.assignCenterColumnOffsets : columnUtils.assignLtrColumnOffsets;

        // sort columns in specified order
        //  - move fixed columns to start and end of ordering respectively
        const visibleColumnsMap = _.keyBy(columns, 'id');
        const fixedStartColumns = _.filter(columns, 'isFixedStart');
        const fixedEndColumns = _.filter(columns, 'isFixedEnd');
        const expandColumn = _.find(columns, { id: constants.EXPAND_COLUMN_ID });
        const dynamicColumns = _.difference(columns, fixedStartColumns, fixedEndColumns, [expandColumn]);
        const columnsInView = _.concat(expandColumn, fixedStartColumns, dynamicColumns, fixedEndColumns);

        const sortedColumnsInView = _.chain(columnsInView)
            .map('id')
            .map((id) => visibleColumnsMap[id])
            .compact()
            .value();

        // recalculate offsets as order has changed
        const sortedColumnsWithOffset = assignColumnOffsets(sortedColumnsInView, width, centerColumnId);

        // Add default flags for column order
        // - used to add CSS hooks to the cell for styling.
        const sortedColumns = _.map(sortedColumnsWithOffset, (col) => {
            col.isFirstChild = false;
            col.isLastChild = false;
            return col;
        });

        // account for row groupings where the expand button is the technical
        // first child, but the hook should be added to the first "content"
        // column (aka the second column in the sorted order).
        if (sortedColumns.length) {
            const firstIndex = isGrouping && sortedColumns.length > 1 ? 1 : 0;

            sortedColumns[firstIndex].isFirstChild = true;
            _.last(sortedColumns).isLastChild = true;
        }

        return sortedColumns;
    }

    /**
     * Determines which columns appear in the available space.
     *
     * @param props {Object} - React instance property hash
     * @param columns {Array} - Array of column descriptors
     * @param width {Number} - Available width in pixels
     *
     * @returns {Array} - Augmented array of columns
     */
    getColumnsInView(props, columns, width) {
        const { centerColumnId } = props;
        const assignColumnOffsets = centerColumnId ? columnUtils.assignCenterColumnOffsets : columnUtils.assignLtrColumnOffsets;

        // group columns by priority for culling
        const columnPriorityGroups = _.chain(columns)
            .thru(columnUtils.assignColumnPriorities)
            .groupBy('priority')
            .sortBy('priority')
            .reverse()
            .value();

        // determine visible columns according to group priority
        const allColumnWidth = columnUtils.getAggregatedColumnWidth(columns);

        let columnsInView = columns;
        let accountedForWidth = 0;

        _.forEach(columnPriorityGroups, (columnGroup) => {
            if (_.head(columnGroup).priority === constants.FIXED_COL_PRIORITY) {
                return false;
            }

            const columnGroupWidth = columnUtils.getAggregatedColumnWidth(columnGroup);
            const higherPriorityColumnWidth = allColumnWidth - accountedForWidth - columnGroupWidth;

            // no space for the group so just cull, else see if space for any columns in group
            if (higherPriorityColumnWidth >= width) {
                columnsInView = _.difference(columnsInView, columnGroup);
                accountedForWidth += columnGroupWidth;
            } else {
                const columnGroupWithOffsets = assignColumnOffsets(columnGroup, width, centerColumnId);
                const columnGroupNotInView = _.filter(columnGroupWithOffsets, (column) =>
                    (column.offset + column.width) > (width - higherPriorityColumnWidth) || column.offset < 0
                );

                if (columnGroupNotInView.length) {
                    columnsInView = _.difference(columnsInView, columnGroupNotInView);
                }

                return false;
            }
        });

        return columnsInView;
    }

    /**
     * Obtains the columns to be rendered, accounting for available space,
     * whether they are enabled, and groupings.
     *
     * @param props {Object} - React instance property hash
     * @param width {Number} - Available width in pixels
     *
     * @returns {Array} - Columns to be rendered
     */
    getColumns(props, width) {
        let { columns } = props;
        const { isGrouping } = props;

        columns = this.getEnabledColumns(columns);

        if (isGrouping) {
            columns.unshift(this.getExpandColumn());
        }

        let columnsInView = this.getColumnsInView(props, columns, width);

        columnsInView = columnUtils.assignFlexColumnWidths(columnsInView, width);
        columnsInView = this.getSortedColumns(props, columnsInView, width);

        return _.map(columnsInView, (col) => _.defaults({
            classes: this.getColumnClasses(col),
            styles: this.getColumnStyles(col),
        }, col));
    }

    getEnabledColumns(columns) {
        return _.chain(columns)
            .map((column) => {

                // normalize itemToLabel to be always array or label functions
                if (_.isFunction(column.itemToLabel)) {
                    column.itemToLabel = [column.itemToLabel];
                }
                return _.defaults(column, defaultColumn);
            })
            .filter('isEnabled')
            .map(_.clone)
            .value();
    }

    /**
     * Determines if columns have changed, and if so emits the `onVisibleColumnsChange` event.
     */
    verifyColReflow(prevStateColumns, stateColumns, callback) {
        if (stateColumns !== prevStateColumns) {
            // column ordering can remain constant even if widths change due to
            // scrollbar appearance and/or flexi-columns, so assert true colonReflowchange
            // before emitting signal.
            const prevCols = _.map(prevStateColumns, 'id');
            const nextCols = _.map(stateColumns, 'id');
            if (!_.isEqual(prevCols, nextCols)) {
                callback(nextCols, stateColumns);
            }
        }
    }

    render() {
        return null;
    }
}

ColumnLayout.propTypes = {

    // List of columns definitions
    columns: PropTypes.array.isRequired,

    // Calculated width
    width: PropTypes.number.isRequired,
    isRtl: PropTypes.bool,
    isGrouping: PropTypes.bool,

    // Template for expand button. Signature: ({ rowId, rowData, rowInfo }):ReactElement
    expandButtonTemplate: PropTypes.func,
    centerColumnId: PropTypes.string,

    // Invoked after list of visible columns changes. Signature: (columnIds:Array):void
    onVisibleColumnsChange: PropTypes.func,

    // Invoked after list of columns objects changes. Signature: (columns:Array):void
    onColumnsChange: PropTypes.func,
};

ColumnLayout.defaultProps = {
    expandButtonTemplate: _.noop,
    onVisibleColumnsChange: _.noop,
    onColumnsChange: _.noop,
};

export default ColumnLayout;
