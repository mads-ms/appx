/**
 * <ReactGrid/> flexible columns unit tests
 */
import $ from 'jqueryAll';
import _ from 'lodash';
import React from 'react';
import ReactGrid from 'src/components/reactGrid/reactGrid';
import DefaultHeaderRenderer from 'src/components/reactGrid/blocks/defaultHeaderRenderer';
import { createCols, createRows } from './reactGridSpecHelper';
import { mount } from 'enzyme';

describe('src/components/reactGrid', () => {
    describe('flexible columns', () => {
        // assertion state
        let cols;
        let wrapper;
        let handleColReflow;

        // controlled state setup before each test
        let defaultProps;

        beforeEach(() => {
            cols = null;
            handleColReflow = jasmine.createSpy().and.callFake((evt) => {
                cols = evt;
            });

            defaultProps = {
                isHeader: false,
                width: 501,
                height: 100,
                rowHeight: 20,
                headerHeight: 30,
            };
        });

        afterEach(() => {
            wrapper.unmount();
        });

        it('should use default props for columns', () => {
            const rowDescriptor = createRows(1);
            const colDescriptor = [{
                id: 'foo',
                template: _.noop,
            }, {
                id: 'bar',
                template: _.noop,
            }];

            let columnIds = null;
            let realColumns = null;

            const onCollReflow = (colIds, realCols) => {
                columnIds = colIds;
                realColumns = realCols;
            };

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}

                    // capture internal state reporting
                    onColReflow={onCollReflow}

                    {...defaultProps}
                />
            );

            function assertions() {
                // assert state
                expect(columnIds.length).toEqual(2);
                expect(columnIds).toEqual(['foo', 'bar']);

                // assert rendering
                const cellNodes = wrapper.find('.reactgrid-cell');

                _.forEach(realColumns, (col) => {
                    expect(col).toEqual(
                        jasmine.objectContaining({
                            minWidth: 0,
                            maxWidth: 0,
                            align: 'none',
                            isCellFit: false,
                            isEnabled: true,
                            header: DefaultHeaderRenderer,
                        })
                    );
                });

                expect(cellNodes.length).toEqual(2);
                expect($(cellNodes.at(0).getDOMNode()).width()).toEqual(0);
                expect($(cellNodes.at(1).getDOMNode()).width()).toEqual(0);
            }

            assertions();
        });

        it('should not override provided props', () => {
            const rowDescriptor = createRows(1);
            const colDescriptor = [{
                id: 'foo',
                width: 40,
                template: _.noop,
                header: _.noop,
                isSortable: false,
            }, {
                id: 'bar',
                width: 40,
                template: _.noop,
                header: _.noop,
                isSortable: false,
            }];

            let columnIds = null;
            let realColumns = null;

            const onCollReflow = (colIds, realCols) => {
                columnIds = colIds;
                realColumns = realCols;
            };

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}

                    // capture internal state reporting
                    onColReflow={onCollReflow}

                    {...defaultProps}
                />
            );

            function assertions() {
                // assert state
                expect(columnIds.length).toEqual(2);
                expect(columnIds).toEqual(['foo', 'bar']);

                // assert rendering
                const cellNodes = wrapper.find('.reactgrid-cell');

                _.forEach(realColumns, (col) => {
                    expect(col).toEqual(
                        jasmine.objectContaining({
                            width: 40,
                            minWidth: 0,
                            maxWidth: 0,
                            align: 'none',
                            isCellFit: false,
                            isEnabled: true,
                            isSortable: false,
                            header: _.noop,
                        })
                    );
                });

                expect(cellNodes.length).toEqual(2);
                expect($(cellNodes.at(0).getDOMNode()).width()).toEqual(40);
                expect($(cellNodes.at(1).getDOMNode()).width()).toEqual(40);
            }

            assertions();
        });

        it('should NOT adjust any flexible column in a [1x5] datagrid when fit perfectly', () => {
            const rowDescriptor = createRows(1);
            const colDescriptor = createCols(['foo', 'bar', 'baz', 'qwux', 'qwix'],
                {
                    'foo': {
                        'width': null,
                        'minWidth': 100,
                        'maxWidth': 200,
                    },
                }
            );

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}

                    // capture internal state reporting
                    onColReflow={handleColReflow}

                    {...defaultProps}
                />
            );

            function assertions() {
                // assert state
                expect(cols.length).toEqual(5);
                expect(cols).toEqual(['foo', 'bar', 'baz', 'qwux', 'qwix']);

                // assert rendering
                const cellNodes = wrapper.find('.reactgrid-cell');

                expect(cellNodes.length).toEqual(5);
                expect($(cellNodes.at(0).getDOMNode()).width()).toEqual(100);
                expect($(cellNodes.at(1).getDOMNode()).width()).toEqual(100);
                expect($(cellNodes.at(2).getDOMNode()).width()).toEqual(100);
                expect($(cellNodes.at(3).getDOMNode()).width()).toEqual(100);
                expect($(cellNodes.at(4).getDOMNode()).width()).toEqual(100);
            }

            assertions();
        });

        it('should maximise any flexible column when space', () => {
            const rowDescriptor = createRows(1);
            const colDescriptor = createCols(['foo'],
                {
                    'foo': {
                        'width': null,
                        'minWidth': 100,
                        'maxWidth': 200,
                    },
                }
            );

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}

                    // capture internal state reporting
                    onColReflow={handleColReflow}

                    // grid width more than enough to display full column
                    {...defaultProps}
                />
            );

            function assertions() {
                // assert state
                expect(cols.length).toEqual(1);
                expect(cols).toEqual(['foo']);

                // assert rendering
                const cellNodes = wrapper.find('.reactgrid-cell');

                expect(cellNodes.length).toEqual(1);
                expect($(cellNodes.at(0).getDOMNode()).width()).toEqual(200);
            }

            assertions();
        });

        it('should distribute available space between multiple flexible columns evenly', () => {
            const rowDescriptor = createRows(1);
            const colDescriptor = createCols(['foo', 'bar'],
                {
                    'foo': {
                        'width': null,
                        'minWidth': 100,
                        'maxWidth': 300,
                    },
                    'bar': {
                        'width': null,
                        'minWidth': 100,
                        'maxWidth': 300,
                    },
                }
            );

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}

                    // capture internal state reporting
                    onColReflow={handleColReflow}

                    // grid width more than enough to display full column
                    {...defaultProps}
                />
            );

            function assertions() {
                // assert state
                expect(cols.length).toEqual(2);
                expect(cols).toEqual(['foo', 'bar']);

                // assert rendering
                const cellNodes = wrapper.find('.reactgrid-cell');

                expect(cellNodes.length).toEqual(2);
                expect($(cellNodes.at(0).getDOMNode()).width()).toEqual(250);
                expect($(cellNodes.at(1).getDOMNode()).width()).toEqual(250);
            }

            assertions();
        });

        it('should adjust any flexible column in a [1x5] datagrid with decreased width constraint', () => {
            const rowDescriptor = createRows(1);
            const colDescriptor = createCols(['foo', 'bar', 'baz', 'qwux', 'qwix'],
                {
                    'foo': {
                        'width': null,
                        'minWidth': 100,
                        'maxWidth': 200,
                    },
                }
            );

            // reduce width (culls one column)
            defaultProps.width = 451;

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}
                    isHeader={false}

                    // capture internal state reporting
                    onColReflow={handleColReflow}

                    {...defaultProps}
                />
            );

            function assertions() {
                // assert state
                expect(cols.length).toEqual(4);
                expect(cols).toEqual(['foo', 'bar', 'baz', 'qwux']);

                // assert rendering
                const cellNodes = wrapper.find('.reactgrid-cell');

                expect(cellNodes.length).toEqual(4);
                expect($(cellNodes.at(0).getDOMNode()).width()).toEqual(150);
                expect($(cellNodes.at(1).getDOMNode()).width()).toEqual(100);
                expect($(cellNodes.at(2).getDOMNode()).width()).toEqual(100);
                expect($(cellNodes.at(3).getDOMNode()).width()).toEqual(100);
            }

            assertions();
        });

        it('should adjust any flexible column in a [1x5] datagrid with increased width constraint', () => {
            const rowDescriptor = createRows(1);
            const colDescriptor = createCols(['foo', 'bar', 'baz', 'qwux', 'qwix'],
                {
                    'foo': {
                        'width': null,
                        'minWidth': 100,
                        'maxWidth': 200,
                    },
                }
            );

            // increase width (culls one column)
            defaultProps.width = 551;

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}
                    isHeader={false}

                    // capture internal state reporting
                    onColReflow={handleColReflow}

                    {...defaultProps}
                />
            );

            function assertions() {
                // assert state
                expect(cols.length).toEqual(5);
                expect(cols).toEqual(['foo', 'bar', 'baz', 'qwux', 'qwix']);

                // assert rendering
                const cellNodes = wrapper.find('.reactgrid-cell');

                expect(cellNodes.length).toEqual(5);
                expect($(cellNodes.at(0).getDOMNode()).width()).toEqual(150);
                expect($(cellNodes.at(1).getDOMNode()).width()).toEqual(100);
                expect($(cellNodes.at(2).getDOMNode()).width()).toEqual(100);
                expect($(cellNodes.at(3).getDOMNode()).width()).toEqual(100);
                expect($(cellNodes.at(4).getDOMNode()).width()).toEqual(100);
            }

            assertions();
        });

        it('should adjust any flexible column in a [1x5] datagrid when a column is enabled', () => {
            const rowDescriptor = createRows(1);
            const colDescriptor = createCols(['foo', 'bar', 'baz', 'qwux', 'qwix'],
                {
                    'foo': {
                        'width': null,
                        'minWidth': 100,
                        'maxWidth': 200,
                    },
                    'qwux': {
                        isEnabled: false,
                    },
                }
            );

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}

                    // capture internal state reporting
                    onColReflow={handleColReflow}

                    {...defaultProps}
                />
            );

            function assertions() {
                // assert state
                expect(cols.length).toEqual(5);
                expect(cols).toEqual(['foo', 'bar', 'baz', 'qwux', 'qwix']);

                // assert rendering
                const cellNodes = wrapper.find('.reactgrid-cell');

                expect(cellNodes.length).toEqual(5);
                expect($(cellNodes.at(0).getDOMNode()).width()).toEqual(100);
                expect($(cellNodes.at(1).getDOMNode()).width()).toEqual(100);
                expect($(cellNodes.at(2).getDOMNode()).width()).toEqual(100);
                expect($(cellNodes.at(3).getDOMNode()).width()).toEqual(100);
                expect($(cellNodes.at(4).getDOMNode()).width()).toEqual(100);
            }

            wrapper.setProps({
                cols: createCols(['foo', 'bar', 'baz', 'qwux', 'qwix'],
                    {
                        'foo': {
                            'width': null,
                            'minWidth': 100,
                            'maxWidth': 200,
                        },
                        'qwux': {
                        } }),
            });
            wrapper.update();

            assertions();
        });

        it('should adjust any flexible column in a [1x5] datagrid when a column is disabled', () => {
            const rowDescriptor = createRows(1);
            const colDescriptor = createCols(['foo', 'bar', 'baz', 'qwux', 'qwix'],
                {
                    'foo': {
                        'width': null,
                        'minWidth': 100,
                        'maxWidth': 200,
                    },
                    'qwux': {
                    } });

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}

                    // capture internal state reporting
                    onColReflow={handleColReflow}

                    {...defaultProps}
                />
            );

            function assertions() {
                // assert state
                expect(cols.length).toEqual(4);
                expect(cols).toEqual(['foo', 'bar', 'baz', 'qwix']);

                // assert rendering
                const cellNodes = wrapper.find('.reactgrid-cell');

                expect(cellNodes.length).toEqual(4);
                expect($(cellNodes.at(0).getDOMNode()).width()).toEqual(200);
                expect($(cellNodes.at(1).getDOMNode()).width()).toEqual(100);
                expect($(cellNodes.at(2).getDOMNode()).width()).toEqual(100);
                expect($(cellNodes.at(3).getDOMNode()).width()).toEqual(100);
            }

            wrapper.setProps({
                cols: createCols(['foo', 'bar', 'baz', 'qwux', 'qwix'],
                    {
                        'foo': {
                            'width': null,
                            'minWidth': 100,
                            'maxWidth': 200,
                        },
                        'qwux': {
                            isEnabled: false,
                        } }),
            });
            wrapper.update();

            assertions();
        });
    });
});
