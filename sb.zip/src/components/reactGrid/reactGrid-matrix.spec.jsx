/**
 * <ReactGrid/> Unit tests
 *
 * - Full DOM rendering takes place as child components such
 *   as <ReactGridRows/> and <ReactGridRow/> are not rendered
 *   in isolation.
 * - Assertions performed on both reported internal state (i.e.
 *   event bodies emitted from the component regarding row and
 *   column reflows), and the actual rendered state.
 * - This ensures that the two are in fact in sync, and that the
 *   reported display is accurate.
 *
 * TODO:
 *  - Improve onRowReflow event instead of via debouncing.
 *  - Move row select to ReactGridRows test
 */
import $ from 'jqueryAll';
import { tap } from 'test/mocks/touchableHelper';
import React from 'react';
import ReactGrid from 'src/components/reactGrid/reactGrid';
import { createCols, createRows } from './reactGridSpecHelper';
import { mount } from 'enzyme';

describe('src/components/reactGrid', () => {
    describe('matrix', () => {
        // some assertions require a real *rendered* DOM for introspection,
        // mainly in relation to content measurements for header+row heights.
        const $fixture = $('<div id="fixture"></div>');
        $(document.body).append($fixture);

        // assertion state
        let cols;
        let rows;
        let wrapper;
        let handleColReflow;
        let handleRowReflow;

        // controlled state setup before each test
        let defaultProps;

        beforeEach(() => {
            cols = [];
            rows = [];
            $fixture.empty();

            defaultProps = {
                isHeader: false,
                width: 501,
                height: 100,
                rowHeight: 20,
                headerHeight: 30,
            };

            handleColReflow = jasmine.createSpy().and.callFake((evt) => {
                cols = evt;
            });
            handleRowReflow = jasmine.createSpy().and.callFake((evt) => {
                rows = evt;
            });
        });

        afterEach(() => {
            wrapper.unmount();
        });

        afterAll(() => {
            $fixture.remove();
        });

        describe('basic', () => {

            it('should render a datagrid with NO rows when none specified', () => {
                const rowDescriptor = createRows();
                const colDescriptor = createCols(['foo']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols.length).toEqual(1);
                    expect(cols).toEqual(['foo']);
                    expect(rows.length).toEqual(0);
                    expect(rows).toEqual([]);

                    // assert rendering
                    expect(wrapper.find('.reactgrid-row').length).toEqual(0);
                    expect(wrapper.find('.reactgrid-cell').length).toEqual(0);
                    expect(wrapper.find('.reactgrid-header').length).toEqual(0);
                }

                assertions();
            });

            it('should render a [5x1] datagrid in correct row order', () => {
                const rowDescriptor = createRows(5);
                const colDescriptor = createCols(['foo']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols.length).toEqual(1);
                    expect(cols).toEqual(['foo']);
                    expect(rows.length).toEqual(5);
                    expect(rows).toEqual(['0', '1', '2', '3', '4']);

                    // assert rendering
                    expect(wrapper.find('.reactgrid-row').length).toEqual(5);
                    expect(wrapper.find('.reactgrid-cell').length).toEqual(5);
                    expect(wrapper.find('.reactgrid-header').length).toEqual(0);
                }

                assertions();
            });

            it('should render a [1x5] datagrid in correct col order', () => {
                const rowDescriptor = createRows(1);
                const colDescriptor = createCols(['foo', 'bar', 'baz', 'qwux', 'qwix']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols.length).toEqual(5);
                    expect(cols).toEqual(['foo', 'bar', 'baz', 'qwux', 'qwix']);
                    expect(rows.length).toEqual(1);
                    expect(rows).toEqual(['0']);

                    // assert rendering
                    expect(wrapper.find('.reactgrid-row').length).toEqual(1);
                    expect(wrapper.find('.reactgrid-cell').length).toEqual(5);
                    expect(wrapper.find('.reactgrid-header').length).toEqual(0);
                }

                assertions();
            });
        });

        describe('header', () => {
            beforeEach(() => {
                defaultProps.isHeader = true;
            });

            it('should render a datagrid with only header', () => {
                const rowDescriptor = createRows();
                const colDescriptor = createCols(['foo', 'bar', 'baz', 'qwux', 'qwix']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader
                        hasHeaderTooltips={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols.length).toEqual(5);
                    expect(cols).toEqual(['foo', 'bar', 'baz', 'qwux', 'qwix']);

                    // assert rendering
                    expect(wrapper.find('.reactgrid-row').length).toEqual(0);
                    expect(wrapper.find('.reactgrid-cell').length).toEqual(5);
                    expect(wrapper.find('.reactgrid-header').length).toEqual(1);
                }

                assertions();
            });

            it('should decorate the header with a custom class', () => {
                const CUSTOM_HEADER_CLASS = 'header-class';
                const rowDescriptor = createRows();
                const colDescriptor = createCols(['foo']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        hasHeaderTooltips={false}
                        headerClass={CUSTOM_HEADER_CLASS}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert rendering
                    expect(wrapper.find(`.${CUSTOM_HEADER_CLASS}`).length).toEqual(1);
                }

                assertions();
            });

        });

        describe('rows', () => {

            it('should decorate rows with a custom class', () => {
                const CUSTOM_ROW_CLASS = 'row-class';
                const rowDescriptor = ['0'];
                const colDescriptor = createCols(['foo']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}
                        rowClass={CUSTOM_ROW_CLASS}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert rendering
                    expect(wrapper.find(`div.${CUSTOM_ROW_CLASS}`).length).toEqual(1);
                }

                assertions();
            });

            it('should not mutate rows when no difference in prop supplied', () => {
                const rowDescriptor = createRows(1);
                const colDescriptor = createCols(['foo']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(rows.length).toEqual(1);
                    expect(rows).toEqual(['0']);

                    // assert handler NOT invoked when data not mutated
                    expect(handleRowReflow).toHaveBeenCalledTimes(1);

                    // assert rendering
                    expect(wrapper.find('.reactgrid-row').length).toEqual(1);
                }

                // In this scenario the new rows arrive immediately after the component
                // has already rendered (so the consumer has NOT been informed).
                wrapper.setProps({
                    rows: rowDescriptor,
                });
                wrapper.update();

                assertions();
            });

            it('should add 5 initial rows in order immediately after initial render', () => {
                const rowDescriptor = createRows();
                const colDescriptor = createCols(['foo']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(rows.length).toEqual(5);
                    expect(rows).toEqual(['0', '1', '2', '3', '4']);

                    // assert handler IS invoked when data mutated
                    expect(handleRowReflow).toHaveBeenCalledTimes(2);

                    // assert rendering
                    expect(wrapper.find('.reactgrid-row').length).toEqual(5);
                }

                // In this scenario the new rows arrive immediately after the component
                // has already rendered (so the consumer has NOT been informed).
                wrapper.setProps({
                    rows: createRows(5),
                });
                wrapper.update();

                assertions();
            });

            it('should add 5 initial rows in order a while after initial render', () => {
                const rowDescriptor = createRows();
                const colDescriptor = createCols(['foo']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(rows.length).toEqual(5);
                    expect(rows).toEqual(['0', '1', '2', '3', '4']);

                    // assert handler IS invoked when data mutated
                    expect(handleRowReflow).toHaveBeenCalledTimes(2);

                    // assert rendering
                    expect(wrapper.find('.reactgrid-row').length).toEqual(5);
                }

                // In this scenario the new rows arrive immediately after the component
                // has already rendered (so the consumer has NOT been informed).
                wrapper.setProps({
                    rows: createRows(5),
                });
                wrapper.update();

                assertions();
            });

            it('should add 4 subsequent rows in order on 3 columns', () => {
                const rowDescriptor = createRows(1);
                const colDescriptor = createCols(['foo', 'bar', 'baz']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(rows.length).toEqual(5);
                    expect(rows).toEqual(['0', '1', '2', '3', '4']);
                    expect(cols.length).toEqual(3);
                    expect(cols).toEqual(['foo', 'bar', 'baz']);

                    // assert handler IS invoked when data mutated
                    expect(handleRowReflow).toHaveBeenCalledTimes(2);

                    // assert rendering
                    expect(wrapper.find('.reactgrid-row').length).toEqual(5);
                    expect(wrapper.find('.reactgrid-cell').length).toEqual(15);
                }

                wrapper.setProps({
                    rows: createRows(5),
                });
                wrapper.update();

                assertions();
            });

            it('should add 4 subsequent rows in order with updated column order', () => {
                const rowDescriptor = createRows(1);
                const colDescriptor = createCols(['foo', 'bar', 'baz']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(rows.length).toEqual(5);
                    expect(rows).toEqual(['0', '1', '2', '3', '4']);
                    expect(cols.length).toEqual(3);
                    expect(cols).toEqual(['baz', 'bar', 'foo']);

                    // assert handler IS invoked when data mutated
                    expect(handleRowReflow).toHaveBeenCalledTimes(3);

                    // assert rendering
                    expect(wrapper.find('.reactgrid-row').length).toEqual(5);
                    expect(wrapper.find('.reactgrid-cell').length).toEqual(15);
                }

                wrapper.setProps({
                    rows: createRows(5),
                    cols: createCols(['baz', 'bar', 'foo']),
                });
                wrapper.update();

                assertions();
            });

            it('should remove 2 rows and maintain order of others', () => {
                const rowDescriptor = createRows(5);
                const colDescriptor = createCols(['foo']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(rows.length).toEqual(3);
                    expect(rows).toEqual(['2', '3', '4']);

                    // assert handler IS invoked when data mutated
                    expect(handleRowReflow).toHaveBeenCalledTimes(2);

                    // assert rendering
                    expect(wrapper.find('.reactgrid-row').length).toEqual(3);
                }

                wrapper.setProps({
                    rows: createRows(2, 5),
                });
                wrapper.update();

                assertions();
            });

            it('should expose row data, row id, and row info to cellRenderers', () => {
                let rowIdArg;
                let rowDataArg;
                let rowInfoArg;
                let rowColumnArg;

                const rowDescriptor = [{
                    id: '1',
                    data: {
                        key: 'value',
                    },
                }];

                const colDescriptor = createCols(['foo', 'bar', 'baz'], {
                    'foo': {
                        template: (cellContract) => {
                            rowColumnArg = cellContract.column;
                            rowIdArg = cellContract.rowId;
                            rowDataArg = cellContract.rowData;
                            rowInfoArg = cellContract.rowInfo;

                            return (<div>rowData</div>);
                        },
                    },
                });

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    expect(rowColumnArg).toEqual(jasmine.objectContaining({
                        id: 'foo',
                    }));
                    expect(rowIdArg).toEqual('1');
                    expect(rowDataArg).toEqual({ key: 'value' });
                    expect(rowInfoArg).toEqual(jasmine.objectContaining({
                        isDivider: false,
                    }));
                }

                assertions();
            });

            it('supports selecting rows', () => {
                const rowDescriptor = createRows(5);
                const colDescriptor = createCols(['foo']);
                const onRowSelect = jasmine.createSpy();

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onRowSelect={onRowSelect}

                        {...defaultProps}
                    />
                );

                tap(wrapper.find('.reactgrid-row').first());

                expect(onRowSelect).toHaveBeenCalled();
            });

            it('supports expanding rows', () => {
                const rowDescriptor = createRows(5);
                const colDescriptor = createCols(['foo']);
                const onRowExpand = jasmine.createSpy('onRowExpand');
                const onRowSelect = jasmine.createSpy('onRowSelect');

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}

                        // capture internal state reporting
                        onRowSelect={onRowSelect}
                        onRowExpand={onRowExpand}

                        {...defaultProps}
                    />
                );

                tap(wrapper.find('.reactgrid-row').first());

                expect(onRowExpand).not.toHaveBeenCalled();
                expect(onRowSelect).toHaveBeenCalled();
            });
        });

        describe('cols', () => {
            it('should decorate cells with a custom class, when cellClass passed as string', () => {
                const CUSTOM_CELL_CLASS = 'col-class';
                const rowDescriptor = createRows(1);
                const colDescriptor = createCols(['foo']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}
                        cellClass={CUSTOM_CELL_CLASS}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert rendering
                    expect(wrapper.find(`.${CUSTOM_CELL_CLASS}`).length).toEqual(1);
                }

                assertions();
            });

            it('should not mutate cols when no difference in prop supplied', () => {
                const rowDescriptor = createRows(1);
                const colDescriptor = createCols(['foo']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols.length).toEqual(1);
                    expect(cols).toEqual(['foo']);

                    // assert handler NOT invoked when data not mutated
                    expect(handleColReflow).toHaveBeenCalledTimes(1);

                    // assert rendering
                    expect(wrapper.find('.reactgrid-cell').length).toEqual(1);
                }

                wrapper.setProps({
                    cols: createCols(['foo']),
                });
                wrapper.update();

                assertions();
            });

            it('should add 5 initial cols in order immediately after render', () => {
                const rowDescriptor = createRows(1);
                const colDescriptor = [];

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols.length).toEqual(5);
                    expect(cols).toEqual(['foo', 'bar', 'baz', 'qwux', 'qwix']);

                    // assert handler is invoked when data mutated.
                    // It's only called once because it's not invoked for initial empty column list.
                    expect(handleColReflow).toHaveBeenCalledTimes(1);

                    // assert rendering
                    expect(wrapper.find('.reactgrid-cell').length).toEqual(5);
                }

                wrapper.setProps({
                    cols: createCols(['foo', 'bar', 'baz', 'qwux', 'qwix']),
                });
                wrapper.update();

                assertions();
            });

            it('should add 3 and then 5 cols in order immediately after render', () => {
                const rowDescriptor = createRows(1);
                const colDescriptor = [];

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols.length).toEqual(3);
                    expect(cols).toEqual(['def', 'ghi', 'jkl']);

                    // assert handler is invoked when data mutated.
                    expect(handleColReflow).toHaveBeenCalledTimes(2);

                    // assert rendering
                    expect(wrapper.find('.reactgrid-cell').length).toEqual(3);
                }

                wrapper.setProps({
                    cols: createCols(['abc', 'def']),
                });

                wrapper.setProps({
                    cols: createCols(['def', 'ghi', 'jkl']),
                });
                wrapper.update();

                assertions();
            });

            it('should not call column reflow upon receiving empty column descriptions', () => {
                const rowDescriptor = createRows(1);
                const colDescriptor = [];

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols).toEqual([]);

                    // assert handler is invoked when data mutated.
                    expect(handleColReflow).toHaveBeenCalledTimes(0);

                    // assert rendering
                    expect(wrapper.find('.reactgrid-cell').length).toEqual(0);
                }

                assertions();
            });

            it('should add 5 initial cols in order a while after render', () => {
                const rowDescriptor = createRows(1);
                const colDescriptor = [];

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols.length).toEqual(5);
                    expect(cols).toEqual(['foo', 'bar', 'baz', 'qwux', 'qwix']);

                    // Assert handler is invoked when data mutated.
                    // It's only called once because it's not invoked for initial empty column list.
                    expect(handleColReflow).toHaveBeenCalledTimes(1);

                    // assert rendering
                    expect(wrapper.find('.reactgrid-cell').length).toEqual(5);
                }

                wrapper.setProps({
                    cols: createCols(['foo', 'bar', 'baz', 'qwux', 'qwix']),
                });
                wrapper.update();

                assertions();
            });

            it('should add 3 subsequent cols in order on 3 rows', () => {
                const rowDescriptor = createRows(3);
                const colDescriptor = createCols(['foo', 'bar']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols.length).toEqual(5);
                    expect(cols).toEqual(['foo', 'bar', 'baz', 'qwux', 'qwix']);
                    expect(rows.length).toEqual(3);
                    expect(rows).toEqual(['0', '1', '2']);

                    // assert handler IS invoked when data mutated
                    expect(handleColReflow).toHaveBeenCalledTimes(2);

                    // assert rendering
                    expect(wrapper.find('.reactgrid-cell').length).toEqual(15);
                }

                wrapper.setProps({
                    cols: createCols(['foo', 'bar', 'baz', 'qwux', 'qwix']),
                });
                wrapper.update();

                assertions();
            });

            it('should add 3 subsequent cols in order with updated row order', () => {
                const rowDescriptor = createRows(3);
                const colDescriptor = createCols(['foo', 'bar']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols.length).toEqual(5);
                    expect(cols).toEqual(['foo', 'bar', 'baz', 'qwux', 'qwix']);
                    expect(rows.length).toEqual(3);
                    expect(rows).toEqual(['2', '1', '0']);

                    // assert handler IS invoked when data mutated
                    expect(handleColReflow).toHaveBeenCalledTimes(2);

                    // assert rendering
                    expect(wrapper.find('.reactgrid-cell').length).toEqual(15);
                }

                wrapper.setProps({
                    cols: createCols(['foo', 'bar', 'baz', 'qwux', 'qwix']),
                    rows: createRows(3).reverse(),
                });
                wrapper.update();

                assertions();
            });

            it('should remove 2 cols and maintain order of others', () => {
                const rowDescriptor = createRows(1);
                const colDescriptor = createCols(['foo', 'bar', 'baz', 'qwux', 'qwix']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols.length).toEqual(3);
                    expect(cols).toEqual(['baz', 'qwux', 'qwix']);

                    // assert handler IS invoked when data mutated
                    expect(handleColReflow).toHaveBeenCalledTimes(2);

                    // assert rendering
                    expect(wrapper.find('.reactgrid-cell').length).toEqual(3);
                }

                wrapper.setProps({
                    cols: createCols(['baz', 'qwux', 'qwix']),
                });
                wrapper.update();

                assertions();
            });

            it('should apply first-child modifier class to first col and last-child to last col', () => {
                const rowDescriptor = createRows(1);
                const colDescriptor = createCols(['foo', 'bar', 'baz']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols.length).toEqual(3);
                    expect(cols).toEqual(['foo', 'bar', 'baz']);

                    // assert rendering
                    expect(wrapper.find('.reactgrid-cell').length).toEqual(3);
                    expect(wrapper.find('.reactgrid-cell').first().hasClass('reactgrid-cell--first-child')).toBe(true);
                    expect(wrapper.find('.reactgrid-cell').last().hasClass('reactgrid-cell--last-child')).toBe(true);
                }

                assertions();
            });

            it('should use custom row style function', () => {
                const CUSTOM_ROW_CLASS = 'row-class';
                const rowDescriptor = createRows(1);
                const colDescriptor = createCols(['foo', 'bar', 'baz']);

                const styleFunction = jasmine.createSpy().and.returnValue({ opacity: 0.73 });

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isHeader={false}
                        rowClass={CUSTOM_ROW_CLASS}
                        rowStyleFunction={styleFunction}

                        // capture internal state reporting
                        onColReflow={handleColReflow}
                        onRowReflow={handleRowReflow}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(cols.length).toEqual(3);
                    expect(cols).toEqual(['foo', 'bar', 'baz']);

                    // assert rendering
                    expect(wrapper.find(`div.${CUSTOM_ROW_CLASS}`).length).toEqual(1);
                    expect(wrapper.find(`div.${CUSTOM_ROW_CLASS}`).at(0).props().style.opacity).toEqual(0.73);
                    expect(styleFunction).toHaveBeenCalled();
                }

                assertions();
            });
        });
    });
});
