import * as numberFormat from 'src/numberFormat';
import dateTime from 'src/modules/dateTime';

export const numberFormatter = numberFormat.format.bind(numberFormat);

export const percentFormatter = (value) => numberFormat.formatPercentage(value, 2);

export const dateTimeFormatter = (value) => dateTime.formatUserDateTime(dateTime.createDateTime(value));

export const numberValueFormatter = (value, digits = 2) => numberFormatter(value, digits);

export const amountFormatter = (value, decimals) => numberFormatter(value, decimals);

export const accountCurrencyFormatter = (value) => numberFormatter(value, 2 /* decimals */);

export const dateFormatter = (value) => dateTime.formatUserDate(dateTime.createDate(value));
