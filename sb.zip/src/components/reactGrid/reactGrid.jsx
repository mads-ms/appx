/* eslint max-lines: "off" */
/**
 * ReactGrid is an optimised React component for displaying content
 * within a matrix structure (M rows by N columns). Written with stringent
 * performance goals in mind, it enables developers to render features
 * with potentially tens of thousands of rows in a memory-efficient and
 * performant manner across all target runtimes.
 *
 * Such layouts come in many guises, from a simple list of items with
 * static string content (e.g. M rows by 1 col like a todo list), to
 * complex features with groupings, many columns, and rich HTML content
 * (e.g. datagrids). ReactGrid boasts a wide-array of features to
 * facilitate the creation of such features and lend them native-like
 * performance and interactions, with extension points for implementing
 * bespoke behaviours.
 *
 * ### Features
 *
 * - Create/Update/Order/Add/Remove ops on rows+columns
 * - Row selection
 * - Custom CSS classes for header, row and cells
 * - Flexible column (only one) between a defined pixel range
 * - Fixed item ordering (i.e. always first/last/nth-child)
 * - Separated header (if desired, useful for fixed header implementations)
 * - Auto-adjustment to scrollbar appearance
 * - Auto-sizing to space available in conjunction with culling directives
 * - Content culling to control overflow and render optimization
 * - Drag and drop reordering behaviours on rows
 * - Grouped contents to N-levels with expand/collapse behaviours
 * - Event streams of current state (rendered rows/cols/scrolling)
 *
 * ### Not Included
 *
 * The following are *NOT* part of ReactGrid. Developers should create
 * their own abstraction atop of this component to compose multiple
 * concerns together.
 *
 * - Loading state
 * - Null/Blank state
 * - Auto-Resizing (no listener for resize, needs to be told)
 * - Content
 * - Column/Row picker
 *
 * ### Content Agnostic
 *
 * Whatever the layout shown, it is important to understand that
 * ReactGrid itself is *content-agnostic*. It is not responsible for
 * the contents it houses, but rather provides a mechanism to arrange
 * it. Therefore its primary concern are the rows, columns and cells
 * it generates, according to the schemas passed in via Props. It is
 * up to collaborator objects to populate and update the cells as
 * they see fit (ordinarily through connect()'d templates).
 *
 * In a related manner this agnosticism towards the content rendered
 * by ReactGrid extends to the dimensions of the rows and columns.
 * Column widths are declared in a descriptor object per column, but
 * the height for each-level of row grouping is measured first in the
 * DOM, then applied as a constant to all sibling rows. This means that
 * rows can be as skinny or fat as the UI demands, and sized with pure
 * CSS (either via "natural" content sizing, or as a constant), rather
 * than having to declare it with JavaScript (though this is also
 * supported).
 *
 * ### Optimized Runtime
 *
 * ReactGrid employs a number of advanced techniques to achieve optimal
 * rendering performance (with correlating high FPS). There are three
 * main optimizations: positioned cells/rows, occlusion culling, and
 * row pooling. Together they complement the already formidable raw
 * speed of React and its own lifecycle hooks to mitigate redundant
 * rendering.
 *
 * *Positioning* allows browsers to optimise layout and paint times by
 * allowing it to render individual cells (as opposed to unions
 * containing an entire component). It does this by providing layout
 * boundaries and promoting content to its own GPU layer for
 * compositing. It also facilitates native UI effects such as animated
 * sorting.
 *
 * *Occlusion culling* involves only rendering what is visible on
 * screen, which aids performance in multiple ways. First it keeps the
 * DOM lighter which enables browsers in any style recalculations
 * during paints. It also helps for the initial render of the content
 * (as only a subset of rows are passed along to React to generate the
 * DOM). As a second order effect, informing collaborators of which
 * rows are actually visible enables them to manage any subscriptions
 * and reduce network traffic to what is required to present a complete
 * UI to the user.
 *
 * *Row pooling* enables React to dramatically reduce DOM mutations
 * when the content is scrolled. Instead of rendering new rows, react
 * is smart enough to change the data in the cells and adjust the Y
 * offset of a pre-rendered row to position it correctly within the
 * scroll view.
 *
 * Such row updates also take place in clusters, rather than as
 * individual rows appear/disappear from view, further reducing
 * unnecessary renders(). Thus, where content overflows off screen in a
 * ReactGrid component, there is always some buffer to aid inertia
 * scrolling. This update pattern can be viewed by inspecting ReactGrid\
 * in Chrome dev tools and simply scrolling up and down.
 *
 * Finally, during scrolling cells are informed to defer any content
 * updates until scroll end to prevent unwanted flickering.
 *
 * See [the dedicated decision log page](https://wiki/display/STGO/Datagrid+Mach+II)
 * for further background information.
 *
 * ### Application <=> ReactGrid Contract
 *
 * If ReactGrid is content-agnostic, how are developers meant to
 * associate content with a given row/cell, and order them? Basically,
 * rows and columns can both have a unique ID associated with them
 * (e.g. a generated GUID or something domain-specific as a Position ID).
 *
 * While rows are described by consumers as an array of String IDs,
 * columns are more complex, and are passed as an array of descriptor
 * hashes. This descriptor comprises a number of properties (including
 * ID) which describe how a column is setup. The crucial two properties
 * for columns are 'id' and 'template'. The former should be
 * self-explanatory, but the latter is more complex.
 *
 * The value for the `template` property should be a function which
 * accepts a hash containing the following fields:
 *
 * - column: {Hash} - original column definition
 * - rowId {String} - foreign key of row currently being rendered
 * - rowData: {Hash} - row data passed to all cell renderers
 *      { defined by consumers }
 * - rowInfo: {Hash} - row state flags
 *      {
 *          isDivider: {Boolean}
 *          template: {Function}
 *          level: {Number}
 *      }
 * - canUpdate {Boolean} - flag whether a cell is allowed to update or not
 *
 * Combining the rowId with the columnId should be enough information
 * for the template function to route the render request (from
 * ReactGrid) to the appropriate React Component to render the
 * contents of the cell. This can be taken a step further by using a
 * factory method to provide a generic template function that connects
 * to a Redux store individually, and delegates the actual rendering to
 * a cellRender function (commonly a stateless React component).
 *
 * The order of row IDs and columns descriptors in their respective
 * arrays determine the appearance of the ReactGrid instance. In this
 * manner then, altering their ordering effectively "sorts" the
 * content and triggers a re-render via the React lifecycle through to
 * the templates associated with each cell (and thus the contract is
 * fulfilled).
 *
 *  <ReactGrid
 *      rowHeight={20}
 *      cols={[
 *          {
 *              id: 'col1',
 *              isEnabled: false, (default: true),
 *              header: () => <div>Column 1</div>,
 *              template: () => Date.now(),
 *              width: 80,
 *          },
 *          {
 *              id: 'col2',
 *              header: () => <div>Column 2</div>,
 *              template: () => Date.now(),
 *              width: 80,
 *          },
 *      ]}
 *      rows={[
 *          '1',
 *          '2',
 *          '3',
 *      ]}
 *  />
 */
import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import ExpandButton from './blocks/expandButton';
import ReactGridHeader from './reactGridHeader';
import ReactGridRows from './reactGridRows';
import PluginSupport from './plugins/pluginSupport';
import * as pluginsConstants from './plugins/constants';
import ColumnLayout from './columnLayout';
import ResizableWrapper from 'src/components/resizable/resizableWrapper';
import { UI } from 'openui';
import _ from 'lodash';
import { bindHandlers } from 'src/utils/bindHandlers';
import * as constants from 'src/components/reactGrid/constants';
import { createRenderer } from './reactGridRendererUtils';
import groupingPropTypes from './propTypes/groupingPropTypes';
import columnPropTypes from './propTypes/columnPropTypes';
import rowsPropTypes from './propTypes/rowsPropTypes';

class ReactGrid extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            visibleColumns: [],
            width: props.width,
        };

        // private state
        this.expandButtonTemplate = this.expandButtonTemplate.bind(this);

        this.setEl = (ref) => {
            this.el = ref;
        };
    }

    componentDidMount() {
        this.setMeasurements(this.props);
    }

    componentWillReceiveProps(nextProps) {
        // actual dimensions may differ from parent so refresh own bounds
        //  - Use changes in wrapper to signal recalculation of own bounds
        //  - Use changes in rows to infer scrollbar appearance may change

        if (nextProps.isRtl !== this.props.isRtl ||
            nextProps.isGrouping !== this.props.isGrouping ||
            nextProps.width !== this.props.width ||
            nextProps.height !== this.props.height ||
            nextProps.headerHeight !== this.props.headerHeight ||
            nextProps.cols !== this.props.cols ||
            (nextProps.rows && (nextProps.rows.length !== this.props.rows.length))) {

            this.setMeasurements(nextProps);
        }
    }

    setMeasurements(props) {
        const viewport = this.getBounds(props);
        this.setState(viewport);
    }

    /**
     * Obtains various geometric properties of the Component
     *
     * @returns {
     *      height {Number} - Height of _entire_ component in pixels
     *      width {Number} - Width of _entire_ component in pixels
     *      scrollHeight {Number} - Height of the child scrollView containing rows in pixels
     *      scrollLeft {Number}
     *      scrollRight {Number}
     * }
     */
    getBounds(props) {
        const elBounds = this.el.getBoundingClientRect();
        const scrollBounds = this.el.querySelector('.reactgrid-scrollbody').getBoundingClientRect();

        // 'getBoundingClientRect' method gives different results between browsers
        //  subtracting 1px to avoid issues on chrome (http://stackoverflow.com/a/27171789)
        const height = (elBounds.height ? elBounds.height - 1 : 0) || props.height;

        // Use scroll bound width if not 0 to take into the account scroll bar
        const width = Math.floor(scrollBounds.width || props.width);
        const headerHeight = props.isHeader ? props.headerHeight : 0;
        const scrollHeight = height - headerHeight;
        const scrollLeft = scrollBounds.left - elBounds.left;
        const scrollRight = elBounds.right - scrollBounds.right;

        return {
            height,
            width,
            scrollHeight,
            scrollLeft,
            scrollRight,
        };
    }

    /**
     * Gets an <ExpandButton/> React component bound to a particular row.
     */
    expandButtonTemplate({ rowId, rowData, rowInfo }) {
        const isEnabled = Boolean(_.size(rowData.rows)) && !rowInfo.isStatic;

        return (
            <ExpandButton
                isEnabled={isEnabled}
                rowId={rowId}
                rowData={rowData}
                rowInfo={rowInfo}
                isExpanded={rowInfo.isExpanded}
                onTap={this.handleRowExpand}
            />
        );
    }

    handleRowExpand(evt, row) {
        evt.preventDefault();

        this.props.onRowExpand(evt, row);
    }

    handleSectionExpand(evt, row) {
        this.props.onSectionExpand(evt, row);
    }

    handleRowTap(evt, row) {
        this.props.onRowTap(evt, row);
    }

    handleRowPress(evt, row) {
        this.props.onRowPress(evt, row);
    }

    handleVisibleColumnsChange(columnIds, columns) {
        this.props.onColReflow(columnIds, columns);
    }

    handleColumnsChange(columns) {
        this.setState({ visibleColumns: columns });

    }

    render() {
        const columnLayout = createRenderer(this.props.columnLayout, {
            columns: this.props.cols,
            width: this.state.width,
            isRtl: this.props.isRtl,
            expandButtonTemplate: this.expandButtonTemplate,
            centerColumnId: this.props.centerColumnId,
            isGrouping: this.props.isGrouping,
            onVisibleColumnsChange: this.handleVisibleColumnsChange,
            onColumnsChange: this.handleColumnsChange,
        });

        return (
            <div
                ref={this.setEl}
                className={classNames(this.props.className, 'reactgrid grid grid--y')}
            >

                {columnLayout}
                {this.props.isHeader &&
                <PluginSupport
                    plugins={this.props.children}
                    type={pluginsConstants.HEADER_PLUGIN_TYPE}
                >
                    {(headPlugins) => (
                        <ReactGridHeader
                            headerClass={this.props.headerClass}
                            headerHeight={this.props.headerHeight}
                            headerLineHeight={this.props.headerLineHeight}
                            cellClass={this.props.cellClass}
                            columns={this.props.cols}
                            visibleColumns={this.state.visibleColumns}
                            width={this.state.width}
                            height={this.state.height}
                            sort={this.props.sort}
                            onHeaderSort={this.props.onHeaderSort}
                        >
                            {headPlugins}
                        </ReactGridHeader>
                    )}
                </PluginSupport>
                }

                <PluginSupport
                    plugins={this.props.children}
                    type={pluginsConstants.ROW_PLUGIN_TYPE}
                >
                    {(rowPlugins) => (
                        <ReactGridRows
                            isRtl={this.props.isRtl}
                            isGrouping={this.props.isGrouping}
                            isSectioned={this.props.isSectioned}
                            isHeightFill={this.props.isHeightFill}
                            isWidthFill={this.props.isWidthFill}
                            isScrollingDisabled={this.props.isScrollingDisabled}
                            sort={this.props.sort}
                            grouping={this.props.grouping}
                            expandedGroups={this.props.expandedGroups}
                            keepGroupsExpanded={this.props.keepGroupsExpanded}
                            rowClass={this.props.rowClass}
                            cellClass={this.props.cellClass}
                            cullRatio={this.props.cullRatio}
                            featureArea={this.props.featureArea}
                            height={this.state.scrollHeight}
                            rowHeight={this.props.rowHeight}
                            rowLineHeight={this.props.rowLineHeight}
                            dividerHeight={this.props.dividerHeight}
                            dividerLineHeight={this.props.dividerLineHeight}
                            rows={this.props.rows}
                            columns={this.state.visibleColumns}
                            selectedRow={this.props.selectedRow}
                            onRowTap={this.handleRowTap}
                            onRowPress={this.handleRowPress}
                            onRowDoubleTap={this.props.onRowDoubleTap}
                            onRowSelect={this.props.onRowSelect}
                            onRowReflow={this.props.onRowReflow}
                            onRowSort={this.props.onRowSort}
                            onDividerTap={this.handleSectionExpand}
                            onScroll={this.props.onScroll}
                            onScrollStart={this.props.onScrollStart}
                            onScrollEnd={this.props.onScrollEnd}
                            onRowTouchStart={this.props.onRowTouchStart}
                            width={this.props.width}
                            isMenuShown={this.props.isMenuShown}
                            scrollOffset={this.props.scrollOffset}
                            scrollLeft={this.state.scrollLeft}
                            scrollRight={this.state.scrollRight}
                            isStickyGrouping={this.props.isStickyGrouping}
                            rowStyleFunction={this.props.rowStyleFunction}
                        >
                            {rowPlugins}
                        </ReactGridRows>
                    )}
                </PluginSupport>
            </div>
        );
    }
}

ReactGrid.propTypes = {

    // comma-delimited list of CSS classes to add to top-level wrapper
    className: PropTypes.string,

    // comma-delimited list of CSS classes to add to all rows
    rowClass: PropTypes.string,

    // comma-delimited list of CSS classes to add to header row
    headerClass: PropTypes.string,

    // comma-delimited list of CSS classes to add to all cells
    cellClass: PropTypes.string,

    // ID of column anchoring center-column grid layouts
    centerColumnId: PropTypes.string,

    // ratio of screen height which determines cluster-size
    //  - lower value equals smaller clusters and more aggressive culling
    //  - can lead to perceived lower scroll performance on mobile devices
    //    due to a lack of "buffer" to display when a ScrollView is "flung"
    cullRatio: PropTypes.number,

    // columns
    cols: columnPropTypes,

    // rows
    rows: rowsPropTypes,

    // sort definition
    sort: PropTypes.shape({

        // sort id
        id: PropTypes.string,

        // sort mode
        // 0 - two states of sort
        // 1 - three states of sort
        mode: PropTypes.number,

        // sort direction
        // 1 - asc
        // 0 - initial order
        // -1 - desc
        direction: PropTypes.number,

        // custom sort compare function
        // Example:
        // const myCustomSortCompareFunction = (a, b) => {
        //   if(a === b){
        //      return 0;
        //   }
        //   return a > b ? 1 : -1;
        // }
        compareFunction: PropTypes.func,
    }),

    // grouping definition
    grouping: groupingPropTypes,

    // mapping of group id to expanded state
    expandedGroups: PropTypes.object,

    // flag to indicate if all groups should be expanded until user close them manually
    // should set to true if filtering is applied
    keepGroupsExpanded: PropTypes.bool,

    // ID of currently selected row
    selectedRow: PropTypes.string,

    // height and width of parent element in pixels
    //  - only used as a proxy for resizing, rendered dimensions of
    //    component are still measured to determine appearance
    height: PropTypes.number,

    width: PropTypes.number,

    // height of header row in pixels
    headerHeight: PropTypes.number,

    // lineHeight of header row in pixels
    headerLineHeight: PropTypes.number,

    // height of divider rows in pixels
    dividerHeight: PropTypes.number,

    // lineHeight of divider rows in pixels
    dividerLineHeight: PropTypes.number,

    // height of rows in pixels (affects all levels)
    rowHeight: PropTypes.number,

    // lineHeight of rows in pixels
    rowLineHeight: PropTypes.number,

    // flag whether rows are grouped (i.e. rows->sub-rows). If so, expand buttons
    // are injected into the parent rows to enable expand/collapse behaviours.
    isGrouping: PropTypes.bool,

    // flag whether rows are sectioned. (i.e. section header->rows). If so,
    // top-level rows are treated as section headers with expand/collapse
    // behaviours. Sections can contain child grouped rows.
    isSectioned: PropTypes.bool,

    // flag whether top-level rows stick to the top when scrolling
    isStickyGrouping: PropTypes.bool,

    // flag whether to display a header
    isHeader: PropTypes.bool,

    // flag whether cells should be laid out right-to-left
    //  - omit if prefer to use the global layout direction
    isRtl: PropTypes.bool,

    // indicates whether context menu currently being shown
    isMenuShown: PropTypes.bool,

    // flag whether the grid shows the rows constrained by the parent's
    // dimensions, or if it just overrides scrolling and all rows are shown
    isHeightFill: PropTypes.bool,

    // flag whether the grid expands rows to fill the parent's dimensions (i.e.
    // 100% allows for resizing), or if they are sized to the specified width.
    // NOTE: Sizing to the displayed columns isn't applicable as ReactGrid needs
    // a width in the first instance in order to compute which columns to display!
    isWidthFill: PropTypes.bool,

    // indicates whether grid scrolling is disabled;
    // in case this is true, content will still have grid--scroll when it doesn't fit the view,
    // but vertical overflow (overflow-y) will be set to hidden
    // this is particularly useful in situations when scrolling might interfere
    // with other functionality, like drag-n-drop on touch devices (see bug #722586 for example)
    isScrollingDisabled: PropTypes.bool,

    // handler invoked after calculation of column layout
    onColReflow: PropTypes.func,

    // custom function to enhance row styles
    rowStyleFunction: PropTypes.func,

    onRowTap: PropTypes.func,
    onRowPress: PropTypes.func,
    onRowDoubleTap: PropTypes.func,
    onRowExpand: PropTypes.func,
    onSectionExpand: PropTypes.func,
    onRowReflow: PropTypes.func,
    onRowSelect: PropTypes.func,
    onRowSort: PropTypes.func,
    onRowTouchStart: PropTypes.func,
    onScroll: PropTypes.func,
    onScrollStart: PropTypes.func,
    onScrollEnd: PropTypes.func,
    onHeaderSort: PropTypes.func,

    // featureArea for logging
    featureArea: PropTypes.string,

    // initial scroll offset
    scrollOffset: PropTypes.number,

    // column layout, responsible for generating sorted and visible columns data with position/size metrics information.
    columnLayout: PropTypes.oneOfType([PropTypes.func, PropTypes.object]),
};

ReactGrid.defaultProps = {
    isRtl: UI.isRTL(),
    isGrouping: false,
    isSectioned: false,
    isStickyGrouping: false,
    isHeader: true,
    isMenuShown: false,
    isHeightFill: false,
    width: 0,
    height: 0,
    headerHeight: constants.HEADER_HEIGHT,
    headerLineHeight: constants.HEADER_LINEHEIGHT,
    rowLineHeight: constants.ROW_LINEHEIGHT,
    rowHeight: constants.ROW_HEIGHT,
    dividerHeight: constants.DIVIDER_HEIGHT,
    dividerLineHeight: constants.DIVIDER_LINEHEIGHT,
    onScroll: _.noop,
    onScrollStart: _.noop,
    onScrollEnd: _.noop,
    onRowTap: _.noop,
    onRowPress: _.noop,
    onRowDoubleTap: _.noop,
    onRowExpand: _.noop,
    onRowSelect: _.noop,
    onRowReflow: _.noop,
    onRowTouchStart: _.noop,
    onColReflow: _.noop,
    onRowSort: _.noop,
    onSectionExpand: _.noop,
    onHeaderSort: _.noop,
    keepGroupsExpanded: false,
    expandedGroups: {},
    columnLayout: ColumnLayout,
};

export default ResizableWrapper(bindHandlers(ReactGrid));
