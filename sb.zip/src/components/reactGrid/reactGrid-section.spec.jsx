/**
 * <ReactGrid/> grouping of rows unit tests
 */

import $ from 'jqueryAll';
import { tap } from 'test/mocks/touchableHelper';
import React from 'react';
import ReactGrid from 'src/components/reactGrid/reactGrid';
import { createCols } from './reactGridSpecHelper';
import { mount } from 'enzyme';

describe('src/components/reactGrid', () => {

    // some assertions require a real *rendered* DOM for introspection,
    // mainly in relation to content measurements for header+row heights.
    const $fixture = $('<div id="fixture"></div>');
    $(document.body).append($fixture);

    // assertion state
    let cols;
    let rows;
    let wrapper;

    // controlled state setup before each test
    let defaultProps;

    beforeEach(() => {
        cols = [];
        rows = [];
        $fixture.empty();

        defaultProps = {
            isHeader: false,
            width: 501,
            height: 100,
            rowHeight: 20,
            headerHeight: 30,
        };
    });

    afterEach(() => {
        wrapper.unmount();
    });

    describe('sections', function() {
        it('should render section header when only divider and no rows', () => {
            const rowDescriptor = [{
                id: 'group1',
                rows: [],
                isExpanded: true,
                sectionHeader: 'Group 1',
            }];
            const colDescriptor = createCols(['foo']);

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}
                    isGrouping
                    isSectioned
                    dividerHeight={20}

                    // capture internal state reporting
                    onColReflow={(evt) => {
                        cols = evt;
                    }}
                    onRowReflow={(evt) => {
                        rows = evt;
                    }}

                    {...defaultProps}
                />
            );

            function assertions() {
                // assert state
                expect(rows.length).toEqual(1);
                expect(rows).toEqual(['group1']);

                // assert rendering
                expect(wrapper.find('.reactgrid-divider').length).toEqual(1);
            }

            assertions();
        });

        it('should render a [1x1] hierarchical datagrid with section header when section NOT expanded', () => {
            const rowDescriptor = [{
                id: 'group1',
                rows: [{ id: '1_1' }],
                isExpanded: false,
                sectionHeader: 'Group 1',
            }];
            const colDescriptor = createCols(['foo']);

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}
                    isSectioned
                    dividerHeight={20}

                    // capture internal state reporting
                    onColReflow={(evt) => {
                        cols = evt;
                    }}
                    onRowReflow={(evt) => {
                        rows = evt;
                    }}

                    {...defaultProps}
                />
            );

            function assertions() {
                // assert state
                expect(rows.length).toEqual(1);
                expect(rows).toEqual(['group1']);

                // assert rendering
                expect(wrapper.find('.reactgrid-row').length).toEqual(0);
                expect(wrapper.find('.reactgrid-divider').length).toEqual(1);
            }

            assertions();
        });

        it('should render a [2x1] hierarchical datagrid with section header when section expanded', () => {
            const rowDescriptor = [{
                id: 'group1',
                rows: [{ id: '1_1' }],
                isExpanded: true,
                sectionHeader: 'Group 1',
            }];
            const colDescriptor = createCols(['foo']);

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}
                    isSectioned
                    dividerHeight={20}

                    // capture internal state reporting
                    onColReflow={(evt) => {
                        cols = evt;
                    }}
                    onRowReflow={(evt) => {
                        rows = evt;
                    }}

                    {...defaultProps}
                />
            );

            function assertions() {
                // assert state
                expect(cols.length).toEqual(1);
                expect(cols).toEqual(['foo']);
                expect(rows.length).toEqual(2);
                expect(rows).toEqual(['group1', '1_1']);

                // assert rendering
                expect(wrapper.find('.reactgrid-row').length).toEqual(1);
                expect(wrapper.find('.reactgrid-divider').length).toEqual(1);
            }

            assertions();
        });

        it('should render a [3x1] hierarchical datagrid with section header and expand button column when section expanded', () => {
            const rowDescriptor = [{
                id: 'group1',
                rows: [{
                    id: '1_1',
                    isExpanded: true,
                    rows: [{ id: '1_1_1' }],
                }],
                isExpanded: true,
                sectionHeader: 'Group 1',
            }];
            const colDescriptor = createCols(['foo']);

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}
                    isGrouping
                    isSectioned
                    dividerHeight={20}

                    // capture internal state reporting
                    onColReflow={(evt) => {
                        cols = evt;
                    }}
                    onRowReflow={(evt) => {
                        rows = evt;
                    }}

                    {...defaultProps}
                />
            );

            function assertions() {
                // assert state
                expect(cols.length).toEqual(2);
                expect(cols).toEqual(['expand', 'foo']);
                expect(rows.length).toEqual(3);
                expect(rows).toEqual(['group1', '1_1', '1_1_1']);

                // assert rendering
                expect(wrapper.find('.reactgrid-row').length).toEqual(2);
                expect(wrapper.find('.reactgrid-divider').length).toEqual(1);
            }

            assertions();
        });

        it('should render section header with label and expand button', () => {
            const rowDescriptor = [{
                id: 'group1',
                rows: [],
                isExpanded: true,
                sectionHeader: 'Group 1',
            }];
            const colDescriptor = createCols(['foo', 'bar', 'baz']);

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}
                    isSectioned
                    dividerHeight={20}

                    // capture internal state reporting
                    onColReflow={(evt) => {
                        cols = evt;
                    }}
                    onRowReflow={(evt) => {
                        rows = evt;
                    }}

                    {...defaultProps}
                />
            );

            function assertions() {
                // assert rendering
                const divider = wrapper.find('.reactgrid-divider');
                expect(divider.length).toEqual(1);
                expect(divider.at(0).text().trim()).toEqual('Group 1');
            }

            assertions();
        });

        it('should render standard section header with positioned column content', () => {
            const rowDescriptor = [{
                id: 'group1',
                rows: [],
                isExpanded: true,
                sectionHeader: 'Group 1',
                sectionColumns: ['baz'],
            }];
            const colDescriptor = createCols(['foo', 'bar', 'baz'], {
                'baz': {
                    /* eslint-disable react/prop-types */
                    template: ({ rowId }) => (<div>{ rowId }</div>),
                    /* eslint-enable react/prop-types */
                },
            });

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}
                    isSectioned
                    dividerHeight={20}

                    // capture internal state reporting
                    onColReflow={(evt) => {
                        cols = evt;
                    }}
                    onRowReflow={(evt) => {
                        rows = evt;
                    }}

                    {...defaultProps}
                />, {
                    attachTo: $fixture[0],
                }
            );

            function assertions() {
                // assert rendering
                const dividerCell = wrapper.find('.reactgrid-cell');
                expect(dividerCell.length).toEqual(1);
                expect(dividerCell.at(0).text().trim()).toEqual('group1');
            }

            assertions();
        });

        it('should inform consumers when section header tapped (expanded)', () => {
            const rowDescriptor = [{
                id: 'group1',
                rows: [{ id: '1_1' }],
                isExpanded: false,
                sectionHeader: 'Group 1',
            }];
            const colDescriptor = createCols(['foo']);
            let divider;

            wrapper = mount(
                <ReactGrid
                    cols={colDescriptor}
                    rows={rowDescriptor}
                    isSectioned
                    dividerHeight={20}

                    // capture internal state reporting
                    onColReflow={(evt) => {
                        cols = evt;
                    }}
                    onRowReflow={(evt) => {
                        rows = evt;
                    }}
                    onSectionExpand={(evt, row) => {
                        divider = row;
                    }}

                    {...defaultProps}
                />
            );

            function assertions() {
                // "open" the section
                expect(rows.length).toEqual(1);
                expect(rows).toEqual(['group1']);
                tap(wrapper.find('.reactgrid-divider .reactgrid-row-content div').last());
                expect(divider.rowId).toEqual('group1');
            }

            assertions();
        });

        describe('should properly handle keepGroupsExpanded', () => {
            it('set to true, when rowInfo does not enforce section expanded state', () => {
                const rowDescriptor = [{
                    id: 'group1',
                    rows: [{ id: '1_1' }],
                    sectionHeader: 'Group 1',
                }];
                const colDescriptor = createCols(['foo']);
                const keepGroupsExpanded = true;

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isSectioned
                        keepGroupsExpanded={keepGroupsExpanded}
                        dividerHeight={20}

                        // capture internal state reporting
                        onColReflow={(evt) => {
                            cols = evt;
                        }}
                        onRowReflow={(evt) => {
                            rows = evt;
                        }}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(rows.length).toEqual(2);
                    expect(rows).toEqual(['group1', '1_1']);
                    expect(keepGroupsExpanded).toBeTruthy();

                    // assert rendering
                    expect(wrapper.find('.reactgrid-row').length).toEqual(1);
                    expect(wrapper.find('.reactgrid-divider').length).toEqual(1);
                }

                assertions();
            });

            it('set to false, when rowInfo does not enforce section expanded state', () => {
                const rowDescriptor = [{
                    id: 'group1',
                    rows: [{ id: '1_1' }],
                    sectionHeader: 'Group 1',
                }];
                const colDescriptor = createCols(['foo']);
                const keepGroupsExpanded = false;

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isSectioned
                        keepGroupsExpanded={keepGroupsExpanded}
                        dividerHeight={20}

                        // capture internal state reporting
                        onColReflow={(evt) => {
                            cols = evt;
                        }}
                        onRowReflow={(evt) => {
                            rows = evt;
                        }}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(keepGroupsExpanded).toBeFalsy();
                    expect(rows.length).toEqual(1);
                    expect(rows).toEqual(['group1']);

                    // assert rendering
                    expect(wrapper.find('.reactgrid-row').length).toEqual(0);
                    expect(wrapper.find('.reactgrid-divider').length).toEqual(1);
                }

                assertions();
            });

            it('should override keepGroupsExpanded with rowInfo`s isExpanded flag', () => {
                const rowDescriptor = [{
                    id: 'group1',
                    rows: [{ id: '1_1' }],
                    isExpanded: false,
                    sectionHeader: 'Group 1',
                }];
                const colDescriptor = createCols(['foo']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isSectioned
                        keepGroupsExpanded
                        dividerHeight={20}

                        // capture internal state reporting
                        onColReflow={(evt) => {
                            cols = evt;
                        }}
                        onRowReflow={(evt) => {
                            rows = evt;
                        }}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(rows.length).toEqual(1);
                    expect(rows).toEqual(['group1']);

                    // assert rendering
                    expect(wrapper.find('.reactgrid-row').length).toEqual(0);
                    expect(wrapper.find('.reactgrid-divider').length).toEqual(1);
                }

                assertions();
            });
        });

        describe('should handle keepGroupsExpanded in case of both sections and groups', () => {
            it('should have expanded section if isExpanded is true', () => {
                const rowDescriptor = [{
                    id: 'group1',
                    rows: [{ id: '1_1',
                        isExpanded: true,
                        rows: [{
                            id: '1_2',
                        }],
                    }],
                    sectionHeader: 'Group 1',
                }];
                const colDescriptor = createCols(['foo']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isSectioned
                        keepGroupsExpanded
                        dividerHeight={20}

                        // capture internal state reporting
                        onColReflow={(evt) => {
                            cols = evt;
                        }}
                        onRowReflow={(evt) => {
                            rows = evt;
                        }}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(rows.length).toEqual(3);
                    expect(rows).toEqual(['group1', '1_1', '1_2']);

                    // assert rendering
                    expect(wrapper.find('.reactgrid-row').length).toEqual(2);
                    expect(wrapper.find('.reactgrid-divider').length).toEqual(1);
                }

                assertions();
            });

            it('should not have expanded section if isExpanded is false', () => {
                const rowDescriptor = [{
                    id: 'group1',
                    rows: [{ id: '1_1',
                        isExpanded: false,
                        rows: [{
                            id: '1_2',
                        }],
                    }],
                    sectionHeader: 'Group 1',
                }];
                const colDescriptor = createCols(['foo']);

                wrapper = mount(
                    <ReactGrid
                        cols={colDescriptor}
                        rows={rowDescriptor}
                        isSectioned
                        keepGroupsExpanded
                        dividerHeight={20}

                        // capture internal state reporting
                        onColReflow={(evt) => {
                            cols = evt;
                        }}
                        onRowReflow={(evt) => {
                            rows = evt;
                        }}

                        {...defaultProps}
                    />
                );

                function assertions() {
                    // assert state
                    expect(rows.length).toEqual(2);
                    expect(rows).toEqual(['group1', '1_1']);

                    // assert rendering
                    expect(wrapper.find('.reactgrid-row').length).toEqual(1);
                    expect(wrapper.find('.reactgrid-divider').length).toEqual(1);
                }

                assertions();
            });
        });
    });
});
