import React from 'react';
import { mount } from 'enzyme';
import { tap } from 'test/mocks/touchableHelper';
import ActionButton from 'src/components/reactGrid/blocks/actionButton';

describe('src/components/reactGrid/blocks/actionButton', () => {

    const instrument = {
        getName: () => 'mockInstrument',
        getSecondaryName: () => 'mockInstrument secondary',
        displayAndFormat: { Currency: 'eurusd' },
    };

    it('renders succesfully', () => {
        const testProps = {
            column: {},
            instrument,
            isEnabled: true,
            value: '109',
            price: {},
        };
        const wrapper = mount(<ActionButton {...testProps}/>);
        expect(wrapper.find('.actionbtn').length).toEqual(1);
    });

    it('supports tap event', () => {
        const tapSpy = jasmine.createSpy();
        const testProps = {
            column: {
                onTap: tapSpy,
            },
            instrument,
            isEnabled: true,
            value: '109',
            price: {},
        };
        const wrapper = mount(<ActionButton {...testProps}/>);
        tap(wrapper.find('.actionbtn'));

        expect(tapSpy).toHaveBeenCalled();
    });
});
