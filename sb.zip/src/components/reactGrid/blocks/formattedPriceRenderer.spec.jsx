import React from 'react';
import { mount } from 'enzyme';
import FormattedPriceRenderer from './formattedPriceRenderer';

describe('src/components/reactGrid/blocks/formattedPriceRenderer', () => {
    describe('render', () => {

        it('should pass properties correctly', () => {

            const rowData = {
                instrument: {
                    Format: { OrderDecimals: 4 },
                },
            };

            const wrapper = mount(
                <FormattedPriceRenderer
                    rowData={rowData}
                    tooltip="test-tooltip"
                    className="tst-class-name"
                    value="12.3212"
                />
            );

            expect(wrapper.length).toBe(1);
            expect(wrapper.getDOMNode().title).toEqual('test-tooltip');
            expect(wrapper.hasClass('tst-class-name')).toBeTruthy();
            expect(wrapper.find('FormattedPrice').length).toBe(1);
        });
    });

});
