import PropTypes from 'prop-types';
import React from 'react';
import Localization from 'src/localization';

const intervalMap = {
    15: Localization.getText('HTML5_Trade_Signals_15_Min'),
    30: Localization.getText('HTML5_Trade_Signals_30_Min'),
    60: Localization.getText('HTML5_Trade_Signals_1_Hour'),
    240: Localization.getText('HTML5_Trade_Signals_4_Hours'),
    1440: Localization.getText('HTML5_Trade_Signals_1_Day'),
};

export default function IntervalLabel({ interval }) {
    return (
        <p>{intervalMap[interval]}</p>
    );
}

IntervalLabel.propTypes = {
    interval: PropTypes.number.isRequired,
};
