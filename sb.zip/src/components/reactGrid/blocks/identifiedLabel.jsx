import PropTypes from 'prop-types';
import React from 'react';
import DateTime from 'src/modules/dateTime';

export default function IdentifiedLabel({ date }) {
    // FIX #746961 - separate date from time to mantain
    // the expected pattern on arabic
    const dateTime = DateTime.createDateTime(date);
    const dateParsed = dateTime.formatDate({ showYear: false });
    const timeParsed = dateTime.formatTime({ showSeconds: false });

    return (
        <div className="grid grid--seriessm">
            <p className="grid-cell g--fit">{dateParsed}</p>
            <p className="grid-cell g--fill">{timeParsed}</p>
        </div>
    );
}

IdentifiedLabel.propTypes = {
    date: PropTypes.string.isRequired,
};
