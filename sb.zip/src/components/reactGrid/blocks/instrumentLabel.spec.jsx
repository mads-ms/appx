import React from 'react';
import { shallow } from 'enzyme';
import InstrumentLabel from 'src/components/reactGrid/blocks/instrumentLabel';

describe('src/components/reactGrid/blocks/instrumentLabel', () => {
    it('renders successfully', () => {
        const wrapper = shallow(<InstrumentLabel name="EURUSD" type="FxSpot"/>);
        expect(wrapper.find('.instr-name').length).toEqual(1);
        expect(wrapper.find('.instr-name').text()).toEqual('EURUSD');
        expect(wrapper.find('InstrumentIcon').length).toEqual(1);
        expect(wrapper.find('InstrumentIcon').props().isLarge).toEqual(false);
    });

    it('passes instrument type to <InstrumentIcon/>', () => {
        const wrapper = shallow(<InstrumentLabel name="EURUSD" type="FxSpot"/>);
        expect(wrapper.find('InstrumentIcon').props().instrument).toEqual({ AssetType: 'FxSpot', DisplayHint: undefined });
    });

    it('passes instrument type with subType to <InstrumentIcon/>', () => {
        const wrapper = shallow(<InstrumentLabel name="EURUSD" type="FxSpot" subType="PreciousMetal"/>);
        const props = wrapper.find('InstrumentIcon').props();
        expect(props.instrument).toEqual({ AssetType: 'FxSpot', DisplayHint: 'PreciousMetal' });
    });

    it('supports double row render with description', () => {
        const wrapper = shallow(<InstrumentLabel name="EURUSD" type="FxSpot" description="Euro/Dollar"/>);
        expect(wrapper.find('.instr-desc').length).toEqual(1);
        expect(wrapper.find('.instr-desc').text()).toEqual('Euro/Dollar');
        expect(wrapper.find('InstrumentIcon').props().isLarge).toEqual(true);
    });

    it('supports additional instrument information', () => {
        const wrapper = shallow(<InstrumentLabel name="EURUSD" type="FxSpot" info="21-12-2011 @1.234"/>);
        expect(wrapper.find('.instr-name').length).toEqual(1);
        expect(wrapper.find('.instr-info').text()).toEqual('21-12-2011 @1.234');
    });
});
