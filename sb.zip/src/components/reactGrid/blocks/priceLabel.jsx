import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import * as numberFormat from 'src/numberFormat';
import { getChangeDataValue } from '../commonFormatting';

export default function PriceLabel({ price, currency, format, profitValue, className, amount, priceChange }) {

    if (_.isNil(format) || _.isNil(price)) {
        return <p className={className}>-</p>;
    }

    const profit = _.isNil(profitValue) ? price : profitValue;
    const profitDir = _.isNil(priceChange) ? (price - profit) : priceChange;
    const profitProp = getChangeDataValue(profitDir);
    const parts = numberFormat.formatPriceParts(price, format);
    const prefix = parts.Pre + parts.First + parts.Pips;

    let result;
    if (parts.DeciPips) {
        result = [prefix, <sub key="deciPips">{parts.DeciPips}</sub>];
    } else {
        result = [prefix + parts.DeciPips + parts.Post];
    }

    if (currency) {
        result = _.concat(result, ' ', currency);
    }

    if (amount) {
        result = _.concat(amount, ' @', result);
    }

    return (
        <p className={className}>
            <span data-profit={profitProp}>
                {result}
            </span>
        </p>
    );
}

PriceLabel.propTypes = {
    currency: PropTypes.string,
    className: PropTypes.string,
    price: PropTypes.number,
    profitValue: PropTypes.number,
    priceChange: PropTypes.number,
    amount: PropTypes.string,
    format: PropTypes.object,
};
