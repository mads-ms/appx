import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import Button from 'src/components/button/button';
import Icon from 'src/components/icon/icon';
import { bindHandlers } from 'src/utils/bindHandlers';

class ExpandButton extends React.Component {

    handleTap(evt) {
        this.props.onTap(evt, this.props);
    }

    render() {
        const { isEnabled, className, title, rowInfo } = this.props;

        if (!isEnabled) {
            return false;
        }

        return (
            <Button onTap={this.handleTap} className={classNames(className, 'btn--link', 'grid')}>
                <Icon title={title} type={rowInfo.isExpanded ? 'toggleclose' : 'toggleopen'}/>
            </Button>
        );
    }
}

ExpandButton.propTypes = {
    className: PropTypes.string,
    isEnabled: PropTypes.bool,
    rowId: PropTypes.string,
    rowData: PropTypes.object,
    rowInfo: PropTypes.object,
    onTap: PropTypes.func,
    title: PropTypes.string,
};

ExpandButton.defaultProps = {
    isEnabled: true,
    onTap: _.noop,
};

export default bindHandlers(ExpandButton);
