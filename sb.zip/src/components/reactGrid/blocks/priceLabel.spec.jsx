import React from 'react';
import { shallow } from 'enzyme';
import PriceLabel from 'src/components/reactGrid/blocks/priceLabel';

describe('src/components/reactGrid/blocks/priceLabel', () => {
    it('renders successfully', () => {
        const wrapper = shallow(<PriceLabel price={1.234} format={{ Decimals: 2, Format: 'AllowDecimalPips' }}/>);
        expect(wrapper.find('span').text()).toEqual('1.234');
    });

    it('renders formatted price', () => {
        const wrapper = shallow(<PriceLabel price={1.2345} format={{ Decimals: 6, Format: 'ModernFractions', NumeratorDecimals: 0, OrderDecimals: 6 }}/>);
        expect(wrapper.find('span').text()).toEqual('1\'15');
    });

    it('displays currency', () => {
        const wrapper = shallow(<PriceLabel price={1.234} currency="EUR" format={{ Decimals: 2, Format: 'AllowDecimalPips' }}/>);
        expect(wrapper.find('span').text()).toEqual('1.234 EUR');
    });

    it('shows no profit by default', () => {
        const wrapper = shallow(<PriceLabel price={-1.234} format={{ Decimals: 2, Format: 'AllowDecimalPips' }}/>);
        expect(wrapper.find('span').props()['data-profit']).toEqual('0');
    });

    it('supports positive profit', () => {
        const wrapper = shallow(<PriceLabel price={1.234} profitValue={1.233} format={{ Decimals: 2, Format: 'AllowDecimalPips' }}/>);
        expect(wrapper.find('span').props()['data-profit']).toEqual('+ve');
    });

    it('supports negative profit', () => {
        const wrapper = shallow(<PriceLabel price={-1.234} profitValue={-1.233} format={{ Decimals: 2, Format: 'AllowDecimalPips' }}/>);
        expect(wrapper.find('span').props()['data-profit']).toEqual('-ve');
    });

    it('supports custom className', () => {
        const wrapper = shallow(<PriceLabel price={-1.234} className="myClass" format={{ Decimals: 2, Format: 'AllowDecimalPips' }}/>);
        expect(wrapper.find('p').hasClass('myClass')).toEqual(true);
    });

    it('supports custom className when no price', () => {
        const wrapper = shallow(<PriceLabel className="myClass"/>);
        expect(wrapper.find('p').hasClass('myClass')).toEqual(true);
    });

    it('supports undefined price', () => {
        const wrapper = shallow(<PriceLabel format={{ Decimals: 2, Format: 'AllowDecimalPips' }}/>);
        expect(wrapper.text()).toEqual('-');
    });

    it('supports undefined format', () => {
        const wrapper = shallow(<PriceLabel price={-1.234}/>);
        expect(wrapper.text()).toEqual('-');
    });

    it('shows negative profit based on priceChange and not profitValue if priceChange is defined', () => {
        const wrapper = shallow(<PriceLabel price={1.234} priceChange={-0.001} profitValue={1.233} format={{ Decimals: 2, Format: 'AllowDecimalPips' }}/>);
        expect(wrapper.find('span').props()['data-profit']).toEqual('-ve');
    });

    it('shows positive profit based on priceChange if priceChange is defined', () => {
        const wrapper = shallow(<PriceLabel price={-1.234} priceChange={0.001} profitValue={-1.233} format={{ Decimals: 2, Format: 'AllowDecimalPips' }}/>);
        expect(wrapper.find('span').props()['data-profit']).toEqual('+ve');
    });

    it('shows profit based on priceChange if priceChange is defined', () => {
        const wrapper = shallow(<PriceLabel price={1.234} priceChange={0.00} profitValue={1.233} format={{ Decimals: 2, Format: 'AllowDecimalPips' }}/>);
        expect(wrapper.find('span').props()['data-profit']).toEqual('0');
    });
});
