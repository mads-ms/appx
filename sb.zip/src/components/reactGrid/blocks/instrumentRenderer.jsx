import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import InstrumentIcon from 'src/components/instrument/instrumentIcon';
import InstrumentName from 'src/components/instrument/instrumentName';
import InstrumentSecondaryInfo from 'src/components/instrument/instrumentSecondaryInfo';

class InstrumentRenderer extends React.PureComponent {

    render() {
        const { instrument, onIconTap } = this.props;

        if (!instrument) {
            return false;
        }

        return (
            <div className="instr grid grid--fit-fill grid--cross-center">
                <InstrumentIcon instrument={instrument} onTap={onIconTap} className="grid-cell"/>
                <InstrumentName {...this.props}>
                    <InstrumentSecondaryInfo showExpiryDateForFutures={false} {...this.props}/>
                </InstrumentName>
            </div>
        );
    }
}

InstrumentRenderer.propTypes = {
    instrument: PropTypes.object.isRequired,
    onIconTap: PropTypes.func,
};

InstrumentRenderer.defaultProps = {
    onIconTap: _.noop,
};

export default InstrumentRenderer;
