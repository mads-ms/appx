import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import FormattedPrice from 'src/components/formattedPrice/formattedPrice';

export default function FormattedPriceRenderer({ rowData, value, tooltip, className }) {
    return (
        <p className={className} title={tooltip}>
            {
                _.isNil(value) ?
                    '\u00A0' :
                    <FormattedPrice price={value} instrument={rowData.instrument}/>
            }
        </p>
    );
}

FormattedPriceRenderer.propTypes = {
    rowData: PropTypes.object,
    value: PropTypes.string,
    tooltip: PropTypes.string,
    className: PropTypes.string,
};
