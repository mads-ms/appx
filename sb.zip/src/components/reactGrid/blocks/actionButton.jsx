import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import Touchable from 'src/components/touchable/touchable';
import { bindHandlers } from 'src/utils/bindHandlers';
import Icon from 'src/components/icon/icon';

class ActionButton extends React.Component {

    handleTap(evt) {
        const { column, instrument } = this.props;

        this.props.column.onTap({
            column,
            instrument,
            evt,
        });
    }

    render() {
        const { isEnabled, className, value, betaValue, column, direction, betaDirection, title } = this.props;

        const dir = direction || betaDirection;
        let update = '';
        const primaryTitleTestClass = column.primaryTitle ? 'tst-' + column.primaryTitle.trim().replace(' ', '-') : '';
        const secondaryTitleTestClass = column.secondaryTitle ? 'tst-' + column.secondaryTitle.trim().replace(' ', '-') : '';

        if (dir === 'up') {
            update = 'pos';
        } else if (dir === 'down') {
            update = 'neg';
        }

        // Not using <Button /> here because ActionButton must not have `btn` class name. Refer to @TI for questioning this decision.
        return (
            <Touchable onTap={this.handleTap} isEnabled={isEnabled}>
                <button
                    className={classNames(className, 'actionbtn')}
                    type="button"
                    disabled={!isEnabled}
                    data-price-update={update}
                    title={isEnabled ? title : ''}
                >
                    <p className={primaryTitleTestClass}>
                        {isEnabled && (value === '' || value == null) ? '-' : value}
                    </p>
                    {betaValue != null &&
                        <p className={classNames('beta', secondaryTitleTestClass)}>
                            {betaValue}
                        </p>
                    }
                    <Icon type="arrow" className={classNames('indicator', { 'indicator--right': column.align === 'start' })}/>
                </button>
            </Touchable>
        );
    }
}

ActionButton.propTypes = {
    betaDirection: PropTypes.string,
    betaValue: PropTypes.node,
    className: PropTypes.string,
    column: PropTypes.object.isRequired,
    direction: PropTypes.string,
    instrument: PropTypes.object,
    isEnabled: PropTypes.bool,
    title: PropTypes.string,
    value: PropTypes.node.isRequired,
};

export default bindHandlers(ActionButton);
