import PropTypes from 'prop-types';
import React from 'react';
import Header from './defaultHeaderRenderer';
import Localization from 'src/localization';

class InstrumentHeader extends React.PureComponent {

    render() {
        const { column, sort } = this.props;

        return (
            <Header
                column={column}
                sort={sort}
                primaryTitle={Localization.getText('HTML5_Instrument')}
                isSortAlignEnd
            />
        );
    }
}
InstrumentHeader.propTypes = {
    column: PropTypes.object.isRequired,
    sort: PropTypes.object,
};

export default InstrumentHeader;
