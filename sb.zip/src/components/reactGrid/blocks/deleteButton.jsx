import PropTypes from 'prop-types';
import React from 'react';
import Button from 'src/components/button/button';
import classNames from 'classnames';
import { bindHandlers } from 'src/utils/bindHandlers';
import Icon from 'src/components/icon/icon';

class DeleteButton extends React.Component {

    handleTap(evt) {
        this.deleteRow(evt);
    }

    // onTouchStart is handled to avoid conflicts with drag and drop library (e.g. bug #750964)
    // calling stopPropagation() in deleteRow() will prevent hammer from firing a tap event,
    // since it listens to events on the documentElement
    handleTouchStart(evt) {
        this.deleteRow(evt);
    }

    deleteRow(evt) {
        this.props.column.onRowRemoving({
            column: this.props.column,
            instrument: this.props.instrument,
        });

        // the DeleteButton component is intended to be placed inside the row of ReactGrid
        // since the result of the tap on the button is the removal of the row,
        // we are stopping tap propagation here to avoid unnecessary interference with the row events (e.g. bug #712044)
        evt.stopPropagation();
    }

    render() {
        return (
            <Button
                onTap={this.handleTap}
                onTouchStart={this.handleTouchStart}
                className={classNames(this.props.className, 'reactgrid-removebtn btn btn--clear')}
            >
                <Icon type="delete"/>
            </Button>
        );
    }
}

DeleteButton.propTypes = {
    className: PropTypes.string,
    column: PropTypes.object.isRequired,
    instrument: PropTypes.object.isRequired,
};

export default bindHandlers(DeleteButton);
