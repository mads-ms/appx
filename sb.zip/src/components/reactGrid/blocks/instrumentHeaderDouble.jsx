import PropTypes from 'prop-types';
import React from 'react';
import Header from './defaultHeaderRenderer';
import Localization from 'src/localization';

class InstrumentHeaderDouble extends React.PureComponent {

    render() {
        const { sort, column } = this.props;
        const primaryTitle = column.primaryTitle || Localization.getText('HTML5_Instrument');
        const secondaryTitle = column.secondaryTitle || Localization.getText('HTML5_Description');

        return (
            <Header
                sort={sort}
                column={column}
                primaryTitle={primaryTitle}
                secondaryTitle={secondaryTitle}
                isSortAlignEnd
            />
        );
    }
}

InstrumentHeaderDouble.propTypes = {
    column: PropTypes.object.isRequired,
    sort: PropTypes.object,
};

export default InstrumentHeaderDouble;

