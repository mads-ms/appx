import React from 'react';
import { mount } from 'enzyme';
import DefaultCellRenderer from 'src/components/reactGrid/blocks/defaultCellRenderer';
import * as renderUtils from 'src/components/reactGrid/reactGridRendererUtils';

describe('src/components/reactGrid/blocks/defaultCellRenderer', () => {

    describe('cell content', () => {
        // eslint-disable-next-line no-unused-vars
        const itemToLabel = [({ rowData, rowInfo }) => rowData.primary];
        const columnId = 'test';

        const testProps = {
            rowData: { primary: 'primary', secondary: 'secondary' },
            rowInfo: {},
            column: { id: columnId, itemToLabel },
        };

        it('renders primary item only', () => {
            const wrapper = mount(<DefaultCellRenderer {...testProps}/>);
            expect(wrapper.find('div').length).toEqual(1);
            expect(wrapper.find('p').length).toEqual(1);
            expect(wrapper.find('span').text()).toEqual('primary');
        });

        it('renders primary and secondary test classes', () => {

            testProps.column.itemToLabel = [
                ({ rowData }) => rowData.primary,
                ({ rowData }) => rowData.secondary,
            ];

            const wrapper = mount(<DefaultCellRenderer {...testProps}/>);
            expect(wrapper.find('div').length).toEqual(1);
            expect(wrapper.find('p').length).toEqual(2);
        });

        it('renders primary and secondary content', () => {

            testProps.column.itemToLabel = [
                ({ rowData }) => rowData.primary,
                ({ rowData }) => rowData.secondary,
            ];

            const wrapper = mount(<DefaultCellRenderer {...testProps}/>);
            expect(wrapper.find('div').length).toEqual(1);
            expect(wrapper.find('span').at(0).text()).toEqual('primary');
            expect(wrapper.find('span').at(1).text()).toEqual('secondary');
        });

        it('renders primary and secondary tst classes', () => {

            testProps.column.itemToLabel = [
                ({ rowData }) => rowData.primary,
                ({ rowData }) => rowData.secondary,
            ];

            const wrapper = mount(<DefaultCellRenderer {...testProps}/>);
            expect(wrapper.find('div').length).toEqual(1);
            expect(wrapper.find(`.${renderUtils.getPrimaryItemTestClass(testProps.column)}`).length).toEqual(1);
            expect(wrapper.find(`.${renderUtils.getSecondaryItemTestClass(testProps.column)}`).length).toEqual(1);
        });
    });

    describe('tooltips', () => {
        let itemToLabel;
        let testProps;

        beforeEach(() => {
            itemToLabel = [
                ({ rowData }) => rowData.primary,
                ({ rowData }) => rowData.secondary,
            ];

            const columnId = 'test';

            testProps = {
                rowData: { primary: 'primary content', secondary: 'secondary content' },
                rowInfo: {},
                column: { id: columnId, itemToLabel },
            };

        });

        it('should render primary tooltip privided via function', () => {
            testProps.column.primaryTooltip = ({ rowData }) => `Tooltip for: ${rowData.primary}`;

            const wrapper = mount(<DefaultCellRenderer {...testProps}/>);
            const primaryContent = wrapper.find(`.${renderUtils.getPrimaryItemTestClass(testProps.column)}`).first();
            expect(primaryContent.prop('title')).toEqual('Tooltip for: primary content');
        });

        it('should render secondary tooltip privided via function', () => {
            testProps.column.secondaryTooltip = ({ rowData }) => `Tooltip for: ${rowData.secondary}`;

            const wrapper = mount(<DefaultCellRenderer {...testProps}/>);
            const secondaryContent = wrapper.find(`.${renderUtils.getSecondaryItemTestClass(testProps.column)}`).first();
            expect(secondaryContent.prop('title')).toEqual('Tooltip for: secondary content');
        });

        it('should not render tooltip when there\'s no function provided', () => {
            const wrapper = mount(<DefaultCellRenderer {...testProps}/>);
            const primaryContent = wrapper.find(`.${renderUtils.getPrimaryItemTestClass(testProps.column)}`).first();
            const secondaryContent = wrapper.find(`.${renderUtils.getSecondaryItemTestClass(testProps.column)}`).first();
            expect(primaryContent.prop('title')).toBeUndefined();
            expect(secondaryContent.prop('title')).toBeUndefined();
        });
    });

    describe('primary/secondary templates', () => {

        const itemToLabel = [({ rowData }) => rowData.primary];
        const columnId = 'test';

        const testProps = {
            rowData: { primary: 'primary', secondary: 'secondary' },
            primaryTemplate: () => <div id="primary-template">primary</div>,
            secondaryTemplate: () => <div id="secondary-template">secondary</div>,
            column: { id: columnId, itemToLabel },
        };

        it('should render primary tooltip privided via function', () => {
            testProps.column.itemToLabel = [
                ({ rowData }) => rowData.primary,
                ({ rowData }) => rowData.secondary,
            ];

            const wrapper = mount(<DefaultCellRenderer {...testProps}/>);
            expect(wrapper.find('#primary-template').length).toEqual(1);
            expect(wrapper.find('#secondary-template').length).toEqual(1);
        });
    });

});
