import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import { IconHigh, IconLow } from '../reactGridBlocks';
import * as sortUtils from 'src/components/reactGrid/reactGridSortUtils';
import * as renderUtils from 'src/components/reactGrid/reactGridRendererUtils';

class Header extends React.PureComponent {

    render() {
        const {
            column,
            sort,
            isSortAlignEnd,
        } = this.props;

        const isSortable = sortUtils.getIsColumnSortable(column);

        const sortProps = {
            'data-sortable': isSortable,
            'data-align-end': isSortAlignEnd,
        };
        let sortIcons = false;

        if (isSortable) {
            sortProps['data-sortdir'] = sortUtils.getColumnSortDataValue(column, sort);
            sortIcons = [<IconHigh key="icon-high"/>, <IconLow key="icon-low"/>];
        }

        const primaryTitle = this.props.primaryTitle || column.primaryTitle;
        const secondaryTitle = this.props.secondaryTitle || column.secondaryTitle;
        const unitsLabel = this.props.unitsLabel || column.unitsLabel;
        const headerElements = isSortAlignEnd ? [primaryTitle, ' ', ...sortIcons] : [...sortIcons, ' ', primaryTitle];
        const primaryTitleTestClass = renderUtils.getPrimaryHeaderTestClass(column);
        const secondaryTitleTestClass = renderUtils.getSecondaryHeaderTestClass(column);

        return (
            <div
                className={classNames('col-header', 'tst-col-header', column.className)}
                {...sortProps}
            >
                {primaryTitle &&
                <p className={primaryTitleTestClass}>
                    {headerElements}
                    {unitsLabel && <span className="units"> ({unitsLabel})</span>}
                </p>
                }
                {secondaryTitle &&
                <p className={classNames('beta', secondaryTitleTestClass)}>{secondaryTitle}</p>
                }
                {!primaryTitle && !secondaryTitle &&
                <p>&nbsp;</p>
                }
            </div>
        );
    }

}

Header.propTypes = {
    // Removed as required because there are instances where this renderer is used as template,
    // it's cloned and populated with columns.
    column: PropTypes.object,
    sort: PropTypes.object,
    primaryTitle: PropTypes.string,
    secondaryTitle: PropTypes.string,
    unitsLabel: PropTypes.string,
    isSortAlignEnd: PropTypes.bool,
};

export default Header;
