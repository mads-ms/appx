import React from 'react';
import PropTypes from 'prop-types';
import InstrumentIcon from 'src/components/instrument/instrumentIcon';

export default function InstrumentLabel({ name, tooltip, type, info, subType, description }) {

    return (
        <div className="instr grid grid--cross-center">
            <InstrumentIcon
                className="grid-cell g--fit instr-market"
                instrument={{ AssetType: type, DisplayHint: subType }}
                isLarge={Boolean(description)}
            />
            <dl className="grid-cell" title={tooltip}>
                <dt className="instr-name">
                    {name}
                    {info && <sub className="instr-info">{info}</sub>}
                </dt>
                <dd className="instr-desc">
                    {description && description}
                </dd>
            </dl>
        </div>
    );
}

InstrumentLabel.propTypes = {
    description: PropTypes.string,
    iconClass: PropTypes.string,
    info: PropTypes.string,
    name: PropTypes.string,
    tooltip: PropTypes.string,
    type: PropTypes.string,
    subType: PropTypes.string,
};
