import React from 'react';
import { mount } from 'enzyme';
import { tap } from 'test/mocks/touchableHelper';
import Icon from 'src/components/icon/icon';
import ExpandButton from 'src/components/reactGrid/blocks/expandButton';

describe('src/components/reactGrid/blocks/expandButton', () => {
    it('renders succesfully', () => {
        const wrapper = mount(<ExpandButton rowInfo={{}} rowData={{}}/>);
        expect(wrapper.find('.btn').length).toEqual(1);
    });

    it('supports tap event', () => {
        const tapSpy = jasmine.createSpy('tapSpy');
        const wrapper = mount(<ExpandButton onTap={tapSpy} id="id" rowInfo={{}} rowData={{}}/>);
        tap(wrapper.find('.btn').first());

        expect(tapSpy).toHaveBeenCalledWith(jasmine.any(Event), jasmine.objectContaining({ id: 'id' }));
    });

    it('changes icon type on expand', () => {
        const wrapper = mount(<ExpandButton rowInfo={{}} rowData={{}}/>);
        const initialType = wrapper.find(Icon).prop('type');
        wrapper.setProps({ rowInfo: { isExpanded: true } });
        const newType = wrapper.find(Icon).prop('type');

        expect(initialType).not.toEqual(newType);
    });
});
