import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import { getChangeDataValue } from '../commonFormatting';

export default function ProfitLabel({ value, profitValue, children, className, title }) {

    if (_.isNil(value)) {
        return <span title={title} className={className}>-</span>;
    }

    const profitDir = value - profitValue;
    const profitProp = getChangeDataValue(profitDir, '');

    return <span title={title} className={className} data-profit={profitProp}>{children}</span>;
}

ProfitLabel.propTypes = {
    className: PropTypes.string,
    title: PropTypes.string,
    value: PropTypes.number,
    profitValue: PropTypes.number,
};

ProfitLabel.defaultProps = {
    profitValue: 0,
};
