import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import * as renderUtils from 'src/components/reactGrid/reactGridRendererUtils';
import classNames from 'classnames';

const DefaultContentTemplate = ({ className, tooltip, value }) => (
    <p className={className} title={tooltip}>
        <span>{value}</span>
    </p>
);

DefaultContentTemplate.propTypes = {
    rowData: PropTypes.object,
    value: PropTypes.string,
    tooltip: PropTypes.string,
    className: PropTypes.string,
};

class DefaultCellRenderer extends React.PureComponent {
    render() {
        const {
            column,
            primaryTemplate,
            secondaryTemplate,
            rowData,
        } = this.props;

        if (!column.itemToLabel) {
            return null;
        }

        let [primary, secondary] = column.itemToLabel;

        primary = _.isFunction(primary) ? primary(this.props) : '';
        secondary = _.isFunction(secondary) ? secondary(this.props) : null;

        const primaryClassName = renderUtils.getPrimaryItemTestClass(column);
        const secondaryClassName = renderUtils.getSecondaryItemTestClass(column);

        const primaryTooltip = _.isFunction(column.primaryTooltip) ? column.primaryTooltip(this.props) : undefined;
        const secondaryTooltip = _.isFunction(column.secondaryTooltip) ? column.secondaryTooltip(this.props) : undefined;

        const primaryRenderer = renderUtils.createRenderer(primaryTemplate, {
            className: primaryClassName,
            value: primary,
            tooltip: primaryTooltip,
            rowData,
        });

        const secondaryRenderer = renderUtils.createRenderer(secondaryTemplate, {
            className: classNames(secondaryClassName, 'beta'),
            value: secondary,
            tooltip: secondaryTooltip,
            rowData,
        });

        return (
            <div>
                {primaryRenderer}
                {secondary &&
                    secondaryRenderer
                }
            </div>
        );
    }
}

DefaultCellRenderer.propTypes = {
    column: PropTypes.shape({
        id: PropTypes.string.isRequired,
        itemToLabel: PropTypes.arrayOf(PropTypes.func),
        primaryTooltip: PropTypes.func,
        secondaryTooltip: PropTypes.func,
    }),

    rowData: PropTypes.object,
    primaryTemplate: PropTypes.oneOfType([
        PropTypes.func,
        PropTypes.element,
    ]),
    secondaryTemplate: PropTypes.oneOfType([
        PropTypes.func,
        PropTypes.element,
    ]),
};

DefaultCellRenderer.defaultProps = {
    primaryTemplate: DefaultContentTemplate,
    secondaryTemplate: DefaultContentTemplate,
};

export default DefaultCellRenderer;
