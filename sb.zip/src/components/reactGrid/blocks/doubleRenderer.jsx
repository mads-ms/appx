import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';

class DoubleRenderer extends React.PureComponent {

    render() {
        const { primary, secondary } = this.props;
        const childrenProps = _.omit(this.props, ['primary', 'secondary']);
        const first = React.createElement(primary, childrenProps);
        const second = React.createElement(secondary, childrenProps);

        return (
            <div>
                <p>
                    {first}
                </p>
                <p className="beta">
                    {second}
                </p>
            </div>
        );
    }
}

DoubleRenderer.propTypes = {
    rowData: PropTypes.object,
    primary: PropTypes.func.isRequired,
    secondary: PropTypes.func.isRequired,
};

export default DoubleRenderer;
