import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import { ActionButton, IconHigh, IconLow } from '../reactGridBlocks';
import { getIsColumnSortable, getColumnSortDataValue } from 'src/components/reactGrid/reactGridSortUtils';

class ColumnPickerHeader extends React.PureComponent {

    render() {
        const {
            column,
            sort,
            className,
        } = this.props;

        const isSortable = getIsColumnSortable(column);
        const sortDataValue = getColumnSortDataValue(column, sort);

        const sortIcons = isSortable && [<IconHigh key="icon-high"/>, <IconLow key="icon-low"/>];

        const headerElements = column.isSortAlignEnd ? [column.primaryTitle, ...sortIcons] : [...sortIcons, column.primaryTitle];

        return (
            <div
                className={classNames('col-header', className)}
                data-sortdir={sortDataValue}
            >
                <ActionButton
                    betaValue={column.secondaryTitle}
                    title={column.primaryTitle}
                    value={headerElements}
                    column={column}
                    isEnabled
                />
            </div>
        );
    }

}

ColumnPickerHeader.propTypes = {
    className: PropTypes.string,
    column: PropTypes.object.isRequired,
    sort: PropTypes.object,
};

export default ColumnPickerHeader;
