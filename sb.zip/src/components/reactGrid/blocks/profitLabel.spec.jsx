import React from 'react';
import { shallow } from 'enzyme';
import ProfitLabel from 'src/components/reactGrid/blocks/profitLabel';

describe('src/components/reactGrid/blocks/profitLabel', () => {
    it('renders successfully', () => {
        const wrapper = shallow(<ProfitLabel value={1.234}>1.234.00</ProfitLabel>);
        expect(wrapper.find('span').text()).toEqual('1.234.00');
    });

    it('supports positive profit', () => {
        const wrapper = shallow(<ProfitLabel value={1.234} profitValue={1.233}/>);
        expect(wrapper.find('span').props()['data-profit']).toEqual('+ve');
    });

    it('supports negative profit', () => {
        const wrapper = shallow(<ProfitLabel value={-1.234}/>);
        expect(wrapper.find('span').props()['data-profit']).toEqual('-ve');
    });

    it('supports neutral profit', () => {
        const wrapper = shallow(<ProfitLabel value={-1.234} profitValue={-1.234}/>);
        expect(wrapper.find('span').props()['data-profit']).toEqual('');
    });

    it('supports custom className', () => {
        const wrapper = shallow(<ProfitLabel price={-1.234} className="myClass"/>);
        expect(wrapper.find('span').hasClass('myClass')).toEqual(true);
    });

    it('supports custom className when no value', () => {
        const wrapper = shallow(<ProfitLabel className="myClass"/>);
        expect(wrapper.find('span').hasClass('myClass')).toEqual(true);
    });

    it('supports undefined value', () => {
        const wrapper = shallow(<ProfitLabel/>);
        expect(wrapper.find('span').text()).toEqual('-');
    });
});
