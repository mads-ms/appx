import React from 'react';
import PropTypes from 'prop-types';
import InstrumentDouble from 'src/components/instrument/instrumentDouble';

class InstrumentDoubleRenderer extends React.PureComponent {

    render() {
        return (
            <InstrumentDouble
                instrument={this.props.rowData.instrument}
            />
        );
    }

}

InstrumentDoubleRenderer.propTypes = {
    rowData: PropTypes.shape({
        instrument: PropTypes.object.isRequired,
    }),
};

export default InstrumentDoubleRenderer;
