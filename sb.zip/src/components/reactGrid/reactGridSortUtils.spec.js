import * as sortUtils from 'src/components/reactGrid/reactGridSortUtils';

describe('src/components/reactGrid/reactGridSortUtils', () => {

    describe('getSort()', () => {

        it('should return column sort', () => {
            const config = {};

            expect(sortUtils.getSort(config)).toBeFalsy();

            config.sort = { id: 'a', fields: 'a' };
            expect(sortUtils.getSort(config)).toEqual({ id: 'a', fields: [{ path: 'a' }] });

            config.sort = { id: 'a', fields: ['a', 'b'] };
            expect(sortUtils.getSort(config)).toEqual({ id: 'a', fields: [{ path: 'a' }, { path: 'b' }] });

            config.sort = {
                id: 'a',
                compareFunction: () => {
                },
                fields: [
                    {
                        path: 'a.a',
                        direction: 1,
                        compareFunction: () => {
                        },
                    },
                    {
                        path: 'a.b',
                        direction: -1,
                    },
                ],
            };
            expect(sortUtils.getSort(config)).toEqual(config.sort);
        });
    });

    describe('getNextSortDirection()', () => {

        it('should change correctly sort direction with default sort mode', () => {

            // change from asc to desc
            expect(sortUtils.getNextSortDirection(1)).toBe(-1);

            // change from desc to asc
            expect(sortUtils.getNextSortDirection(-1)).toBe(1);

            // don't change sort direction
            expect(sortUtils.getNextSortDirection(0)).toBe(0);
        });

        it('should change correctly sort direction with extended sort mode', () => {

            // change from asc to desc
            expect(sortUtils.getNextSortDirection(1, 1)).toBe(-1);

            // change from desc to no sort
            expect(sortUtils.getNextSortDirection(-1, 1)).toBe(0);

            // change from no sort to asc
            expect(sortUtils.getNextSortDirection(0, 1)).toBe(1);
        });
    });

    describe('getSortedColumn()', () => {

        it('should return false', () => {
            expect(sortUtils.getSortedColumn('test', undefined)).toBeFalsy();
            expect(sortUtils.getSortedColumn('test', [])).toBeFalsy();
        });

        it('should return column by sort id', () => {
            const columns = [
                {
                    sort: { id: 'a' },
                },
                {
                    sort: { id: 'b' },
                },
            ];

            expect(sortUtils.getSortedColumn({ id: 'b' }, columns)).toEqual({
                sort: { id: 'b' },
            });
        });
    });

    describe('getIsColumnSortable()', () => {

        it('should not be sortable', () => {
            expect(sortUtils.getIsColumnSortable({})).toBeFalsy();
            expect(sortUtils.getIsColumnSortable(undefined)).toBeFalsy();
        });

        it('should be sortable', () => {
            expect(sortUtils.getIsColumnSortable({ sort: {} })).toBe(true);
        });
    });

    describe('getIsSortSupported()', () => {

        it('sorting should be enabled', () => {
            expect(sortUtils.getIsSortSupported({
                compareFunction: () => {
                },
            }, null)).toBe(true);

            expect(sortUtils.getIsSortSupported({}, { sort: {} })).toBe(true);
        });

        it('sorting should be disabled', () => {
            expect(sortUtils.getIsSortSupported(null, null)).toBe(false);
            expect(sortUtils.getIsSortSupported({ direction: 0 }, null)).toBe(false);
        });
    });

    describe('defaultCompareFunction()', () => {

        it('it sorts correctly empty values', () => {
            expect(sortUtils.defaultCompareFunction({ a: null }, { a: null }, 'a')).toBe(0);
            expect(sortUtils.defaultCompareFunction({ a: null }, { a: undefined }, 'a')).toBe(0);
            expect(sortUtils.defaultCompareFunction({ a: null }, { a: '' }, 'a')).toBe(0);
        });

        it('it sorts correctly string values', () => {
            expect(sortUtils.defaultCompareFunction({ a: 'A ' }, { a: 'A' }, 'a')).toBe(0);
            expect(sortUtils.defaultCompareFunction({ a: 'ą' }, { a: 'a' }, 'a')).toBe(1);
        });

        it('it sorts correctly mixed values', () => {
            expect(sortUtils.defaultCompareFunction({ a: 10 }, { a: '' }, 'a')).toBe(1);
            expect(sortUtils.defaultCompareFunction({ a: '' }, { a: 10 }, 'a')).toBe(-1);
        });

        it('it sorts correctly number values', () => {
            expect(sortUtils.defaultCompareFunction({ a: 10 }, { a: -10 }, 'a')).toBe(1);
            expect(sortUtils.defaultCompareFunction({ a: -10 }, { a: 10 }, 'a')).toBe(-1);
        });

        it('it sorts correctly number string values', () => {
            expect(sortUtils.defaultCompareFunction({ a: '100' }, { a: 99 }, 'a')).toBe(1);
            expect(sortUtils.defaultCompareFunction({ a: -10 }, { a: '10' }, 'a')).toBe(-1);
        });

        it('it sorts correctly number string values2', () => {
            expect(sortUtils.defaultCompareFunction({ a: '100' }, { a: '99' }, 'a')).toBe(1);
            expect(sortUtils.defaultCompareFunction({ a: '99' }, { a: '100' }, 'a')).toBe(-1);
        });

        it('it sorts correctly nested properties', () => {
            expect(sortUtils.defaultCompareFunction({ a: { a: 10 } }, { a: { a: -10 } }, 'a.a')).toBe(1);
            expect(sortUtils.defaultCompareFunction({ a: { a: -10 } }, { a: { a: 10 } }, 'a.a')).toBe(-1);
        });
    });

    describe('getColumnSortDataValue()', () => {

        it('should return no sort data value', () => {
            expect(sortUtils.getColumnSortDataValue({}, {})).toBe('-');
            expect(sortUtils.getColumnSortDataValue({ sort: {} }, { direction: 0 })).toBe('-');
        });

        it('should return asc sort data value', () => {
            expect(sortUtils.getColumnSortDataValue({ sort: {} }, {})).toBe('high');
            expect(sortUtils.getColumnSortDataValue({ sort: {} }, { direction: 1 })).toBe('high');
        });

        it('should return desc sort data value', () => {
            expect(sortUtils.getColumnSortDataValue({ sort: {} }, { direction: -1 })).toBe('low');
        });
    });

    describe('getNormalizedSort()', () => {

        it('should return correct sort definition', () => {
            expect(sortUtils.getNormalizedSort({})).toBe(null);
            expect(sortUtils.getNormalizedSort({ sortKey: 'a', isHighLow: false })).toEqual({ id: 'a', direction: 1 });
            expect(sortUtils.getNormalizedSort({ sortKey: 'a', isHighLow: true })).toEqual({ id: 'a', direction: -1 });
            expect(sortUtils.getNormalizedSort({ id: 'a', direction: -1 })).toEqual({ id: 'a', direction: -1 });
            expect(sortUtils.getNormalizedSort({ id: 'a', direction: 1 })).toEqual({ id: 'a', direction: 1 });
            expect(sortUtils.getNormalizedSort({ id: 'a' })).toEqual({ id: 'a', direction: 1 });
        });
    });

    describe('sortRows()', () => {

        let itemA;
        let itemB;
        let itemC;
        let itemD;
        let data;
        let columnSort;
        let gridSort;
        let sortedData;
        let column;

        const customCompareFunction = (currentA, currentB) => {
            const valueA = currentA.a + currentA.b;
            const valueB = currentB.a + currentB.b;

            if (valueA === valueB) {
                return 0;
            }

            return valueA > valueB ? 1 : -1;
        };

        beforeEach(() => {
            itemA = { name: 'itemA', a: 10, b: 10 };
            itemC = { name: 'itemC', a: 30, b: 30 };
            itemB = { name: 'itemB', a: 20, b: 20 };
            itemD = { name: 'itemD', a: 10, b: 20 };
            data = [itemB, itemA, itemC];
            columnSort = [];
            gridSort = {};
        });

        describe('using custom compare function', () => {

            beforeEach(() => {
                columnSort = { id: 'b', fields: [{ path: 'b' }] };
                gridSort.compareFunction = customCompareFunction;
                column = { itemToLabel: ({ rowData }) => rowData.b };
            });

            it('should use external sort compare function', () => {
                // default
                sortedData = sortUtils.sortRows(data, gridSort, columnSort, column);

                expect(sortedData[0]).toEqual(itemA);
                expect(sortedData[1]).toEqual(itemB);
                expect(sortedData[2]).toEqual(itemC);

                // asc
                gridSort.direction = 1;
                sortedData = sortUtils.sortRows(data, gridSort, columnSort, column);

                expect(sortedData[0]).toEqual(itemA);
                expect(sortedData[1]).toEqual(itemB);
                expect(sortedData[2]).toEqual(itemC);

                // desc
                gridSort.direction = -1;
                sortedData = sortUtils.sortRows(data, gridSort, columnSort, column);

                expect(sortedData[0]).toEqual(itemC);
                expect(sortedData[1]).toEqual(itemB);
                expect(sortedData[2]).toEqual(itemA);
            });

            it('should use column sort compare function', () => {
                columnSort = { id: 'a', compareFunction: customCompareFunction };

                // default
                sortedData = sortUtils.sortRows(data, gridSort, columnSort, column);

                expect(sortedData[0]).toEqual(itemA);
                expect(sortedData[1]).toEqual(itemB);
                expect(sortedData[2]).toEqual(itemC);

                // asc
                gridSort.direction = 1;
                sortedData = sortUtils.sortRows(data, gridSort, columnSort, column);

                expect(sortedData[0]).toEqual(itemA);
                expect(sortedData[1]).toEqual(itemB);
                expect(sortedData[2]).toEqual(itemC);

                // desc
                gridSort.direction = -1;
                sortedData = sortUtils.sortRows(data, gridSort, columnSort, column);

                expect(sortedData[0]).toEqual(itemC);
                expect(sortedData[1]).toEqual(itemB);
                expect(sortedData[2]).toEqual(itemA);
            });

            it('should use column sort field compare function', () => {
                columnSort = { id: 'a', fields: [{ compareFunction: customCompareFunction }] };

                // default
                sortedData = sortUtils.sortRows(data, gridSort, columnSort, column);

                expect(sortedData[0]).toEqual(itemA);
                expect(sortedData[1]).toEqual(itemB);
                expect(sortedData[2]).toEqual(itemC);

                // asc
                gridSort.direction = 1;
                sortedData = sortUtils.sortRows(data, gridSort, columnSort, column);

                expect(sortedData[0]).toEqual(itemA);
                expect(sortedData[1]).toEqual(itemB);
                expect(sortedData[2]).toEqual(itemC);

                // desc
                gridSort.direction = -1;
                sortedData = sortUtils.sortRows(data, gridSort, columnSort, column);

                expect(sortedData[0]).toEqual(itemC);
                expect(sortedData[1]).toEqual(itemB);
                expect(sortedData[2]).toEqual(itemA);
            });
        });

        describe('using single sort property', () => {

            beforeEach(() => {
                columnSort = { id: 'a', fields: [{ path: 'a' }] };
                column = { itemToLabel: ({ rowData }) => rowData.b };
            });

            it('should sort rows in default direction', () => {

                sortedData = sortUtils.sortRows(data, gridSort, columnSort, column);

                expect(sortedData[0]).toEqual(itemA);
                expect(sortedData[1]).toEqual(itemB);
                expect(sortedData[2]).toEqual(itemC);

            });

            it('should sort rows asc', () => {

                gridSort.direction = 1;
                sortedData = sortUtils.sortRows(data, gridSort, columnSort, column);

                expect(sortedData[0]).toEqual(itemA);
                expect(sortedData[1]).toEqual(itemB);
                expect(sortedData[2]).toEqual(itemC);
            });

            it('should sort rows desc', () => {

                gridSort.direction = -1;
                sortedData = sortUtils.sortRows(data, gridSort, columnSort, column);

                expect(sortedData[0]).toEqual(itemC);
                expect(sortedData[1]).toEqual(itemB);
                expect(sortedData[2]).toEqual(itemA);
            });

            it('should sort rows desc with desc order on sort field', () => {

                columnSort = { id: 'a', fields: [{ path: 'a', direction: -1 }] };
                gridSort.direction = -1;
                sortedData = sortUtils.sortRows(data, gridSort, columnSort, column);

                expect(sortedData[0]).toEqual(itemA);
                expect(sortedData[1]).toEqual(itemB);
                expect(sortedData[2]).toEqual(itemC);
            });
        });

        describe('using multiple sort properties', () => {

            beforeEach(() => {
                columnSort = { id: 'a', fields: [{ path: 'a' }, { path: 'b' }] };
                itemA = { name: 'itemA', a: 10, b: 30 };
                itemB = { name: 'itemB', a: 10, b: 20 };
                itemC = { name: 'itemC', a: 30, b: 10 };
                data = [itemA, itemB, itemC];
            });

            it('should sort rows in default direction', () => {

                sortedData = sortUtils.sortRows(data, gridSort, columnSort);

                expect(sortedData[0]).toEqual(itemB);
                expect(sortedData[1]).toEqual(itemA);
                expect(sortedData[2]).toEqual(itemC);
            });

            it('should sort asc', () => {

                gridSort.direction = 1;
                sortedData = sortUtils.sortRows(data, gridSort, columnSort);

                expect(sortedData[0]).toEqual(itemB);
                expect(sortedData[1]).toEqual(itemA);
                expect(sortedData[2]).toEqual(itemC);
            });

            it('should sort desc', () => {

                gridSort.direction = -1;
                sortedData = sortUtils.sortRows(data, gridSort, columnSort);

                expect(sortedData[0]).toEqual(itemC);
                expect(sortedData[1]).toEqual(itemA);
                expect(sortedData[2]).toEqual(itemB);
            });

            it('should sort desc with desc order on sort field', () => {

                columnSort = { id: 'a', fields: [{ path: 'a' }, { path: 'b', direction: -1 }] };

                gridSort.direction = -1;
                sortedData = sortUtils.sortRows(data, gridSort, columnSort);

                expect(sortedData[0]).toEqual(itemC);
                expect(sortedData[1]).toEqual(itemB);
                expect(sortedData[2]).toEqual(itemA);
            });
        });

        describe('using itemToLabel to get values', () => {

            beforeEach(() => {
                columnSort = { id: 'a' };
                column = { itemToLabel: [({ rowData }) => rowData.a] };
            });

            it('should sort rows in default direction', () => {

                sortedData = sortUtils.sortRows(data, gridSort, columnSort, column);

                expect(sortedData[0]).toEqual(itemA);
                expect(sortedData[1]).toEqual(itemB);
                expect(sortedData[2]).toEqual(itemC);

            });

            it('should sort rows asc', () => {

                gridSort.direction = 1;
                sortedData = sortUtils.sortRows(data, gridSort, columnSort, column);

                expect(sortedData[0]).toEqual(itemA);
                expect(sortedData[1]).toEqual(itemB);
                expect(sortedData[2]).toEqual(itemC);
            });

            it('should sort rows desc', () => {

                gridSort.direction = -1;
                sortedData = sortUtils.sortRows(data, gridSort, columnSort, column);

                expect(sortedData[0]).toEqual(itemC);
                expect(sortedData[1]).toEqual(itemB);
                expect(sortedData[2]).toEqual(itemA);
            });

            it('should sort rows desc with desc order on sort field', () => {

                columnSort = { id: 'a', fields: [{ path: 'a', direction: -1 }] };
                gridSort.direction = -1;
                sortedData = sortUtils.sortRows(data, gridSort, columnSort);

                expect(sortedData[0]).toEqual(itemA);
                expect(sortedData[1]).toEqual(itemB);
                expect(sortedData[2]).toEqual(itemC);
            });
        });

        describe('using itemToLabel to get values for double row mode', () => {

            beforeEach(() => {
                gridSort = {};
                itemA = { name: 'itemA', a: 10, b: 10 };
                itemC = { name: 'itemC', a: 30, b: 30 };
                itemB = { name: 'itemB', a: 20, b: 20 };
                itemD = { name: 'itemD', a: 10, b: 20 };
                data = [itemB, itemA, itemC, itemD];
                columnSort = { id: 'a' };
                column = {
                    itemToLabel: [
                        ({ rowData }) => rowData.a,
                        ({ rowData }) => rowData.b,
                    ],
                };
            });

            it('should sort rows in default direction', () => {

                sortedData = sortUtils.sortRows(data, gridSort, columnSort, column);

                expect(sortedData[0]).toEqual(itemA);
                expect(sortedData[1]).toEqual(itemD);
                expect(sortedData[2]).toEqual(itemB);
                expect(sortedData[3]).toEqual(itemC);

            });

            it('should sort rows asc', () => {

                gridSort.direction = 1;
                sortedData = sortUtils.sortRows(data, gridSort, columnSort, column);

                expect(sortedData[0]).toEqual(itemA);
                expect(sortedData[1]).toEqual(itemD);
                expect(sortedData[2]).toEqual(itemB);
                expect(sortedData[3]).toEqual(itemC);
            });

            it('should sort rows desc', () => {

                gridSort.direction = -1;
                sortedData = sortUtils.sortRows(data, gridSort, columnSort, column);

                expect(sortedData[0]).toEqual(itemC);
                expect(sortedData[1]).toEqual(itemB);
                expect(sortedData[2]).toEqual(itemD);
                expect(sortedData[3]).toEqual(itemA);
            });

            it('should sort rows desc with desc order on sort field', () => {

                columnSort = { id: 'a', fields: [{ path: 'a', direction: -1 }] };
                gridSort.direction = -1;
                sortedData = sortUtils.sortRows(data, gridSort, columnSort);

                expect(sortedData[0]).toEqual(itemA);
                expect(sortedData[1]).toEqual(itemD);
                expect(sortedData[2]).toEqual(itemB);
                expect(sortedData[3]).toEqual(itemC);
            });
        });
    });
});

