import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import { bindHandlers } from 'src/utils/bindHandlers';
import ColumnPicker from 'src/components/columnPicker/columnPicker';
import Enums from 'src/spine/enums';
import shallowEqual from 'react-redux/lib/utils/shallowEqual';
import Localization from 'src/localization';
import * as columnPickerConstatns from 'src/components/columnPicker/columnPickerConstants';
import config from 'src/config';

const EMPTY_ARRAY = [];

class ColumnPickerView extends React.Component {
    componentWillMount() {
        this.state = {
            rowTypes: this.getRowTypes(),
            columns: this.getColumns(this.props),
        };
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.singleColumnIds !== this.props.singleColumnIds ||
            nextProps.doubleColumnIds !== this.props.doubleColumnIds ||
            nextProps.visibleColumnIds !== this.props.visibleColumnIds) {

            const columns = this.getColumns(nextProps);

            if (!shallowEqual(this.state.columns, columns)) {
                this.setState({
                    columns,
                });
            }
        }
    }

    mapColPickerRowToColumn(baseIndex, state, row, index) {
        // use row info if available
        const rowInfo = row.rowInfo || row;

        return _.omit(_.defaults({
            id: rowInfo.originalId,
            state,
            order: index + baseIndex,
        }, rowInfo), ['height']);
    }

    getRowTypes() {
        const { rowDisplayModeLabels, rowDisplayModes } = this.props;

        return _.reduce(rowDisplayModes, (rowTypes, rowType) => {
            rowTypes[rowType] = rowDisplayModeLabels[rowType];
            return rowTypes;
        }, {});
    }

    mapColumn(columnId, column, order, state, rowType) {
        let primaryTitle = column.primaryTitle;
        let subtitle = column.secondaryTitle;

        if (primaryTitle && column.hasPrimaryTitleCurrency) {
            primaryTitle = `${primaryTitle} (${this.props.accountCurrency.CurrencyCode})`;
        }

        if (subtitle && column.hasSecondaryTitleCurrency) {
            subtitle = `${subtitle} (${this.props.accountCurrency.CurrencyCode})`;
        }

        if (!subtitle && rowType === Enums.RowDisplayMode.Double) {
            subtitle = ' ';
        }

        return {
            id: columnId,
            name: primaryTitle,
            subtitle,
            order,
            state,
            isFixed: column.isFixedStart || column.isFixedEnd,
        };
    }

    getColumnSets(showColumnNames, visibleColumnNames, allColumnNames) {
        showColumnNames = _.filter(showColumnNames, (columnId) => _.includes(allColumnNames, columnId));

        const visibleColumnNamesForRowType = _.filter(visibleColumnNames || [], (columnId) => _.includes(allColumnNames, columnId));
        const invisibleColumnNames = _.reject(showColumnNames, (columnId) => _.includes(visibleColumnNamesForRowType, columnId));
        const availableColumnsNames = _.reject(allColumnNames, (columnId) => _.includes(showColumnNames, columnId));

        return {
            visibleColumnNamesForRowType,
            invisibleColumnNames,
            availableColumnsNames,
        };
    }

    getColumns(props) {
        const {
            singleColumnIds,
            doubleColumnIds,
            visibleColumnIds,
            columnsDefinition,
            columnAvailableConst,
            columnInvisibleConst,
            columnVisibleConst,
            rowDisplayModes,
        } = props;

        return _.reduce(rowDisplayModes, (columns, rowType) => {
            const columnDefinitions = columnsDefinition.columnDefinitions[rowType];

            if (!columnDefinitions) {
                columns[rowType] = [];
                return columns;
            }

            const allColumnNames = _.keys(columnDefinitions);
            let showColumnNames;

            switch (rowType) {
                case Enums.RowDisplayMode.Single:
                    showColumnNames = singleColumnIds;
                    break;

                case Enums.RowDisplayMode.Double:
                    showColumnNames = doubleColumnIds;
                    break;

                default:
                    showColumnNames = [];
            }

            const {
                visibleColumnNamesForRowType,
                invisibleColumnNames,
                availableColumnsNames,
            } = this.getColumnSets(showColumnNames, visibleColumnIds[rowType], allColumnNames);

            const visibleColumns = _.map(
                visibleColumnNamesForRowType,
                (columnId, index) => this.mapColumn(
                    columnId,
                    columnDefinitions[columnId],
                    index,
                    columnVisibleConst,
                    rowType
                ));

            const invisibleColumns = _.map(
                invisibleColumnNames,
                (columnId, index) => this.mapColumn(
                    columnId,
                    columnDefinitions[columnId],
                    index + visibleColumns.length,
                    columnInvisibleConst,
                    rowType
                ));

            const availableColumns = _.map(
                availableColumnsNames,
                (columnId, index) => this.mapColumn(
                    columnId,
                    columnDefinitions[columnId],
                    index + visibleColumns.length + invisibleColumns.length,
                    columnAvailableConst,
                    rowType
                ));

            columns[rowType] = _.concat(visibleColumns, invisibleColumns, availableColumns);
            return columns;
        }, {});
    }

    handleColumnsChange(rowType, columns) {
        const { columnAvailableConst, columnInvisibleConst, columnVisibleConst } = this.props;

        const nextColumns = _.concat(
            _.map(columns.visibleColumns,
                this.mapColPickerRowToColumn.bind(this,
                    0, columnVisibleConst)),
            _.map(columns.invisibleColumns,
                this.mapColPickerRowToColumn.bind(this,
                    columns.visibleColumns.length, columnInvisibleConst)),
            _.map(columns.availableColumns,
                this.mapColPickerRowToColumn.bind(this,
                    columns.availableColumns.length + columns.visibleColumns.length, columnAvailableConst))
        );

        // update column picker
        this.setState({
            columns: _.defaults({
                [this.props.selectedRowDisplayMode]: nextColumns,
            }, this.state.columns),
        });

        this.props.onColumnsChange(
            this.props.componentId,
            _.concat(
                _.map(columns.visibleColumns, 'id'),
                _.map(columns.invisibleColumns, 'id')
            )
        );
    }

    handleRowModeChange(rowMode) {
        this.props.onRowModeChange(this.props.componentId, Number(rowMode));
    }

    render() {
        return (
            <ColumnPicker
                resizeTimestamp={this.props.resizeTimestamp}
                width={this.props.width}
                columns={this.state.columns}
                rowTypes={this.state.rowTypes}
                selectedRowDisplayMode={this.props.selectedRowDisplayMode}
                selectedRowType={this.props.selectedRowType}
                onColumnsChange={this.handleColumnsChange}
                onRowTypeChange={this.handleRowModeChange}
            />
        );
    }
}

ColumnPickerView.propTypes = {
    componentId: PropTypes.string.isRequired,
    resizeTimestamp: PropTypes.number,

    // columns definition
    // see reactGrid.jsx cols prop
    columnsDefinition: PropTypes.object.isRequired,
    width: PropTypes.number,
    selectedRowDisplayMode: PropTypes.oneOf([
        Enums.RowDisplayMode.Single,
        Enums.RowDisplayMode.Double,
        Enums.RowDisplayMode.TradeBoard,
    ]),
    selectedRowType: PropTypes.string,
    accountCurrency: PropTypes.object,
    singleColumnIds: PropTypes.arrayOf(PropTypes.string),
    doubleColumnIds: PropTypes.arrayOf(PropTypes.string),
    visibleColumnIds: PropTypes.objectOf(PropTypes.arrayOf(PropTypes.string)),
    onColumnsChange: PropTypes.func,
    onRowModeChange: PropTypes.func,

    // Display modes of column picker.
    // Can be arbitrary list, as seen in Options Chain.
    // For most cases i.e. [Enums.RowDisplayMode.Single, Enums.RowDisplayMode.Double];
    rowDisplayModes: PropTypes.arrayOf(PropTypes.number),

    // labels for display mode
    columnInvisibleConst: PropTypes.string,
    columnVisibleConst: PropTypes.string,
    columnAvailableConst: PropTypes.string,
    rowDisplayModeLabels: PropTypes.object,
};

ColumnPickerView.defaultProps = {
    accountCurrency: {
        CurrencyCode: '',
        Decimals: '',
    },
    visibleColumnIds: {
        [Enums.RowDisplayMode.Single]: EMPTY_ARRAY,
        [Enums.RowDisplayMode.Double]: EMPTY_ARRAY,
    },
    rowDisplayModes: config.isTabletApp ?
        [Enums.RowDisplayMode.Double] :
        [Enums.RowDisplayMode.Single, Enums.RowDisplayMode.Double],

    rowDisplayModeLabels: {
        [Enums.RowDisplayMode.Single]: Localization.getText('HTML5_SingleRow'),
        [Enums.RowDisplayMode.Double]: Localization.getText('HTML5_DoubleRow'),
        [Enums.RowDisplayMode.TradeBoard]: Localization.getText('HTML5_TradeBoard'),
    },
    columnInvisibleConst: columnPickerConstatns.COLUMN_INVISIBLE,
    columnVisibleConst: columnPickerConstatns.COLUMN_VISIBLE,
    columnAvailableConst: columnPickerConstatns.COLUMN_AVAILABLE,
    onColumnsChange: _.noop,
    onRowModeChange: _.noop,
};

export default bindHandlers(ColumnPickerView);
