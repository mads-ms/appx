import React from 'react';
import _ from 'lodash';
import { mount } from 'enzyme';
import { wrapInTestContext, getWrappedInstance } from 'test/mocks/dragDropHelper';
import ColumnPickerGrid, { VISIBLE_DIVIDER_ID, INVISIBLE_DIVIDER_ID, AVAILABLE_DIVIDER_ID } from 'src/components/columnPicker/columnPickerGrid';

describe('src/components/columnPicker/columnPickerGrid', () => {
    let wrapper;
    const WrappedColumnPicker = wrapInTestContext(ColumnPickerGrid);

    afterEach(() => {
        wrapper.unmount();
    });

    it('renders successfully', () => {

        wrapper = mount(
            <WrappedColumnPicker columns={[]} onChange={_.noop}/>
        );

        expect(getWrappedInstance(wrapper) instanceof ColumnPickerGrid).toBe(true);
    });

    it('handles row sort - fires event when all sections has columns', () => {
        const columnPickerSpy = jasmine.createSpyObj('columnPicker', ['onChange']);

        wrapper = mount(
            <WrappedColumnPicker columns={[]} onChange={columnPickerSpy.onChange}/>
        );

        const rows = [
            { id: VISIBLE_DIVIDER_ID },
            { id: '1', order: 1 },
            { id: '0', order: 0 },
            { id: INVISIBLE_DIVIDER_ID },
            { id: '2', order: 2 },
            { id: AVAILABLE_DIVIDER_ID },
            { id: '3', order: 3 },
        ];
        const draggedRow = { id: '1', order: 1 };
        const expectedColumns = {
            draggedColumn: draggedRow,
            visibleColumns: [{ id: '1', order: 1 }, { id: '0', order: 0 }],
            invisibleColumns: [{ id: '2', order: 2 }],
            availableColumns: [{ id: '3', order: 3 }],
        };

        getWrappedInstance(wrapper).handleGridRowsReorder(rows, draggedRow);
        expect(columnPickerSpy.onChange).toHaveBeenCalledWith(expectedColumns);
    });

    it('handles row sort - fires event when no visible columns', () => {
        const columnPickerSpy = jasmine.createSpyObj('columnPicker', ['onChange']);

        wrapper = mount(
            <WrappedColumnPicker columns={[]} onChange={columnPickerSpy.onChange}/>
        );

        const rows = [
            { id: INVISIBLE_DIVIDER_ID },
            { id: '1', order: 1 },
            { id: '0', order: 0 },
            { id: '2', order: 2 },
            { id: AVAILABLE_DIVIDER_ID },
            { id: '3', order: 3 },
        ];
        const draggedRow = { id: '1', order: 1 };
        const expectedColumns = {
            draggedColumn: draggedRow,
            visibleColumns: [],
            invisibleColumns: [{ id: '1', order: 1 }, { id: '0', order: 0 }, { id: '2', order: 2 }],
            availableColumns: [{ id: '3', order: 3 }],
        };

        getWrappedInstance(wrapper).handleGridRowsReorder(rows, draggedRow);
        expect(columnPickerSpy.onChange).toHaveBeenCalledWith(expectedColumns);
    });

    it('handles row sort - fires event when no shown columns', () => {
        const columnPickerSpy = jasmine.createSpyObj('columnPicker', ['onChange']);

        wrapper = mount(
            <WrappedColumnPicker columns={[]} onChange={columnPickerSpy.onChange}/>
        );

        const rows = [
            { id: AVAILABLE_DIVIDER_ID },
            { id: '1', order: 1 },
            { id: '0', order: 0 },
            { id: '2', order: 2 },
            { id: '3', order: 3 },
        ];
        const draggedRow = { id: '1', order: 1 };
        const expectedColumns = {
            draggedColumn: draggedRow,
            visibleColumns: [],
            invisibleColumns: [],
            availableColumns: [{ id: '1', order: 1 }, { id: '0', order: 0 }, { id: '2', order: 2 }, { id: '3', order: 3 }],
        };

        getWrappedInstance(wrapper).handleGridRowsReorder(rows, draggedRow);
        expect(columnPickerSpy.onChange).toHaveBeenCalledWith(expectedColumns);
    });

    it('handles row sort - fires no event when dragging fixed column', () => {
        const columnPickerSpy = jasmine.createSpyObj('columnPicker', ['onChange']);

        wrapper = mount(
            <WrappedColumnPicker columns={[]} onChange={columnPickerSpy.onChange}/>
        );

        const rows = [
            { id: VISIBLE_DIVIDER_ID },
            { id: '1', order: 1 },
            { id: '0', order: 0, isFixed: true },
            { id: INVISIBLE_DIVIDER_ID },
            { id: '2', order: 2 },
            { id: AVAILABLE_DIVIDER_ID },
            { id: '3', order: 3 },
        ];
        const draggedRow = { id: '0', order: 0, isFixed: true };

        getWrappedInstance(wrapper).handleGridRowsReorder(rows, draggedRow);
        expect(columnPickerSpy.onChange.calls.count()).toEqual(0);
    });

    it('handles row sort - add fixed column in visible columns at zero index and fires event when dragged column does not affect order of fixed column within the same section', () => {
        const columnPickerSpy = jasmine.createSpyObj('columnPicker', ['onChange']);
        const columns = [{ id: '0', order: 0, isFixed: true }];

        wrapper = mount(
            <WrappedColumnPicker columns={columns} onChange={columnPickerSpy.onChange}/>
        );

        const rows = [
            { id: VISIBLE_DIVIDER_ID },
            { id: '2', order: 2 },
            { id: '1', order: 1 },
            { id: INVISIBLE_DIVIDER_ID },
            { id: '3', order: 3 },
            { id: AVAILABLE_DIVIDER_ID },
            { id: '4', order: 4 },
        ];

        const draggedRow = { id: '1', order: 1 };
        const expectedColumns = {
            draggedColumn: draggedRow,
            visibleColumns: [{ id: '0', order: 0, isFixed: true }, { id: '2', order: 2 }, { id: '1', order: 1 }],
            invisibleColumns: [{ id: '3', order: 3 }],
            availableColumns: [{ id: '4', order: 4 }],
        };

        getWrappedInstance(wrapper).handleGridRowsReorder(rows, draggedRow);
        expect(columnPickerSpy.onChange).toHaveBeenCalledWith(expectedColumns);
    });

    it('handles row sort - add fixed column in visible columns in middle and fires event when dragged column does not affect order of fixed column within the same section of visible items', () => {
        const columnPickerSpy = jasmine.createSpyObj('columnPicker', ['onChange']);
        const columns = [{ id: '1', order: 1, isFixed: true }];

        wrapper = mount(
            <WrappedColumnPicker columns={columns} onChange={columnPickerSpy.onChange}/>
        );

        const rows = [
            { id: VISIBLE_DIVIDER_ID },
            { id: '2', order: 2 },
            { id: '0', order: 0 },
            { id: INVISIBLE_DIVIDER_ID },
            { id: '3', order: 3 },
            { id: AVAILABLE_DIVIDER_ID },
            { id: '4', order: 4 },
        ];

        const draggedRow = { id: '0', order: 0 };
        const expectedColumns = {
            draggedColumn: draggedRow,
            visibleColumns: [{ id: '2', order: 2 }, { id: '1', order: 1, isFixed: true }, { id: '0', order: 0 }],
            invisibleColumns: [{ id: '3', order: 3 }],
            availableColumns: [{ id: '4', order: 4 }],
        };

        getWrappedInstance(wrapper).handleGridRowsReorder(rows, draggedRow);
        expect(columnPickerSpy.onChange).toHaveBeenCalledWith(expectedColumns);
    });

    it('handles row sort - add fixed column in visible columns at zero and last index and fires event when dragged column does not affect order of fixed columns within the same section', () => {
        const columnPickerSpy = jasmine.createSpyObj('columnPicker', ['onChange']);
        const columns = [{ id: '0', order: 0, isFixed: true }, { id: '3', order: 3, isFixed: true }];

        wrapper = mount(
            <WrappedColumnPicker columns={columns} onChange={columnPickerSpy.onChange}/>
        );

        const rows = [
            { id: VISIBLE_DIVIDER_ID },
            { id: '2', order: 2 },
            { id: '1', order: 1 },
            { id: INVISIBLE_DIVIDER_ID },
            { id: '4', order: 4 },
            { id: AVAILABLE_DIVIDER_ID },
            { id: '5', order: 5 },
        ];

        const draggedRow = { id: '2', order: 2 };
        const expectedColumns = {
            draggedColumn: draggedRow,
            visibleColumns: [{ id: '0', order: 0, isFixed: true }, { id: '2', order: 2 }, { id: '1', order: 1 }, { id: '3', order: 3, isFixed: true }],
            invisibleColumns: [{ id: '4', order: 4 }],
            availableColumns: [{ id: '5', order: 5 }],
        };

        getWrappedInstance(wrapper).handleGridRowsReorder(rows, draggedRow);
        expect(columnPickerSpy.onChange).toHaveBeenCalledWith(expectedColumns);
    });
});
