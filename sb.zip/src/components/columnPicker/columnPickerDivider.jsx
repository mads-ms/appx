import PropTypes from 'prop-types';
import React from 'react';
import Icon from 'src/components/icon/icon';

function ColumnPickerDivider({ rowInfo }) {
    if (rowInfo.isNotSortable) {
        return false;
    }

    return (
        <div className="grid grid--grail colpicker-divider">
            <Icon key="icon" type="sort"/>
        </div>
    );
}

ColumnPickerDivider.propTypes = {
    rowInfo: PropTypes.object,
};

export default ColumnPickerDivider;
