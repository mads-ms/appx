import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import Button from 'src/components/button/button';
import { bindHandlers } from 'src/utils/bindHandlers';

class ColumnPickerTabButton extends React.Component {
    handleRowTypeTap() {
        this.props.onRowTypeTap(this.props.rowType);
    }

    render() {
        return (
            <div className="grid-cell">
                <Button
                    onTap={this.handleRowTypeTap}
                    className={classNames('btn--large', 'tst-row-type-' + this.props.rowType, {
                        'btn--clear': !this.props.isSelected,
                    })}
                >
                    {this.props.header}
                </Button>
            </div>
        );
    }
}

ColumnPickerTabButton.propTypes = {
    rowType: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    isSelected: PropTypes.bool,
    header: PropTypes.string,
    onRowTypeTap: PropTypes.func,
};

ColumnPickerTabButton.defaultProps = {
    onRowTypeTap: _.noop,
};

export default bindHandlers(ColumnPickerTabButton);
