import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import Localization from 'src/localization';
import { bindHandlers } from 'src/utils/bindHandlers';
import ReactGrid from 'src/components/reactGrid/reactGrid';
import ColumnPickerDivider from './columnPickerDivider';
import * as constants from './columnPickerConstants';
import DraggableGridRowPlugin from 'src/components/reactGrid/plugins/draggableRow/dragableGridRowPlugin';
import * as gridConstants from 'src/components/reactGrid/constants';
import enums from 'src/spine/enums';
import * as labelFunctions from './labelFunctions';

export const VISIBLE_DIVIDER_ID = 'VISIBLE_DIVIDER_ID';
export const INVISIBLE_DIVIDER_ID = 'INVISIBLE_DIVIDER_ID';
export const AVAILABLE_DIVIDER_ID = 'AVAILABLE_DIVIDER_ID';

function getDivider(id, name) {
    return {
        id: String(id),
        height: gridConstants.DIVIDER_HEIGHT,
        lineHeight: gridConstants.DIVIDER_LINEHEIGHT,
        className: 'colpicker-divider reactgrid-divider',
        isNotSortable: true,
        name,
    };
}

function mapColumn(column) {
    return _.defaults({
        id: String(column.id),
        originalId: column.id,
        lineHeight: column.subtitle ? gridConstants.DOUBLE_ROW_LINEHEIGHT : gridConstants.SINGLE_ROW_LINEHEIGHT,
    }, column);
}

class ColumnPickerGrid extends React.Component {
    handleGridRowsReorder(rows, draggedRow) {
        // If dragged row is fixed, disregarding sort and keeping the order as is
        if (draggedRow.isFixed) {
            return;
        }

        const visibleColumns = [];
        const invisibleColumns = [];
        const availableColumns = [];
        let columnsForNextRow = visibleColumns;
        let index = 0;
        let checkFixedColumns = true;

        const fixedColumns = _.chain(this.props.columns)
            .filter(['isFixed', true])
            .sortBy('order')
            .value();

        _.forEach(rows, (row) => {
            if (row.id === VISIBLE_DIVIDER_ID) {
                return;
            }

            if (row.id === INVISIBLE_DIVIDER_ID) {
                columnsForNextRow = invisibleColumns;
                checkFixedColumns = false;
                return;
            }

            if (row.id === AVAILABLE_DIVIDER_ID) {
                columnsForNextRow = availableColumns;
                checkFixedColumns = false;
                return;
            }

            // check if it is present in fixed col.
            // if found, insert at that index
            if (checkFixedColumns && fixedColumns.length > 0 && fixedColumns[0].order === index) {
                columnsForNextRow.push(fixedColumns[0]);
                fixedColumns.shift();
            }

            columnsForNextRow.push(row);

            index++;
        });

        _.forEach(fixedColumns, (fixedColumn) => {
            if (fixedColumn.order > -1) {
                visibleColumns.push(fixedColumn);
            }
        });

        this.props.onChange({
            draggedColumn: draggedRow,
            visibleColumns,
            invisibleColumns,
            availableColumns,
        });
    }

    getIsSingleRow() {
        const displayMode = this.props.selectedRowDisplayMode;
        return displayMode === enums.RowDisplayMode.Single || displayMode === enums.RowDisplayMode.TradeBoard;
    }

    getRowHeight(isSingleRow) {
        return isSingleRow ? constants.SINGLE_ROW_HEIGHT : constants.DOUBLE_ROW_HEIGHT;
    }

    getItemToLabel(isSingleRow) {
        return isSingleRow ? labelFunctions.getName : [labelFunctions.getName, labelFunctions.getSubTitle];
    }

    render() {
        const { columns } = this.props;

        if (columns.length === 0) {
            return false;
        }

        const nonFixedColumns = _.reject(columns, 'isFixed');
        const isSingleRow = this.getIsSingleRow();

        const visibleRows = _
            .chain(nonFixedColumns)
            .filter((column) => column.state === constants.COLUMN_VISIBLE)
            .sortBy('order')
            .map(mapColumn)
            .value();

        const invisibleRows = _
            .chain(nonFixedColumns)
            .filter((column) => column.state === constants.COLUMN_INVISIBLE)
            .sortBy('order')
            .map(mapColumn)
            .value();

        const availableRows = _
            .chain(nonFixedColumns)
            .filter((column) => column.state === constants.COLUMN_AVAILABLE)
            .sortBy('order')
            .map(mapColumn)
            .value();

        if (this.props.reverseOrder) {
            _.reverse(visibleRows);
            _.reverse(invisibleRows);
            _.reverse(availableRows);
        }

        const rows = _.concat(
            visibleRows.length ? [getDivider(VISIBLE_DIVIDER_ID, Localization.getText('HTML5_ShownColumns'))] : [],
            visibleRows,
            invisibleRows.length ? [getDivider(INVISIBLE_DIVIDER_ID, Localization.getText('HTML5_NotVisibleColumns'))] : [],
            invisibleRows,
            [getDivider(AVAILABLE_DIVIDER_ID, Localization.getText('HTML5_AvailableColumns'))],
            availableRows
        );

        return (
            <ReactGrid
                resizeTimestamp={this.props.resizeTimestamp}
                isHeader={false}
                cellClass="grid grid--cross-center colpicker-cell"
                cols={[
                    {
                        id: 'name',
                        itemToLabel: this.getItemToLabel(isSingleRow),
                        align: 'start',

                        // Fluid width
                        minWidth: 1,
                        maxWidth: 9999,
                    },
                    {
                        id: 'icon',
                        template: ColumnPickerDivider,
                        width: 40,
                    },
                ]}
                rowHeight={this.getRowHeight(isSingleRow)}
                rows={rows}
                width={this.props.width}
                height={this.props.height}
            >
                <DraggableGridRowPlugin
                    onRowsReorder={this.handleGridRowsReorder}
                />
            </ReactGrid>
        );
    }
}

ColumnPickerGrid.propTypes = {
    width: PropTypes.number,
    height: PropTypes.number,
    resizeTimestamp: PropTypes.number,
    columns: PropTypes.arrayOf(PropTypes.shape({
        id: PropTypes.string.isRequired,
        name: PropTypes.string,
        subtitle: PropTypes.string,
        order: PropTypes.number.isRequired,
        state: PropTypes.oneOf([
            constants.COLUMN_AVAILABLE,
            constants.COLUMN_VISIBLE,
            constants.COLUMN_INVISIBLE,
        ]),
    })).isRequired,
    selectedRowDisplayMode: PropTypes.oneOf([
        enums.RowDisplayMode.Single,
        enums.RowDisplayMode.Double,
        enums.RowDisplayMode.TradeBoard,
    ]),
    onChange: PropTypes.func.isRequired,
    reverseOrder: PropTypes.bool,
};

ColumnPickerGrid.defaultProps = {
    reverseOrder: false,
};

export default bindHandlers(ColumnPickerGrid);
