import config from 'src/config';

export const COLUMN_AVAILABLE = 'COLUMN_AVAILABLE';
export const COLUMN_VISIBLE = 'COLUMN_VISIBLE';
export const COLUMN_INVISIBLE = 'COLUMN_INVISIBLE';

export const SINGLE_ROW_HEIGHT = config.isDesktopApp ? 25 : 26;
export const DOUBLE_ROW_HEIGHT = config.isDesktopApp ? 45 : 46;
