import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import { bindHandlers } from 'src/utils/bindHandlers';
import Localization from 'src/localization';
import Button from 'src/components/button/button';
import Icon from 'src/components/icon/icon';
import ColumnPickerGrid from './columnPickerGrid';
import ColumnPickerTabButton from './columnPickerTabButton';
import Enums from 'src/spine/enums';

class ColumnPicker extends React.Component {
    constructor(props) {
        super(props);

        this.setColumnPickerEl = (ref) => {
            this.columnPickerEl = ref;
        };

        const selectedRowType = _.get(props, 'selectedRowType', props.defaultRowType);

        this.state = {
            selectedRowType,
        };
    }

    componentWillReceiveProps(nextProps) {
        if (!_.isUndefined(nextProps.selectedRowType) && nextProps.selectedRowType !== this.state.selectedRowType) {
            this.setState({
                selectedRowType: nextProps.selectedRowType,
            });
        }
    }

    handleRowTypeTap(rowType) {
        if (_.isUndefined(this.props.selectedRowType)) {
            if (this.state.selectedRowType === rowType) {
                return;
            }

            this.setState({
                selectedRowType: rowType,
            });
        } else if (this.props.selectedRowType === rowType) {
            return;
        }

        this.props.onRowTypeChange(rowType);
    }

    handleColumnsChange(columns) {
        this.props.onColumnsChange(this.state.selectedRowType, columns);
    }

    render() {
        const {
            rowTypes,
            columns,
            resizeTimestamp,
            selectedRowDisplayMode,
        } = this.props;

        const {
            selectedRowType,
        } = this.state;

        const rowTypeColumns = columns[selectedRowType];
        const selectedRowTypeProps = rowTypes[selectedRowType];
        const reverseOrder = _.get(selectedRowTypeProps, 'reverseOrder', false);

        return (
            <div className="sheet tst-colpicker sheet--alt grid grid--y grid--fit-fill">
                <div className="grid-cell">
                    <header className="sheet-header header">
                        <div className="header-title">
                            {Localization.getText('HTML5_ColumnPicker_DefaultHeaderTitle')}
                        </div>
                        <Button
                            className="js-popup-close tst-popup-close header-close btn--clear btn--inline"
                            title={Localization.getText('Close')}
                        >
                            <Icon type="close"/>
                        </Button>
                    </header>
                    <div className="colpicker-layouts grid">
                        {_.size(rowTypes) > 1 && _.map(rowTypes, (rowTypeProps, rowType) => (
                            <ColumnPickerTabButton
                                rowType={rowType}
                                key={rowType}
                                isSelected={selectedRowType === rowType}
                                header={_.isString(rowTypeProps) ? rowTypeProps : rowTypeProps.header}
                                onRowTypeTap={this.handleRowTypeTap}
                            />
                        ))}
                    </div>
                </div>
                <div className="grid" ref={this.setColumnPickerEl}>
                    <ColumnPickerGrid
                        resizeTimestamp={resizeTimestamp}
                        columns={rowTypeColumns}
                        selectedRowDisplayMode={selectedRowDisplayMode}
                        onChange={this.handleColumnsChange}
                        reverseOrder={reverseOrder}
                    />
                </div>
            </div>
        );
    }
}

/**
 * ColumnPicker.propTypes
 * @property {string} defaultRowType    Defines default value for selected row type.
 * @property {string} selectedRowType   Defines value for selected row type. Difference between @see defaultRowType and selectedRowType is
 *                                      the same as between defaultValue and value for React form elements - @see selectedRowType specifies a
 *                                      hard value for selected row type which cannot be changed by @see ColumnPicker internally without
 *                                      having selectedRowType changed externally (e.g. after @see onRowTypeChange was fired), however
 *                                      @see defaultRowType specifies a default value, and the actual selected row type can be changed
 *                                      internally without props being passed. When both @see defaultRowType and selectedRowType are specified,
 *                                      @see defaultRowType value is ignored.
 */
ColumnPicker.propTypes = {
    columns: PropTypes.objectOf(PropTypes.array),
    rowTypes: PropTypes.objectOf(PropTypes.oneOfType([
        PropTypes.shape({
            header: PropTypes.string.isRequired,
            reverseOrder: PropTypes.bool,
        }),
        PropTypes.string,
    ])),
    selectedRowDisplayMode: PropTypes.oneOf([
        Enums.RowDisplayMode.Single,
        Enums.RowDisplayMode.Double,
        Enums.RowDisplayMode.TradeBoard,
    ]),
    defaultRowType: PropTypes.string,
    selectedRowType: PropTypes.string,
    onColumnsChange: PropTypes.func.isRequired,
    onRowTypeChange: PropTypes.func,
    width: PropTypes.number,
    resizeTimestamp: PropTypes.number,
};

ColumnPicker.defaultProps = {
    onRowTypeChange: _.noop,
    selectedRowDisplayMode: Enums.RowDisplayMode.Single,
};

export default bindHandlers(ColumnPicker);
