export const getName = ({ rowInfo }) => rowInfo.name;
export const getSubTitle = ({ rowInfo }) => rowInfo.subtitle;
