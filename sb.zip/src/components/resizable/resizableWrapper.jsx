import React from 'react';
import PropTypes from 'prop-types';
import Resizable from './resizable';

export default (ComposedComponent) => {

    class ResizableWrapper extends React.PureComponent {
        render() {
            return (
                <Resizable resizeTimestamp={this.props.resizeTimestamp}>
                    {(resizableProps) => (
                        <ComposedComponent
                            {...this.props}
                            width={this.props.width || resizableProps.parentViewport.width}
                            height={this.props.height || resizableProps.parentViewport.height}
                        />
                    )}
                </Resizable>
            );
        }
    }

    ResizableWrapper.propTypes = {
        resizeTimestamp: PropTypes.number,
        width: PropTypes.number,
        height: PropTypes.number,
    };

    ResizableWrapper.defaultProps = {
        resizeTimestamp: 0,
    };

    return ResizableWrapper;
};
