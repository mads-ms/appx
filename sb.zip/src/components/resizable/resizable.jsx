import PropTypes from 'prop-types';
import React from 'react';
import Spine from 'spineAll';
import _ from 'lodash';
import * as util from 'src/utils/util';
import ReactDOM from 'react-dom';
import { bindHandlers } from 'src/utils/bindHandlers';
import { UI } from 'openui';
import config from 'src/config';

class Resizable extends React.Component {
    constructor() {
        super();

        this.isUnmounted = false;
        this.state = {
            viewport: {
                width: 0,
                height: 0,
            },
        };
        this.isUiResizePending = false;
        this.isUiBusy = false;
    }

    componentDidMount() {
        if (this.props.ownerModule) {
            this.props.ownerModule.on('ui:resize', this.handleUiResize);
        }

        if (config.isPhoneApp || config.isTabletApp) {
            UI.on('orientationchange', this.handleUiResize);
        }

        Spine.on('ui:busy', this.handleUiBusy)
            .on('ui:idle', this.handleUiIdle);

        util.nextTick(this.handleUiResize);
    }

    componentDidUpdate(prevProps) {
        if (prevProps.resizeTimestamp !== this.props.resizeTimestamp) {
            this.handleUiResize();
        }
    }

    componentWillUnmount() {
        if (this.props.ownerModule) {
            this.props.ownerModule.off('ui:resize', this.handleUiResize);
        }

        if (config.isPhoneApp || config.isTabletApp) {
            UI.off('orientationchange', this.handleUiResize);
        }

        Spine.off('ui:busy', this.handleUiBusy)
            .off('ui:idle', this.handleUiIdle);

        this.isUnmounted = true;
    }

    handleUiBusy() {
        this.isUiBusy = true;
    }

    handleUiIdle() {
        this.isUiBusy = false;
        if (this.isUiResizePending) {
            this.isUiResizePending = false;
            this.handleUiResize();
        }
    }

    handleUiResize() {
        if (this.isUnmounted) {
            return;
        }

        const { isSuspendOnBusy, ownerModule, targetElement, onResize } = this.props;

        if ((this.isUiBusy && isSuspendOnBusy) || (ownerModule && !ownerModule.isActive())) {
            this.isUiResizePending = true;
            return;
        }

        const element = targetElement || ReactDOM.findDOMNode(this);

        if (!element) {
            return;
        }

        const rect = element.getBoundingClientRect();

        this.setState({
            viewport: {
                width: rect.width,
                height: rect.height,
            },
        });

        onResize(this.state.viewport);
    }

    render() {
        const { children } = this.props;
        const { viewport } = this.state;

        if (_.isFunction(children)) {
            return children({
                parentViewport: viewport,
            });
        }

        return children;
    }
}

Resizable.propTypes = {
    ownerModule: PropTypes.shape({
        on: PropTypes.func.isRequired,
        off: PropTypes.func.isRequired,
        isActive: PropTypes.func.isRequired,
    }),
    children: PropTypes.oneOfType([PropTypes.element, PropTypes.func]),
    onResize: PropTypes.func,
    isSuspendOnBusy: PropTypes.bool,
    targetElement: PropTypes.instanceOf(window.HTMLElement),
    resizeTimestamp: PropTypes.number,
};

Resizable.defaultProps = {
    onResize: _.noop,
    isSuspendOnBusy: true,
    resizeTimestamp: Date.now(),
};

export default bindHandlers(Resizable);
