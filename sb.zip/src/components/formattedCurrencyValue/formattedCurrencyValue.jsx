import React from 'react';
import PropTypes from 'prop-types';
import * as numberFormat from 'src/numberFormat';
import * as instrumentQueries from 'src/modules/instruments/queries';

function FormattedCurrencyValue(props) {
    const { children, instrument } = props;
    const currency = instrumentQueries.getCurrencyLabel(instrument);
    const currencyDecimals = instrument.Format.CurrencyDecimals;
    const formattedValue = numberFormat.format(
        children,
        children === 0 ? 0 : currencyDecimals
    );

    return <span className="t-num">{formattedValue} {currency}</span>;
}

FormattedCurrencyValue.propTypes = {
    instrument: PropTypes.object.isRequired,
    children: PropTypes.number.isRequired,
};

export default FormattedCurrencyValue;
