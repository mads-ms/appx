import React from 'react';
import PropTypes from 'prop-types';

/**
 * Takes a context prop and uses it to recreate the context for children
 */
export default class ContextInjector extends React.Component {
    getChildContext() {
        return this.props.context;
    }

    render() {
        return this.props.children;
    }
}

ContextInjector.propTypes = {
    context: PropTypes.object.isRequired,
    children: PropTypes.element,
};

ContextInjector.defaultProps = {
    children: false,
};

ContextInjector.childContextTypes = {
    store: PropTypes.object,
    dragDropManager: PropTypes.object,
};
