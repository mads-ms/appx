/* eslint-disable react/no-unused-state */
import _ from 'lodash';
import $ from 'jqueryAll';
import PropTypes from 'prop-types';
import React from 'react';
import ReactDOM from 'react-dom';
import asap from 'asap';
import shallowEqual from 'react-redux/lib/utils/shallowEqual';
import config from 'src/config';
import { bindHandlers } from 'src/utils/bindHandlers';
import { PopupManager, CardManager, detect } from 'openui';
import log from 'src/modules/log';
import ContextInjector from './contextInjector';

class Dialog extends React.Component {

    constructor(props) {
        super(props);

        // waiting for 16.0.1
        // https://github.com/facebook/react/issues/11017
        // this.dialogContent = document.createDocumentFragment();
        this.dialogContent = document.createElement('span');

        // set to true when unmounted, which then blocks async rendering
        this.isUnmounted = false;

        // whether hide has triggered ;- if the dialog does a hide itself, which then causes an unmount, when then hides again
        // then hide can trigger twice and this guards against it.
        this.hasHideTriggered = false;

        // we show immediately, so allow an initial render,
        // but do not let through any more renders until we are shown
        this.state = {
            isShowing: true,
        };
        this.isUpdatePending = false;
    }

    componentWillReceiveProps(nextProps) {
        if (this.props.type !== nextProps.type) {
            throw new Error('Cannot change Dialog type from "' + this.props.type + '" to "' + nextProps.type + '"');
        }
    }

    shouldComponentUpdate(nextProps, nextState) {

        const shouldUpdate = this.isUpdatePending ||
            !shallowEqual(this.props, nextProps);

        if (!shouldUpdate) {
            return false;
        }

        if (nextState.isShowing) {
            // avoid setting state as it isn't allow in this lifecycle method
            this.isUpdatePending = true;
            return false;
        }

        return true;
    }

    componentWillUnmount() {
        this.isUnmounted = true;
        if (this.dialog) {
            this.dialog.hide();
        } else if (!this.hasHideTriggered) {
            // if the dialog is mounted and immediately unmounted, keep the behaviour of calling hide
            // but because the effect is asynchronous, no dialog will ever be created
            this.props.onHide();
        }
    }

    showDialog() {
        const { type, parent } = this.props;

        let manager;
        switch (type) {
            case 'popup':
                manager = parent ? new PopupManager({ $parent: $(parent) }) : PopupManager.getInstance();
                this.dialog = manager.getPopup();
                break;

            case 'card':
                manager = parent ? new CardManager({ $parent: $(parent) }) : CardManager.getInstance();
                this.dialog = manager.getCard();
                break;

            default:
                throw new Error('Invalid Dialog type: "' + type + '"');
        }

        this.dialog.on('show', this.handleShow)
            .on('hide', this.handleHide)
            .on('preshow', this.handlePreshow)
            .on('prehide', this.handlePrehide)
            .on('resize', this.handleResize);

        // remove component-specific props
        const dialogOptions = _.omit(this.props, 'type', 'children');

        // force immediate animations for IE/Edge, as they're too janky
        if (detect.os.ms || detect.os.edge) {
            dialogOptions.isImmediateShow = true;
            dialogOptions.isImmediateHide = true;
        }

        // force all cards on desktop to be non-draggable
        if (type === 'card' && config.isDesktopApp) {
            dialogOptions.isDraggable = false;
        }

        try {
            this.dialog.show(this.dialogContent, dialogOptions);
        } catch (error) {
            // #775723 Somehow the dialog could not be shown due to anchor not being on DOM
            log.error('Could not show the dialog', { error, type, dialogOptions });
        }
    }

    renderDialogContent() {
        if (this.isUnmounted) {
            return;
        }

        ReactDOM.render(
            <ContextInjector context={this.context}>{this.props.children}</ContextInjector>,
            this.dialogContent,
            () => {
                if (this.isUnmounted) {
                    return;
                }

                if (this.dialog) {
                    // would be nice to remove at some point and only do if resizeTimestamp changes
                    this.handleRender();
                } else {
                    this.showDialog();
                }
            }
        );
    }

    unmountContent() {
        this.dialog.off('show', this.handleShow)
            .off('hide', this.handleHide)
            .off('preshow', this.handlePreshow)
            .off('prehide', this.handlePrehide)
            .off('resize', this.handleResize);

        asap(() => {
            ReactDOM.unmountComponentAtNode(this.dialogContent);
            this.isUnmounted = true;
            this.dialog = null;
            this.dialogContent = null;
        });
    }

    handleRender() {
        if (!this.props.shouldRepositionOnRender) {
            return;
        }

        switch (this.props.type) {
            case 'popup':
                this.dialog.reposition();
                break;

            case 'card':
                this.dialog.refresh();
                break;
        }
    }

    handleShow() {
        this.setState({
            isShowing: false,
        }, () => {
            this.isUpdatePending = false;
        });

        this.props.onShow();
    }

    handleHide() {
        // some users do something like `isShown && !isWaiting`
        // so if `isWaiting` becomes true while shown, it relies on the hide handler triggered while unmount
        // to set `isShown` to false again
        // ideally this should be wrapped in a check for isUnmounted
        if (!this.hasHideTriggered) {
            this.hasHideTriggered = true;
            this.props.onHide();
        }
        this.unmountContent();
    }

    handlePreshow() {
        this.props.onPreshow();
    }

    handlePrehide() {
        this.props.onPrehide();
    }

    handleResize() {
        this.props.onResize();
    }

    render() {
        // It would be nice to use portals, but we need support for chosing when to unmount
        // See: https://github.com/facebook/react/issues/10826
        // return ReactDOM.createPortal(
        //     this.props.children,
        //     this.dialogContent
        //     );

        asap(() => this.renderDialogContent());
        return false;
    }
}

Dialog.propTypes = {
    onHide: PropTypes.func,
    onPrehide: PropTypes.func,
    onPreshow: PropTypes.func,
    onShow: PropTypes.func,
    onResize: PropTypes.func,
    type: PropTypes.oneOf(['popup', 'card']),
    parent: PropTypes.instanceOf(HTMLElement),
    resizeTimestamp: PropTypes.number,
    shouldRepositionOnRender: PropTypes.bool,
};

Dialog.defaultProps = {
    onHide: _.noop,
    onPrehide: _.noop,
    onPreshow: _.noop,
    onShow: _.noop,
    onResize: _.noop,
    type: config.isPhoneApp ? 'card' : 'popup',
    resizeTimestamp: Date.now(),
    shouldRepositionOnRender: true,
};

Dialog.contextTypes = {
    store: PropTypes.object,
    dragDropManager: PropTypes.object,
};

export default bindHandlers(Dialog);
