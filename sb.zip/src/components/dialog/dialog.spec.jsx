import React from 'react';
import { mount } from 'enzyme';
import { PopupManager, CardManager } from 'openui';
import Dialog from 'src/components/dialog/dialog';
import velocity from 'test/mocks/velocity';
import getStore from 'src/store';

describe('src/components/dialog/dialog', () => {
    let popupManager;
    let cardManager;
    let wrapper;

    beforeEach(() => {
        jasmine.clock().install();
        popupManager = PopupManager.getInstance();
        cardManager = CardManager.getInstance();
        spyOn(popupManager, 'getPopup').and.callThrough();
        spyOn(cardManager, 'getCard').and.callThrough();
    });

    afterEach(() => {
        wrapper.unmount();
        jasmine.clock().uninstall();
    });

    function mountWithStore(TestDialog) {
        return mount(TestDialog, { context: { store: getStore() } });
    }

    it('renders a dialog if it has children', () => {
        wrapper = mountWithStore(<Dialog><span/></Dialog>);
        const instance = wrapper.instance();

        jasmine.clock().tick(1);
        expect(instance.dialog.isShown()).toBe(true);
    });

    it('renders a dialog if it does not have children', () => {
        wrapper = mountWithStore(<Dialog/>);
        const instance = wrapper.instance();

        jasmine.clock().tick(1);
        expect(instance.dialog.isShown()).toBe(true);
    });

    it('renders a popup when specified', () => {
        wrapper = mountWithStore(<Dialog type="popup"/>);

        jasmine.clock().tick(1);
        expect(popupManager.getPopup).toHaveBeenCalledTimes(1);
        expect(cardManager.getCard).not.toHaveBeenCalled();
    });

    it('renders a card when specified', () => {
        wrapper = mountWithStore(<Dialog type="card"/>);

        jasmine.clock().tick(1);
        expect(popupManager.getPopup).not.toHaveBeenCalled();
        expect(cardManager.getCard).toHaveBeenCalledTimes(1);
    });

    it('throws an error if you try and change props', () => {
        wrapper = mountWithStore(<Dialog type="card"/>);

        // react helpfully calls window.onerror directly, which is picked up by jasmine
        // so we need to suppress the global error handler or the test fails
        spyOn(window, 'onerror');

        expect(() => {
            wrapper.setProps({
                type: 'popup',
            });
        }).toThrow();
    });

    it('triggers preshow before a dialog is shown', () => {
        const preshowSpy = jasmine.createSpy('preshowSpy');
        wrapper = mountWithStore(<Dialog onPreshow={preshowSpy}/>);

        jasmine.clock().tick(1);

        expect(preshowSpy).not.toHaveBeenCalled();

        velocity.callAllBegins();

        expect(preshowSpy).toHaveBeenCalledTimes(1);
    });

    it('triggers show after a dialog is shown', () => {
        const showSpy = jasmine.createSpy('showSpy');
        wrapper = mountWithStore(<Dialog onShow={showSpy}/>);

        jasmine.clock().tick(1);

        expect(showSpy).not.toHaveBeenCalled();

        velocity.callAllCompletes();

        expect(showSpy).toHaveBeenCalledTimes(1);
    });

    it('triggers prehide before a dialog is hidden', () => {
        const prehideSpy = jasmine.createSpy('prehideSpy');
        wrapper = mountWithStore(<Dialog onPrehide={prehideSpy}/>);

        jasmine.clock().tick(1);

        wrapper.unmount();

        expect(prehideSpy).not.toHaveBeenCalled();

        velocity.callAllBegins();

        expect(prehideSpy).toHaveBeenCalledTimes(1);
    });

    it('Triggers hide after a dialog unmounted', () => {
        const hideSpy = jasmine.createSpy('hideSpy');
        wrapper = mountWithStore(<Dialog onHide={hideSpy}/>);

        jasmine.clock().tick(1);

        wrapper.unmount();

        expect(hideSpy).not.toHaveBeenCalled();

        velocity.callAllCompletes();

        expect(hideSpy).toHaveBeenCalledTimes(1);
    });

    it('triggers hide after a dialog is hidden', () => {
        const hideSpy = jasmine.createSpy('hideSpy');
        wrapper = mountWithStore(<Dialog onHide={hideSpy}/>);

        jasmine.clock().tick(1);
        velocity.callAllCompletes();

        // simulate hide coming from open ui rather than from the dialog
        const instance = wrapper.instance();

        instance.dialog.hide();

        expect(hideSpy).not.toHaveBeenCalled();

        velocity.callAllCompletes();

        expect(hideSpy).toHaveBeenCalledTimes(1);

        wrapper.unmount();

        jasmine.clock().tick(1);
        velocity.callAllCompletes();

        expect(hideSpy).toHaveBeenCalledTimes(1);
    });

    it('copes with an unmount immediately after rendering and still triggers onHide', () => {
        const hideSpy = jasmine.createSpy('hideSpy');
        wrapper = mountWithStore(<Dialog onHide={hideSpy}/>);
        const instance = wrapper.instance();

        wrapper.unmount();

        expect(hideSpy).toHaveBeenCalledTimes(1);

        jasmine.clock().tick(1);
        velocity.callAllCompletes();

        expect(hideSpy).toHaveBeenCalledTimes(1);
        expect(instance.dialog).toEqual(undefined);
    });

    it('triggers resize when dialog is resized', () => {
        const resize = jasmine.createSpy('resize');
        wrapper = mountWithStore(<Dialog onResize={resize}/>);

        jasmine.clock().tick(1);

        expect(resize).not.toHaveBeenCalled();

        // trigger resize from underlying dialog
        wrapper.instance().dialog.trigger('resize');

        expect(resize).toHaveBeenCalledTimes(1);
    });

    it('reposition when content is rendered', () => {
        wrapper = mountWithStore(<Dialog><div>Content</div></Dialog>);

        jasmine.clock().tick(1);
        velocity.callAllCompletes();

        const dialog = wrapper.instance().dialog;
        spyOn(dialog, 'reposition').and.callThrough();
        wrapper.setProps({
            resizeTimestamp: 1,
        });

        expect(dialog.reposition).toHaveBeenCalledTimes(0);

        jasmine.clock().tick(1);

        expect(dialog.reposition).toHaveBeenCalledTimes(1);
    });

    it('does not reposition when it is disabled', () => {
        wrapper = mountWithStore(<Dialog shouldRepositionOnRender={false}><div>Content</div></Dialog>);

        jasmine.clock().tick(1);
        velocity.callAllCompletes();

        const dialog = wrapper.instance().dialog;
        spyOn(dialog, 'reposition').and.callThrough();
        wrapper.setProps({
            resizeTimestamp: 1,
        });

        jasmine.clock().tick(1);

        expect(dialog.reposition).toHaveBeenCalledTimes(0);
    });

    it('does not render while showing, but renders the change after showing', () => {
        wrapper = mountWithStore(<Dialog shouldRepositionOnRender={false}><div>Content</div></Dialog>);

        jasmine.clock().tick(1);

        const renderDialogContent = spyOn(wrapper.instance(), 'renderDialogContent');
        wrapper.setProps({
            children: <div>Content2</div>,
        });

        jasmine.clock().tick(1);

        expect(renderDialogContent).not.toHaveBeenCalled();

        velocity.callAllCompletes();
        jasmine.clock().tick(1);

        expect(renderDialogContent).toHaveBeenCalledTimes(1);
    });

    it('does not render while showing, but renders the change after showing - only once', () => {
        wrapper = mountWithStore(<Dialog shouldRepositionOnRender={false}><div>Content</div></Dialog>);

        jasmine.clock().tick(1);

        const renderDialogContent = spyOn(wrapper.instance(), 'renderDialogContent');
        wrapper.setProps({
            children: <div>Content2</div>,
        });

        jasmine.clock().tick(1);

        wrapper.setProps({
            children: <div>Content3</div>,
        });

        jasmine.clock().tick(1);

        expect(renderDialogContent).not.toHaveBeenCalled();

        velocity.callAllCompletes();
        jasmine.clock().tick(1);

        expect(renderDialogContent).toHaveBeenCalledTimes(1);
    });

    it('renders after showing', () => {
        wrapper = mountWithStore(<Dialog shouldRepositionOnRender={false}><div>Content</div></Dialog>);

        jasmine.clock().tick(1);
        velocity.callAllCompletes();

        const renderDialogContent = spyOn(wrapper.instance(), 'renderDialogContent');
        wrapper.setProps({
            children: <div>Content2</div>,
        });

        jasmine.clock().tick(1);

        expect(renderDialogContent).toHaveBeenCalledTimes(1);
    });

});
