import _ from 'lodash';
import $ from 'jqueryAll';
import React from 'react';
import PropTypes from 'prop-types';
import DialogManager from 'spine/commonControllers/dialogManager';
import DateTime from 'src/modules/dateTime';
import DateTimePickerController from 'spine/commonControllers/dateTimePicker';

class DateTimePicker extends React.Component {

    constructor() {
        super();

        this.setEl = (ref) => {
            this.el = ref;
        };

        // pass in the global dialogManager to DateTimePicker
        // so that the dialog it creates belongs to the same stacking context
        // as other dialogs
        this.dialogManager = DialogManager.getInstance();
    }

    componentDidMount() {
        this.dateTimePickerController = new DateTimePickerController({
            label: this.props.label,
            disabledDays: this.props.disabledDays,
            disabledDates: this.props.disabledDates,
            showDate: this.props.showDate,
            firstDayOfWeek: this.props.firstDayOfWeek,
            showTime: this.props.showTime,
            is24Hour: this.props.is24Hour,
            minuteStep: this.props.minuteStep,
            hasOwnTextInput: this.props.hasOwnTextInput,
            usesPopup: this.props.usesPopup,
            panelManager: this.props.panelManager,
            dialogManager: this.dialogManager,
            minDate: this.props.minDate,
            maxDate: this.props.maxDate,
            showHeader: this.props.showHeader,
        });

        this.dateTimePickerController.setValue(DateTime.createDateTime(this.props.value));
        this.dateTimePickerController.on('change', this.props.onChange);
        $(this.el).append(this.dateTimePickerController.el);
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.value !== this.props.value) {
            this.dateTimePickerController.setValue(DateTime.createDateTime(nextProps.value));
        }
        if (nextProps.minDate !== this.props.minDate) {
            this.dateTimePickerController.setMinDate(nextProps.minDate);
        }
        if (nextProps.maxDate !== this.props.maxDate) {
            this.dateTimePickerController.setMaxDate(nextProps.maxDate);
        }
        if (nextProps.disabledDays !== this.props.disabledDays) {
            this.dateTimePickerController.clearDisabledDays();
            this.dateTimePickerController.disableDays(nextProps.disabledDays);
        }
        if (nextProps.disabledDates !== this.props.disabledDates) {
            this.dateTimePickerController.clearDisabledDates();
            this.dateTimePickerController.disableDates(nextProps.disabledDates);
        }
    }

    shouldComponentUpdate() {
        return false;
    }

    componentWillUnmount() {
        this.dateTimePickerController.release();
        this.dateTimePickerController.off('change');
    }

    render() {
        return <div ref={this.setEl}/>;
    }
}

DateTimePicker.propTypes = {
    onChange: PropTypes.func,
    label: PropTypes.string,
    disabledDays: PropTypes.array,
    disabledDates: PropTypes.array,
    showDate: PropTypes.bool,
    firstDayOfWeek: PropTypes.number,
    showTime: PropTypes.bool,
    is24Hour: PropTypes.bool,
    minuteStep: PropTypes.number,
    hasOwnTextInput: PropTypes.bool,
    usesPopup: PropTypes.bool,
    panelManager: PropTypes.object,
    value: PropTypes.any,
    minDate: PropTypes.object,
    maxDate: PropTypes.object,
    showHeader: PropTypes.bool,
};

DateTimePicker.defaultProps = {
    onChange: _.noop,
};

export default DateTimePicker;
