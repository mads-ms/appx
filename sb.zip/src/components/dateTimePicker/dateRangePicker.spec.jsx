import React from 'react';
import { shallow } from 'enzyme';
import DateRangePicker from 'src/components/dateTimePicker/dateRangePicker';
import DateTime from 'src/modules/dateTime';
import Button from 'src/components/button/button';
import Localization from 'src/localization';

describe('src/components/dateRangePicker', () => {

    it('"Set" button should be disabled and "Invalid Date Range" displayed for invalid date', () => {
        let startDate = DateTime.createDateTime('2017-08-24T13:00:00.0Z');
        let endDate = DateTime.createDateTime('2017-08-23T13:00:00.0Z');
        const wrapper = shallow(<DateRangePicker startDate={startDate} endDate={endDate}/>);
        let buttonProps = wrapper.find(Button).props();

        expect(buttonProps.children).toEqual(Localization.getText('HTML5_InvalidDateRange'));
        expect(buttonProps.isEnabled).toEqual(false);

        startDate = DateTime.createDateTime('2017-08-14T13:00:00.0Z');
        endDate = DateTime.createDateTime('2017-08-14T12:00:00.0Z');
        wrapper.setProps({ startDate, endDate });
        buttonProps = wrapper.find(Button).props();

        expect(buttonProps.children).toEqual(Localization.getText('HTML5_InvalidDateRange'));
        expect(buttonProps.isEnabled).toEqual(false);

        startDate = DateTime.createDate('2017-08-04');
        endDate = DateTime.createDate('2017-08-03');
        wrapper.setProps({ startDate, endDate });
        buttonProps = wrapper.find(Button).props();

        expect(buttonProps.children).toEqual(Localization.getText('HTML5_InvalidDateRange'));
        expect(buttonProps.isEnabled).toEqual(false);
    });

    it('"Set" button should be disabled and "Invalid Date Range" displayed for invalid date range with minDate', () => {
        const minDate = DateTime.createDateTime('2017-08-24T14:00:00.0Z');
        let startDate = DateTime.createDateTime('2017-08-24T13:00:00.0Z');
        const endDate = DateTime.createDateTime('2017-08-24T15:00:00.0Z');
        const wrapper = shallow(<DateRangePicker minDate={minDate} startDate={startDate} endDate={endDate}/>);
        let buttonProps = wrapper.find(Button).props();

        expect(buttonProps.children).toEqual(Localization.getText('HTML5_InvalidDateRange'));
        expect(buttonProps.isEnabled).toEqual(false);

        startDate = DateTime.createDateTime('2017-08-24T14:00:00.0Z');
        wrapper.setProps({ startDate });
        buttonProps = wrapper.find(Button).props();

        expect(buttonProps.children).toEqual(Localization.getText('HTML5_Set'));
        expect(buttonProps.isEnabled).toEqual(true);
    });

    it('"Set" button should be disabled and "Invalid Date Range" displayed for invalid date range with maxDate', () => {
        const startDate = DateTime.createDateTime('2017-08-24T12:00:00.0Z');
        const endDate = DateTime.createDateTime('2017-08-24T12:00:00.0Z');
        const maxDate = DateTime.createDateTime('2017-08-24T10:00:00.0Z');
        const wrapper = shallow(<DateRangePicker maxDate={maxDate} startDate={startDate} endDate={endDate}/>);
        const buttonProps = wrapper.find(Button).props();

        expect(buttonProps.children).toEqual(Localization.getText('HTML5_InvalidDateRange'));
        expect(buttonProps.isEnabled).toEqual(false);

    });
});
