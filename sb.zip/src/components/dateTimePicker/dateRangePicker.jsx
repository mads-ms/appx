import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import DatePicker from 'src/components/dateTimePicker/dateTimePicker';
import Sheet from 'src/components/sheet/sheet';
import SheetHeader from 'src/components/sheet/sheetHeader';
import Localization from 'src/localization';
import { bindHandlers } from 'src/utils/bindHandlers';
import Button from 'src/components/button/button';
import DateTime from 'src/modules/dateTime';
import { getLog } from 'src/modules/log';
import { UI } from 'openui';

const log = getLog('dateRangePicker');

class DateRangePicker extends React.PureComponent {
    constructor(props) {
        super(props);

        this.minutesOffset = Math.abs(DateTime.getUserUtcOffset());
        this.state = {
            startDate: props.startDate ? this.createDate(props.startDate) : this.createDate(),
            endDate: props.endDate ? this.createDate(props.endDate) : this.createDate(),
            minDate: props.minDate ? this.createDate(props.minDate) : null,
            maxDate: props.maxDate ? this.createDate(props.maxDate) : null,
        };

        log.debug('constructor', props);
    }

    componentWillReceiveProps(nextProps) {
        const nextState = {};

        if (nextProps.startDate !== this.props.startDate) {
            nextState.startDate = this.createDate(nextProps.startDate);
        }

        if (nextProps.endDate !== this.props.endDate) {
            nextState.endDate = this.createDate(nextProps.endDate);
        }

        if (nextProps.minDate !== this.props.minDate) {
            nextState.minDate = this.createDate(nextProps.minDate);
        }

        if (nextProps.maxDate !== this.props.maxDate) {
            nextState.maxDate = this.createDate(nextProps.maxDate);
        }

        // _.isEmpty will do in this case as dateRangePicker operates on relatively static data.
        // It's also not intended to be used inside grids etc. So we should be good here.
        if (!_.isEmpty(nextState)) {
            this.setState(nextState);
        }
    }

    createDate(date) {

        // Due to the fact that datePicker displays and operates only UTC dates
        // We need to shift date by the UTC/user time offset
        const dateMoment = DateTime.createMutableDateTime(date).addMinutes(this.minutesOffset);

        if (date && _.isObject(date)) {
            date.options = _.defaults({ hasTime: this.props.showTime }, date.options);
        }
        if (this.props.showTime) {
            return DateTime.createDateTime(dateMoment);
        }
        return DateTime.createDate(dateMoment);
    }

    defaultValidate(startDate, endDate, minDate, maxDate) {

        const startDateMoment = startDate.getMoment();
        const endDateMoment = endDate.getMoment();
        let valid = 1;

        if (minDate) {
            valid &= minDate.getMoment().isSameOrBefore(startDateMoment);
        }

        if (maxDate) {
            valid &= endDateMoment.isSameOrBefore(maxDate.getMoment());
        }

        // Is start before end.
        valid &= startDateMoment.isSameOrBefore(endDateMoment);
        return Boolean(valid);
    }

    validate(startDate, endDate, minDate, maxDate) {
        if (_.isFunction(this.props.validate)) {
            return this.props.validate.call(this, startDate, endDate, minDate, maxDate);
        }
        return this.defaultValidate(startDate, endDate, minDate, maxDate);
    }

    handleStartChange(startDate) {
        log.debug('handleStartChange', startDate);
        this.setState({ startDate });
    }

    handleEndChange(endDate) {
        log.debug('handleEndChange', endDate);
        this.setState({ endDate });
    }

    handleSet() {

        // Due to the fact that datePicker displays and operates only UTC dates
        // We need to shift date by the UTC/user time offset
        const startDateMoment = DateTime.createMutableDateTime(this.state.startDate).addMinutes(-this.minutesOffset);
        const endDateMoment = DateTime.createMutableDateTime(this.state.endDate).addMinutes(-this.minutesOffset);
        this.props.onSet(
            DateTime.createDateTime(startDateMoment),
            DateTime.createDateTime(endDateMoment)
        );
    }

    render() {
        const {
            startDate,
            endDate,
            maxDate,
            minDate,
        } = this.state;

        const isValid = this.validate(startDate, endDate, minDate, maxDate);
        const handleSet = isValid ? this.handleSet : _.noop;

        const startDateComponent = (<DatePicker
            value={startDate}
            minDate={minDate}
            maxDate={maxDate}
            minuteStep={1}
            onChange={this.handleStartChange}
            showTime={this.props.showTime}
            showDate
            showHeader={false}
        />);

        const endDateComponent = (<DatePicker
            value={endDate}
            minDate={minDate}
            maxDate={maxDate}
            minuteStep={1}
            onChange={this.handleEndChange}
            showTime={this.props.showTime}
            showDate
            showHeader={false}
        />);

        return (
            <div className="grid grid--series grid--scroll">
                <div className="grid-cell">
                    <Sheet isAlt>
                        <SheetHeader>
                            {this.props.title}
                        </SheetHeader>
                        <div className="daterangepicker grid grid--fit-all">
                            <div className="grid-cell">{UI.isRTL() ? endDateComponent : startDateComponent}</div>
                            <div className="grid-cell sep sep--left">{UI.isRTL() ? startDateComponent : endDateComponent}</div>
                        </div>
                        <Button
                            isEnabled={isValid}
                            className="btn--primary btn--large"
                            onTap={handleSet}
                        >
                            {isValid ? Localization.getText('HTML5_Set') : Localization.getText('HTML5_InvalidDateRange')}
                        </Button>
                    </Sheet>
                </div>
            </div>
        );
    }
}

DateRangePicker.propTypes = {
    onSet: PropTypes.func,
    startDate: PropTypes.object,
    endDate: PropTypes.object,
    minDate: PropTypes.object,
    maxDate: PropTypes.object,
    validate: PropTypes.func,
    showTime: PropTypes.bool,
    title: PropTypes.string,
};

DateRangePicker.defaultProps = {
    onSet: _.noop,
    showTime: true,
};

export default bindHandlers(DateRangePicker);
