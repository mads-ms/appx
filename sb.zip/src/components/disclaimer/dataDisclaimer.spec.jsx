import React from 'react';
import { mount } from 'enzyme';
import DataDisclaimer from 'src/components/disclaimer/dataDisclaimer';
import Dialog from 'src/components/dialog/dialog';
import { tap } from 'test/mocks/touchableHelper';

describe('src/components/disclaimer/dataDisclaimer', () => {

    let wrapper;

    afterEach(() => {
        wrapper.unmount();
    });

    it('should render link with ExchangeDataProvider and SectorDisclaimer labels', () => {

        wrapper = mount(<DataDisclaimer/>);

        expect(wrapper.children().hasClass('data-disclaimer-link')).toEqual(true);
        expect(wrapper.state().showDisclaimer).toEqual(false);

        const link = wrapper.find('button');

        expect(link.length).toEqual(1);

        expect(link.hasClass('btn--inline')).toEqual(true);
        expect(link.hasClass('btn--link')).toEqual(true);
        expect(link.text()).toEqual('[[#$]]SectorDisclaimer[[/$]]');
    });

    it('should render disclaimer dialog of "popup" type with expected text', () => {

        wrapper = mount(<DataDisclaimer/>);

        tap(wrapper.find('.btn--link'));
        wrapper.update();

        expect(wrapper.state().showDisclaimer).toEqual(true);

        const dialog = wrapper.find(Dialog);
        expect(dialog.length).toEqual(1);
        expect(dialog.props().type).toEqual('popup');
    });

});
