import React from 'react';
import { bindHandlers } from 'src/utils/bindHandlers';
import Localization from 'src/localization';
import Button from 'src/components/button/button';
import DisclaimerDialog from 'src/modules/disclaimerDialog/disclaimerDialog';

// Data disclaimer will be moved to the new disclaimer system eventually
class DataDisclaimer extends React.PureComponent {

    constructor() {
        super();

        this.state = {
            showDisclaimer: false,
        };
    }

    handleTapLink() {
        this.setState({
            showDisclaimer: true,
        });
    }

    handleClose() {
        this.setState({
            showDisclaimer: false,
        });
    }

    render() {

        const { showDisclaimer } = this.state;
        const disclaimerText = `${Localization.getText('ExchangeDataProvider')} \u2022 `;
        const linkText = Localization.getText('SectorDisclaimer');

        return (
            <div className="data-disclaimer-link">
                {disclaimerText}
                <Button
                    onTap={this.handleTapLink}
                    className="btn--inline btn--link"
                >
                    {linkText}
                </Button>
                {showDisclaimer &&
                    <DisclaimerDialog
                        title={Localization.getText('SectorDisclaimer')}
                        onOk={this.handleClose}
                        onHide={this.handleClose}
                        onClose={this.handleClose}
                        showClose
                    >
                        {Localization.getText('SectorDisclaimerTooltip')}
                    </DisclaimerDialog>
                }
            </div>
        );
    }
}

export default bindHandlers(DataDisclaimer);
