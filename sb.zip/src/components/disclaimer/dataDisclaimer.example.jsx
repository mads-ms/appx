import React from 'react';
import DataDisclaimer from 'src/components/disclaimer/dataDisclaimer';
import { examplesOf } from 'src/modules/examples/utils';

export default examplesOf('DataDisclaimer')
    .add('Default', () => (
        <DataDisclaimer/>
    ));
