import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import _ from 'lodash';

const sizeMap = {
    'small': 'sm',
    'normal': '',
    'large': 'lg',
    'extra-large': 'xlg',
};

export default function Icon({ className, type, size, title }) {
    const classes = ['icon', 'icon--' + type, className];
    if (size !== 'normal') {
        classes.push('icon--' + sizeMap[size]);
    }

    return <i title={title} className={classNames(classes)}/>;
}

Icon.propTypes = {
    className: PropTypes.string,
    size: PropTypes.oneOf(_.keys(sizeMap)),
    type: PropTypes.string.isRequired,
    title: PropTypes.string,
};

Icon.defaultProps = {
    size: 'normal',
};
