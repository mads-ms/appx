import UnderlayController from 'spine/commonControllers/underlay';
import PropTypes from 'prop-types';
import React from 'react';

class Underlay extends React.Component {
    constructor() {
        super();

        // remove default underlay when this one is rendered
        const prevUnderlay = document.getElementById('underlay');
        if (prevUnderlay && prevUnderlay.parentNode) {
            prevUnderlay.parentNode.removeChild(prevUnderlay);
        }
        this.className = (prevUnderlay && prevUnderlay.className) || '';
    }

    componentDidMount() {
        UnderlayController.getInstance().update();
    }

    render() {
        return <div id="underlay" className={this.className}></div>;
    }
}

Underlay.propTypes = {
    className: PropTypes.string,
};

export default Underlay;
