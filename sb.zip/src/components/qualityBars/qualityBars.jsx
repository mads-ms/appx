import PropTypes from 'prop-types';
import React from 'react';
import _ from 'lodash';

function QualityBars({ quality, barsNumber }) {

    // Normalizing quality number because the number of bars could differ from 10
    // Rounding to the next number
    const normalizedQuality = Math.round((quality * barsNumber) / 10);

    const liStyle = {
        opacity: (normalizedQuality / 10),
    };

    const bars = _.map(new Array(normalizedQuality), (obj, index) =>
        <li className="tradesignals-quality-bar" style={liStyle} key={index}/>
    );

    return (
        <ul className="tradesignals-quality">
            {bars}
        </ul>
    );
}

QualityBars.propTypes = {
    quality: PropTypes.oneOf([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]),
    barsNumber: PropTypes.number,
};

QualityBars.defaultProps = {
    barsNumber: 10,
};

export default QualityBars;
