import React from 'react';
import PropTypes from 'prop-types';
import { bindHandlers } from 'src/utils/bindHandlers';
import TooltipButton from 'src/components/tooltipDialog/tooltipButton';
import * as featureTracker from 'src/featureTracker';
import config from 'src/config';

class ToolTipLabel extends React.PureComponent {
    handleShowTooltip() {
        const {
            toolTipHeaderText,
            featureArea,
        } = this.props;

        if (featureArea) {
            featureTracker.logEvent(featureArea, `Tooltip: ${toolTipHeaderText} shown`, {
                sessionId: config.sessionId,
            });
        }
    }

    render() {
        const {
            className,
            labelText,
            toolTipHeaderText,
            toolTipBodyText,
        } = this.props;

        return (
            <span className={className}>
                {labelText}
                {toolTipHeaderText && (
                    <TooltipButton
                        tooltipTitle={toolTipHeaderText}
                        tooltipText={toolTipBodyText}
                        onShowTooltip={this.handleShowTooltip}
                    />
                )}
            </span>
        );
    }
}

ToolTipLabel.propTypes = {
    className: PropTypes.string,
    labelText: PropTypes.string,
    toolTipHeaderText: PropTypes.string,
    toolTipBodyText: PropTypes.string,
    featureArea: PropTypes.string,
};

ToolTipLabel.defaultProps = {
    className: '',
    labelText: '',
    toolTipHeaderText: '',
    toolTipBodyText: '',
};

export default bindHandlers(ToolTipLabel);
