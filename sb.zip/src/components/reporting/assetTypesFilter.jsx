import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import AssetTypesFilterItem from './assetTypesFilterItem';
import { bindHandlers } from 'src/utils/bindHandlers';
import { assetTypeItemProps } from './propTypes';

class AssetTypesFilter extends React.PureComponent {
    handleTap(assetType) {
        this.props.onFilterChange(assetType);
    }

    render() {
        return (
            <div className="reporting-assetfilter">
                {_.map(this.props.assetTypes, (assetTypeItem) => (
                    <AssetTypesFilterItem
                        key={assetTypeItem.assetType}
                        onTap={this.handleTap}
                        assetTypeItem={assetTypeItem}
                    />
                ))}
            </div>
        );
    }
}

AssetTypesFilter.propTypes = {
    onFilterChange: PropTypes.func.isRequired,
    assetTypes: PropTypes.arrayOf(PropTypes.shape(assetTypeItemProps)).isRequired,
};

export default bindHandlers(AssetTypesFilter);
