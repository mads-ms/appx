import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import Localization from 'src/localization';
import Dropdown from 'src/components/dropdown/dropdown';
import DropdownItem from 'src/components/dropdown/dropdownItem';
import VerticalRadioButtonGroup from 'src/components/radioButton/verticalRadioButtonGroup';
import RadioButton from 'src/components/radioButton/radioButton';
import { bindHandlers } from 'src/utils/bindHandlers';
import * as featureTracker from 'src/featureTracker';
import config from 'src/config';

// Used by Bookings and ProfitLoss to choose between predefined
// views(set of groupings keys)
class GroupByViewSelector extends React.PureComponent {

    handleChangeView(viewId) {
        this.props.onChangeView(viewId);

        if (this.props.featureArea) {
            featureTracker.logEvent(this.props.featureArea, 'Group by changed', {
                viewId,
                sessionId: config.sessionId,
            });
        }
    }

    handleFirstCustomGroupingKeyChange(newValue) {
        this.props.onChangeCustomGroupingKeys(newValue, this.props.secondGroupByKeyId);
    }

    handleSecondCustomGroupingKeyChange(newValue) {
        this.props.onChangeCustomGroupingKeys(this.props.firstGroupByKeyId, newValue);
    }

    isCustomGroupingSelected() {
        return (this.props.viewId === 'custom');
    }

    firstGroupingKeyFilter(item) {
        return (item.id !== 'none' && item.id !== this.props.secondGroupByKeyId);
    }

    secondGroupingKeyFilter(item) {
        return (item.id !== this.props.firstGroupByKeyId);
    }

    getCustomGroupingSection() {
        if (!this.isCustomGroupingSelected()) {
            return null;
        }

        return (
            <div className="grid grid--y grid--fit-all grid--series">
                <div className="grid-cell">
                    <p className="form-legend">{Localization.getText('HTML5_Custom_Grouping')}</p>
                </div>

                <div className="grid-cell">
                    <Dropdown
                        onChange={this.handleFirstCustomGroupingKeyChange}
                        label={Localization.getText('HTML5_FirstGroupBy')}
                        isEnabled={this.isCustomGroupingSelected()}
                        value={this.props.firstGroupByKeyId}
                    >
                        {_.map(
                            _.filter(this.props.groupingKeys, (item) =>
                                item.id !== 'none' && item.id !== this.props.secondGroupByKeyId
                            ),
                            (groupingKey) => (
                                <DropdownItem key={groupingKey.id} value={groupingKey.id}>
                                    <span>{groupingKey.name}</span>
                                </DropdownItem>
                            )
                        )}
                    </Dropdown>
                </div>

                <div className="grid-cell">
                    <Dropdown
                        onChange={this.handleSecondCustomGroupingKeyChange}
                        label={Localization.getText('HTML5_ThenGroupBy')}
                        isEnabled={this.isCustomGroupingSelected()}
                        value={this.props.secondGroupByKeyId}
                    >
                        {_.map(
                            _.reject(this.props.groupingKeys, (item) =>
                                item.id === this.props.firstGroupByKeyId
                            ),
                            (groupingKey) => (
                                <DropdownItem key={groupingKey.id} value={groupingKey.id}>
                                    <span>{groupingKey.name}</span>
                                </DropdownItem>
                            )
                        )}
                    </Dropdown>
                </div>
            </div>
        );
    }

    render() {
        return (
            <div className="grid grid--y grid--fit-all">
                <div className="grid-cell">
                    <p className="form-legend">{Localization.getText('HTML5_GroupBy')}</p>
                    <VerticalRadioButtonGroup
                        onChange={this.handleChangeView}
                        radioFamily="typeRadio"
                        value={this.props.viewId}
                    >
                        {_.map(this.props.views, (view) => (
                            <RadioButton
                                key={view.id}
                                value={view.id}
                                className="reporting-filterlabel"
                            >
                                {view.name}
                            </RadioButton>
                        ))}
                    </VerticalRadioButtonGroup>
                </div>
                {this.getCustomGroupingSection()}
            </div>
        );
    }
}

GroupByViewSelector.propTypes = {
    viewId: PropTypes.string.isRequired,
    firstGroupByKeyId: PropTypes.string.isRequired,
    secondGroupByKeyId: PropTypes.string,
    views: PropTypes.array.isRequired,
    groupingKeys: PropTypes.array.isRequired,
    featureArea: PropTypes.string,
    onChangeView: PropTypes.func.isRequired,
    onChangeCustomGroupingKeys: PropTypes.func.isRequired,
};

export default (bindHandlers(GroupByViewSelector));
