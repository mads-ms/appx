import React from 'react';
import classNames from 'classnames';
import Localization from 'src/localization';
import ReportingInstrument from 'src/components/reporting/reportingInstrument';
import ReportingAssetType from 'src/components/reporting/reportingAssetType';
import dateTime from 'src/modules/dateTime';

const NON_INSTRUMENT_RELATED_TEXT = Localization.getText('HTML5_Non_instrument');
const NON_ASSET_TYPE_TEXT = Localization.getText('HTML5_Non_asset_type');
const NON_SECTOR_TEXT = Localization.getText('HTML5_Non_sector');

export function getTemplate(templateKey, obj, className) {

    switch (templateKey) {

        case 'bookingType':
        case 'year':
            return <div className={classNames('t-truncate', className)}>{obj || ''}</div>;

        case 'assetType':
            return obj ?
                <ReportingAssetType
                    reportingAssetType={obj}
                    className={className}
                /> :
                <div className={classNames('t-truncate', className)}>{NON_ASSET_TYPE_TEXT}</div>;

        case 'instrument':
        case 'underlyingInstrument':
            return obj ?
                <ReportingInstrument
                    reportingInstrument={obj}
                    className={className}
                /> :
                <div className={classNames('t-truncate', className)}>{NON_INSTRUMENT_RELATED_TEXT}</div>;

        case 'day':
            return <div className={classNames('t-truncate', className)}>{obj ? dateTime.formatUserDate(dateTime.createDate(obj)) : ''}</div>;

        case 'month':
            return (
                <div className={classNames('t-truncate', className)}>{obj ? dateTime.shortMonthName(Number(obj.toString().substring(5, 7)) - 1) +
                    ' ' + obj.toString().substring(0, 4) : ''}
                </div>
            );

        case 'sector':
            return <div className={classNames('t-truncate', className)}>{obj || NON_SECTOR_TEXT}</div>;

        default:
            return obj.toString();
    }
}
