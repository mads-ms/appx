import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import { bindHandlers } from 'src/utils/bindHandlers';
import InstrumentIcon from 'src/components/instrument/instrumentIcon';
import Touchable from 'src/components/touchable/touchable';
import Icon from 'src/components/icon/icon';
import * as numberFormat from 'src/numberFormat';
import { assetTypeItemProps } from './propTypes';
import * as instrumentAssetTypeQueries from 'src/modules/instruments/assetType/queries';

class AssetTypesFilterItem extends React.PureComponent {

    handleChange() {
        this.props.onTap(this.props.assetTypeItem.assetType);
    }

    render() {
        const assetTypeItem = this.props.assetTypeItem;
        const {
            assetType,
            isChecked,
            count,
            sum,
        } = assetTypeItem;

        const instrument = { AssetType: assetType };
        const label = instrumentAssetTypeQueries.getAssetTypeName(instrument);

        const checkboxClasses = classNames('checkbox-icon', {
            'checked': isChecked,
        });

        return (
            <Touchable onTap={this.handleChange}>
                <div className="grid tst-assetfilter-row">
                    <div className="reporting-assetfilter-item grid g--1of2 grid--seriessm grid--fit-all">
                        <div className="grid-cell">
                            <Icon type="tick" className={checkboxClasses}/>
                        </div>
                        <InstrumentIcon
                            className="instr-market grid-cell g--cross-center"
                            instrument={instrument}
                        />
                        <div className="reporting-assetfilter-name grid-cell tst-asset-types-filter-name">
                            {label} ({numberFormat.format(count)})
                        </div>
                    </div>
                    <div className="grid-cell">
                        <p className="t-end tst-asset-types-filter-sum">{numberFormat.format(sum, 2)}</p>
                    </div>
                </div>
            </Touchable>
        );
    }
}

AssetTypesFilterItem.propTypes = {
    onTap: PropTypes.func.isRequired,
    assetTypeItem: PropTypes.shape(assetTypeItemProps).isRequired,
};

export default bindHandlers(AssetTypesFilterItem);
