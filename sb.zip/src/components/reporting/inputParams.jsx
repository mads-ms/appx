import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import Localization from 'src/localization';
import DateRange from 'src/components/reporting/dateRange';
import ViewSelector from 'src/components/reporting/groupByViewSelector/groupByViewSelector';
import AccountBalancesSelector from 'src/modules/accountBalancesSelector';
import { bindHandlers } from 'src/utils/bindHandlers';
import * as reportingQueries from 'src/modules/reporting/queries';

class InputParams extends React.PureComponent {

    handleChangeView(viewId) {
        const {
            componentId,
            accountInfo,
            rangeId,
            startDate,
            endDate,
            views,
        } = this.props;

        const accountId = accountInfo.accountId;

        const chosenView = _.find(views, { 'id': viewId });

        const {
            firstGroupByKeyId,
            secondGroupByKeyId,
        } = chosenView;

        const params = {
            componentId,
            accountId,
            rangeId,
            startDate,
            endDate,
            viewId,
            firstGroupByKeyId,
            secondGroupByKeyId,
        };

        this.props.onChangeInputParams(params);
    }

    handleChangeCustomGroupingKeys(firstGroupByKeyId, secondGroupByKeyId) {
        const {
            componentId,
            accountInfo,
            rangeId,
            startDate,
            endDate,
            viewId,
        } = this.props;

        const accountId = accountInfo.accountId;

        const params = {
            componentId,
            accountId,
            rangeId,
            startDate,
            endDate,
            viewId,
            firstGroupByKeyId,
            secondGroupByKeyId,
        };

        this.props.onChangeInputParams(params);
    }

    handleDateRangeChanged(rangeId, startDate, endDate) {
        const {
            componentId,
            accountInfo,
            viewId,
            firstGroupByKeyId,
            secondGroupByKeyId,
        } = this.props;

        const accountId = accountInfo.accountId;

        const params = {
            componentId,
            accountId,
            rangeId,
            startDate,
            endDate,
            viewId,
            firstGroupByKeyId,
            secondGroupByKeyId,
        };

        this.props.onChangeInputParams(params);
    }

    handleAccountChanged(accountId) {
        const {
            componentId,
            viewId,
            rangeId,
            startDate,
            endDate,
            firstGroupByKeyId,
            secondGroupByKeyId,
        } = this.props;

        const params = {
            componentId,
            accountId,
            rangeId,
            startDate,
            endDate,
            viewId,
            firstGroupByKeyId,
            secondGroupByKeyId,
        };

        this.props.onChangeInputParams(params);
    }

    render() {
        const {
            componentId,
            accountInfo,
            viewId,
            rangeId,
            startDate,
            endDate,
            firstGroupByKeyId,
            secondGroupByKeyId,
            featureArea,
            views,
            groupingKeys,
        } = this.props;

        return (
            <div className="grid grid--y grid--fit-all grid--series">
                <div className="grid-cell">
                    <div className="h3 sep sep--bottom">
                        {Localization.getText('HTML5_Filter')}
                    </div>
                </div>

                <div className="grid-cell">
                    <p className="form-legend">{Localization.getText('HTML5_Account')}</p>
                    <AccountBalancesSelector
                        componentId={componentId}
                        onSelect={this.handleAccountChanged}
                        accountId={accountInfo.accountId}
                        showClient
                        showGroups
                        featureArea={featureArea}
                    />
                </div>

                <div className="grid-cell">
                    <p className="form-legend">{Localization.getText('HTML5_Chart_period')}</p>
                    <DateRange
                        predefinedRanges={reportingQueries.getPredefinedRanges()}
                        onChange={this.handleDateRangeChanged}
                        rangeId={rangeId}
                        startDate={startDate}
                        endDate={endDate}
                        featureArea={featureArea}
                    />
                </div>

                <div className="grid-cell">
                    <ViewSelector viewId={viewId}
                        firstGroupByKeyId={firstGroupByKeyId}
                        secondGroupByKeyId={secondGroupByKeyId}
                        views={views}
                        groupingKeys={groupingKeys}
                        onChangeView={this.handleChangeView}
                        onChangeCustomGroupingKeys={this.handleChangeCustomGroupingKeys}
                        featureArea={featureArea}
                    />
                </div>
            </div>
        );
    }
}

InputParams.propTypes = {
    componentId: PropTypes.string.isRequired,
    accountInfo: PropTypes.object.isRequired,
    rangeId: PropTypes.string.isRequired,
    startDate: PropTypes.string.isRequired,
    endDate: PropTypes.string.isRequired,
    viewId: PropTypes.string.isRequired,
    firstGroupByKeyId: PropTypes.string.isRequired,
    secondGroupByKeyId: PropTypes.string,
    resizeTimestamp: PropTypes.number,
    onChangeInputParams: PropTypes.func,
    featureArea: PropTypes.string,
    views: PropTypes.arrayOf(PropTypes.shape({
        id: PropTypes.string.isRequired,
        name: PropTypes.string.isRequired,
        firstGroupByKeyId: PropTypes.string.isRequired,
        secondGroupByKeyId: PropTypes.string.isRequired,
    }).isRequired).isRequired,
    groupingKeys: PropTypes.arrayOf(PropTypes.shape({
        id: PropTypes.string.isRequired,
        name: PropTypes.string.isRequired,
    }).isRequired).isRequired,
};

export default bindHandlers(InputParams);

