import React from 'react';
import PropTypes from 'prop-types';
import InstrumentIcon from 'src/components/instrument/instrumentIcon';
import classNames from 'classnames';
import * as assetTypes from 'src/modules/instruments/assetType/assetTypes';

class ReportingAssetType extends React.PureComponent {

    render() {
        const {
            className,
            reportingAssetType,
        } = this.props;

        const {
            AssetType,
            Description,
        } = reportingAssetType;

        return (<div className={classNames('grid', className)}>
            {
                (AssetType && AssetType !== assetTypes.CASH &&
                    <InstrumentIcon
                        className="grid-cell g--cross-center g--fit instr-market"
                        instrument={{ AssetType }}
                    />
                )
            }
            <div className="grid-cell t-truncate g--fit g--cross-center">
                {Description}
            </div>
        </div>);
    }
}

ReportingAssetType.propTypes = {
    reportingAssetType: PropTypes.shape({
        AssetType: PropTypes.string,
        Description: PropTypes.string.isRequired,
    }).isRequired,
    className: PropTypes.string,
};

export default ReportingAssetType;
