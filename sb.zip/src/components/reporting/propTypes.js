import PropTypes from 'prop-types';

export const assetTypeItemProps = {
    assetType: PropTypes.string,
    sum: PropTypes.number,
    count: PropTypes.number,
    isChecked: PropTypes.bool,
};

export const openCloseItemProps = {
    key: PropTypes.string,
    isChecked: PropTypes.bool,
    sum: PropTypes.number,
};
