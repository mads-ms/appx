import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import Localization from 'src/localization';
import Dropdown from 'src/components/dropdown/dropdown';
import DropdownItem from 'src/components/dropdown/dropdownItem';
import DateTime from 'src/modules/dateTime';
import DateTimePicker from 'src/components/dateTimePicker/dateTimePicker';
import { DATE_RANGE_CUSTOM } from 'src/modules/reporting/constants';
import { bindHandlers } from 'src/utils/bindHandlers';
import * as featureTracker from 'src/featureTracker';
import config from 'src/config';

/**
 * Displays a dropdown with pre-defined date ranges for the user to choose from.
 * All dates going in and out of this component are strings in the format YYYY-MM-DD.
 *
 * Time is not supported.
 *
 * Props:
 * - predefinedRanges. Ranges are defined in src/components/reporting/reportingQueries.
 *   If the range with id DATE_RANGE_CUSTOM is included it will allow the user to
 *   specify custom start and end dates.
 * - rangeId: The id of the range that is currently selected
 * - startDate: The current startDate (string formatted as YYY-MM-DD)
 * - endDate: The current endDate (string formatted as YYY-MM-DD)
 * - onChange: Eventhandler that will be called when the date range and or start
 *   or end date changes.
 *
 * Signature is func(rangeId, startDate, enddate)
 */
class DateRange extends React.PureComponent {

    constructor(props) {
        super(props);

        this.range = this.getPredefinedRange(this.props.rangeId);
    }

    getPredefinedRange(rangeId) {
        return _.find(this.props.predefinedRanges, { id: rangeId });
    }

    handlePredefinedRangeChange(rangeId) {
        this.range = this.getPredefinedRange(rangeId);

        const {
            onChange,
            startDate,
            endDate,
            featureArea,
        } = this.props;

        if (rangeId === DATE_RANGE_CUSTOM) {
            // Only change the range id but hang on to the existing start and
            // end dates to initialise the custom range with the dates from the
            // most previously chosen predefined range
            onChange(rangeId, startDate, endDate);
        } else {
            this.props.onChange(
                rangeId,
                this.range.startDate.toOapi(),
                this.range.endDate.toOapi()
            );
        }

        if (featureArea) {
            featureTracker.logEvent(featureArea, 'Date range changed', {
                rangeId,
                sessionId: config.sessionId,
            });
        }
    }

    handleStartDateChange(value) {
        // Ignore changes to the indiviual date fields unless the custom range is activated
        if (this.range.id !== DATE_RANGE_CUSTOM) {
            return;
        }

        // If the user chooses a start date that lies after the currently selected end date then
        // set the end date to be the same as the start date
        if (value.getMoment().isAfter(this.props.endDate)) {
            this.props.onChange(
                this.range.id,
                value.toOapi(),
                value.toOapi()
            );
        } else {
            this.props.onChange(
                this.range.id,
                value.toOapi(),
                this.props.endDate
            );
        }
    }

    handleEndDateChange(value) {
        // Ignore changes to the indiviual date fields unless the custom range is activated
        if (this.range.id !== DATE_RANGE_CUSTOM) {
            return;
        }

        // If the user chooses an end date that lies before the currently selected start date then
        // set the start date to be the same as the end date
        if (value.getMoment().isBefore(this.props.startDate)) {
            this.props.onChange(
                this.range.id,
                value.toOapi(),
                value.toOapi()
            );
        } else {
            this.props.onChange(
                this.range.id,
                this.props.startDate,
                value.momentArg
            );
        }
    }

    renderDateDetails() {
        if (this.range.id === DATE_RANGE_CUSTOM) {
            return (
                <div className={classNames('grid', { 'grid--fit-all': this.props.horizontalAlignment })}>
                    <div className="grid-cell tst-date-range-start-date">
                        <DateTimePicker
                            hasOwnTextInput
                            showDate
                            maxDate={DateTime.now()}
                            value={this.props.startDate}
                            onChange={this.handleStartDateChange}
                        />
                    </div>

                    <div className="grid-cell tst-date-range-end-date">
                        <DateTimePicker
                            hasOwnTextInput
                            showDate
                            maxDate={DateTime.now()}
                            value={this.props.endDate}
                            onChange={this.handleEndDateChange}
                        />
                    </div>
                </div>
            );
        }

        return (
            <div className="btn btn--outline tst-date-range-selection" disabled>
                { Localization.getText('HTML5_date_range').replace('{0}',
                    DateTime.formatUserDate(DateTime.createDate(this.props.startDate))).replace('{1}',
                    DateTime.formatUserDate(DateTime.createDate(this.props.endDate)))
                }
            </div>
        );
    }

    render() {
        const classes = classNames('grid grid--seriessm', {
            'grid--fit-all': this.props.horizontalAlignment,
            'grid--y': !this.props.horizontalAlignment,
        });

        return (
            <div className={classes}>
                <div className="grid-cell">
                    <Dropdown
                        onChange={this.handlePredefinedRangeChange}
                        label={Localization.getText('HTML5_Select_range')}
                        value={this.props.rangeId}
                    >
                        {_.map(this.props.predefinedRanges, (range) => (
                            <DropdownItem key={range.id} value={range.id}>
                                <span>{range.name}</span>
                            </DropdownItem>
                        ))}
                    </Dropdown>
                </div>

                <div className="grid-cell">
                    {this.renderDateDetails()}
                </div>
            </div>
        );
    }
}

DateRange.propTypes = {
    predefinedRanges: PropTypes.arrayOf(PropTypes.shape({
        id: PropTypes.string.isRequired,
        name: PropTypes.string.isRequired,

        // moment DateTime instances
        startDate: PropTypes.object.isRequired,
        endDate: PropTypes.object.isRequired,
    })).isRequired,
    rangeId: PropTypes.string.isRequired,

    // OApi format: YYYY-MM-DD
    startDate: PropTypes.string.isRequired,

    // OApi format: YYYY-MM-DD
    endDate: PropTypes.string.isRequired,
    onChange: PropTypes.func,
    horizontalAlignment: PropTypes.bool,
    featureArea: PropTypes.string,
};

DateRange.defaultProps = {
    onChange: _.noop,
    horizontalAlignment: false,
};

export default bindHandlers(DateRange);
