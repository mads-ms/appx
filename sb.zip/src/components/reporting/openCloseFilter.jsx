import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import OpenCloseFilterItem from './openCloseFilterItem';
import { bindHandlers } from 'src/utils/bindHandlers';
import { openCloseItemProps } from './propTypes';

class OpenCloseFilter extends React.PureComponent {
    handleTap(openCloseItem) {
        this.props.onFilterChange(openCloseItem.key);
    }

    render() {
        return (
            <div>
                {_.map(this.props.openCloseOptions, (option) => (
                    <OpenCloseFilterItem
                        key={option.key}
                        onTap={this.handleTap}
                        openCloseItem={option}
                    />
                ))}
            </div>
        );
    }
}

OpenCloseFilter.propTypes = {
    onFilterChange: PropTypes.func.isRequired,
    openCloseOptions: PropTypes.arrayOf(PropTypes.shape(openCloseItemProps)).isRequired,
};

export default bindHandlers(OpenCloseFilter);
