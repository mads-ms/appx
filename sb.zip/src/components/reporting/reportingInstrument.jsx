import React from 'react';
import PropTypes from 'prop-types';
import InstrumentIcon from 'src/components/instrument/instrumentIcon';
import classNames from 'classnames';
import * as assetTypes from 'src/modules/instruments/assetType/assetTypes';

class ReportingInstrument extends React.PureComponent {

    render() {
        const {
            AssetType,
            SubType,
            Description,
        } = this.props.reportingInstrument;

        if (AssetType && AssetType !== assetTypes.CASH) {
            return (
                <div className={classNames('grid', this.props.className)}>
                    <InstrumentIcon
                        className="grid-cell g--cross-center g--fit instr-market"
                        instrument={{ AssetType, DisplayHint: SubType }}
                    />
                    <div className="t-truncate grid-cell g--cross-center" title={Description}>
                        {Description}
                    </div>
                </div>);
        }

        return (
            <div className="t-truncate" title={Description}>
                {Description}
            </div>
        );
    }
}

ReportingInstrument.propTypes = {
    reportingInstrument: PropTypes.shape({
        AssetType: PropTypes.string,
        SubType: PropTypes.string,
        Description: PropTypes.string.isRequired,
    }).isRequired,
    className: PropTypes.string,
};

export default ReportingInstrument;
