import _ from 'lodash';

const GROUP_BY_KEY_DELIMETER = '|#|';

function getDefaultGroupLevelDef(path) {
    return {
        path,
        getGroupKey: (dataItem) => _.get(dataItem, path),
        getSortValue: (dataItem) => _.get(dataItem, path),
    };
}

/**
 * Sorts the data using the getSortValue functions on each groupLevel.
 *
 * This is the first step in the grouping process and ensures that both group
 * rows and their children appear in the correct order.
 *
 * Sorting is performed ascending on the values returned by the getSortValue
 * function on each groupLevel.
 */
export function getSortedData({ data, groupLevels }) {
    const sortFunctions = _.map(groupLevels, 'getSortValue');
    const sortDirections = _.times(_.size(groupLevels), _.constant('asc'));
    const sortedData = _.orderBy(data, sortFunctions, sortDirections);

    return sortedData;
}

/**
 * Adds a groupByKeys property to each dataItem in sortedData.
 *
 * The groupByKeys is an array with one groupByKey for each groupLevel. Each
 * groupByKey is extracted using the getGroupKey function from the groupLevel.
 */
export function addGroupByKeys({ sortedData, groupLevels }) {
    const res = _.map(sortedData, (dataItem) => _.defaults(dataItem, {
        groupByKeys: _.invokeMap(groupLevels, 'getGroupKey', dataItem),
    }
    ));

    return res;
}

/**
 * Clones a dataItem in a way where all property paths needed by the groupLevels
 * above the groupLevelIndex are preserved in their original order.
 *
 * Property paths not needed are excluded.
 */
function cloneDataItemForGroupRow({ dataItem, groupLevels, groupLevelIndex }) {
    // Get the paths for the current group level and above
    const pathsToKeep = _.map(_.take(groupLevels, groupLevelIndex + 1), 'path');
    const keys = _.keys(dataItem);

    return _.pick(dataItem, _.intersection(keys, pathsToKeep));
}

/**
 * Flattens an array of groupByKeys into a string with values separated by the GROUP_BY_KEY_DELIMETER.
 */
function getGroupKeyAsString({ groupByKeys, groupLevelIndex }) {
    return _.join(_.slice(groupByKeys, 0, groupLevelIndex + 1), GROUP_BY_KEY_DELIMETER);
}

/**
 * Recursive function that performs the actual grouping.
 *
 * The rows input parameter is recursively built and will hold the final result
 * when the function is done.
 *
 * - rows: The resulting rows. Should be an empty array on first call.
 * - data: The sorted data with groupByKeys added. Notice that we narrow this one on each recursion.
 * - groupLevels: All the groupLevels defining how we group the entire data set.
 * - sumByPath: The path of the property to sum by.
 * - groupLevelIndex: The current groupLevel to process
 */
export function getRowsForGroup({ rows, data, groupLevels, sumByPath, groupLevelIndex }) {
    const groupedData = _.groupBy(data, (dataItem) => dataItem.groupByKeys[groupLevelIndex]);
    const groupByKeys = _.keys(groupedData);

    _.forEach(groupByKeys,
        function(groupByKey) {

            // Add a row for the group itself.
            const getSumForGroup = _.sumBy(_.get(groupedData, groupByKey),
                function(dataItem) {
                    return _.get(dataItem, sumByPath, 0);
                });

            const dataItem = _.head(_.get(groupedData, groupByKey));
            const clonedDataItem = cloneDataItemForGroupRow({
                dataItem,
                groupLevels,
                groupLevelIndex,
            });

            let clonedDataItemWithUpdatedSum = clonedDataItem;

            if (sumByPath) {
                clonedDataItemWithUpdatedSum = _.set(clonedDataItem, sumByPath, getSumForGroup);
            }

            const fullGroupByKeyAsString = getGroupKeyAsString({
                groupByKeys: dataItem.groupByKeys,
                groupLevelIndex,
            });

            const parentGroupByKeyAsString = getGroupKeyAsString({
                groupByKeys: dataItem.groupByKeys,
                groupLevelIndex: (groupLevelIndex > 0) ? groupLevelIndex - 1 : 0,
            });

            const isExpandable = _.size(groupLevels) > groupLevelIndex + 1;

            const row = {
                id: fullGroupByKeyAsString,
                isExpandable,
                groupId: parentGroupByKeyAsString,
            };

            _.set(row, 'data', clonedDataItemWithUpdatedSum);

            rows.push(row);

            // If this was an expandable row then add the children
            if (isExpandable) {
                getRowsForGroup(
                    {
                        rows,
                        data: _.get(groupedData, groupByKey),
                        groupLevels,
                        sumByPath,
                        groupLevelIndex: groupLevelIndex + 1,
                    });
            }
        });
}

/**
 * Group an array of data items producing a set of rows that can be fed directly
 * to the reporting/grid.
 *
 * - data: Required. An array of objects to group
 * - groupLevels: Required. An array of group level definitions. Can be n-levels deep but grid supports a max. of 2 levels.
 *
 * Each group level definition must be an object with:
 *  {
 *      path: Required. A string specifying the path to the object in data.,
 *      getGroupKey:  Optional. A function to get the groupKey from a dataItem. The value returned must be a scalar.
 *      Example: (dataItem) => dataItem.someProp
 *               If this function is not specified the object from path will be used as is.
 *      getSortValue: Optional. A function to get the sortKey from a dataItem. The value returned must be a scalar.
 *                    Example: (dataItem) => dataItem.someProp
 *                    If this function is not specified the object from path will be used as is.
 *  }
 *  - sumByPath: Optional. A path defining a a property to sum by. All group rows will get a property with this path
 *               that holds the sum of all row objects in the group.
 */
export function getGroupedRows({ data, groupLevels, sumByPath }) {
    const groupLevelsSanitized = _.map(groupLevels, (gl) =>
        _.defaults(gl, getDefaultGroupLevelDef(gl.path))
    );

    const sortedData = getSortedData(
        {
            data: _.cloneDeep(data),
            groupLevels: groupLevelsSanitized,
        });

    const dataWithGroupKeys = addGroupByKeys(
        {
            sortedData,
            groupLevels: groupLevelsSanitized,
        });

    const rows = [];
    getRowsForGroup(
        {
            rows,
            data: dataWithGroupKeys,
            groupLevels: groupLevelsSanitized,
            sumByPath,
            groupLevelIndex: 0, // Start at the first group level. Will recurse through all group levels!
        });
    return rows;
}
