import _ from 'lodash';
import $ from 'jqueryAll';
import React from 'react';
import PropTypes from 'prop-types';
import Localization from 'src/localization';
import ReactGrid from 'src/components/reactGrid/reactGrid';
import Icon from 'src/components/icon/icon';
import Button from 'src/components/button/button';
import Notice from 'src/components/notice/notice';
import * as constants from 'src/components/reporting/grid/constants';
import { bindHandlers } from 'src/utils/bindHandlers';
import ExpandButton from 'src/components/reporting/grid/expandButton';
import * as featureTracker from 'src/featureTracker';
import config from 'src/config';
import { Header } from 'src/components/reactGrid/reactGridBlocks';

class Grid extends React.PureComponent {

    getRows(props) {
        return _.compact(_.map(props.rows, (rowInfo) => {

            const { gridState } = props;

            const {
                groupingEnabled,
                selectionEnabled,
                selectedRowIds,
                expandedGroupIds,
            } = gridState;

            const {
                id,
                groupId,
                data,
            } = rowInfo;

            const isGroupExpanded = groupingEnabled && _.includes(expandedGroupIds, groupId);
            const isExpandable = groupingEnabled && rowInfo.isExpandable;
            const isExpanded = isGroupExpanded && isExpandable;
            const isSelected = selectionEnabled && _.includes(selectedRowIds, id);
            const className = {
                'is-selected': isSelected,
                'reactgrid-divider': isExpandable,
                'is-selectable': selectionEnabled,
            };

            if (groupingEnabled && !isGroupExpanded && !isExpandable) {
                return null;// Hide rows in collapsed groups.
            }

            return {
                id,
                groupId,
                data,
                isGroupExpanded,
                isExpandable,
                isExpanded,
                isSelected,
                className,
            };

        }));
    }

    getCols(props) {
        return props.gridState.groupingEnabled ? _.concat([this.getExpandColDef()], props.cols) : props.cols;
    }

    wasExpandButtonClicked(evt) {
        return Boolean($(evt.target).closest('.js-expand-button').length);
    }

    handleExpandAllToggle() {
        const {
            gridState,
        } = this.props;

        const newGridState = _.clone(gridState);
        newGridState.expandAll = !newGridState.expandAll;

        if (newGridState.expandAll) {
            // Get all groups ids from the rows and add them to the list of expanded groups.
            // This way the user can collapse individual groups after expanding them all
            const groups = _.groupBy(this.getRows(this.props), 'groupId');
            const groupIds = _.keys(groups);
            const uniqueGroupKeys = _.uniq(groupIds);
            newGridState.expandedGroupIds = uniqueGroupKeys;
        } else {
            newGridState.expandedGroupIds = [];
        }

        this.props.onGridStateChanged({
            eventType: newGridState.expandAll ? constants.GRID_STATE_CHANGE_ALL_ROWS_EXPANDED : constants.GRID_STATE_CHANGE_ALL_ROWS_COLLAPSED,
            updatedGridState: newGridState,
        });

        if (this.props.featureArea) {
            featureTracker.logEvent(
                this.props.featureArea,
                newGridState.expandAll ? 'Expand all rows' : 'Collapse all rows',
                {
                    sessionId: config.sessionId,
                }
            );
        }
    }

    handleExpandButtonClicked(rowInfo) {
        const groupId = rowInfo.groupId;
        const { gridState } = this.props;
        let eventType = constants.GRID_STATE_CHANGE_ROW_EXPANDED;
        let expandedGroupIds = _.clone(gridState.expandedGroupIds);

        if (_.includes(expandedGroupIds, groupId)) {
            expandedGroupIds = _.pull(expandedGroupIds, groupId);
            eventType = constants.GRID_STATE_CHANGE_ROW_COLLAPSED;
        } else {
            expandedGroupIds.push(groupId);
        }

        const newGridState = _.clone(gridState);
        newGridState.expandedGroupIds = expandedGroupIds;

        this.props.onGridStateChanged({
            eventType,
            rowInfo,
            updatedGridState: newGridState,
        });

        if (this.props.featureArea) {
            featureTracker.logEvent(
                this.props.featureArea,
                eventType === constants.GRID_STATE_CHANGE_ROW_EXPANDED ? 'Row expanded' : 'Row collapsed',
                {
                    sessionId: config.sessionId,
                }
            );
        }
    }

    handleGridRowSelect(evt, { rowId, rowInfo }) {
        const { gridState } = this.props;

        // Ignore the row selection if it originates from an expand button click.
        if (this.wasExpandButtonClicked(evt)) {
            return;
        }

        // Regular select
        if (!gridState.selectionEnabled) {
            return;
        }

        let selectedRowIds = _.clone(gridState.selectedRowIds);

        if (!gridState.multiSelectEnabled) {
            selectedRowIds = [];
        }

        if (!_.includes(selectedRowIds, rowId)) {
            selectedRowIds.push(rowId);
        }

        const newGridState = _.clone(gridState);
        newGridState.selectedRowIds = selectedRowIds;

        this.props.onGridStateChanged({
            eventType: constants.GRID_STATE_CHANGE_ROW_SELECTED,
            rowInfo,
            updatedGridState: newGridState,
        });

        if (this.props.featureArea) {
            featureTracker.logEvent(this.props.featureArea, 'Row selected', {
                rowId,
                sessionId: config.sessionId,
            });
        }
    }

    getExpandColDef() {
        const { gridState } = this.props;

        return {
            id: 'rpt_grid_expand_col',
            isFixed: true,
            width: 25,
            isNotSortable: true,
            header: Header,
            primaryTitle: () => {
                if (!gridState.groupingEnabled) {
                    return '';
                }
                const iconClass = gridState.expandAll ? 'toggleclose' : 'toggleopen';
                return (
                    <div className="grid">
                        <div className="grid-cell g--cross-center">
                            <Button
                                className="btn--link"
                                onTap={this.handleExpandAllToggle}
                            >
                                <Icon type={iconClass}/>
                            </Button>
                        </div>
                    </div>);
            },
            template: ({ rowInfo }) => {
                if (!rowInfo.isExpandable) {
                    return '';
                }
                return (
                    <ExpandButton
                        rowInfo={rowInfo}
                        onTap={this.handleExpandButtonClicked}
                    />);
            },
        };
    }

    render() {
        const {
            gridState,
            rows,
            width,
            height,
        } = this.props;

        if (!gridState || !rows) {
            return (
                <Notice message={Localization.getText('HTML5_NoData')}/>
            );
        }

        return (
            <ReactGrid
                width={width}
                height={height}
                cols={this.getCols(this.props)}
                rows={this.getRows(this.props)}
                onRowSelect={this.handleGridRowSelect}
            />
        );
    }
}

Grid.propTypes = {
    height: PropTypes.number.isRequired,
    width: PropTypes.number.isRequired,
    cols: PropTypes.array.isRequired,
    rows: PropTypes.array,
    gridState: PropTypes.object.isRequired,
    featureArea: PropTypes.string,
    onGridStateChanged: PropTypes.func,
};

export default bindHandlers(Grid);
