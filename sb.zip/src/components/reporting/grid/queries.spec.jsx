import _ from 'lodash';
import { getGroupedRows } from 'src/components/reporting/grid/queries';

const data =
    [
        {
            tradeDate: '2016-01-05',
            assetType: 'FX',
            bookingType: 'Commission',
            instrument: {
                uic: 1,
                description: 'EURUSD',
            },
            amount: -5,
        },
        {
            tradeDate: '2016-01-05',
            assetType: 'FX',
            bookingType: 'Commission',
            instrument: {
                uic: 1,
                description: 'EURUSD',
            },
            amount: -6,
        },
        {
            tradeDate: '2016-01-05',
            assetType: 'FX',
            bookingType: 'PL',
            instrument: {
                uic: 1,
                description: 'EURUSD',
            },
            amount: 215,
        },
        {
            tradeDate: '2016-01-06',
            assetType: 'FX',
            bookingType: 'PL',
            instrument: {
                uic: 2,
                description: 'USDJPY',
            },
            amount: 89,
        },
        {
            tradeDate: '2016-01-07',
            assetType: 'Shares',
            bookingType: 'Exchange Fee',
            instrument: {
                uic: 3,
                description: 'Google',
            },
            amount: -7,
        },
        {
            tradeDate: '2016-01-07',
            assetType: 'Shares',
            bookingType: 'Commission',
            instrument: {
                uic: 3,
                description: 'Google',
            },
            amount: -5,
        },
        {
            tradeDate: '2016-01-08',
            assetType: 'Shares',
            bookingType: 'Exchange Fee',
            instrument: {
                uic: 4,
                description: 'Apple',
            },
            amount: -9,
        },
    ];

describe('src/components/reporting/grid/queries/getGroupedRows()', () => {
    it('one level of grouping with sumByPath should return correct data', () => {
        const group1 = {
            path: 'assetType',
        };

        const rows = getGroupedRows({
            data: _.cloneDeep(data),
            groupLevels: [group1],
            sumByPath: 'amount',
        });

        const expected = [
            {
                id: 'FX',
                isExpandable: false,
                groupId: 'FX',
                data: {
                    assetType: 'FX',
                    amount: 293,
                },
            },
            {
                id: 'Shares',
                isExpandable: false,
                groupId: 'Shares',
                data: {
                    assetType: 'Shares',
                    amount: -21,
                },
            },
        ];

        expect(rows).toEqual(expected);
    });

    it('one level of grouping with no sumByPath should return correct data', () => {
        const group1 = {
            path: 'assetType',
        };

        const rows = getGroupedRows({
            data: _.cloneDeep(data),
            groupLevels: [group1],
        });

        const expected = [
            {
                id: 'FX',
                isExpandable: false,
                groupId: 'FX',
                data: {
                    assetType: 'FX',
                },
            },
            {
                id: 'Shares',
                isExpandable: false,
                groupId: 'Shares',
                data: {
                    assetType: 'Shares',
                },
            },
        ];

        expect(rows).toEqual(expected);
    });

    it('two levels of grouping with sumByPath should return correct data', () => {
        const group1 = {
            path: 'assetType',
        };

        const group2 = {
            path: 'instrument',
            getGroupKey: (dataItem) => dataItem.instrument.uic,
            getSortValue: (dataItem) => dataItem.instrument.description,
        };

        const rows = getGroupedRows({
            data,
            groupLevels: [group1, group2],
            sumByPath: 'amount',
        });

        const expected = [
            {
                id: 'FX',
                isExpandable: true,
                groupId: 'FX',
                data: {
                    assetType: 'FX',
                    amount: 293,
                },
            },
            {
                id: 'FX|#|1',
                isExpandable: false,
                groupId: 'FX',
                data: {
                    assetType: 'FX',
                    instrument: {
                        uic: 1,
                        description: 'EURUSD',
                    },
                    amount: 204,
                },
            },
            {
                id: 'FX|#|2',
                isExpandable: false,
                groupId: 'FX',
                data: {
                    assetType: 'FX',
                    instrument: {
                        uic: 2,
                        description: 'USDJPY',
                    },
                    amount: 89,
                },
            },
            {
                id: 'Shares',
                isExpandable: true,
                groupId: 'Shares',
                data: {
                    assetType: 'Shares',
                    amount: -21,
                },
            },
            {
                id: 'Shares|#|3',
                isExpandable: false,
                groupId: 'Shares',
                data: {
                    assetType: 'Shares',
                    instrument: {
                        uic: 3,
                        description: 'Google',
                    },
                    amount: -12,
                },
            },
            {
                id: 'Shares|#|4',
                isExpandable: false,
                groupId: 'Shares',
                data: {
                    assetType: 'Shares',
                    instrument: {
                        uic: 4,
                        description: 'Apple',
                    },
                    amount: -9,
                },
            },
        ];

        expect(rows).toEqual(expected);
    });

    it('two levels of grouping with no sumBy path should return correct data', () => {
        const group1 = {
            path: 'assetType',
        };

        const group2 = {
            path: 'instrument',
            getGroupKey: (dataItem) => dataItem.instrument.uic,
            getSortValue: (dataItem) => dataItem.instrument.description,
        };

        const rows = getGroupedRows({
            data,
            groupLevels: [group1, group2],
        });

        const expected = [
            {
                id: 'FX',
                isExpandable: true,
                groupId: 'FX',
                data: {
                    assetType: 'FX',
                },
            },
            {
                id: 'FX|#|1',
                isExpandable: false,
                groupId: 'FX',
                data: {
                    assetType: 'FX',
                    instrument: {
                        uic: 1,
                        description: 'EURUSD',
                    },
                },
            },
            {
                id: 'FX|#|2',
                isExpandable: false,
                groupId: 'FX',
                data: {
                    assetType: 'FX',
                    instrument: {
                        uic: 2,
                        description: 'USDJPY',
                    },
                },
            },
            {
                id: 'Shares',
                isExpandable: true,
                groupId: 'Shares',
                data: {
                    assetType: 'Shares',
                },
            },
            {
                id: 'Shares|#|3',
                isExpandable: false,
                groupId: 'Shares',
                data: {
                    assetType: 'Shares',
                    instrument: {
                        uic: 3,
                        description: 'Google',
                    },
                },
            },
            {
                id: 'Shares|#|4',
                isExpandable: false,
                groupId: 'Shares',
                data: {
                    assetType: 'Shares',
                    instrument: {
                        uic: 4,
                        description: 'Apple',
                    },
                },
            },
        ];

        expect(rows).toEqual(expected);
    });
});
