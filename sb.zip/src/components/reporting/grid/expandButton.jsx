import React from 'react';
import PropTypes from 'prop-types';
import Icon from 'src/components/icon/icon';
import Button from 'src/components/button/button';
import { bindHandlers } from 'src/utils/bindHandlers';

class ExpandButton extends React.PureComponent {

    handleOnTap() {
        this.props.onTap(this.props.rowInfo);
    }

    render() {

        const { rowInfo } = this.props;
        const iconClass = rowInfo.isExpanded ? 'toggleclose' : 'toggleopen';

        return (
            <div className="grid">
                <div className="grid-cell g--cross-center">
                    <Button className="btn--link js-expand-button"
                        onTap={this.handleOnTap}
                    >
                        <Icon type={iconClass}/>
                    </Button>
                </div>
            </div>
        );
    }
}

ExpandButton.propTypes = {
    rowInfo: PropTypes.object.isRequired,
    onTap: PropTypes.func.isRequired,
};

export default bindHandlers(ExpandButton);
