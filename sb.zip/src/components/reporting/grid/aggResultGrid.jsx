import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import Localization from 'src/localization';
import InitStatus from 'src/components/reporting/initStatus';
import ReportingGrid from 'src/components/reporting/grid/grid';
import * as reportingGridConstants from 'src/components/reporting/grid/constants';
import * as reportingGridQueries from 'src/components/reporting/grid/queries';
import { bindHandlers } from 'src/utils/bindHandlers';

const AGG_GRID_WIDTH = 450;

// holds the aggregated results of the chosen grouping keys. If the secondGroupByKeyId is set, the grid will be grouped
// to reflect the two levels (Used by Bookings and ProfitLoss).
class AggResultGrid extends React.PureComponent {

    handleOnGridStateChanged({ eventType, rowInfo, updatedGridState }) {
        const {
            componentId,
            onChangeGridState,
            onShowDetails,
        } = this.props;

        // save the updated grid state to  preserve the selection/expansion.
        onChangeGridState({
            componentId,
            gridState: updatedGridState,
        });

        if (eventType === reportingGridConstants.GRID_STATE_CHANGE_ROW_SELECTED) {
            onShowDetails({ rowInfo });
        }
    }

    getRows() {
        const {
            data,
            firstGroupByKeyId,
            secondGroupByKeyId,
            groups,
            noGroupKey,
        } = this.props;

        const hasMultipleGroups = (secondGroupByKeyId && secondGroupByKeyId !== noGroupKey);
        const groupLevels = [groups[firstGroupByKeyId].groupLevelDef];

        if (hasMultipleGroups) {
            groupLevels.push(groups[secondGroupByKeyId].groupLevelDef);
        }

        return reportingGridQueries.getGroupedRows({
            data,
            groupLevels,
            sumByPath: 'Amount',
        });
    }

    getCols() {
        return this.props.onGetCols(this.props);
    }

    render() {
        const {
            componentId,
            isLoading,
            error,
            data,
            gridState,
            parentViewport,
            width,
        } = this.props;

        if (error || isLoading) {
            return (
                <InitStatus
                    isLoading={isLoading}
                    error={Localization.getText('HTML5_Data_Load_Error')}
                />
            );
        }

        if (_.size(data) === 0) {
            return (
                <InitStatus
                    isLoading={false}
                    error={Localization.getText('HTML5_No_data_found_query')}
                />
            );
        }

        return (
            <ReportingGrid
                componentId={componentId}
                cols={this.getCols()}
                rows={this.getRows()}
                gridState={gridState}
                onGridStateChanged={this.handleOnGridStateChanged}
                height={parentViewport.height}
                width={width}
                featureArea={this.props.featureArea}
            />
        );
    }
}

AggResultGrid.propTypes = {
    componentId: PropTypes.string.isRequired,
    parentViewport: PropTypes.shape({
        width: PropTypes.number.isRequired,
        height: PropTypes.number.isRequired,
    }),

    width: PropTypes.number,
    accountInfo: PropTypes.object.isRequired,

    // objects with a key for each group. each key must hold an object with a groupLevelDef
    groups: PropTypes.object.isRequired,

    // key for the "no group" selected
    noGroupKey: PropTypes.string.isRequired,
    gridState: PropTypes.object,
    data: PropTypes.array,
    firstGroupByKeyId: PropTypes.string.isRequired,

    // can really be any object. Defined by path in groupDef.
    firstGroupByKeyVal: PropTypes.any.isRequired,

    secondGroupByKeyId: PropTypes.string,

    // can really be any object. Defined by path in groupDef.
    secondGroupByKeyVal: PropTypes.any,
    isLoading: PropTypes.bool.isRequired,
    error: PropTypes.bool,
    featureArea: PropTypes.string,
    onGetCols: PropTypes.func.isRequired,
    onShowDetails: PropTypes.func,
    onChangeGridState: PropTypes.func,
};

AggResultGrid.defaultProps = {
    width: AGG_GRID_WIDTH,
};

export default bindHandlers(AggResultGrid);
