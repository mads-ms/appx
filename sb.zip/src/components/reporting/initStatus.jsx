import React from 'react';
import PropTypes from 'prop-types';
import Loader from 'src/components/loader/loader';
import Notice from 'src/components/notice/notice';

// display a spinner or error message as appropriate
class InitStatus extends React.PureComponent {

    render() {
        const { isLoading, error } = this.props;

        if (isLoading) {
            return (
                <Loader isVisible isInstant/>
            );
        }

        if (error) {
            return (
                <Notice message={error}/>
            );
        }
        return <div/>;
    }
}

InitStatus.propTypes = {
    isLoading: PropTypes.bool.isRequired,
    error: PropTypes.string,
};

InitStatus.defaultProps = {
    error: '',
};

export default InitStatus;
