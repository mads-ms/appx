import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import { bindHandlers } from 'src/utils/bindHandlers';
import Touchable from 'src/components/touchable/touchable';
import Icon from 'src/components/icon/icon';
import * as numberFormat from 'src/numberFormat';
import Localization from 'src/localization';
import { openCloseItemProps } from './propTypes';

class OpenCloseFilterItem extends React.PureComponent {

    handleChange() {
        this.props.onTap(this.props.openCloseItem);
    }

    render() {
        const openCloseItem = this.props.openCloseItem;
        const {
            isChecked,
            key,
            sum,
        } = openCloseItem;

        const labels = {
            'ToOpen': Localization.getText('HTML5_openclose_open'),
            'ToClose': Localization.getText('HTML5_openclose_close'),
        };

        const checkboxClasses = classNames('checkbox-icon', {
            'checked': isChecked,
        });

        return (
            <Touchable onTap={this.handleChange}>
                <div className="grid grid--series">
                    <div className="grid grid--seriessm">
                        <div className="grid-cell g--fit">
                            <Icon type="tick" className={checkboxClasses}/>
                        </div>
                        <div className="grid-cell g--fit">
                            {labels[key]}
                        </div>
                    </div>
                    <div className="grid-cell">
                        <p className="t-end">{numberFormat.format(sum, 2)}</p>
                    </div>
                </div>
            </Touchable>
        );
    }
}

OpenCloseFilterItem.propTypes = {
    onTap: PropTypes.func.isRequired,
    openCloseItem: PropTypes.shape(openCloseItemProps).isRequired,
};

export default bindHandlers(OpenCloseFilterItem);
