import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import Enums from 'src/spine/enums';
import { bindHandlers } from 'src/utils/bindHandlers';
import Touchable from 'src/components/touchable/touchable';
import * as instrumentAssetTypeQueries from 'src/modules/instruments/assetType/queries';

class InstrumentIcon extends React.PureComponent {

    handleTap(event) {
        this.props.onTap(event, this.props.instrument);
    }

    getIconClass(instrument) {
        const instrumentType = Enums.InstrumentType.fromAssetTypeString(instrument.AssetType);
        const instrumentSubtype = Enums.InstrumentSubType.getSubtypeFromDisplayHint(instrument.DisplayHint);

        return (instrumentSubtype) ?
            `mkt--i${instrumentType}-${instrumentSubtype}` :
            `mkt--i${instrumentType}`;
    }

    render() {
        const { className, isBlock, isLarge, isMono, instrument, onTap } = this.props;
        const iconClass = this.getIconClass(instrument);
        const classes = classNames('instr-market mkt tst-instrument-icon', className, iconClass, {
            'mkt--lg': isLarge,
            'mkt--block': isBlock,
            'mkt--mono': isMono,
        });
        const tooltip = instrumentAssetTypeQueries.getAssetTypeName(instrument, { tooltip: true });

        let instrumentIcon = (
            <div className={classes} title={tooltip}>
                <b></b><i></i>
            </div>
        );

        if (onTap) {
            instrumentIcon = (
                <Touchable onTap={this.handleTap}>
                    {instrumentIcon}
                </Touchable>
            );
        }

        return instrumentIcon;
    }
}

InstrumentIcon.propTypes = {
    className: PropTypes.string,
    instrument: PropTypes.object.isRequired,
    isBlock: PropTypes.bool,
    isLarge: PropTypes.bool,
    isMono: PropTypes.bool,
    onTap: PropTypes.func,
};

InstrumentIcon.defaultProps = {
    isBlock: false,
    isLarge: false,
    isMono: false,
};

export default bindHandlers(InstrumentIcon);
