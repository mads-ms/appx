import React from 'react';
import { shallow } from 'enzyme';
import InstrumentIcon from 'src/components/instrument/instrumentIcon';

describe('src/components/instrument/instrumentIcon', () => {
    it('renders successfully', () => {
        const wrapper = shallow(<InstrumentIcon instrument={{ AssetType: 'StockOption' }}/>);
        expect(wrapper.hasClass('mkt')).toBe(true);
        expect(wrapper.find('i').length).toEqual(1);
        expect(wrapper.hasClass('mkt--i64')).toBe(true);
    });

    it('can render subType classNames', () => {
        const wrapper = shallow(<InstrumentIcon instrument={{ AssetType: 'FxSpot', DisplayHint: 'PreciousMetal' }}/>);
        expect(wrapper.hasClass('mkt--i1-10')).toBe(true);
    });

    it('can render in large size', () => {
        const wrapper = shallow(<InstrumentIcon instrument={{ AssetType: 'StockOption' }} isLarge/>);
        expect(wrapper.hasClass('mkt--lg')).toBe(true);
    });

    it('can render custom classNames', () => {
        const wrapper = shallow(<InstrumentIcon instrument={{ AssetType: 'StockOption' }} className="myClass"/>);
        expect(wrapper.hasClass('myClass')).toBe(true);
    });
});
