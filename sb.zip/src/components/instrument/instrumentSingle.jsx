import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import InstrumentName from 'src/components/instrument/instrumentName';
import InstrumentIcon from 'src/components/instrument/instrumentIcon';
import * as queries from 'src/modules/instruments/queries';
import config from 'src/config';

class InstrumentSingle extends React.PureComponent {

    render() {
        const { instrument, children, onIconTap } = this.props;
        const title = config.isDesktopApp ? queries.getToolTip(instrument) : null;
        const className = classNames('instr grid grid--fit-fill grid--cross-center', this.props.className);

        return (
            <div className={className} title={title}>
                <InstrumentIcon instrument={instrument} onTap={onIconTap} className="grid-cell"/>
                <InstrumentName instrument={instrument} className="grid-cell"/>
                {children}
            </div>
        );
    }
}

InstrumentSingle.propTypes = {
    instrument: PropTypes.object.isRequired,
    className: PropTypes.string,
    onIconTap: PropTypes.func,
};

export default InstrumentSingle;
