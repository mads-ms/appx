import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import * as instrumentsQueries from 'src/modules/instruments/queries';
import classNames from 'classnames';

function InstrumentCountry({ instrument, className }) {
    const countryCode = _.get(instrument, 'Exchange.CountryCode', null);
    const country = instrumentsQueries.getLocalizedCountry(countryCode);
    const classes = classNames('instr-country', className);

    return (
        <dd className={classes}>{country}</dd>
    );
}

InstrumentCountry.propTypes = {
    instrument: PropTypes.object.isRequired,
    className: PropTypes.string,
};

export default InstrumentCountry;
