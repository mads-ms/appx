import React from 'react';
import PropTypes from 'prop-types';
import config from 'src/config';
import * as instrumentsQueries from 'src/modules/instruments/queries';
import InstrumentIcon from './instrumentIcon';
import InstrumentName from './instrumentName';

class InstrumentInline extends React.PureComponent {

    render() {
        const { instrument, onIconTap } = this.props;
        const title = config.isDesktopApp ? instrumentsQueries.getToolTip(instrument) : null;

        return (
            <div className="instr grid" title={title}>
                <div className="grid-cell g--cross-center g--fit">
                    <InstrumentIcon instrument={instrument} isBlock onTap={onIconTap}/>
                </div>
                <dl className="grid-cell">
                    <InstrumentName instrument={instrument}/>
                </dl>
            </div>
        );
    }

}

InstrumentInline.propTypes = {
    instrument: PropTypes.object.isRequired,
    onIconTap: PropTypes.func,
};

export default InstrumentInline;
