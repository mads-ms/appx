import React from 'react';
import PropTypes from 'prop-types';
import * as instrumentsQueries from 'src/modules/instruments/queries';
import classNames from 'classnames';

function InstrumentSymbol({ instrument, className }) {
    const symbol = instrumentsQueries.getSymbol(instrument);
    const classes = classNames('instr-symbol', className);

    return (
        <dt className={classes}>{symbol}</dt>
    );
}

InstrumentSymbol.propTypes = {
    instrument: PropTypes.object.isRequired,
    className: PropTypes.string,
};

export default InstrumentSymbol;
