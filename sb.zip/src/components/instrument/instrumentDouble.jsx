import React from 'react';
import PropTypes from 'prop-types';
import * as instrumentsQueries from 'src/modules/instruments/queries';
import InstrumentIcon from './instrumentIcon';
import InstrumentName from './instrumentName';
import InstrumentDescription from './instrumentDescription';
import InstrumentSecondaryInfo from './instrumentSecondaryInfo';
import config from 'src/config';

class InstrumentDouble extends React.PureComponent {

    render() {
        const { instrument, altDescription, showCurrency, onIconTap, children } = this.props;
        const title = config.isDesktopApp ? instrumentsQueries.getToolTip(instrument) : null;

        return (
            <div className="instr grid" title={title}>
                <div className="grid-cell g--cross-center g--fit">
                    <InstrumentIcon instrument={instrument} isLarge onTap={onIconTap}/>
                </div>
                <dl className="grid-cell">
                    <InstrumentName instrument={instrument}>
                        {children}
                    </InstrumentName>
                    <InstrumentDescription
                        altDescription={altDescription}
                        instrument={instrument}
                        showCurrency={showCurrency}
                    >
                        <InstrumentSecondaryInfo {...this.props}/>
                    </InstrumentDescription>
                </dl>
            </div>
        );
    }

}

InstrumentDouble.propTypes = {
    instrument: PropTypes.object.isRequired,
    showCurrency: PropTypes.bool,
    altDescription: PropTypes.string,
    onIconTap: PropTypes.func,
};

export default InstrumentDouble;
