import PropTypes from 'prop-types';
import React from 'react';
import Localization from 'src/localization';
import Enums from 'src/spine/enums';
import Touchable from 'src/components/touchable/touchable';

/**
 * @deprecated Only for when you need to pass the spine instrument
 */
function InstrStrikePrice(strikePrice) {
    return strikePrice && ('@ ' + strikePrice);
}

/**
 * @deprecated Only for when you need to pass the spine instrument
 */
function InstrFxForwardSubInfo(instrument) {
    return (
        <sub>{instrument.valueDate}</sub>
    );
}

/**
 * @deprecated Only for when you need to pass the spine instrument
 */
function InstrFutureSubInfo(instrument) {
    return (
        <sub>{instrument.expiryDate}</sub>
    );
}

/**
 * @deprecated Only for when you need to pass the spine instrument
 */
function InstrOptionSubInfo(instrument) {
    return (
        <sub>
            {`${instrument.callPut} ${instrument.expiryDate} ${InstrStrikePrice(instrument.strikePrice)}`}
        </sub>
    );
}

/**
 * @deprecated Only for when you need to pass the spine instrument
 */
function InstrDigitalOptionSubInfo(instrument) {
    return (
        <sub>
            {`${instrument.typeName} ${instrument.expiryDate} ${InstrStrikePrice(instrument.barrierPrice)}`}
        </sub>
    );
}

/**
 * @deprecated Only for when you need to pass the spine instrument
 */
function InstrSubInfo(instrument) {
    if (instrument.showFxForwardSubInfo) {
        return InstrFxForwardSubInfo(instrument);
    }

    if (instrument.showOptionSubInfo) {
        return InstrOptionSubInfo(instrument);
    }

    if (instrument.showDigitalOptionSubInfo) {
        return InstrDigitalOptionSubInfo(instrument);
    }

    if (instrument.showFutureSubInfo) {
        return InstrFutureSubInfo(instrument);
    }

    return false;
}

/**
 * @deprecated Only for when you need to pass the spine instrument
 */
export function InstrName(instrument) {
    return (
        <dt className="instr-name">
            {instrument.name}
            {instrument.showSubInfoWithName && InstrSubInfo(instrument)}
        </dt>
    );
}

/**
 * @deprecated Only for when you need to pass the spine instrument
 */
function InstrCurrency(currency) {
    return ([
        <span key="instr">&bull;</span>,
        <sub key="currency">{currency}</sub>,
    ]);
}

/**
 * @deprecated Only for when you need to pass the spine instrument
 */
function InstrDesc(instrument, altDesc, isShowCurrency) {
    if (altDesc) {
        return <dd className="instr-desc">{altDesc}</dd>;
    }

    return (
        <dd className="instr-desc">
            {instrument.desc}
            {isShowCurrency && instrument.showCurrency && InstrCurrency(instrument.currency)}
        </dd>
    );
}

/**
 * @deprecated Only for when you need to pass the spine instrument
 */
export function DoubleRow({ instrument, handleTap, altDesc }) {
    return (
        <div className="instr grid">
            <Touchable onTap={handleTap}>
                <div className="grid-cell g--cross-center g--fit" title={instrument.showToolTip ? `${instrument.typeName} ${instrument.desc}` : null}>
                    <div className={`instr-market mkt mkt--lg mkt--${instrument.iconClass}`}><b></b><i></i></div>
                </div>
            </Touchable>
            <dl className="grid-cell" title={instrument.showToolTip ? `${instrument.typeName} ${instrument.desc}` : null}>
                {InstrName(instrument)}
                {InstrDesc(instrument, altDesc)}
            </dl>
        </div>
    );
}

DoubleRow.propTypes = {
    handleTap: PropTypes.func,
    instrument: PropTypes.object,
    altDesc: PropTypes.any,
};

/**
 * @deprecated Only for when you need to pass the spine instrument
 */
export function tradeButtonsTooltip(symbol, instrumentType, exchangeSymbol) {
    if (symbol && instrumentType) {
        let tooltip = `${Localization.getText('HTML5_Trade')} ${symbol}`;

        // Not to show source for Fx and CFD (excluding vanilla CFD & stock index) and Bonds
        const isAnyFx = Enums.InstrumentType.isAnyFx(instrumentType);
        const isStockIndex = Enums.InstrumentType.isStockIndex(instrumentType);
        const isNonSingleStockCfd = Enums.InstrumentType.isNonSingleStockCfd(instrumentType);
        const isBonds = Enums.InstrumentType.isBonds(instrumentType);

        const shouldHideSource = isAnyFx || !isStockIndex && isNonSingleStockCfd || isBonds;

        if (!shouldHideSource) {
            tooltip += '\n';
            tooltip += sourceTooltip(exchangeSymbol);
        }
        return tooltip;
    }
    return null;
}

/**
 * @deprecated Only for when you need to pass the spine instrument
 */
export function sourceTooltip(exchangeSymbol) {
    if (exchangeSymbol) {
        return `${Localization.getText('HTML5_Source')}: ${exchangeSymbol}`;
    }

    return null;
}
