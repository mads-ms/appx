import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import * as instrumentsQueries from 'src/modules/instruments/queries';

class InstrumentDescription extends React.PureComponent {

    render() {
        const {
            instrument,
            showCurrency,
            children,
            isBold,
            altDescription,
        } = this.props;

        const secondaryName = instrumentsQueries.getSecondaryName(instrument);
        const currencyLabel = instrumentsQueries.getCurrencyLabel(instrument);
        const classes = classNames('instr-desc', {
            't-normal': !isBold,
        });

        if (altDescription) {
            return <dd className={classes}>{altDescription}</dd>;
        }

        const currency = showCurrency && instrumentsQueries.shouldShowCurrency(instrument) && (
            <span>
                &bull;
                <sub>{currencyLabel}</sub>
            </span>
        );

        return (
            <dd className={classes}>
                {secondaryName} {currency}
                {children}
            </dd>
        );
    }
}

InstrumentDescription.propTypes = {
    instrument: PropTypes.object.isRequired,
    altDescription: PropTypes.string,
    showCurrency: PropTypes.bool,
    isBold: PropTypes.bool,
};

InstrumentDescription.defaultProps = {
    isBold: true,
};

export default InstrumentDescription;
