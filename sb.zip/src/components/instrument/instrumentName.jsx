import React from 'react';
import PropTypes from 'prop-types';
import * as instrumentsQueries from 'src/modules/instruments/queries';
import classNames from 'classnames';

class InstrumentName extends React.PureComponent {

    render() {
        const { instrument, children, className } = this.props;
        const name = instrumentsQueries.getName(instrument);
        const classes = classNames('instr-name', className);

        return (

            <dt className={classes}>
                {name}
                {children}
            </dt>
        );
    }
}

InstrumentName.propTypes = {
    instrument: PropTypes.object.isRequired,
    className: PropTypes.string,
};

export default InstrumentName;
