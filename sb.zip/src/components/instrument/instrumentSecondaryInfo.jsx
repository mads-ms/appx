import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import Enums from 'src/spine/enums';
import Localization from 'src/localization';
import * as numberFormat from 'src/numberFormat';
import DateTime from 'src/modules/dateTime';
import * as assetTypeQueries from 'src/modules/instruments/assetType/queries';
import * as instrumentQueries from 'src/modules/instruments/queries';

class InstrumentSecondaryInfo extends React.PureComponent {
    getPutCallText(putCall) {
        if (putCall === Enums.CallPut.Call) {
            return Localization.getText('HTML5_Call');
        } else if (putCall === Enums.CallPut.Put) {
            return Localization.getText('HTML5_Put');
        }
    }

    getFormattedExpiryDate(expiryDate) {
        const date = DateTime.createDate(expiryDate);
        return DateTime.formatUtcDateTime(date, { showSeconds: false });
    }

    getFormattedStrikePrice(strikePrice) {
        const { instrument } = this.props;

        if (strikePrice) {
            const instrumentFormat = instrumentQueries.getFormat(instrument);
            return numberFormat.formatStrike(strikePrice, instrumentFormat);
        }
    }

    getFormattedBarrier(barrier) {
        const { instrument } = this.props;

        if (barrier) {
            const instrumentFormat = instrumentQueries.getFormat(instrument);
            return numberFormat.formatBarrier(barrier, instrumentFormat);
        }
    }

    renderOptionInfo(optionType, expiryDate, price) {
        return <sub>{optionType} {expiryDate} @ {price}</sub>;
    }

    render() {
        const { instrument, optionData, showExpiryDateForFutures } = this.props;

        if (!instrument) {
            return null;
        }

        if (assetTypeQueries.isContractOption(instrument)) {
            const callPut = this.getPutCallText(instrument.PutCall);
            const expiryDate = this.getFormattedExpiryDate(instrument.ExpiryDate);
            const price = this.getFormattedStrikePrice(instrument.StrikePrice);

            return this.renderOptionInfo(callPut, expiryDate, price);
        }

        if (assetTypeQueries.isFxOption(instrument) && !_.isEmpty(optionData)) {
            const expiryDate = this.getFormattedExpiryDate(optionData.ExpiryDate);
            let optionType;
            let price;

            if (assetTypeQueries.isFxBinaryOption(instrument)) {
                optionType = instrumentQueries.getOptionTypeText(instrument);
                price = this.getFormattedBarrier(optionData.LowerBarrier || optionData.UpperBarrier);
            } else {
                optionType = this.getPutCallText(optionData.PutCall);
                price = this.getFormattedStrikePrice(optionData.StrikePrice);
            }

            return this.renderOptionInfo(optionType, expiryDate, price);
        }

        if (assetTypeQueries.isFuture(instrument) && showExpiryDateForFutures) {
            const expiryDate = this.getFormattedExpiryDate(instrument.ExpiryDate);

            return <sub>{expiryDate}</sub>;
        }

        return null;
    }
}

InstrumentSecondaryInfo.propTypes = {
    instrument: PropTypes.object.isRequired,
    optionData: PropTypes.object,
    showExpiryDateForFutures: PropTypes.bool,
};

InstrumentSecondaryInfo.defaultProps = {
    showExpiryDateForFutures: true,
    optionData: {},
};

export default InstrumentSecondaryInfo;
