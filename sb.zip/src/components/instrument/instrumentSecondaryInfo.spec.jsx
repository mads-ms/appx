import React from 'react';
import Enums from 'src/spine/enums';
import Localization from 'src/localization';
import { mount } from 'enzyme';
import InstrumentSecondaryInfo from 'src/components/instrument/instrumentSecondaryInfo';
import * as assetTypes from 'src/modules/instruments/assetType/assetTypes';
import DateTime from 'src/modules/dateTime';

describe('src/componenets/instrument/instrumentSecondaryInfo', () => {
    let wrapper;

    afterEach(() => {
        wrapper.unmount();
    });

    it('renders', () => {
        const instrument = { AssetType: assetTypes.CFD };
        wrapper = mount(<InstrumentSecondaryInfo instrument={instrument}/>);
        expect(wrapper.isEmptyRender()).toEqual(true);
    });

    it('renders secondary info for a future option', () => {
        const instrument = {
            AssetType: assetTypes.FUTURES_OPTION,
            ExpiryDate: DateTime.createDateTime('2017-02-01T01:01:01Z'),
            StrikePrice: 1.2,
            PutCall: Enums.CallPut.Put,
            Format: {
                StrikeDecimals: 4,
            },
        };

        wrapper = mount(<InstrumentSecondaryInfo instrument={instrument}/>);
        expect(wrapper.find('sub').text()).toEqual(`${Localization.getText('HTML5_Put')} 01-Feb-2017 01:01 GMT @ 1.2000`);
    });

    it('renders secondary info for an FX vanilla option', () => {
        const instrument = {
            AssetType: assetTypes.FX_VANILLA_OPTION,
            Format: {
                StrikeDecimals: 4,
            },
        };
        const optionData = {
            ExpiryDate: DateTime.createDateTime('2017-01-01T01:01:01Z'),
            StrikePrice: 1.1,
            PutCall: Enums.CallPut.Call,
        };

        wrapper = mount(<InstrumentSecondaryInfo
            instrument={instrument}
            optionData={optionData}
        />);
        expect(wrapper.find('sub').text()).toEqual(`${Localization.getText('HTML5_Call')} 01-Jan-2017 01:01 GMT @ 1.1000`);
    });

    it('renders secondary info for an FX one-touch option', () => {
        const instrument = {
            AssetType: assetTypes.FX_ONE_TOUCH_OPTION,
            Format: {
                StrikeDecimals: 4,
                BarrierDecimals: 2,
            },
        };
        const optionData = {
            ExpiryDate: DateTime.createDateTime('2017-01-01T01:01:01Z'),
            LowerBarrier: 1.1,
        };

        wrapper = mount(<InstrumentSecondaryInfo
            instrument={instrument}
            optionData={optionData}
        />);
        expect(wrapper.find('sub').text()).toEqual(`${Localization.getText('HTML5_OneTouch')} 01-Jan-2017 01:01 GMT @ 1.10`);
    });

    it('renders secondary info for an FX no-touch option', () => {
        const instrument = {
            AssetType: assetTypes.FX_NO_TOUCH_OPTION,
            Format: {
                StrikeDecimals: 4,
                BarrierDecimals: 3,
            },
        };
        const optionData = {
            ExpiryDate: DateTime.createDateTime('2017-01-01T01:01:01Z'),
            LowerBarrier: 1.1,
        };

        wrapper = mount(<InstrumentSecondaryInfo
            instrument={instrument}
            optionData={optionData}
        />);
        expect(wrapper.find('sub').text()).toEqual(`${Localization.getText('HTML5_NoTouch')} 01-Jan-2017 01:01 GMT @ 1.100`);
    });

    it('renders secondary info for a future', () => {
        const instrument = {
            AssetType: assetTypes.CONTRACT_FUTURES,
            ExpiryDate: DateTime.createDateTime('2017-01-01T01:01:01Z'),
        };

        wrapper = mount(<InstrumentSecondaryInfo instrument={instrument}/>);
        expect(wrapper.find('sub').text()).toEqual('01-Jan-2017 01:01 GMT');
    });
});
