import React from 'react';
import Localization from 'src/localization';

export default function Splash() {
    return (
        <section id="splash" className="splash">
            <div className="js-boot splash-boot grid grid--grail">
                <div className="grid-cell">
                    <div className="js-brand splash-brand grid grid--grail">
                        <div className="logo logo--splash"></div>
                    </div>
                    <div className="js-load load load--lg" data-loading={Localization.getText('HTML5_Loading')}></div>
                </div>
            </div>
            <div className="splash-screens-wrapper grid grid--grail">
                <div className="js-screens splash-screens grid-cell"></div>
            </div>
        </section>);
}
