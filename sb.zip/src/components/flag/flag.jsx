import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';

const SIZE_MAP = {
    'small': 'sm',
    'normal': '',
    'large': 'lg',
    'extra-large': 'xlg',
};

const Flag = ({ countryIsoCode, size, className }) => {
    const countryCode = _.lowerCase(countryIsoCode);
    const classes = ['flag', `flag--${countryCode}`, className];
    if (size !== 'normal') {
        classes.push('flag--' + SIZE_MAP[size]);
    }

    return <i className={classNames(classes)}/>;
};

Flag.propTypes = {
    countryIsoCode: PropTypes.string.isRequired,
    size: PropTypes.oneOf(_.keys(SIZE_MAP)),
    className: PropTypes.string,
};

Flag.defaultProps = {
    size: 'normal',
};

export default Flag;
