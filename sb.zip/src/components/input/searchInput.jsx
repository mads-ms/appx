import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import Icon from 'src/components/icon/icon';
import Touchable from 'src/components/touchable/touchable';
import Localization from 'src/localization';
import { bindHandlers } from 'src/utils/bindHandlers';
import classNames from 'classnames';

// Delayed time between keyup search
const SEARCH_DEBOUNCE_TIME_MS = 1000;

class SearchInput extends React.PureComponent {

    constructor(props) {
        super(props);

        this.debouncedSearchInput = _.debounce((value) => {
            this.props.onRequest(value);
        }, SEARCH_DEBOUNCE_TIME_MS);
    }

    handleChange(e) {
        const { value } = e.currentTarget;

        if (value.length >= this.props.searchMinChars || !value) {
            this.debouncedSearchInput(value);
        }

        this.props.onChange(value);
    }

    handleClear() {
        this.debouncedSearchInput.cancel();
        this.props.onChange('');
        this.props.onRequest('');
    }

    get isActivated() {
        if (!this.props.value) {
            return false;
        }
        return this.props.value.length >= this.props.searchMinChars;
    }

    render() {
        return (
            <div className={classNames('search', this.props.className)}>
                <Touchable onTap={this.handleClear}>
                    <Icon type="clear-search" className={this.isActivated ? 'is-activated' : null}/>
                </Touchable>
                <input
                    type="search"
                    value={this.props.value}
                    onChange={this.handleChange}
                    className="form-control"
                    autoComplete="off"
                    autoCorrect="off"
                    autoCapitalize="off"
                    spellCheck="false"
                    placeholder={Localization.getText('HTML5_Search')}/>
                <Icon type="search"/>
            </div>
        );
    }

}

SearchInput.propTypes = {
    value: PropTypes.string,
    searchMinChars: PropTypes.number,
    className: PropTypes.string,

    // Callbacks
    onChange: PropTypes.func,
    onRequest: PropTypes.func,
};

SearchInput.defaultProps = {
    value: '',
    searchMinChars: 3,

    // Callbacks
    onChange: _.noop,
    onRequest: _.noop,
};

export default bindHandlers(SearchInput);
