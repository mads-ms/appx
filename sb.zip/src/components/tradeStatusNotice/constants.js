export const TRADE_COMPLETE_NOTICE_DURATION = 3000;

export const TRANSITION_ENTER = {
    duration: 500,
    easing: 'easeInQuint',
    animation: {
        opacity: 1,
    },
    style: {
        opacity: 0,
    },
};

export const TRANSITION_LEAVE = {
    duration: 500,
    easing: 'easeOutQuint',
    animation: {
        opacity: 0,
    },
    style: {
        opacity: 1,
    },
};
