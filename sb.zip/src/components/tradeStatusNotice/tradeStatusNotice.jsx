import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { bindHandlers } from 'src/utils/bindHandlers';
import { VelocityTransitionGroup } from 'velocity-react';
import Notice from 'src/components/notice/notice';
import * as statusTypes from 'src/modules/tradeModel/status/statusTypes';
import * as constants from './constants';

class TradeStatusNotice extends React.PureComponent {
    constructor(props) {
        super(props);

        const { status, isEnabled } = props;
        const isVisible = this.isStatusShown(status) && isEnabled;

        // Explicit binding to ensure it is bound if the timer is immediately set.
        this.handleTradeCompleteTimeout = this.handleTradeCompleteTimeout.bind(this);
        this.tradeCompleteTimeout = null;
        this.state = { isVisible };

        // Set the trade complete timeout if the notice is immediately visible.
        if (isVisible && this.isTradeComplete(status)) {
            this.startTradeCompleteTimeout();
        }
    }

    componentWillReceiveProps(nextProps) {
        const { status, statusInfo } = this.props;
        const { isVisible } = this.state;

        if (this.isStatusShown(nextProps.status)) {
            if (nextProps.isEnabled) {
                if (!isVisible) {
                    this.setState({
                        isVisible: true,
                    });
                }

                // Set the trade complete timeout if the notice becomes visible and reset it if the notice
                // is already visible but the displayed status or info changes.
                if (this.isTradeComplete(nextProps.status) &&
                    (!isVisible || status !== nextProps.status || statusInfo !== nextProps.statusInfo)) {
                    this.startTradeCompleteTimeout();
                }
            }
        } else if (isVisible) {
            // Only hide the status notice if it is visible and changes to a status that should
            // no longer be shown (ignore it becoming disabled - we will handle a timeout or user
            // interaction in this case).
            this.setState({
                isVisible: false,
            });

            clearTimeout(this.tradeCompleteTimeout);
            this.tradeCompleteTimeout = null;
        }
    }

    componentWillUnmount() {
        clearTimeout(this.tradeCompleteTimeout);
        this.tradeCompleteTimeout = null;
    }

    handleNoticeTap() {
        const { status, onClose } = this.props;

        if (status === statusTypes.WAITING) {
            return;
        }

        clearTimeout(this.tradeCompleteTimeout);
        this.tradeCompleteTimeout = null;

        onClose();
    }

    handleTradeCompleteTimeout() {
        const { onClose } = this.props;

        this.tradeCompleteTimeout = null;

        onClose();
    }

    startTradeCompleteTimeout() {
        clearTimeout(this.tradeCompleteTimeout);
        this.tradeCompleteTimeout = setTimeout(this.handleTradeCompleteTimeout, constants.TRADE_COMPLETE_NOTICE_DURATION);
    }

    isStatusShown(status) {
        return status && status !== statusTypes.READY;
    }

    isTradeComplete(status) {
        return status === statusTypes.SUCCESS || status === statusTypes.ERROR;
    }

    render() {
        const { status, statusInfo, isAstroStyle, isCompact } = this.props;
        const { isVisible } = this.state;
        let statusNotice;

        if (isVisible) {
            let iconClassName;

            if (status === statusTypes.SUCCESS) {
                iconClassName = 'icon--checkmark';
            } else if (status === statusTypes.WAITING) {
                iconClassName = 'none';
            }

            statusNotice = (
                <Notice
                    message={statusInfo}
                    iconClassName={iconClassName}
                    onTap={this.handleNoticeTap}
                    isAstroStyle={isAstroStyle}
                    isCompact={isCompact}
                    isCover
                    isMask
                />
            );
        }

        return (
            <VelocityTransitionGroup
                enter={constants.TRANSITION_ENTER}
                leave={constants.TRANSITION_LEAVE}
                component="div"
            >
                {statusNotice}
            </VelocityTransitionGroup>
        );
    }
}

TradeStatusNotice.propTypes = {
    status: PropTypes.string,
    statusInfo: PropTypes.oneOfType([PropTypes.string, PropTypes.array]),
    isEnabled: PropTypes.bool,
    isAstroStyle: PropTypes.bool,
    isCompact: PropTypes.bool,
    onClose: PropTypes.func,
};

TradeStatusNotice.defaultProps = {
    statusInfo: '',
    isEnabled: true,
    isAstroStyle: false,
    isCompact: false,
    onClose: _.noop,
};

export default bindHandlers(TradeStatusNotice);
