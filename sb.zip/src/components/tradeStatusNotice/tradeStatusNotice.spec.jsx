import React from 'react';
import { shallow } from 'enzyme';
import * as statusTypes from 'src/modules/tradeModel/status/statusTypes';
import * as constants from './constants';
import TradeStatusNotice from './tradeStatusNotice';

describe('src/components/tradeStatusNotice/tradeStatusNotice', () => {

    let onClose;
    let status;
    let statusInfo;
    let isEnabled;
    let notice;

    beforeEach(() => {
        jasmine.clock().install();

        onClose = jasmine.createSpy('onClose');
        status = statusTypes.READY;
        statusInfo = null;
        isEnabled = true;

        notice = shallow(
            <TradeStatusNotice
                status={status}
                statusInfo={statusInfo}
                isEnabled={isEnabled}
                onClose={onClose}
            />
        );
    });

    afterEach(() => {
        jasmine.clock().uninstall();
    });

    it('calls on close when the notice is tapped when ready', () => {
        notice.instance().handleNoticeTap();

        expect(onClose).toHaveBeenCalledTimes(1);
    });

    it('calls on close when the notice is tapped when success', () => {
        notice.setProps({ status: statusTypes.SUCCESS });
        notice.instance().handleNoticeTap();

        expect(onClose).toHaveBeenCalledTimes(1);
    });

    it('calls on close when the notice is tapped when error', () => {
        notice.setProps({ status: statusTypes.ERROR });
        notice.instance().handleNoticeTap();

        expect(onClose).toHaveBeenCalledTimes(1);
    });

    it('does not call on close when the notice is tapped when waiting', () => {
        notice.setProps({ status: statusTypes.WAITING });
        notice.instance().handleNoticeTap();

        expect(onClose).not.toHaveBeenCalled();
    });

    it('calls on close after the timeout when the status changes to success', () => {
        notice.setProps({ status: statusTypes.SUCCESS });
        jasmine.clock().tick(constants.TRADE_COMPLETE_NOTICE_DURATION);

        expect(onClose).toHaveBeenCalledTimes(1);
    });

    it('calls on close after the timeout when the status changes to error', () => {
        notice.setProps({ status: statusTypes.ERROR });
        jasmine.clock().tick(constants.TRADE_COMPLETE_NOTICE_DURATION);

        expect(onClose).toHaveBeenCalledTimes(1);
    });

    it('does not call on close after a timeout when the status changes to waiting', () => {
        notice.setProps({ status: statusTypes.WAITING });
        jasmine.clock().tick(constants.TRADE_COMPLETE_NOTICE_DURATION);

        expect(onClose).not.toHaveBeenCalled();
    });

    it('calls on close after the timeout when the status changes to success after becoming disabled', () => {
        notice.setProps({ status: statusTypes.SUCCESS });
        notice.setProps({ isEnabled: false });
        jasmine.clock().tick(constants.TRADE_COMPLETE_NOTICE_DURATION);

        expect(onClose).toHaveBeenCalledTimes(1);
    });

    it('calls on close after the timeout when the status changes to error after becoming disabled', () => {
        notice.setProps({ status: statusTypes.ERROR });
        notice.setProps({ isEnabled: false });
        jasmine.clock().tick(constants.TRADE_COMPLETE_NOTICE_DURATION);

        expect(onClose).toHaveBeenCalledTimes(1);
    });

    it('does not call on close after a timeout when the status changes to waiting after becoming disabled', () => {
        notice.setProps({ status: statusTypes.WAITING });
        notice.setProps({ isEnabled: false });
        jasmine.clock().tick(constants.TRADE_COMPLETE_NOTICE_DURATION);

        expect(onClose).not.toHaveBeenCalled();
    });

    it('calls on close after the reset timeout when the status info changes while a success', () => {
        notice.setProps({ status: statusTypes.SUCCESS });
        jasmine.clock().tick(constants.TRADE_COMPLETE_NOTICE_DURATION - 1);
        notice.setProps({ statusInfo: 'Success!' });
        jasmine.clock().tick(constants.TRADE_COMPLETE_NOTICE_DURATION - 1);

        expect(onClose).not.toHaveBeenCalled();

        jasmine.clock().tick(1);

        expect(onClose).toHaveBeenCalledTimes(1);
    });

    it('calls on close after the reset timeout when the status info changes while an error', () => {
        notice.setProps({ status: statusTypes.ERROR });
        jasmine.clock().tick(constants.TRADE_COMPLETE_NOTICE_DURATION - 1);
        notice.setProps({ statusInfo: 'Failure!' });
        jasmine.clock().tick(constants.TRADE_COMPLETE_NOTICE_DURATION - 1);

        expect(onClose).not.toHaveBeenCalled();

        jasmine.clock().tick(1);

        expect(onClose).toHaveBeenCalledTimes(1);
    });

    it('calls on close after the timeout when the status changes from waiting to success', () => {
        notice.setProps({ status: statusTypes.WAITING });
        notice.setProps({ status: statusTypes.SUCCESS });

        jasmine.clock().tick(constants.TRADE_COMPLETE_NOTICE_DURATION);

        expect(onClose).toHaveBeenCalledTimes(1);
    });

    it('calls on close after the timeout when the status changes from waiting to error', () => {
        notice.setProps({ status: statusTypes.WAITING });
        notice.setProps({ status: statusTypes.ERROR });

        jasmine.clock().tick(constants.TRADE_COMPLETE_NOTICE_DURATION);

        expect(onClose).toHaveBeenCalledTimes(1);
    });

    it('calls on close after the timeout when the notice is mounted while a success', () => {
        status = statusTypes.SUCCESS;
        notice = shallow(
            <TradeStatusNotice
                status={status}
                statusInfo={statusInfo}
                isEnabled={isEnabled}
                onClose={onClose}
            />
        );

        jasmine.clock().tick(constants.TRADE_COMPLETE_NOTICE_DURATION);

        expect(onClose).toHaveBeenCalledTimes(1);
    });

    it('calls on close after the timeout when the notice is mounted while an error', () => {
        status = statusTypes.ERROR;
        notice = shallow(
            <TradeStatusNotice
                status={status}
                statusInfo={statusInfo}
                isEnabled={isEnabled}
                onClose={onClose}
            />
        );

        jasmine.clock().tick(constants.TRADE_COMPLETE_NOTICE_DURATION);

        expect(onClose).toHaveBeenCalledTimes(1);
    });

    it('does not call on close after the timeout when the notice is mounted while waiting', () => {
        status = statusTypes.WAITING;
        notice = shallow(
            <TradeStatusNotice
                status={status}
                statusInfo={statusInfo}
                isEnabled={isEnabled}
                onClose={onClose}
            />
        );

        jasmine.clock().tick(constants.TRADE_COMPLETE_NOTICE_DURATION);

        expect(onClose).not.toHaveBeenCalled();
    });
});
