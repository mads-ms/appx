import PropTypes from 'prop-types';
import React from 'react';
import _ from 'lodash';
import classNames from 'classnames';
import { bindHandlers } from 'src/utils/bindHandlers';
import Icon from 'src/components/icon/icon';
import Button from 'src/components/button/button';

class MenuButton extends React.Component {
    handleTap(event) {
        event.preventDefault();
        this.props.onTap(event.target);
    }

    render() {
        const { className } = this.props;
        const buttonClassName = classNames(
            'btn--inline btn--clear btn--compact btn--toggled tst-btn-toggled',
            className
        );
        return (
            <Button onTap={this.handleTap} className={buttonClassName}>
                <Icon type="menu-sm"/>
            </Button>
        );
    }
}

MenuButton.propTypes = {
    className: PropTypes.string,
    onTap: PropTypes.func,
};

MenuButton.defaultProps = {
    onTap: _.noop,
};

export default bindHandlers(MenuButton);
