/**
 * The <SwipeMenu/> Component is internal to <ReactGrid> and should not be
 * accessed directly. It supervises a single Row within the ScrollView which
 * is used to show actions relating to the Row's contents.
 *
 * It uses the legacy ActionMenuController to access the data it needs (i.e.
 * menu item labels) to render the UI, and passes on the rowID to an `onActionTap`
 * callback to allow <ReactGrid> consumers to dispatch actions in response to
 * user input.
 */
import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import Pannable from 'src/components/touchable/pannable';
import SwipeMenuItem from './swipeMenuItem';
import { bindHandlers } from 'src/utils/bindHandlers';
import Hammer from 'hammerjs';
import * as actionMenuActions from 'src/components/contextMenu/actionMenuActions';
import * as menuUtils from 'src/components/contextMenu/utils';

// the maximum number of actions to display
const MAX_ACTIONS = 3;
const MIN_CLOSE_DISTANCE = 50;

class SwipeMenu extends React.Component {

    constructor(props) {
        super(props);

        this.node = null;
    }

    componentWillMount() {
        this.addPressOutsideListener();
    }

    componentWillUnmount() {
        this.removePressOutListener();
    }

    handleRef(ref) {
        this.node = ref;
    }

    handlePressOutside(evt) {
        if (!this.node.contains(evt.srcEvent.target)) {
            this.props.onHide();
        }
    }

    addPressOutsideListener() {
        this.removePressOutListener();

        this.windowListener = new Hammer.Manager(window);
        this.windowListener.add(new Hammer.Press({ time: 0 }));
        this.windowListener.on('press', this.handlePressOutside);
    }

    removePressOutListener() {
        if (this.windowListener) {
            this.windowListener.destroy();
            this.windowListener = null;
        }
    }

    handleButtonAction(action) {
        if (action.id === actionMenuActions.ACTION_SHOW_MORE.id) {
            this.props.onShowMore();
        }
        this.props.onHide();
    }

    handlePan() {
        this.props.onHide();
    }

    render() {
        const {
            featureArea,
            width,
            height,
        } = this.props;

        const actionsData = menuUtils.getActionsData(this.props) || {};
        const menuItems = menuUtils.getMenuItems(this.props);
        let allowedMenuItems = menuUtils.filterMenuItems(menuItems, actionsData);

        if (_.isEmpty(allowedMenuItems)) {
            return false;
        }

        if (allowedMenuItems.length > MAX_ACTIONS) {
            allowedMenuItems = _.concat(allowedMenuItems.slice(0, MAX_ACTIONS - 1), <SwipeMenuItem action={actionMenuActions.ACTION_SHOW_MORE}/>);
        }

        const style = {
            position: 'absolute',
            top: 0,
            width,
            height,
        };

        return (
            <Pannable
                directionSupport="right"
                threshold={MIN_CLOSE_DISTANCE}
                onPan={this.handlePan}
            >
                <div ref={this.handleRef} className="tst-swipe-menu swipemenu grid grid--seriesxs" style={style}>
                    {_.map(allowedMenuItems, (menuItem) => React.cloneElement(menuItem, {
                        key: menuItem.props.action.id,
                        actionData: actionsData,
                        onAction: this.handleButtonAction,
                        featureArea,
                    })
                    )}
                </div>
            </Pannable>
        );
    }
}

SwipeMenu.propTypes = {
    actionsData: PropTypes.object,
    onGetActionsData: PropTypes.func,
    featureArea: PropTypes.string,
    width: PropTypes.number,
    height: PropTypes.number,
    onHide: PropTypes.func,
    onShowMore: PropTypes.func,
};

SwipeMenu.defaultProps = {
    onHide: _.noop,
    onShowMore: _.noop,
};

export default bindHandlers(SwipeMenu);
