import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import { bindHandlers } from 'src/utils/bindHandlers';
import * as featureTracker from 'src/featureTracker';
import Button from 'src/components/button/button';
import makeCancelable from 'src/utils/promiseCancelable';

class SwipeMenuItem extends React.PureComponent {

    constructor(props) {
        super(props);

        this.loadActionPromise = null;
    }

    componentWillUnmount() {
        if (this.loadActionPromise) {
            this.loadActionPromise.cancel();
        }
    }

    handleTap(event) {
        const { action, actionData } = this.props;

        event.stopPropagation();

        if (this.loadActionPromise) {
            this.loadActionPromise.cancel();
        }

        if (action.loadAction) {
            this.loadActionPromise = makeCancelable(action.loadAction(actionData));
            this.loadActionPromise.promise
                .then((controller) => {
                    this.performAction(controller);
                });
        } else {
            this.performAction();
        }
    }

    performAction(controller) {
        const { action, actionData, onAction, featureArea } = this.props;
        action.performAction(actionData, controller);
        onAction(action, actionData);

        if (featureArea) {
            featureTracker.logEvent(this.featureArea, 'Swipe Menu - ' + action.id);
        }
    }

    render() {
        const { action: { label, shortLabel } } = this.props;

        return (
            <Button className="btn--noround btn--compact grid-cell" onTap={this.handleTap}>
                {shortLabel || label}
            </Button>
        );
    }
}

SwipeMenuItem.propTypes = {
    isEnabled: PropTypes.bool,
    action: PropTypes.shape({
        id: PropTypes.string.isRequired,
        label: PropTypes.string.isRequired,
        shortLabel: PropTypes.string,
        loadAction: PropTypes.func,
        performAction: PropTypes.func,
    }).isRequired,
    actionData: PropTypes.object,
    featureArea: PropTypes.string,
    onAction: PropTypes.func,
};

SwipeMenuItem.defaultProps = {
    isEnabled: true,
    onAction: _.noop,
};

export default bindHandlers(SwipeMenuItem);
