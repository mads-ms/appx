import React from 'react';
import BaseWindowFrame from 'window-frame';
import Localization from 'src/localization';
import proShellCommunication from 'src/proShellCommunication';

function WindowFrame(props) {
    const { children } = props;
    const titleClose = Localization.getText('HTML5_WindowFrame_Close');
    const titleDock = Localization.getText('HTML5_WindowFrame_Dock');
    const titleMaximize = Localization.getText('HTML5_WindowFrame_Maximize');
    const titleMinimize = Localization.getText('HTML5_WindowFrame_Minimize');
    const titleRestoreDown = Localization.getText('HTML5_WindowFrame_RestoreDown');
    const isTrafficLightsEnabled = proShellCommunication.capability('trafficLights', false);
    return (
        <BaseWindowFrame
            {...props}
            titleClose={titleClose}
            titleDock={titleDock}
            titleMaximize={titleMaximize}
            titleMinimize={titleMinimize}
            titleRestoreDown={titleRestoreDown}
            isTrafficLightsEnabled={isTrafficLightsEnabled}
        >
            {children}
        </BaseWindowFrame>
    );
}

export default WindowFrame;
