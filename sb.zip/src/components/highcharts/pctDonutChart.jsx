import React from 'react';
import PropTypes from 'prop-types';
import Highchart from 'src/components/highcharts/highchart';

const DONUTCHART_MIN_HEIGHT = 160;
const DONUTCHART_MIN_WIDTH = 160;
const DONUTCHART_VALUE_CLASS = 'pctdonutchart-value';
const DONUTCHART_REMAINING_CLASS = 'pctdonutchart-remaining';

/**
 *  Simple red/green donut chart showing a percentage. Used by perf overview etc.
 */
export default class PctDonutChart extends React.PureComponent {

    getHighchartsDataSeries() {
        return [{
            y: this.props.pctAsInt,
            className: DONUTCHART_VALUE_CLASS,
        }, {
            y: (100 - this.props.pctAsInt),
            className: DONUTCHART_REMAINING_CLASS,
        }];
    }

    getHtmlTitle() {
        const { title, pctAsInt } = this.props;

        return (
            `<div class="grid grid--y">
                <div class="grid-cell g--cross-center">
                    <p class="t-center t-large">${title}</p>
                </div>
                <div class="grid-cell">
                    <p class="t-center t-xxlarge">${pctAsInt}%</p>
                </div>
            </div>`
        );
    }

    render() {
        const config = {
            chart: {
                type: 'pie',
                height: DONUTCHART_MIN_HEIGHT,
                width: DONUTCHART_MIN_WIDTH,
                spacingTop: 0,
                spacingRight: 0,
                spacingLeft: 0,
                className: this.props.className,
            },
            plotOptions: {
                pie: {
                    shadow: false,
                    dataLabels: {
                        enabled: false,
                    },
                    showInLegend: true,
                },
                series: {
                    states: {
                        hover: {
                            enabled: false,
                        },
                    },
                },
            },
            tooltip: {
                enabled: false,
            },
            title: {
                verticalAlign: 'middle',
                height: 50,
                useHTML: true,
                text: this.getHtmlTitle(),
            },
            exporting: {
                enabled: false,
            },
            credits: {
                enabled: false,
            },
            legend: {
                enabled: false,
            },
            series: [{
                data: this.getHighchartsDataSeries(),
                innerSize: '75%',
                size: '100%',
                borderWidth: 0,
            }],
        };

        return (
            <Highchart config={config}/>
        );
    }
}

PctDonutChart.propTypes = {
    pctAsInt: PropTypes.number.isRequired,
    title: PropTypes.string,
    className: PropTypes.string,
};

PctDonutChart.defaultProps = {
    className: 'pctdonutchart',
};
