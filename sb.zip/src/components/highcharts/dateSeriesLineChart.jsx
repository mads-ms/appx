import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import Highchart from 'src/components/highcharts/highchart';
import DateTime from 'src/modules/dateTime';
import * as formatters from './formatters';

/**
 *  Red/green line(area) chart component. Positive values are shown with a green gradient and negative with a red
 *  Used by perf overview etc.
 */
export default class DateSeriesLineChart extends React.PureComponent {

    getHighchartsDataSeries() {
        return _.map(this.props.data, (series) => {
            const dataPoints = _.map(series.values, (value) => ({
                x: DateTime.createDate(value.x).valueOf(), // Convert from OApi string to unix timestamp
                y: value.y,
            }));

            return {
                name: series.name,
                className: this.props.className,
                data: dataPoints,
                threshold: 0,
                type: 'area',
                negativeColor: true,
            };
        });
    }

    getConfig() {
        const {
            height,
            valueFormatter,
            tooltipFormatter,
        } = this.props;

        return {
            chart: {
                type: 'area',
                height,
                spacingTop: 20,
                spacingRight: 0,
                className: this.props.className,
            },
            credits: {
                enabled: false,
            },
            title: {
                text: '',
            },
            series: this.getHighchartsDataSeries(),
            legend: {
                enabled: false,
            },
            exporting: {
                enabled: false,
            },
            xAxis: [{
                type: 'datetime',
                title: null,
                maxPadding: 0.03,
                tickPixelInterval: 100,
                labels: {
                    formatter: valueFormatter,
                },
            }],
            yAxis: {
                title: {
                    text: null,
                },
            },
            defs: {
                'linechart-neg-gradient': {
                    tagName: 'linearGradient',
                    id: 'linechart-neg-gradient',
                    x1: 0,
                    y1: 1,
                    x2: 0,
                    y2: 0,
                    children: [{
                        tagName: 'stop',
                        offset: 0,
                    }, {
                        tagName: 'stop',
                        offset: 1,
                    }],
                },
                'linechart-gradient': {
                    tagName: 'linearGradient',
                    id: 'linechart-gradient',
                    x1: 0,
                    y1: 1,
                    x2: 0,
                    y2: 0,
                    children: [{
                        tagName: 'stop',
                        offset: 0,
                    }, {
                        tagName: 'stop',
                        offset: 1,
                    }],
                },
            },
            plotOptions: {
                series: {
                    stacking: 'normal',
                },
            },
            tooltip: {
                formatter() {
                    return tooltipFormatter(this.key, this.x, this.y, this.series);
                },
            },
        };
    }

    render() {
        return (
            <Highchart
                config={this.getConfig()}
                resizeTimestamp={this.props.resizeTimestamp}
            />
        );
    }
}

DateSeriesLineChart.propTypes = {
    resizeTimestamp: PropTypes.number.isRequired,
    height: PropTypes.number.isRequired,
    valueFormatter: PropTypes.func,
    tooltipFormatter: PropTypes.func,
    data: PropTypes.arrayOf(
        PropTypes.shape({
            name: PropTypes.string.isRequired, // Name of the data series
            values: PropTypes.arrayOf(
                PropTypes.shape(
                    {
                        x: PropTypes.string.isRequired, // Date string in OApi format
                        y: PropTypes.number.isRequired, // Value
                    })),
        })
    ).isRequired,
    className: PropTypes.string,
};

DateSeriesLineChart.defaultProps = {
    valueFormatter: formatters.defaultDateFormatter,
    tooltipFormatter: formatters.defaultTooltipDateFormatter,
    className: 'linechart',
};
