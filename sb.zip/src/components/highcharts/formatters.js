import * as numberFormat from 'src/numberFormat';
import DateTime from 'src/modules/dateTime';

export function defaultValueFormatter(value) {
    return numberFormat.format(value, 0);
}

export function defaultTooltipFormatter(key, y) {
    return `<b>${key}</b><br/>${numberFormat.format(y, 2)}`;
}

export function pctInParensValueFormatter(value, total) {
    return `${numberFormat.format(value, 0)} (${numberFormat.formatPercentageRatio(value / total, 0)})`;
}

export function pctInParensTooltipFormatter(key, y, total) {
    return `<b>${key}</b><br/>${numberFormat.format(y, 2)} (${numberFormat.formatPercentageRatio(y / total, 0)})`;
}

export function defaultDateFormatter() {
    return DateTime.formatUserDate(this.value);
}

export function defaultTooltipDateFormatter(key, x, y, series) {
    const formattedDateTime = DateTime.formatUserDate(x);
    return `<b>${series.name}</b><br/>${formattedDateTime}<br/>${numberFormat.format(y, 2)}`;
}
