import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import Highchart from './highchart';
import * as formatters from './formatters';

/**
 * Horizontal bar chart component showing positive bars in green and negative in red. Used by perfOverview, portfolio etc.
 *
 */
export default class BarChart extends React.PureComponent {

    getConfig() {
        const {
            data,
            height,
            width,
            valueFormatter,
            tooltipFormatter,
            onBarClick,
            enableAnimation,
            className,
            gradient,
            negGradient,
        } = this.props;

        const categories = _.map(data, 'name');
        const values = _.map(data, 'value');
        const total = _.sum(values);

        return {
            chart: {
                type: 'bar',
                height,
                width,
                spacingTop: 20,
                spacingRight: 10,
                className,
            },
            credits: {
                enabled: false,
            },
            title: {
                text: '',
            },
            series: [{
                data: values,
                cursor: 'pointer',
                point: {
                    events: {
                        click() {
                            onBarClick(this.category);
                        },
                    },
                },
            }],
            defs: {
                'barchart-gradient': {
                    tagName: 'linearGradient',
                    id: gradient,
                    x1: 0,
                    y1: 1,
                    x2: 0,
                    y2: 0,
                    children: [{
                        tagName: 'stop',
                        offset: 0,
                    }, {
                        tagName: 'stop',
                        offset: 1,
                    }],
                },
                'barchart-neg-gradient': {
                    tagName: 'linearGradient',
                    id: negGradient,
                    x1: 0,
                    y1: 1,
                    x2: 0,
                    y2: 0,
                    children: [{
                        tagName: 'stop',
                        offset: 0,
                    }, {
                        tagName: 'stop',
                        offset: 1,
                    }],
                },
            },
            legend: {
                enabled: false,
            },
            exporting: {
                enabled: false,
            },
            xAxis: [{
                categories,
                labels: {
                    step: 1,
                },
            }, {
                opposite: true,
                categories: values,
                linkedTo: 0,
                labels: {
                    step: 1,
                    formatter() {
                        return valueFormatter(this.value, total);
                    },
                },
            }],
            yAxis: {
                title: {
                    text: null,
                },
            },
            plotOptions: {
                series: {
                    stacking: 'normal',
                    animation: enableAnimation,
                },
                bar: {
                    borderWidth: 0,
                    zones: [
                        {
                            value: 0,
                        },
                    ],
                },
            },
            tooltip: {
                formatter() {
                    return tooltipFormatter(this.key, this.y, total);
                },
            },
        };
    }

    render() {
        return (
            <Highchart
                config={this.getConfig()}
                resizeTimestamp={this.props.resizeTimestamp}
            />
        );
    }
}

BarChart.propTypes = {
    resizeTimestamp: PropTypes.number.isRequired,
    valueFormatter: PropTypes.func,
    tooltipFormatter: PropTypes.func,
    onBarClick: PropTypes.func,
    data: PropTypes.arrayOf(
        PropTypes.shape({
            name: PropTypes.string.isRequired,
            value: PropTypes.number.isRequired,
        })
    ).isRequired,
    enableAnimation: PropTypes.bool,
    className: PropTypes.string,
    gradient: PropTypes.string,
    negGradient: PropTypes.string,

    // highcharts requires an explicit height, width auto-adjusts unless an explicit
    // width is passed. (For pop-ups it is necessary to pass a width)
    height: PropTypes.number.isRequired,
    width: PropTypes.number,
};

BarChart.defaultProps = {
    valueFormatter: formatters.defaultValueFormatter,
    tooltipFormatter: formatters.defaultTooltipFormatter,
    enableAnimation: true,
    onBarClick: _.noop,
    className: 'barchart',
    gradient: 'barchart-gradient',
    negGradient: 'barchart-neg-gradient',
};
