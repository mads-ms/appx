/**
 * Provides a react wrapper for highcharts
 * This is using the styled version to allow for CSS only styling
 */
import React from 'react';
import PropTypes from 'prop-types';
import Highcharts from 'highcharts/js/highcharts';
import _ from 'lodash';
import { UI } from 'openui';

class Highchart extends React.PureComponent {

    constructor() {
        super();
        this.setEl = (ref) => {
            this.el = ref;
        };
    }

    componentDidMount() {
        this.updateChart(this.props);
    }

    componentWillUpdate(nextProps) {
        if (this.props.config !== nextProps.config) {
            this.updateChart(nextProps);
        } else if (this.props.resizeTimestamp !== nextProps.resizeTimestamp && this.chart) {
            UI.nextTick(() => {
                this.chart.reflow();
            });
        }
    }

    componentWillUnmount() {
        if (this.chart) {
            this.chart.destroy();
        }
    }

    updateChart(props) {
        const { config } = props;
        const chartConfig = _.defaults({ renderTo: this.el }, config.chart);
        const opts = _.defaults({ chart: chartConfig }, config);

        if (this.chart) {
            this.chart.destroy();
        }
        this.chart = Highcharts.chart(opts);
    }

    render() {
        return <div ref={this.setEl}/>;
    }
}

Highchart.propTypes = {
    config: PropTypes.object.isRequired,
    resizeTimestamp: PropTypes.number,
};

export default Highchart;
