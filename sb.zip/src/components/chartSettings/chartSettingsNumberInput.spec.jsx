import React from 'react';
import { mount } from 'enzyme';
import ChartSettingsNumberInput from './chartSettingsNumberInput';

describe('src/components/chartSettings/chartSettingsNumberInput', () => {

    let wrapper;

    afterEach(() => {
        wrapper.unmount();
    });

    it('renders number input successfully', () => {
        wrapper = mount(
            <ChartSettingsNumberInput
                min={0}
                max={100}
                step={1}
                value={80}
                onChange={() => {}}
            />
        );

        expect(wrapper.find('input').length).toBe(1);
        expect(wrapper.find('input').getDOMNode().pattern).not.toEqual('\\d*');
    });

    it('renders number input successfully as integer', () => {
        wrapper = mount(
            <ChartSettingsNumberInput
                min={0}
                max={100}
                step={1}
                value={80}
                onChange={() => {}}
                isInteger
            />
        );

        expect(wrapper.find('input').length).toBe(1);
        expect(wrapper.find('input').getDOMNode().pattern).toEqual('\\d*');
    });

    it('fires handleChange on change event of input', () => {

        const handleChange = spyOn(ChartSettingsNumberInput.prototype, 'handleChange').and.callThrough();
        const onChangeProp = jasmine.createSpy('onChangeProp');
        const dummyEvent = {
            target: {
                value: '90',
            },
        };

        wrapper = mount(
            <ChartSettingsNumberInput
                min={0}
                max={100}
                step={1}
                value={80}
                onChange={onChangeProp}
                isInteger
            />
        );

        wrapper.simulate('change', dummyEvent);

        expect(handleChange).toHaveBeenCalled();
        expect(onChangeProp).toHaveBeenCalledWith(Number(dummyEvent.target.value));
    });

});
