import PropTypes from 'prop-types';
import React from 'react';
import Checkbox from 'src/components/checkbox/checkbox';

function ChartSettingsCheckbox({ label, isChecked, onChange }) {

    const checkboxComponent = (
        <Checkbox
            className="form-label"
            isChecked={isChecked}
            onChange={onChange}
        >
            {label}
        </Checkbox>
    );

    return checkboxComponent;
}

ChartSettingsCheckbox.propTypes = {
    onChange: PropTypes.func.isRequired,
    isChecked: PropTypes.bool,
    label: PropTypes.string,
};

export default ChartSettingsCheckbox;
