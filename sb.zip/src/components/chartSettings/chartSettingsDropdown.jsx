import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import Dropdown from 'src/components/dropdown/dropdown';
import DropdownItem from 'src/components/dropdown/dropdownItem';

function ChartSettingsDropdown({ label, items, onChange, selected }) {
    return (
        <Dropdown
            label={label}
            onChange={onChange}
            value={selected}
        >
            {
                _.map(items, (item) => (
                    <DropdownItem
                        key={item.id}
                        value={item.id}
                    >
                        {item.label}
                    </DropdownItem>
                ))
            }
        </Dropdown>
    );
}

ChartSettingsDropdown.propTypes = {
    onChange: PropTypes.func.isRequired,
    selected: PropTypes.string,
    label: PropTypes.string,
    items: PropTypes.arrayOf(PropTypes.shape({
        id: PropTypes.string,
        label: PropTypes.string,
    })),
};

export default ChartSettingsDropdown;
