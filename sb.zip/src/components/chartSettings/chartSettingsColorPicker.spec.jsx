import React from 'react';
import { shallow } from 'enzyme';
import ChartSettingsColorPicker, { COLORS } from './chartSettingsColorPicker';
import Dropdown from 'src/components/dropdown/dropdown';
import DropdownItem from 'src/components/dropdown/dropdownItem';

describe('src/components/chartSettings/ChartSettingsColorPicker', () => {
    const label = 'Label text';

    it('renders successfully', () => {
        const wrapper = shallow(
            <ChartSettingsColorPicker
                label={label}
                onChange={() => {}}
            />
        );

        expect(wrapper.find(Dropdown).length).toBe(1);
        expect(wrapper.find(DropdownItem).length).toBe(COLORS.length);
    });

});
