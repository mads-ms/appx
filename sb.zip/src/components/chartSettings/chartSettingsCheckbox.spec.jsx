import React from 'react';
import { shallow } from 'enzyme';
import ChartSettingsCheckbox from './chartSettingsCheckbox';
import Checkbox from 'src/components/checkbox/checkbox';

describe('src/components/chartSettings/chartSettingsCheckbox', () => {
    const label = 'Label text';

    it('renders successfully', () => {
        const wrapper = shallow(
            <ChartSettingsCheckbox
                label={label}
                onChange={() => {}}
                isChecked
            />
        );

        expect(wrapper.find(Checkbox).length).toBe(1);
    });

});
