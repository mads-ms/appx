import React from 'react';
import { shallow } from 'enzyme';
import ChartSettingsLineWidth from './chartSettingsLineWidth';
import Dropdown from 'src/components/dropdown/dropdown';
import DropdownItem from 'src/components/dropdown/dropdownItem';

describe('src/components/chartSettings/chartSettingsLineWidth', () => {

    const count = 7;

    it('renders successfully', () => {
        const wrapper = shallow(
            <ChartSettingsLineWidth
                label="labelText"
                count={7}
                value={3}
                onChange={() => {}}
            />
        );

        expect(wrapper.find(Dropdown).length).toBe(1);
        expect(wrapper.find(DropdownItem).length).toBe(count);
    });

});
