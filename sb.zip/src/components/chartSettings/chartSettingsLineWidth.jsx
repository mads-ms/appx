import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import Dropdown from 'src/components/dropdown/dropdown';
import DropdownItem from 'src/components/dropdown/dropdownItem';

function ChartSettingsLineWidth({ label, count = 6, onChange, value }) {

    const dropdownComponent = (
        <div className="grid-cell">
            <Dropdown
                label={label}
                onChange={onChange}
                value={value}
            >
                {_.map(_.range(1, count + 1), (width) =>
                    (<DropdownItem
                        key={width}
                        value={width}
                    >
                        {`${width}px`}
                    </DropdownItem>)
                )}

            </Dropdown>
        </div>
    );

    return dropdownComponent;
}

ChartSettingsLineWidth.propTypes = {
    onChange: PropTypes.func.isRequired,
    value: PropTypes.number,
    label: PropTypes.string,
    count: PropTypes.number,
};

export default ChartSettingsLineWidth;
