import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';

function FormGroup(props) {
    const { label, children, subtext } = props;

    return (
        <div className="form-group form-group--alt">
            <div className={classNames('grid', { 'grid--series': !subtext })}>
                { label && <label className="grid-cell form-label">{label}</label> }
                <div className="grid-cell">
                    {children}
                </div>
            </div>
            {subtext && <p className="form-note t-end">{subtext}</p>}
        </div>
    );
}

FormGroup.propTypes = {
    label: PropTypes.string,
    subtext: PropTypes.string,
};

export default FormGroup;
