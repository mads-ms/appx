import React from 'react';
import { shallow } from 'enzyme';
import ChartSettingsDropdown from './chartSettingsDropdown';
import Dropdown from 'src/components/dropdown/dropdown';
import DropdownItem from 'src/components/dropdown/dropdownItem';

describe('src/components/chartSettings/chartSettingsDropdown', () => {

    const items = [
        { id: 'a', label: 'Item-a' },
        { id: 'b', label: 'Item-b' },
        { id: 'c', label: 'Item-c' },
        { id: 'd', label: 'Item-d' },
        { id: 'e', label: 'Item-e' },
    ];

    it('renders successfully', () => {
        const wrapper = shallow(
            <ChartSettingsDropdown
                label={items[0].label}
                items={items}
                selected={items[0].id}
                onChange={() => {}}
            />
        );

        expect(wrapper.find(Dropdown).length).toBe(1);
        expect(wrapper.find(DropdownItem).length).toBe(items.length);
    });

});
