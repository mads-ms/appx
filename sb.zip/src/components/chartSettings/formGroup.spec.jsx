import React from 'react';
import { shallow } from 'enzyme';
import FormGroup from './formGroup';

describe('src/components/chartSettings/formGroup', () => {

    const label = 'labelText';
    const subtext = 'subText';

    it('renders with label successfully', () => {
        const wrapper = shallow(
            <FormGroup
                label={label}
            >
                <div className="children"></div>
            </FormGroup>
        );

        expect(wrapper.find('label').length).toBe(1);
    });

    it('renders with subtext successfully', () => {
        const wrapper = shallow(
            <FormGroup
                subtext={subtext}
            >
                <div className="children"></div>
            </FormGroup>
        );

        expect(wrapper.find('.form-note').length).toBe(1);
    });

    it('renders with label and subtext successfully', () => {
        const wrapper = shallow(
            <FormGroup
                label={label}
                subtext={subtext}
            >
                <div className="children"></div>
            </FormGroup>
        );

        expect(wrapper.find('label').length).toBe(1);
        expect(wrapper.find('.form-note').length).toBe(1);
    });

});
