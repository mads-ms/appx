import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { bindHandlers } from 'src/utils/bindHandlers';

class ChartSettingsNumberInput extends React.Component {

    handleChange(event) {
        const { min, max, isInteger } = this.props;
        const inputVal = Number(event.target.value);

        this.props.onChange(_.clamp(isInteger ? parseInt(inputVal, 10) : inputVal, min, max));
    }

    render() {
        const { value, min, max, step, isInteger } = this.props;
        return (
            <input
                type="number"
                className="form-control"
                step={step}
                min={min}
                max={max}
                pattern={isInteger ? '\\d*' : null}
                value={value}
                onChange={this.handleChange}
            />
        );
    }
}

ChartSettingsNumberInput.propTypes = {
    onChange: PropTypes.func.isRequired,
    min: PropTypes.number,
    max: PropTypes.number,
    step: PropTypes.number,
    value: PropTypes.number,
    isInteger: PropTypes.bool,
};

export default bindHandlers(ChartSettingsNumberInput);
