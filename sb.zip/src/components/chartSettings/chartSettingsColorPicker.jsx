import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import Dropdown from 'src/components/dropdown/dropdown';
import DropdownItem from 'src/components/dropdown/dropdownItem';

export const COLORS = [
    'transparent',
    '#000000',
    '#111111',
    '#222222',
    '#333333',
    '#444444',
    '#808080',
    '#888888',
    '#999999',
    '#d3d3d3',
    '#dddddd',
    '#f5f5dc',
    '#ffffff',
    '#a52a2a',
    '#ff0000',
    '#ff6666',
    '#ef8252',
    '#eb5e00',
    '#ff8100',
    '#ff9900',
    '#ffa500',
    '#ffba73',
    '#ffff00',
    '#cdef00',
    '#00ff00',
    '#00a800',
    '#008000',
    '#00ffff',
    '#61b7cf',
    '#7890ab',
    '#3498db',
    '#3399dd',
    '#2b88cb',
    '#057d9f',
    '#123456',
    '#002852',
    '#00008b',
    '#0000ff',
    '#8106a9',
    '#b964d4',
    '#ff00ff',
    '#bc8f8f',
    '#800080',
    '#0000ff',
    '#5f9ea0',
    '#d2691e',
    '#ffc0cb',
    '#e93e33',
];

function ChartSettingsColorPicker({ label, onChange, selected }) {

    const dropdownComponent = (
        <div className="grid-cell">
            <Dropdown
                label={label}
                onChange={onChange}
                value={selected}
            >
                { _.map(COLORS, (color) =>
                    (<DropdownItem
                        key={color}
                        value={color}
                    >
                        {color === 'transparent' ?
                            <div className="color color--transparent"></div> :
                            <div className="color" style={{ backgroundColor: color }}></div>
                        }
                    </DropdownItem>)
                )}

            </Dropdown>
        </div>
    );

    return dropdownComponent;
}

ChartSettingsColorPicker.propTypes = {
    onChange: PropTypes.func.isRequired,
    selected: PropTypes.string,
    label: PropTypes.string,
};

export default ChartSettingsColorPicker;
