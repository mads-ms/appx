import _ from 'lodash';
import $ from 'jqueryAll';
import PropTypes from 'prop-types';
import React from 'react';
import Dialog from 'src/components/dialog/dialog';
import Touchable from 'src/components/touchable/touchable';
import { bindHandlers } from 'src/utils/bindHandlers';
import config from 'src/config';

const DELAY = 1000;

class Tooltip extends React.Component {
    constructor() {
        super();

        // element that serves as anchor for tooltipDialog
        this.setEl = (ref) => {
            this.el = $(ref).children();
        };

        this.state = { showTooltip: false };
    }

    componentWillUnmount() {
        this.resetTimeout();
    }

    handleEnter(evt) {
        const node = $(evt.currentTarget);

        // no need to show tooltip
        if (!this.isTruncated(node)) {
            return;
        }

        this.timerID = window.setTimeout(() => {
            this.setState({ showTooltip: true });
        }, DELAY);
    }

    handleLeave() {
        this.resetTimeout();
    }

    resetTimeout() {
        if (this.timerID) {
            window.clearTimeout(this.timerID);
            this.timerID = null;
            this.setState({ showTooltip: false });
        }
    }

    isTruncated(node) {
        return _.some(node.children(), function(child) {
            return (child.scrollWidth > child.offsetWidth);
        });
    }

    render() {
        const tooltipDialog = this.state.showTooltip && (
            <Dialog anchor={this.el} position={this.props.position}>
                <div className="tooltip">{this.props.content}</div>
            </Dialog>
        );

        // setup event handlers
        const touchableProps = config.isDesktopApp ?
            { onMouseEnter: this.handleEnter, onMouseLeave: this.handleLeave } :
            { onTouchStart: this.handleEnter, onTouchEnd: this.handleLeave };

        return (
            <div ref={this.setEl}>
                <Touchable
                    onTap={this.props.onTap}
                    {...touchableProps}
                >
                    {this.props.children}
                </Touchable>
                {tooltipDialog}
            </div>
        );
    }
}

Tooltip.propTypes = {
    content: PropTypes.element.isRequired,
    position: PropTypes.string,
    onTap: PropTypes.func,
};

Tooltip.defaultProps = {
    position: 'top',
    onTap: _.noop,
};

export default bindHandlers(Tooltip);
