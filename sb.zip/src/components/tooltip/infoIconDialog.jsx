import $ from 'jqueryAll';
import PropTypes from 'prop-types';
import React from 'react';
import Dialog from 'src/components/dialog/dialog';
import Icon from 'src/components/icon/icon';
import { bindHandlers } from 'src/utils/bindHandlers';
import Sheet from 'src/components/sheet/sheet';
import SheetHeader from 'src/components/sheet/sheetHeader';
import SheetBody from 'src/components/sheet/sheetBody';
import Touchable from 'src/components/touchable/touchable';
import config from 'src/config';

class InfoIconDialog extends React.Component {

    constructor() {
        super();
        this.state = { showDialog: false };

        // element that serves as anchor for tooltipDialog
        this.setEl = (ref) => {
            this.$iconEl = $(ref).children();
        };
    }

    shouldComponentUpdate(nextProps, nextState) {
        return this.state.showDialog !== nextState.showDialog;
    }

    handleTap(evt) {
        evt.stopPropagation();
        this.setState({ showDialog: true });
    }

    handleDialogHide() {
        if (this.$iconEl.length) {
            this.setState({ showDialog: false });
        }
    }

    render() {
        const {
            header,
            children,
            className,
            position,
            iconType,
            parent,
            type,
        } = this.props;

        const dialog = this.state.showDialog && (
            <Dialog
                isSignalActivity={config.isTabletApp}
                anchor={this.$iconEl}
                position={position}
                type={type}
                onHide={this.handleDialogHide}
                parent={parent}

            >
                <Sheet className="sheet--alt saxoselect-dialog-tooltip grid grid--y grid--fit-fill">
                    { header &&
                        <SheetHeader className="grid-cell">
                            {header}
                        </SheetHeader>
                    }
                    <SheetBody className="grid-cell">
                        {children}
                    </SheetBody>
                </Sheet>
            </Dialog>
        );

        return (
            <div ref={this.setEl} className={className}>
                <Touchable onTap={this.handleTap}>
                    <Icon type={iconType}/>
                </Touchable>
                { dialog }
            </div>
        );
    }
}

InfoIconDialog.propTypes = {
    header: PropTypes.string,
    className: PropTypes.string,
    position: PropTypes.string,
    type: PropTypes.oneOf(['popup', 'card']),
    iconType: PropTypes.oneOf(['details', 'info-alt']),
    parent: PropTypes.instanceOf(HTMLElement),
};

InfoIconDialog.defaultProps = {
    iconType: 'details',
    position: 'top',
    type: config.isPhoneApp ? 'card' : 'popup',
};

export default bindHandlers(InfoIconDialog);
