import $ from 'jqueryAll';
import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import SortableController from 'spine/commonControllers/sortable';

class Sortable extends React.Component {
    componentDidMount() {
        this.initController(this.props);
    }

    componentDidUpdate(prevProps) {
        if (this.hasPropsChanged(prevProps, 'reinitKey', 'element', 'handleSelector', 'itemSelector')) {
            this.initController(this.props);
        }

        if (this.hasPropsChanged(prevProps, 'isActive')) {
            this.setControllerActivated(this.props);
        }
    }

    componentWillUnmount() {
        this.initController(this.props, true);
    }

    hasPropsChanged(otherProps, ...keys) {
        return _.some(keys, (key) => this.props[key] !== otherProps[key]);
    }

    initController(props, isDestroying) {
        if (this.sortableController && (this.sortableController.isActive() || isDestroying)) {
            this.sortableController.release();
            this.sortableController = null;
        }

        if (!isDestroying) {
            if (!this.sortableController && props.element && props.itemSelector) {
                this.sortableController = new SortableController({
                    el: $(props.element),
                    optn: {
                        forceHeight: false,
                        itemSelector: props.itemSelector,
                        handleSelector: props.handleSelector,
                        equal: true,
                        activate: false,
                        placeholder: false,
                        clone: false,
                        velocity: false,
                        signalActivity: false, // UI suppressed in edit mode
                    },
                })
                    .on('change', props.onChange);
            }

            if (props.isActive && this.sortableController) {
                this.sortableController.activate();
            }
        }
    }

    setControllerActivated(props) {
        if (!this.sortableController) {
            if (props.isActive) {
                this.initController(props);
            }
            return;
        }

        if (props.isActive) {
            this.sortableController.activate();
        } else {
            this.sortableController.deactivate();
        }
    }

    render() {
        return false;
    }
}

Sortable.propTypes = {
    element: PropTypes.instanceOf(window.HTMLElement),
    onChange: PropTypes.func,
    reinitKey: PropTypes.any,
    itemSelector: PropTypes.string,
    handleSelector: PropTypes.string,
    isActive: PropTypes.bool,
};

Sortable.defaultProps = {
    onChange: _.noop,
};

export default Sortable;
