import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import Button from 'src/components/button/button';
import Localization from 'src/localization';
import Icon from 'src/components/icon/icon';
import { bindHandlers } from 'src/utils/bindHandlers';
import * as featureTracker from 'src/featureTracker';
import config from 'src/config';

class Tile extends React.PureComponent {
    handleButtonOpenTap() {
        const {
            id,
            title,
            featureArea,
            onOpen,
        } = this.props;

        onOpen(id);

        if (featureArea) {
            featureTracker.logEvent(featureArea, 'Card clicked', {
                title,
                sessionId: config.sessionId,
            });
        }
    }

    render() {
        const {
            className,
            title,
            description,
            iconType,
        } = this.props;

        return (
            <div className={classNames('tile grid grid--y grid--sections grid--fit-fill-fit', className)}>
                <h3 className="grid-cell">{title}</h3>
                <div className="grid grid--series grid--fill-fit">
                    <p className="tile-desc grid-cell">{description}</p>
                    {iconType && (
                        <div className="grid-cell">
                            <Icon type={iconType} size="extra-large"/>
                        </div>
                    )}
                </div>
                <div className="grid-cell">
                    <Button className="btn--primary" onTap={this.handleButtonOpenTap}>
                        {Localization.getText('HTML5_MA_Open')}
                    </Button>
                </div>
            </div>
        );
    }
}

Tile.propTypes = {
    id: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
    className: PropTypes.string,
    description: PropTypes.string,
    iconType: PropTypes.string,
    featureArea: PropTypes.string,
    onOpen: PropTypes.func.isRequired,
};

export default bindHandlers(Tile);
