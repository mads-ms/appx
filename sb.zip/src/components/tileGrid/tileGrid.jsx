import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import Tile from './tile';
import Resizable from 'src/components/resizable/resizable';

class TileGrid extends React.PureComponent {
    render() {
        const {
            tiles,
            onTileOpen,
            resizeTimestamp,
            featureArea,
        } = this.props;

        // cap the measure of a tile's description
        const maxTileWidth = 450;
        const MAX_TILES_PER_ROW = 4;

        return (
            <Resizable resizeTimestamp={resizeTimestamp}>
                {
                    (resizeableProps) => {
                        const itemsPerRow = Math.min(Math.ceil(resizeableProps.parentViewport.width / maxTileWidth), MAX_TILES_PER_ROW);

                        return (
                            <div className="grid grid--scroll">
                                <div className="tilegrid grid grid--wrap grid--lines-start">
                                    {_.map(tiles,
                                        (tile) => {
                                            const {
                                                id,
                                                title,
                                                description,
                                                iconType,
                                            } = tile;

                                            return (
                                                <Tile

                                                    /* size required to maintain column intergity */
                                                    className={`tilegrid-tile g--1of${itemsPerRow}`}
                                                    key={id}
                                                    id={id}
                                                    title={title}
                                                    description={description}
                                                    iconType={iconType}
                                                    featureArea={featureArea}
                                                    onOpen={onTileOpen}
                                                />
                                            );
                                        }
                                    )}
                                </div>
                            </div>
                        );
                    }
                }
            </Resizable>
        );
    }
}

TileGrid.propTypes = {
    onTileOpen: PropTypes.func.isRequired,
    className: PropTypes.string,
    tiles: PropTypes.arrayOf(PropTypes.shape({
        id: PropTypes.string,
        name: PropTypes.string,
        description: PropTypes.string,
        iconType: PropTypes.string,
    })).isRequired,
    resizeTimestamp: PropTypes.number.isRequired,
    featureArea: PropTypes.string,
};

export default TileGrid;
