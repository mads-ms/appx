import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import Dropdown from 'src/components/dropdown/dropdown';
import DropdownItem from 'src/components/dropdown/dropdownItem';

function FilterDropdown({ filterList, selectedItem, onChange }) {
    return (
        <Dropdown
            value={selectedItem}
            onChange={onChange}
        >
            {_.map(filterList, (option, index) => (
                <DropdownItem key={index} value={option.key}>
                    {option.value}
                </DropdownItem>
            ))}
        </Dropdown>
    );
}

FilterDropdown.propTypes = {
    filterList: PropTypes.arrayOf(PropTypes.shape({
        key: PropTypes.number,
        value: PropTypes.string,
    })).isRequired,
    selectedItem: PropTypes.number.isRequired,
    onChange: PropTypes.func.isRequired,
};

export default FilterDropdown;
