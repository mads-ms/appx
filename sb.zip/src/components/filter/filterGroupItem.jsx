import PropTypes from 'prop-types';
import React from 'react';
import { bindHandlers } from 'src/utils/bindHandlers';
import Checkbox from 'src/components/checkbox/checkbox';

class FilterGroupItem extends React.Component {
    handleChange() {
        const { filterGroup, filterItemKey, onChange } = this.props;

        onChange(filterGroup, filterItemKey);
    }

    render() {
        const { className, filterItemLabel, isChecked } = this.props;

        return (
            <div className={className}>
                <Checkbox
                    isChecked={isChecked}
                    onChange={this.handleChange}
                >
                    {filterItemLabel}
                </Checkbox>
            </div>
        );
    }
}

FilterGroupItem.propTypes = {
    className: PropTypes.string,
    filterGroup: PropTypes.string,
    filterItemKey: PropTypes.any,
    filterItemLabel: PropTypes.string,
    isChecked: PropTypes.bool,
    onChange: PropTypes.func,
};

export default bindHandlers(FilterGroupItem);
