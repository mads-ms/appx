import _ from 'lodash';
import React from 'react';
import { mount } from 'enzyme';
import FilterGroup from 'src/components/filter/filterGroup';
import FilterGroupItem from 'src/components/filter/filterGroupItem';

describe('src/components/filterGroup/filterGroup', () => {
    let wrapper;
    const handleChange = _.noop;
    const filterList = [
        {
            label: 'Checked filter',
            isChecked: true,
            isHidden: false,
        },
        {
            label: 'Unchecked filter',
            isChecked: false,
            isHidden: false,
        },
    ];

    afterEach(() => {
        wrapper.unmount();
    });

    it('renders successfully', () => {
        wrapper = mount(
            <FilterGroup
                filterGroupLabel="groupLabel"
                filterList={filterList}
                onFilterChange={handleChange}
            />
        );

        expect(wrapper.children().find(FilterGroupItem).length).toEqual(filterList.length);
    });

    it('doesn`t render hidden filterListItems', () => {
        const extendedFilterList = _.concat(
            filterList,
            {
                label: 'Hidden filter',
                isChecked: false,
                isHidden: true,
            }
        );

        wrapper = mount(
            <FilterGroup
                filterGroupLabel="groupLabel"
                filterList={extendedFilterList}
                onFilterChange={handleChange}
            />
        );

        expect(wrapper.children().find(FilterGroupItem).length).toEqual(2);
    });
});
