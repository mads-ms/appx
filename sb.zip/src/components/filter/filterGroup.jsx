import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import FilterDropdown from './filterDropdown';
import FilterGroupItem from './filterGroupItem';
import TooltipButton from 'src/components/tooltipDialog/tooltipButton';

/**
 * Filter group component.
 * Consists either of a list of filters that can be toggled
 * on or off (represented in the UI as checkboxes), OR
 * a dropdown with only one selected filter option
 */
class FilterGroup extends React.PureComponent {
    render() {
        const {
            className,
            itemClassName,
            labelClassName,
            filterGroup,
            filterGroupLabel,
            filterList,
            selectedDropdownItem,
            tooltip,
            onFilterChange,
        } = this.props;

        let filters;

        if (selectedDropdownItem == null) {
            filters = _.chain(filterList)
                .reject('isHidden')
                .map((filter, index) =>
                    (<FilterGroupItem
                        key={index}
                        className={itemClassName}
                        filterGroup={filterGroup}
                        filterItemKey={filter.key}
                        filterItemLabel={filter.label}
                        isChecked={filter.isChecked}
                        onChange={onFilterChange}
                    />)
                )
                .value();
        } else {
            filters = (
                <FilterDropdown
                    filterList={filterList}
                    selectedItem={selectedDropdownItem}
                    onChange={onFilterChange}
                />
            );
        }

        return (
            <div className={className}>
                <div className={classNames('t-meta', labelClassName)}>
                    {filterGroupLabel}
                    {tooltip && (
                        <TooltipButton
                            tooltipTitle={filterGroupLabel}
                            tooltipText={tooltip}
                        />
                    )}
                </div>
                {filters}
            </div>
        );
    }
}

/*
 * onFilterChange should have 2 parameters:
 *     - filterGroup = this.props.filterGroup
 *     - filterItemLabel
 *
 * OR, for dropdowns, 1 parameter:
 *     - selectedOption
 */
FilterGroup.propTypes = {
    className: PropTypes.string,
    labelClassName: PropTypes.string,
    itemClassName: PropTypes.string,
    filterGroup: PropTypes.string.isRequired,
    filterGroupLabel: PropTypes.string.isRequired,
    filterList: PropTypes.arrayOf(PropTypes.shape({
        label: PropTypes.string,
        isChecked: PropTypes.bool,
        isHidden: PropTypes.bool,
    })).isRequired,
    selectedDropdownItem: PropTypes.number,
    tooltip: PropTypes.string,
    onFilterChange: PropTypes.func.isRequired,
};

FilterGroup.defaultProps = {
    className: '',
};

export default FilterGroup;
