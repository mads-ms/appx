/**
 * Include this file to get access to useful objects in development environment.
 */

import _ from 'lodash';
import getStore from 'src/store';
import getOpenApi from 'src/modules/openApi';
import log from 'src/modules/log';
import AccountModel from 'src/spine/models/account';
import * as workspaceDebugActions from 'src/modules/workspace/debug/workspaceDebugActions';
import workspaceDebugInject from 'src/modules/workspace/debug/workspaceDebugInject';
import UserSettingsModel from 'src/spine/models/userSettings';
import config from 'src/config';

if (BUILD_IS_DEBUG) {
    window.$getOpenApi = getOpenApi;
    window.$getStore = getStore;
    window.$log = log;
    window.$accountModel = AccountModel;
    window.$UserSettings = UserSettingsModel;
    window.$config = config;

    window.$getSubs = (urlFilter, state) =>
        _.chain(getOpenApi().streaming.subscriptions)
            .filter((v) => {
                let filter = true;
                filter = _.isNil(state) ? true : v.currentState === state;
                return filter && (_.isNil(urlFilter) ? true : v.url.indexOf(urlFilter) !== -1);
            })
            .groupBy('url')
            .value();

    window.$activeSubs = (urlFilter, state = 2) => window.$getSubs(urlFilter, state);
    window.$inactiveSubs = (urlFilter, state = 8) => window.$getSubs(urlFilter, state);

    window.$workspaceDebug = {
        visible: (isVisible) => {
            if (isVisible) {
                workspaceDebugInject();
            }
            getStore().dispatch(workspaceDebugActions.visible(isVisible));
        },
        edgesUpdate: (payload) => {
            getStore().dispatch(workspaceDebugActions.edgesUpdate(payload));
        },
    };
}
