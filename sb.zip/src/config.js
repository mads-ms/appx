/**
 * Exports the global configuration object as a module.
 */

import _ from 'lodash';
import * as util from 'src/utils/util';

const config = window.config;
delete window.config;

// despite having 2 bundles, because the config from promaster is used on slave, pro only has a single app id
config.isProApp = config.appId === 'pro';
config.isDesktopApp = config.appId !== 'tablet' && config.appId !== 'phone';
config.isTabletApp = config.appId === 'tablet';
config.isPhoneApp = config.appId === 'phone';
config.isAccountApp = config.appId === 'myaccount' || config.appId === 'csmyaccount' || config.appId === 'monitor';

export default config;

export function getFundCommissionsUrl(accountKey, uic, assetType) {
    const isUrlExternal = _.startsWith(config.appFeatures.fundCommissionsUrl, 'http');
    return isUrlExternal ? util.formatString(config.appFeatures.fundCommissionsUrl, accountKey, uic, assetType) : '';
}
