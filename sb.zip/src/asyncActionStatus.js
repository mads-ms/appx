/**
 * The request responded with a 20x status.
 *
 * @type {string}
 */
export const SUCCESS = 'async-action-status/success';

/**
 * The request is in flight, or the subscription request is in flight and before the first update/snapshot has been returned
 *
 * @type {string}
 */
export const PENDING = 'async-action-status/pending';

/**
 * The request/subscription is in an error state. Either the request failed, or
 * the subscription ended up in an error state.
 *
 * @type {string}
 */
export const ERROR = 'async-action-status/error';

/**
 * Subscription created or place holder has been allocated in preparation
 * to receiving result.
 */
export const CREATED = 'async-action-status/created';

/**
 * The subscription is running
 *
 * @type {string}
 */
export const SUBSCRIBED = 'async-action-status/subscribed';

/**
 * Subscription is suspended.
 *
 * @type {string}
 */
export const UNSUBSCRIBED = 'async-action-status/unsubscribed';

/**
 * No request ever made, empty state
 *
 * @type {string}
 */
export const NONE = 'async-action-status/none';
