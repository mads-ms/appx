import _ from 'lodash';
import * as localStorage from 'src/utils/localStorage';

const configHashParameters = { pushNotifications: {}, openApiAuth: {} };
let locationHash = window.locationHash;
delete window.locationHash;

if (locationHash) {
    if (locationHash.toLowerCase().indexOf('/sso') > 0) {

        // Clear localstorage state
        localStorage.set('appstate', '');
        localStorage.set('riskAccept', '0');
        localStorage.set('serverId', '0');
        localStorage.set('disclaimersAccepted', '0');

        locationHash = locationHash.substring(locationHash.indexOf('oapi'));
        const arr = locationHash.split('/');

        for (let i = 0; i < arr.length - 1; i++) {
            const v = decodeURIComponent(arr[i + 1]);
            switch (arr[i]) {
                case 'exp':
                    configHashParameters.openApiAuth.expiry = parseInt(v, 10);
                    break;

                case 'oapi':
                    configHashParameters.openApiAuth.token = v;
                    break;

                case 'pli':
                    configHashParameters.pageLoadTime = v;
                    break;

                case 'pushId':
                    configHashParameters.pushNotifications.pushId = v;
                    break;

                case 'name':
                    configHashParameters.pushNotifications.name = v;
                    break;

                case 'method':
                    configHashParameters.pushNotifications.method = v;
                    break;

                case 'appId':
                    configHashParameters.pushNotifications.appId = v;
                    break;
            }
        }
    }

    const slaveViewMatchRegex = /#view-([\w-]+)(\?savehash=1)?$/;
    const slaveViewMatch = locationHash.match(slaveViewMatchRegex) || window.name && window.name.match(slaveViewMatchRegex);
    if (slaveViewMatch) {
        configHashParameters.viewControllerName = _.camelCase(slaveViewMatch[1]);
        if (slaveViewMatch[2] === '?savehash=1') {
            window.location.hash = locationHash;
        }
    }
}

export default configHashParameters;
