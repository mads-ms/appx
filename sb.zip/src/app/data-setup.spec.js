import getOpenApi from 'src/modules/openApi';
import {
    start,
    whenStarted,
    __RewireAPI__ as rewire, // eslint-disable-line import/named
} from 'src/app/dataSetup';

import Session from 'src/modules/openApi/session';

describe('src/app/dataSetup', () => {

    beforeEach(() => {
        spyOn(Session, 'start');
        spyOn(Session, 'signout');
    });

    it('starts and resolves whenStarted promise', (done) => {
        getOpenApi().setupPromise = Promise.resolve();
        rewire.__Rewire__('getAccountsFetchedPromise', () => Promise.resolve());
        rewire.__Rewire__('getSettingsFetchedPromise', () => Promise.resolve());

        start();

        whenStarted().then(done);
    });

    it('signs out if open api fails', (done) => {
        getOpenApi().setupPromise = Promise.reject();

        start().catch(() => {
            expect(Session.signout).toHaveBeenCalledTimes(1);
            done();
        });
    });

    it('signs out if accounts fails', (done) => {
        getOpenApi().setupPromise = Promise.resolve();
        rewire.__Rewire__('getAccountsFetchedPromise', () => Promise.reject());
        rewire.__Rewire__('getSettingsFetchedPromise', () => Promise.resolve());

        start().catch(() => {
            expect(Session.signout).toHaveBeenCalledTimes(1);
            done();
        });
    });

    it('by default start session', (done) => {
        getOpenApi().setupPromise = Promise.resolve();
        rewire.__Rewire__('getAccountsFetchedPromise', () => Promise.resolve());
        rewire.__Rewire__('getSettingsFetchedPromise', () => Promise.resolve());

        start().then(() => {
            expect(Session.start).toHaveBeenCalledTimes(1);
            done();
        });

    });

    it('should not start session for non primary trading session', (done) => {
        getOpenApi().setupPromise = Promise.resolve();
        rewire.__Rewire__('getAccountsFetchedPromise', () => Promise.resolve());
        rewire.__Rewire__('getSettingsFetchedPromise', () => Promise.resolve());

        start({ isPrimaryTradingSession: false }).then(() => {
            expect(Session.start).not.toHaveBeenCalled();
            done();
        });
    });
});
