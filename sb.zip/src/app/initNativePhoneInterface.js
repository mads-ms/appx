import config from 'src/config';

// For iOS native app - old hack for getting the setting
window.reqjs = { config: { 'framework/models/userSettings': { features: { isTouchIdEnabled: config.appFeatures.isTouchIdEnabled } } } };

// For ios native app after #637371
window.native = {
    isTouchIdEnabled() {
        return Boolean(config.appFeatures.isTouchIdEnabled);
    },
};
