import openApiFactory from 'src/modules/openApi/openApiFactory';
import { isXwcMaster } from 'src/xwc/xwcDesktopManager';

/**
 * It turns out that starting open api off early in the bundle evaluation does make a difference
 * to our startup time, so if we are the master window, start open api immediately.
 * For phone and tablet, see the open api factory.
 */
if (isXwcMaster) {
    openApiFactory();
}
