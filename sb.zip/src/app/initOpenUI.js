/* eslint-disable unicorn/filename-case */
import { UI } from 'openui';

export default function initOpenUI(hammerOptions) {
    UI.initScrollViews();
    UI.initHammer(hammerOptions);
    UI.initElementBlur();
}
