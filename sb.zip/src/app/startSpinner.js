/**
 * Starts the spinner
 */

const brand = document.querySelector('#splash .js-brand');
const load = document.querySelector('#splash .js-load');
const SHOW_CLASS = 'is-shown';

setTimeout(function() {
    if (brand) {
        brand.classList.add(SHOW_CLASS);
    }
    if (load) {
        load.classList.add(SHOW_CLASS);
    }
}, 0);
