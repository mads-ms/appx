import _ from 'lodash';
import $ from 'jqueryAll';
import config from 'src/config';
import log from 'src/modules/log';
import 'src/modules/log/unhandledErrors';
import getOpenApi from 'src/modules/openApi';
import AccountModel from 'src/spine/models/account';
import Session from 'src/modules/openApi/session';
import fetchMifidClassificationStatus from 'src/spine/presenters/fetchMifidClassificationStatus';
import EqrModel from 'src/spine/models/eqr';
import Enums from 'src/spine/enums';
import { fetchNewsSources } from 'src/modules/newsSources/actions';
import * as userSettingsActions from 'src/modules/settings/actions/userSettingsActions';
import * as disclaimerConstants from 'src/modules/disclaimer/constants';
import * as disclaimerActions from 'src/modules/disclaimer/actions';
import * as profileSettingsActions from 'src/modules/settings/actions/profileSettingsActions';
import * as portfolioSettingsActions from 'src/modules/settings/actions/portfolioSettingsActions';
import * as accountsActions from 'src/modules/accounts/actions';
import * as clientActions from 'src/modules/clients/actions';
import { getSettingsFetchedPromise } from 'src/modules/settings/selectors/settingsSelectors';
import { getAccountsFetchedPromise } from 'src/modules/accounts/utils';
import * as watchlistsFetchingSagaActions from 'src/modules/watchlists/actions/watchlistsFetchingSagaActions';
import getStore from 'src/store';
import PerfLogging from 'src/modules/perfLog/perfLogging';
import { LOGIN_TO_APP_REVEALED } from 'src/modules/perfLog/constants';
import initWatchSubscriptionsCount from 'src/modules/subscriptionsCount/initWatchSubscriptionsCount';
import UserSettings from 'src/spine/models/userSettings';

let resolveStarted;
let isStartedPromise;

PerfLogging.addDurationSubEvent(LOGIN_TO_APP_REVEALED, null, 'dataSetupBundleParsed');

/**
 * For testing only, export the setup so we can reset the state
 */
function setupStartedPromise() {
    isStartedPromise = new Promise((resolve) => {
        resolveStarted = resolve;
    });
}

setupStartedPromise();

/**
 * Returns a promise that will resolve when the data setup has started
 * @returns {Promise}
 */
export function whenStarted() {
    return isStartedPromise;
}

/**
 * Starts the data setup
 * @param {object} [options]
 * @param {boolean} [options.isPrimaryTradingSession=true] - whether to setup this connection as the primary trading session
 * @returns {Promise.<TResult>}
 */
export function start(options) {

    const shouldFetchAccounts = _.get(options, 'fetchAccounts', true);
    const shouldFetchDisclaimers = _.get(options, 'fetchDisclaimers', true);
    const isPrimaryTradingSession = _.get(options, 'isPrimaryTradingSession', true);

    // temporary jquery setup till it is removed
    $.ajaxSetup({ cache: false, headers: { 'Cache-Control': 'no-cache' } });

    const openApiSetupPromise = getOpenApi().setupPromise;

    const store = getStore();
    store.dispatch(userSettingsActions.fetchInitialUserSettings());
    store.dispatch(profileSettingsActions.fetchProfileSettings());
    store.dispatch(portfolioSettingsActions.fetchPortfolioSettings());
    const userSettingsPromise = getSettingsFetchedPromise();
    UserSettings.init();

    log.info('data setup started - waiting');

    userSettingsPromise
        .then(() => {
            // not my account or saxoslect
            if (config.appId === 'phone' || config.appId === 'tablet' || config.appId === 'desktop' || config.appId === 'pro') {
                store.dispatch(watchlistsFetchingSagaActions.initialFetch());

                // fetch disclaimers for master only
                if (shouldFetchDisclaimers) {
                    store.dispatch(disclaimerActions.fetchDisclaimersByType(disclaimerConstants.DISCLAIMER_TYPE_PRE_TRADE));
                }
            }

            // Simple disclaimers are used in Account section
            store.dispatch(disclaimerActions.fetchDisclaimersByType(disclaimerConstants.DISCLAIMER_TYPE_SIMPLE));
        });

    return openApiSetupPromise.then(function() {
        log.info('OpenAPI started');

        if (isPrimaryTradingSession) {
            // start the trading session and ask for full trading
            Session.start();
        }

        if (shouldFetchAccounts) {
            store.dispatch(clientActions.fetchClients());
            store.dispatch(accountsActions.fetchAccounts());
        }

        AccountModel.initialize();

        const accountsPromise = getAccountsFetchedPromise();

        // we always need the mifid status first to know whether to show the disclaimer
        fetchMifidClassificationStatus();

        // not my account or saxoselect or phone
        if (config.appId === 'tablet' || config.appId === 'desktop' || config.appId === 'pro') {
            userSettingsPromise.then(() => {
                // needed to log the user into equity research so the link works
                EqrModel.getCompanySnapshotInitData();
            });
        }

        // fetch news sources - needed for news and opinions modules
        getStore().dispatch(fetchNewsSources());

        // Start watching subscriptions only in dev and test env.
        const isWatchSubscriptionsActive = config.isDesktopApp &&
            config.clientServer.systemEnvironment === 'Test' &&
            Boolean(location.search.match(/[?&]showsubscriptions/g));
        if (isWatchSubscriptionsActive) {
            initWatchSubscriptionsCount(isWatchSubscriptionsActive);
        }

        return accountsPromise;
    })
        .catch(function(reason) {
            log.error('Error initializing', reason);

            Session.signout(Enums.ReturnCode.DataSetupStartFailed);
            return Promise.reject(reason);
        })
        .then(() => {
            log.info('Accounts started');
        })
        .then(() => userSettingsPromise)
        .then(resolveStarted);
}
