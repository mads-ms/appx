import 'jqueryAll';
import _ from 'lodash';
import thunkMiddleware from 'redux-thunk';
import { combineReducers, createStore, applyMiddleware, compose } from 'redux';
import { setCreateStore } from '../../store';

function applyDevTools() {
    return BUILD_IS_DEBUG && window.devToolsExtension ? window.devToolsExtension() : _.identity;
}

export function setupStore() {
    setCreateStore(() => {
        const store = createStore(
            combineReducers({
                app: (state = {}) => state,
            }),
            compose(
                applyMiddleware(thunkMiddleware),
                applyDevTools()
            )
        );

        return { store };
    });
}

setupStore();

