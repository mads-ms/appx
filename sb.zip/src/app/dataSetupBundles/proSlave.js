/**
 * Data setup entry point for the pro sub window app, which doesn't have its own communication but proxies to the master window
 */

import Session from 'src/modules/openApi/session';
import * as dataSetup from 'src/app/dataSetup';
import getSlaveSession from 'src/xwc/xwcProSlaveManager';
import xwcOpenApiFactory from 'src/xwc/xwcOpenApiFactory';
import getOpenApi, { setOpenApi } from 'src/modules/openApi';
import XwcSpineEvents from 'src/xwc/xwcSpineEvents';
import log from 'src/modules/log';
import '../xwcRegisterDateTime';
import { setupSlaveStore } from 'src/xwc/redux/xwcStoreSetup';
import { getXwcManager } from 'src/xwc/xwcDesktopManager';
import { addModuleReducers } from 'src/modules/workspace/moduleReducers';

/**
 * normally we setup the module reducers in the app bundle, but for pro we have an initial state from the master,
 * so we need to make sure the reducers are all added before we setup the store.
 */
addModuleReducers();

// This sets up XWC for this window. it is Asynchronous because of the nature of the pro shell transport.
getSlaveSession()
    .then((session) => {
        // now setup the proxies we need for this window
        const xwcSpineEvents = XwcSpineEvents.getInstance();
        setOpenApi(xwcOpenApiFactory(session));
        xwcSpineEvents.setupOnSession(session);

        // Setup to give openApi to any child framed content - e.g. myaccount
        getXwcManager().on('slaveAck', (evt) => {
            evt.session.registerService('openApi', getOpenApi());
        });

        return session;
    })

    // setup the redux slave store to get the full state and start listening for actions
    .then((session) => setupSlaveStore(session.getService('reduxStore')))

    // now our proxies are in place, setup and get any data setup required
    .then(() => dataSetup.start({ isPrimaryTradingSession: false, fetchDisclaimers: false, fetchAccounts: false }))
    .catch((e) => {
        log.warn('XWC manager could not initialize', e);
        Session.redirectToDefaultApp();
    });
