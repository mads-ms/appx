/**
 * Data setup entry point for tablet
 */

import openApiFactory from 'src/modules/openApi/openApiFactory';

/**
 * Starting open api off early in the bundle evaluation makes a difference to our startup time.
 */
/* eslint import/first:"off" */
openApiFactory();

import initMaster from '../initMaster';

initMaster();
