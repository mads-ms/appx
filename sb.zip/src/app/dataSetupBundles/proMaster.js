/**
 * Data setup entry point for pro master.
 * This will be the main communication instance speaking to open api.
 */

import openApiFactory from 'src/modules/openApi/openApiFactory';

/**
 * Starting open api off early in the bundle evaluation makes a difference to our startup time.
 */
/* eslint import/first:"off" */
openApiFactory();

import getProMasterManager from 'src/xwc/xwcProMasterManager';
import * as dataSetup from 'src/app/dataSetup';
import '../xwcRegisterDateTime';
import { setupMasterStore } from 'src/xwc/redux/xwcStoreSetup';
import XwcSpineEvents from 'src/xwc/xwcSpineEvents';
import getOpenApi, { setOpenApi } from 'src/modules/openApi';
import { getXwcManager } from 'src/xwc/xwcDesktopManager';

const masterReduxStore = setupMasterStore();
const xwcSpineEvents = XwcSpineEvents.getInstance();

setOpenApi(openApiFactory());

dataSetup.start();

getXwcManager().on('slaveAck', (evt) => {
    xwcSpineEvents.setupOnSession(evt.session);

    evt.session.registerService('openApi', getOpenApi());
});

getProMasterManager()
    .on('slaveAck', (evt) => {
        // when a new sub window attempts to connect, setup spine events and give them open api
        xwcSpineEvents.setupOnSession(evt.session);

        evt.session.registerService('openApi', getOpenApi());
        evt.session.registerService('reduxStore', masterReduxStore);
    });
