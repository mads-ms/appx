/**
 * Data setup entry point for a disclaimer app
 */
import openApiRestFactory from 'src/modules/openApi/openApiRestFactory';
import { setOpenApi } from 'src/modules/openApi';
import { setupStore } from 'src/disclaimerStoreFactory';

setOpenApi(openApiRestFactory());
setupStore();
