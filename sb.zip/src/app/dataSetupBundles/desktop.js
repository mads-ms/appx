/**
 * Data setup entry point for desktop.
 * we might be a popup and require to be a xwc slave or we
 * might be the full desktop app operating as a xwc master.
 */

import '../desktopOpenApiSetup'; // keep this import first. See the file for why.
import { isXwcMaster, getXwcManager } from 'src/xwc/xwcDesktopManager';
import Session from 'src/modules/openApi/session';
import * as dataSetup from 'src/app/dataSetup';
import xwcOpenApiFactory from 'src/xwc/xwcOpenApiFactory';
import { setOpenApi } from 'src/modules/openApi';
import XwcSpineEvents from 'src/xwc/xwcSpineEvents';
import { setupSlaveStore } from 'src/xwc/redux/xwcStoreSetup';
import log from 'src/modules/log';
import '../xwcRegisterDateTime';
import initMaster from '../initMaster';
import { addModuleReducers } from 'src/modules/workspace/moduleReducers';
import config from 'src/config';

try {
    // get the xwc manager. This initializes either the slave or master manager.
    // If we are a slave this might fail if the parent opener cannot be reached.
    getXwcManager();
} catch (e) {
    log.warn('XWC manager could not initialize', e);
    if (!isXwcMaster) {
        Session.redirectToDefaultApp();
    }
}

/**
 * Normally we set up the module reducers in the app bundle, but for
 * desktop we add the reducers here so that they're available for
 * the pop-out chart.
 */
addModuleReducers();

if (isXwcMaster) {
    // Enable primary trading session so we get primary trade session logout
    // /monitor is a read only application so is unable to do this
    // /csmyaccount is loaded from within Client station so it can't do this (otherwise it will boot the user out of CS)
    const isPrimaryTradingSession = config.appId !== 'monitor' && config.appId !== 'csmyaccount';
    const fetchDisclaimers = config.appId === 'desktop';

    initMaster({ isPrimaryTradingSession, fetchDisclaimers });
} else {
    // sets up spine events
    const xwcSpineEvents = XwcSpineEvents.getInstance();

    const session = getXwcManager().getMaster();

    // we are slave, so setup the open api proxy and start listening for global spine events
    setOpenApi(xwcOpenApiFactory(session));
    xwcSpineEvents.setupOnSession(session);
    setupSlaveStore(session.getService('reduxStore')).then(() => {
        dataSetup.start({ isPrimaryTradingSession: false, fetchDisclaimers: false, fetchAccounts: false });
    });
}
