/**
 * Phone app entry point.
 */

import _ from 'lodash';
import '../startSpinner';
import * as dataSetup from 'src/app/dataSetup';
import SplashController from 'spine/controllers/splash';
import log from 'src/modules/log';
import serviceWorker from 'src/serviceWorker';
import '../initNativePhoneInterface';
import initOpenUI from '../initOpenUI';
import * as WorkspaceSettingsService from 'src/modules/settings/workspaceSettingsService';
import sessionManager from 'spine/commonControllers/sessionManager';
import SpineGlobalsLink from 'src/modules/globals';
import VisibilityService from 'src/modules/visibility/service';
import * as LoadThemeService from 'src/modules/theme/service';
import '../initSsoHeartbeat';
import { addModuleReducers } from 'src/modules/workspace/moduleReducers';
import { LOGIN_TO_APP_REVEALED } from 'src/modules/perfLog/constants';
import PerfLogging from 'src/modules/perfLog/perfLogging';
import * as insightsActions from 'src/modules/insights/actions';
import getStore from 'src/store';
import config from 'src/config';
import MainApp from 'spine/controllers/mainApp';
import PushNotifications from 'src/pushNotifications';

PerfLogging.addDurationSubEvent(LOGIN_TO_APP_REVEALED, null, 'appBundleParsed');

// Force webpack to use the translated appsplit bundle
// eslint-disable-next-line camelcase, no-undef
__webpack_public_path__ = config.clientServer.scriptBaseUrl;

// Request the appsplit bundle
require.ensure([], _.noop, 'appsplit');

addModuleReducers();

// Wait for data setup to start
const whenSetup = dataSetup.whenStarted()
    .then(() => {
        WorkspaceSettingsService.start();
        SpineGlobalsLink.start();
        LoadThemeService.start();
        VisibilityService.start();
        PushNotifications.setup();

        getStore().dispatch(insightsActions.startSubscription());

        serviceWorker();
    })
    .catch((e) => {
        log.error('Error starting services', e);
    });

initOpenUI();

// init session dialogs and env bootstrapping
sessionManager.start();

const splashController = new SplashController();
const whenOnboarded = splashController.doOnboarding();

Promise.all([whenSetup, whenOnboarded])
    .then(() => {
        const mainAppController = new MainApp();

        Promise.all([splashController.readyToReveal(), mainAppController.whenReady()]).then(([revealCallback]) => {
            revealCallback();
        });
    })
    .catch((e) => {
        log.error('Error starting main app', e);
    });
