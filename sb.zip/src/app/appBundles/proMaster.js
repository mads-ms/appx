/**
 * Pro master entry point.
 */

import '../setupSlaveWindowConfig'; // Purposefully the first import in order to ensure this is the first thing that happens
import _ from 'lodash';
import * as dataSetup from 'src/app/dataSetup';
import log from 'src/modules/log';
import proShellCommunication from 'src/proShellCommunication';
import * as proWorkspaceLoadService from 'src/modules/workspace/proWorkspaceLoad';
import * as workspaceSettingsService from 'src/modules/settings/workspaceSettingsService';
import dragDropHandler from 'src/modules/workspace/dragDropHandler/dragDropHandler';
import * as subWindowUnhandledClose from 'src/modules/windows/subWindowUnhandledCloseService';
import '../initSsoHeartbeat';
import { addModuleReducers } from 'src/modules/workspace/moduleReducers';
import { LOGIN_TO_APP_REVEALED } from 'src/modules/perfLog/constants';
import PerfLogging from 'src/modules/perfLog/perfLogging';
import * as myAccountActions from 'src/modules/myAccount/actions';
import * as myAccountSelectors from 'src/modules/myAccount/selectors';
import promiseTimeout from 'src/utils/promiseTimeout';
import getStore from 'src/store';
import * as insightsActions from 'src/modules/insights/actions';

PerfLogging.addDurationSubEvent(LOGIN_TO_APP_REVEALED, null, 'appBundleParsed');

addModuleReducers();

/**
 * Pro Master runs all the sagas but might not have the required imports to make sure they are
 * available. So we import them here to make them available.
 */
const sagasContext = require.context('src/', true, /[^/]+Sagas\.js$/);
_.forEach(sagasContext.keys(), sagasContext);

const MYACCOUNT_MENU_TIMEOUT = 5000;

// Wait for data setup to start
dataSetup.whenStarted()
    .then(() => {
        proShellCommunication.on(proShellCommunication.messageIds.fromShell.MAIN_WINDOW_READY, (event, mainWindowId) => {

            // Load the my account menus as needed for module permission check in workspace load
            getStore().dispatch(myAccountActions.fetchMenusAndSetupWorkspace());

            promiseTimeout(myAccountSelectors.getPromiseForMenuUpdate(), MYACCOUNT_MENU_TIMEOUT, false)
                .then(() =>
                    proWorkspaceLoadService.start(mainWindowId))
                .then(() => {
                    getStore().dispatch(insightsActions.startSubscription());
                    workspaceSettingsService.start();
                    dragDropHandler.start();
                    subWindowUnhandledClose.start();

                    proShellCommunication.send(proShellCommunication.messageIds.toShell.APP_READY);
                });
        });

        proShellCommunication.send(proShellCommunication.messageIds.toShell.MASTER_WINDOW_READY);
    })
    .catch((e) => {
        log.error('Error showing main window', e);
    });

