/**
 * Disclaimer app entry point.
 */

import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { Hammer } from 'openui';
import getStore from 'src/store';
import initOpenUI from '../initOpenUI';
import App from 'src/modules/app/containers/disclaimer';

// due to limitations in the windows IE web view,
// which is often used by third-party apps,
// force only touch and mouse inputs (avoid pointer events)
initOpenUI({ inputClass: Hammer.TouchMouseInput });

ReactDOM.render(
    <Provider store={getStore()}>
        <App/>
    </Provider>,
    document.getElementById('app')
);
