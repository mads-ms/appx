/**
 * The entry point for the iFrame module which is included inside the iframe in order to communicate with Go
 */

import _ from 'lodash';
import XwcSlaveManager from 'src/xwc/xwcSlaveManager';
import PostMessageChannel from 'src/xwc/channel/xwcPostMessageChannel';

const channelToMaster = new PostMessageChannel(window.parent, { isMaster: false, skipWindowCloseOnDestroy: true }, '*');
const slave = new XwcSlaveManager(channelToMaster, {
    timeoutForNewSlave: 30000, // should be big enough in environments with low bandwidth
    timeoutForAckReply: 10000, // should be big enough in environments with low performance
    rawDataEvents: true,
});

export const isReady = Promise.resolve();

const masterSession = slave.getMaster();
export const openApi = masterSession.getService('openApi');

export const module = masterSession.getService('module');

// Stub out the spine events services to prevent pulling in unused spine dependencies
masterSession.registerService('spineEvents', {
    appEvent: _.noop,
});
