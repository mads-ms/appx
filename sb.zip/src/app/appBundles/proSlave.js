/**
 * Pro slave window entry point.
 */

import config from 'src/config';
import * as dataSetup from 'src/app/dataSetup';
import initOpenUI from '../initOpenUI';
import startMainWindowApp from 'spine/controllers/mainWindowApp';
import SubWindowApp from 'spine/controllers/subWindowApp';
import * as LoadThemeService from 'src/modules/theme/service';
import * as WindowDimensionsService from 'src/modules/windows/windowDimensionsService';
import * as WindowPositionService from 'src/modules/windows/windowPositionService';
import { storeSetupPromise } from 'src/store';
import spineGlobalsLink from 'src/modules/globals';
import visibilityService from 'src/modules/visibility/service';

// module reducers are added in data setup since they needed before the store snapshot is restored

storeSetupPromise.then(() => {
    const initialThemePromise = LoadThemeService.start();

    WindowPositionService.start();
    WindowDimensionsService.start();

    initOpenUI();

    // Wait for data setup to start
    dataSetup.whenStarted()
        .then(() => {
            initialThemePromise.then(() => {
                spineGlobalsLink.start();
                visibilityService.start();

                if (config.isMainWindow) {
                    startMainWindowApp();
                } else {
                    new SubWindowApp();
                }
            });
        });
});
