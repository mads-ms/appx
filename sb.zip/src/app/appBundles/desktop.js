/**
 * Desktop app entry point.
 */

import '../startSpinner';

import * as dataSetup from 'src/app/dataSetup';
import SplashController from 'spine/commonControllers/onboardingSplash';
import SkipOnboardingSplashController from 'spine/commonControllers/skipOnboardingSplash';
import log from 'src/modules/log';
import ViewApp from 'spine/controllers/viewApp';
import { isXwcMaster } from 'src/xwc/xwcDesktopManager';
import initOpenUI from '../initOpenUI';
import * as WorkspaceSettingsService from 'src/modules/settings/workspaceSettingsService';
import sessionManager from 'spine/commonControllers/sessionManager';
import getStore, { storeSetupPromise } from 'src/store';
import SpineGlobalsLink from 'src/modules/globals';
import VisibilityService from 'src/modules/visibility/service';
import * as LoadThemeService from 'src/modules/theme/service';
import '../initSsoHeartbeat';
import { LOGIN_TO_APP_REVEALED } from 'src/modules/perfLog/constants';
import PerfLogging from 'src/modules/perfLog/perfLogging';
import * as insightsActions from 'src/modules/insights/actions';
import config from 'src/config';
import Hammer from 'hammerjs';
import * as appSelectors from 'src/modules/app/selectors';
import MainApp from 'spine/controllers/mainApp';
import PushNotifications from 'src/pushNotifications';

if (config.appId === 'desktop') {
    PerfLogging.addDurationSubEvent(LOGIN_TO_APP_REVEALED, null, 'appBundleParsed');
}

function commonSetup() {
    return dataSetup.whenStarted().then(() => {
        SpineGlobalsLink.start();

        // we force white theme on client station
        if (!appSelectors.isClientStation()) {
            LoadThemeService.start();
        }

        VisibilityService.start();
        PushNotifications.setup();

        if (config.appId === 'desktop') {
            getStore().dispatch(insightsActions.startSubscription());
        }
    });
}

storeSetupPromise.then(() => {
    if (appSelectors.isClientStation()) {
        // Due to limitations in the client station IE web view,
        // force MouseInput events
        initOpenUI({ inputClass: Hammer.MouseInput });
    } else {
        initOpenUI();
    }

    if (isXwcMaster && config.appId !== 'view') {
        const whenSetup = commonSetup().then(() => {
            if (config.appId === 'desktop') {
                WorkspaceSettingsService.start();
            }
        });

        // init session dialogs and env bootstrapping
        sessionManager.start();

        const splashController = config.appId === 'desktop' ? new SplashController() : new SkipOnboardingSplashController();
        const whenOnboarded = splashController.doOnboarding();

        Promise.all([whenSetup, whenOnboarded]).then(() => {
            const mainAppController = new MainApp();

            Promise.all([splashController.readyToReveal(), mainAppController.whenReady()]).then(([revealCallback]) => {
                revealCallback();
            });
        });
    } else {
        commonSetup().then(() => {
            new ViewApp();
        });
    }
}).catch((e) => {
    log.error('Error starting app', e);
});
