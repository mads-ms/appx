import DateTime from 'src/modules/dateTime';
import { registerTypeSerializer } from 'src/xwc/session/xwcMessageFactories';

// DateTime has a feature where it can be passed as a parameter to the shared library
// which will use it correctly because the toString implementation returns a string
// which is compatible with open api.
// in order for popups to make calls to the xwc proxied open api in the same way, we must
// serialize those date times before they are converted to json, losing any prototype methods.
// This is done here rather than as part of xwc in order for xwc to be usable without dateTime's
// dependencies
registerTypeSerializer({
    isInstance(object) {
        return DateTime.isInstance(object);
    },
    serialize(dateTime) {
        return dateTime.toString();
    },
});
