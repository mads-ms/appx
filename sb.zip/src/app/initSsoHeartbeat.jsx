import $ from 'jqueryAll';
import SsoHeartbeat from 'src/modules/app/ssoHeartbeat';
import React from 'react';
import ReactDOM from 'react-dom';

$(() => {
    const heartbeatContainer = $('<div>').appendTo(document.body).hide()[0];
    ReactDOM.render(<SsoHeartbeat/>, heartbeatContainer);
});
