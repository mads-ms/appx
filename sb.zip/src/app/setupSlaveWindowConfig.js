import config from 'src/config';
import proShellCommunication from 'src/proShellCommunication';

function sendSlaveWindowConfiguration() {
    proShellCommunication.send(proShellCommunication.messageIds.toShell.SET_SLAVE_WINDOW_CONFIGURATION, {
        language: document.documentElement.getAttribute('lang'),
        languageDirection: document.documentElement.getAttribute('dir'),
        config,
        dataSetupScriptUrl: config.pro.slaveDataSetupScriptUrl,
        appScriptUrl: config.pro.slaveAppScriptUrl,
        devToolsScriptUrl: config.pro.devToolsScriptUrl,
        isTrafficLightsEnabled: proShellCommunication.capability('trafficLights', false),
    });
}

/*
 * Send the slave window configuration as early as possible so that slave windows can start to be created, before the
 * data setup has started.
 */
sendSlaveWindowConfiguration();

proShellCommunication.on(proShellCommunication.messageIds.fromShell.GET_SLAVE_WINDOW_CONFIGURATION, sendSlaveWindowConfiguration);
