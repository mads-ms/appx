import 'src/app/initNativePhoneInterface';
import config from 'src/config';

describe('src/app/initNativePhoneInterface', function() {

    it('adds a global object', function() {
        expect(window.native).toBeDefined();
    });

    it('includes a isTouchIdEnabled', function() {
        expect(window.native.isTouchIdEnabled).toEqual(jasmine.any(Function));
        config.appFeatures.isTouchIdEnabled = true;
        expect(window.native.isTouchIdEnabled()).toEqual(true);
        config.appFeatures.isTouchIdEnabled = false;
        expect(window.native.isTouchIdEnabled()).toEqual(false);
    });
});
