/**
 * Data setup for an app with normal default open api and xwc setup
 * The master part means that it will be the window communicating with open api.
 */

import openApiFactory from 'src/modules/openApi/openApiFactory';
import getOpenApi, { setOpenApi } from 'src/modules/openApi';
import * as dataSetup from 'src/app/dataSetup';
import { getXwcManager } from 'src/xwc/xwcDesktopManager';
import XwcSpineEvents from 'src/xwc/xwcSpineEvents';
import { setupMasterStore } from 'src/xwc/redux/xwcStoreSetup';

export default function initMaster(dataSetupOptions) {
    // sets up spine events for either master or slave scenario
    const xwcSpineEvents = XwcSpineEvents.getInstance();

    // we are master, so create open api proper
    setOpenApi(openApiFactory());

    // sets up redux so that events get forwarded to sub windows
    const masterReduxStore = setupMasterStore();

    // when a slave request comes in, register the services the slave might require
    getXwcManager().on('slaveAck', (evt) => {
        xwcSpineEvents.setupOnSession(evt.session);

        evt.session.registerService('openApi', getOpenApi());
        evt.session.registerService('reduxStore', masterReduxStore);
    });
    dataSetup.start(dataSetupOptions);
}
