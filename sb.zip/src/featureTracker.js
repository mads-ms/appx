import _ from 'lodash';
import getOpenApi from 'src/modules/openApi';
import DateTime from 'src/modules/dateTime';
import Enums from 'src/spine/enums';
import config from 'src/config';

/*
 * Constants
 */

const SEND_TO_SERVER_INTERVAL_MS = 20000;

/**
 * Feature area constants
 */
export const AREA_STARTUP = 'Startup';
export const AREA_INSTRUMENT_FINDER = 'InstrumentFinder';
export const AREA_WATCHLISTS = 'Watchlists';
export const AREA_PRICE_ALERTS = 'PriceAlerts';
export const AREA_SAXOSELECT = 'SaxoSelect';
export const AREA_TRADING_OVERVIEW = 'TradingOverview';
export const AREA_CHARTS = 'Charts';
export const AREA_FINANCIAL_CALENDAR = 'FinancialCalendar';
export const AREA_NEWS = 'News';
export const AREA_OPINIONS = 'Opinions';
export const AREA_TRADE_TICKET = 'TradeTicket';
export const AREA_POSITIONS = 'Positions';
export const AREA_ORDERS = 'Orders';
export const AREA_STRATEGIES = 'Strategies';
export const AREA_PLATFORM_SETTINGS = 'PlatformSettings';
export const AREA_ACCOUNT_TOOLBAR = 'AccountToolBar';
export const AREA_MARKET_OVERVIEW_EQ = 'MarketOverviewEq';
export const AREA_NETTING = 'Netting';
export const AREA_OPTIONS_CHAIN = 'OptionsChain';
export const AREA_CLOSE_POSITION = 'Close Position';
export const AREA_CLOSED_POSITIONS = 'Closed Positions';
export const AREA_TRADE_SIGNALS = 'TradeSignals';
export const AREA_STANDARD_REPORTS = 'Standard Reports';
export const AREA_DEPOSIT_AND_TRANSFER = 'Deposit and Transfer';
export const AREA_OTHER = 'Other';
export const AREA_BOOKINGS = 'Cash Movements Report';
export const AREA_PERF_OVERVIEW = 'Performance Overview';
export const AREA_CLOSED_POSITIONS_REPORT = 'Closed Positions Report';
export const AREA_PROFIT_LOSS = 'Profit/Loss Report';
export const AREA_PORTFOLIO = 'Portfolio';
export const AREA_ACCOUNT_STATEMENT = 'Account Statement';
export const AREA_REPORT_EXPORT = 'Report Export';
export const AREA_MARGIN_ALERT = 'Margin Alert';

/**
 * Array of next events to log
 */
const featureEvents = [];

/**
 * Logs a feature event
 * @param featureArea {String} The feature area - see constants above (white list enum on the server side)
 * @param featureEvent {String} Name of the actual event
 * @param additionalData {Object=} AdditionalData is a optional custom list of keys and values
 */
export function logEvent(featureArea, featureEvent, additionalData) {
    if (featureArea && featureEvent) {
        featureEvents.push({
            FeatureArea: featureArea,
            FeatureEvent: featureEvent,
            EventDateTime: DateTime.now(),
            AdditionalData: _.assign({}, additionalData, {
                appName: config.appId,
            }),
        });
    }
}

/**
 * Logs a QuickTrade event
 * @param featureArea {String} The feature area - see constants above (white list enum on the server side)
 * @param featureEvent {String} Name of the actual event
 * @param tradeModel {Object=} A trade model object that provides the context for the event - required!
 * @param additionalData {Object=} AdditionalData is a optional custom list of keys and values
 */
export function logQuickTradeEvent(featureArea, featureEvent, tradeModel, additionalData) {
    const instrument = tradeModel.Instrument;

    if (!instrument.isQuickTradeEnabled()) {
        return;
    }

    logEvent(featureArea, featureEvent, _.assign({
        positionId: tradeModel.PositionId || tradeModel.NetPositionId || 'none',
        uic: instrument.uic,
        instrumentType: instrument.instrumentType,
        symbol: instrument.symbol,
        priceToleranceType: Enums.PriceToleranceType.toString(tradeModel.PriceToleranceType),
        priceToleranceValue: tradeModel.PriceToleranceValue,
    }, additionalData));
}

/**
 * Send the queue of events to open api
 */
function sendEvents() {
    if (featureEvents.length) {
        getOpenApi().rest.post('vas', 'v1/featuretracking/events', null, { body: featureEvents.slice(0) });
        featureEvents.length = 0;
    }
}

setInterval(sendEvents, SEND_TO_SERVER_INTERVAL_MS);
