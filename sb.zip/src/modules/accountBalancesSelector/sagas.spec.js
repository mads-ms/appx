import * as accountBalancesSagas from 'src/modules/accountBalancesSelector/sagas';
import * as accountsConstants from 'src/modules/accounts/constants';

describe('src/modules/accountBalancesSelector/sagas', () => {

    it('should combine account and client balances', () => {

        const accountBalances = [
            {
                EndBalance: 1500,
                EndEquity: 1800,
                StartEquity: 700,
            },
            {
                EndBalance: 2800,
                EndEquity: 1900,
                StartEquity: 1700,
            },
        ];
        const clientBalances = [
            {
                EndBalance: 1800,
                EndEquity: 2600,
                StartEquity: 900,
            },
            {
                EndBalance: 2800,
                EndEquity: 3200,
                StartEquity: 2700,
            },
        ];

        const result = accountBalancesSagas.createCombinedBalances({ accountBalances, clientBalances });

        expect(result).toEqual([
            {
                EndBalance: 1500,
                EndEquity: 1800,
                StartEquity: 700,
            },
            {
                EndBalance: 2800,
                EndEquity: 1900,
                StartEquity: 1700,
            },
            {
                AccountId: accountsConstants.SUMMARY_ACCOUNT_ID,
                EndBalance: 4600,
                EndEquity: 5800,
                StartEquity: 3600,
            },
        ]);
    });
});
