import { connect } from 'react-redux';
import * as accountBalancesSelectors from '../selectors';
import AccountDetails from './accountDetails';

function mapStateToProps() {

    const getAccountSummary = accountBalancesSelectors.createGetAccountSummary();

    return (state, ownProps) => {
        const { componentId } = ownProps;

        return {
            accountDetails: getAccountSummary(state, componentId),
        };
    };
}

export default connect(mapStateToProps)(AccountDetails);
