import $ from 'jqueryAll';
import React from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';
import AccountDetailsViewController from 'spine/commonViewControllers/accountDetails';

class AccountDetails extends React.PureComponent {
    constructor(props) {
        super(props);

        this.accountDetailsViewController = new AccountDetailsViewController();
    }

    componentDidMount() {
        this.accountDetailsViewController.render(this.props.accountDetails);
        $(ReactDOM.findDOMNode(this)).append(this.accountDetailsViewController.el);
    }

    componentWillReceiveProps(nextProps) {
        this.accountDetailsViewController.update(nextProps.accountDetails);
    }

    componentWillUnmount() {
        this.accountDetailsViewController.release();
    }

    render() {
        return (<div className="grid"></div>);
    }
}

AccountDetails.propTypes = {
    accountDetails: PropTypes.object.isRequired,
};

export default AccountDetails;
