import { connect } from 'react-redux';
import AccountBalancesSelector from './accountBalancesSelector';
import * as accountsSelectors from 'src/modules/accounts/selectors';
import * as clientSelectors from 'src/modules/clients/selectors';
import * as accountBalancesSelectors from './selectors';
import * as accountBalancesSelectorActions from './actions';
import * as balancesActions from 'src/modules/balances/actions';

function mapStateToProps(state, ownProps) {
    const { componentId } = ownProps;
    let accountId;

    // if instance already initialised respect the cached value, else see if a
    // parent component is passing-in an AccountId.
    accountId = accountBalancesSelectors.getComponentState(state, componentId).accountId || ownProps.accountId;

    // if the accountId is still false use the default account for the client
    if (!accountId) {
        accountId = clientSelectors.getClientDefaultAccountId(state);
    }

    return {
        componentId,
        account: accountsSelectors.getAccountById(state, accountId),
        isSingleAccount: accountsSelectors.isSingleAccount(state),
        hasAccountDetails: accountBalancesSelectors.hasAccountDetails(state, componentId),
    };
}

const mapDispatchToProps = {
    onMount: accountBalancesSelectorActions.initialize,
    onChangeDate: accountBalancesSelectorActions.setDate,
    onSetAccount: accountBalancesSelectorActions.setAccount,
    onAddBalancesListener: balancesActions.addListener,
    onRemoveBalancesListener: balancesActions.removeListener,
};

export default connect(mapStateToProps, mapDispatchToProps)(AccountBalancesSelector);
