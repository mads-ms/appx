import _ from 'lodash';
import DateTime from 'src/modules/dateTime';
import * as accountBalancesSelectorActionTypes from './actionTypes';
import * as moduleTypes from 'src/modules/workspace/moduleTypes';
import { createComponentReducer } from 'src/utils/createComponentReducer';

export const initialComponentState = {

    // the date to display the balances for
    date: DateTime.now().toOapi(),

    // array of historic balance data returned from OAPI
    historicBalances: [],

    // used to compute interday change as not available from OAPI
    previousDayBalances: {},

    accountDetails: [],
    accountId: null,
    showClient: true,
    showGroups: true,
};

export default createComponentReducer(moduleTypes.ACCOUNT_BALANCES_SELECTOR, (componentState = initialComponentState, action) => {
    switch (action.type) {

        case accountBalancesSelectorActionTypes.INITIALIZE:
            return handleInitialize(componentState, action);

        case accountBalancesSelectorActionTypes.SET_ACCOUNT:
            return handleSetAccount(componentState, action);

        case accountBalancesSelectorActionTypes.SET_HISTORIC_BALANCES:
            return handleSetHistoricBalances(componentState, action);

        case accountBalancesSelectorActionTypes.SET_PREVIOUS_DAY_BALANCES:
            return handleSetPreviousDayBalances(componentState, action);

        case accountBalancesSelectorActionTypes.SET_DATE:
            return handleSetDate(componentState, action);

        default:
            return componentState;
    }
});

function handleInitialize(componentState, action) {
    return _.defaults({
        accountId: action.accountId,
        showClient: action.showClient,
        showGroups: action.showGroups,
    }, componentState);
}

function handleSetAccount(componentState, action) {
    return _.defaults({
        accountId: action.accountId,
    }, componentState);
}

function handleSetHistoricBalances(componentState, action) {
    return _.defaults({
        historicBalances: action.historicBalances,
    }, componentState);
}

function handleSetPreviousDayBalances(componentState, action) {
    return _.defaults({
        previousDayBalances: action.previousDayBalances,
    }, componentState);
}

function handleSetDate(componentState, action) {
    return _.defaults({
        date: action.date,
    }, componentState);
}
