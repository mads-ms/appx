import AccountBalancesSelector from './container';

export default AccountBalancesSelector;
