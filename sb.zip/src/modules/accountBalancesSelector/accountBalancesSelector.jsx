import _ from 'lodash';
import React from 'react';
import classNames from 'classnames';
import PropTypes from 'prop-types';
import Localization from 'src/localization';
import Button from 'src/components/button/button';
import Dialog from 'src/components/dialog/dialog';
import AccountList from './accountList/container';
import Icon from 'src/components/icon/icon';
import AccountDetails from './accountDetails/container';
import { bindHandlers } from 'src/utils/bindHandlers';
import * as featureTracker from 'src/featureTracker';
import 'src/modules/balances/sagas';
import config from 'src/config';

class AccountBalancesSelector extends React.PureComponent {
    constructor(props) {
        super(props);

        this.state = {
            isAccountListVisible: false,
            isAccountDetailsVisible: false,
        };

        this.handleSetInfoBtnEl = (ref) => {
            this.infoBtnEl = ref;
        };

        this.handleSetDropdownEl = (ref) => {
            this.dropdownEl = ref;
        };
    }

    componentDidMount() {
        const {
            onMount,
            componentId,
            accountId,
            showClient,
            showGroups,
            date,
        } = this.props;

        onMount({
            componentId,
            accountId,
            showClient,
            showGroups,
            date,
        });

        // Add global balance listener. Will cause subscription to all available accounts.
        this.props.onAddBalancesListener(componentId);
    }

    componentWillReceiveProps(nextProps) {

        // triggers fetch of historical balances for past dates
        if (nextProps.date !== this.props.date) {
            this.props.onChangeDate({
                componentId: this.props.componentId,
                date: nextProps.date,
            });
        }
    }

    componentWillUnmount() {
        // Remove global balance listener. Will cause subscription to all available accounts.
        this.props.onRemoveBalancesListener(this.props.componentId);
    }

    handleAccountChanged(accountId) {
        const {
            onSetAccount,
            onSelect,
            featureArea,
        } = this.props;

        onSetAccount({
            componentId: this.props.componentId,
            accountId,
        });

        onSelect(accountId);

        this.handleDialogHide();

        if (featureArea) {
            featureTracker.logEvent(featureArea, 'Account changed', {
                accountId,
                sessionId: config.sessionId,
            });
        }
    }

    handleInfoTap() {
        this.setState({
            isAccountDetailsVisible: !this.state.isAccountDetailsVisible,
        });
    }

    handleAccountDetailsHide() {
        this.setState({ isAccountDetailsVisible: false });
    }

    handleToggleDropdown() {
        this.setState({ isAccountListVisible: !this.state.isAccountListVisible });
    }

    handleDialogHide() {
        this.setState({ isAccountListVisible: false });
    }

    render() {
        const {
            account,
            isSingleAccount,
            showInfoButton,
            componentId,
            showClient,
            showGroups,
            hasAccountDetails,
        } = this.props;

        const {
            isAccountDetailsVisible,
            isAccountListVisible,
        } = this.state;

        if (!account) {
            return null;
        }

        const isWaitingAccountDetails = isAccountDetailsVisible && !hasAccountDetails;

        const wrapperClasses = classNames('grid grid--series', {
            'grid--fit-all': showInfoButton,
        });

        const dropdownClasses = classNames('dropdown select select--alt icon icon--toggle', {
            'is-open': isAccountListVisible,
            'is-disabled': isSingleAccount,
        });

        return (
            <div className={wrapperClasses}>
                <div className="acctselector grid-cell">
                    <div className={dropdownClasses}>
                        <Button
                            className="dropdown-input form-control btn--nocase btn--clear tst-acctselector-dropdown"
                            onDomRef={this.handleSetDropdownEl}
                            onTap={this.handleToggleDropdown}
                            isEnabled={!isSingleAccount}
                        >
                            <div className="acctselector-item list-item" dir="ltr">
                                <div className="grid grid--space">
                                    <div className="grid-cell g--shrink t-truncate">
                                        {account.IsGroup && Localization.getText('HTML5_Account_Group')}
                                        {account.DisplayName}
                                    </div>
                                    <div className="grid-cell">
                                        <span className="acctselector-currency">{account.BaseCurrency}</span>
                                    </div>
                                </div>
                            </div>
                        </Button>
                    </div>
                    {isAccountListVisible && (
                        <Dialog
                            onHide={this.handleDialogHide}
                            anchor={this.dropdownEl}
                            position="bottom"
                        >
                            <AccountList
                                componentId={componentId}
                                onAccountChanged={this.handleAccountChanged}
                                showClient={showClient}
                                showGroups={showGroups}
                            />
                        </Dialog>
                    )}
                </div>

                {showInfoButton && (
                    <div className="grid-cell">
                        <Button
                            className="btn--square"
                            isWaiting={isWaitingAccountDetails}
                            onDomRef={this.handleSetInfoBtnEl}
                            onTap={this.handleInfoTap}
                        >
                            <Icon type="info-alt"/>
                        </Button>
                        {isAccountDetailsVisible && !isWaitingAccountDetails && (
                            <Dialog
                                onHide={this.handleAccountDetailsHide}
                                anchor={this.infoBtnEl}
                                position="bottom"
                            >
                                <AccountDetails componentId={componentId}/>
                            </Dialog>
                        )}
                    </div>
                )}
            </div>
        );
    }
}

AccountBalancesSelector.propTypes = {
    componentId: PropTypes.string.isRequired,
    account: PropTypes.object.isRequired,
    accountId: PropTypes.string.isRequired,
    isSingleAccount: PropTypes.bool.isRequired,
    hasAccountDetails: PropTypes.bool,
    date: PropTypes.string,
    showInfoButton: PropTypes.bool,
    showClient: PropTypes.bool,
    showGroups: PropTypes.bool,
    onMount: PropTypes.func.isRequired,
    onSelect: PropTypes.func,
    onSetAccount: PropTypes.func.isRequired,
    onChangeDate: PropTypes.func,
    onAddBalancesListener: PropTypes.func.isRequired,
    onRemoveBalancesListener: PropTypes.func.isRequired,
    featureArea: PropTypes.string,
};

AccountBalancesSelector.defaultProps = {
    showClient: true,
    showGroups: true,
    onSelect: _.noop,
    onChangeDate: _.noop,
};

export default bindHandlers(AccountBalancesSelector);
