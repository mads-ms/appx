export const TRIGGER_SET_ACCOUNT = 'sagas/accountBalances/setAccount';
export const TRIGGER_INITIALIZE = 'sagas/accountBalances/initialize';
export const TRIGGER_SET_DATE = 'sagas/accountBalances/setDate';

export const SET_ACCOUNT = 'accountBalances/setAccount';
export const SET_BALANCES = 'accountBalances/setBalances';
export const SET_DATE = 'accountBalances/setDate';
export const SET_HISTORIC_BALANCES = 'accountBalances/setHistoricBalances';
export const SET_PREVIOUS_DAY_BALANCES = 'accountBalances/set-previous-day-balances';
export const GET_ACCOUNTS_DETAILS = 'accountBalances/getAccountsDetails';
export const SET_LAST_BALANCES_UPDATE = 'accountBalances/setLastBalancesUpdate';
export const INITIALIZE = 'accountBalances/initialize';
