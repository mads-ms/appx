import * as accountBalancesSelectorActionTypes from './actionTypes';
import * as moduleLifecycleActions from 'src/modules/moduleLifecycle/actions';
import * as moduleTypes from 'src/modules/workspace/moduleTypes';
import './sagas';

export function initialize({ componentId, accountId, showClient, showGroups, date }) {
    return (dispatch) => {
        dispatch(moduleLifecycleActions.create(moduleTypes.ACCOUNT_BALANCES_SELECTOR, componentId));

        dispatch({
            type: accountBalancesSelectorActionTypes.TRIGGER_INITIALIZE,
            componentId,
            accountId,
            showClient,
            showGroups,
            date,
        });
    };
}

export function setAccount({ componentId, accountId, date, includeClient }) {
    return {
        type: accountBalancesSelectorActionTypes.TRIGGER_SET_ACCOUNT,
        componentId,
        accountId,
        date,
        includeClient,
    };
}

export function setDate({ componentId, date }) {
    return {
        type: accountBalancesSelectorActionTypes.TRIGGER_SET_DATE,
        componentId,
        date,
    };
}
