import _ from 'lodash';
import * as accountBalancesSelectorReducer from './reducer';
import * as accountsSelectors from 'src/modules/accounts/selectors';
import * as balancesSelectors from 'src/modules/balances/selectors';
import DateTime from 'src/modules/dateTime';
import * as accountSummarySelectors from 'src/modules/accountSummary/selectors';
import * as accountConstants from 'src/modules/accounts/constants';
import { createSelector } from 'reselect';

export const getComponentState = (state, componentId) =>
    _.get(state, ['accountBalances', 'components', componentId], accountBalancesSelectorReducer.initialComponentState);

export const getHistoricBalances = createSelector(getComponentState, (componentState) => {
    const { historicBalances } = componentState;

    return _.transform(historicBalances, (result, balance) => {
        const {
            AccountId,
            EndBalance,
            EndEquity,
            StartEquity,
        } = balance;

        result[AccountId] = {
            CashBalance: EndBalance,
            TotalValue: EndEquity,
            UnrealizedPositionsValue: EndEquity - EndBalance,
            AccountValueDayMovement: EndEquity - StartEquity,
            AccountValueDayMovementPct: (EndEquity / StartEquity) - 1,
        };
    }, {});
});

export const getPreviousDayBalances = (state, componentId) =>
    _.get(getComponentState(state, componentId), 'previousDayBalances');

export const getAccountId = (state, componentId) =>
    _.get(getComponentState(state, componentId), 'accountId');

export const getDate = (state, componentId) =>
    _.get(getComponentState(state, componentId), 'date');

/**
 * Get the intraday movement for an account
 */
const calculateMovement = (startValue, currentValue, asPct) => {
    let movement;
    if (startValue === 0 && currentValue !== 0) {
        movement = null;
    } else if (startValue === 0 && currentValue === 0) {
        movement = 0;
    } else {
        movement = asPct ? (currentValue / startValue) - 1 : currentValue - startValue;
    }

    return movement;
};

export const getAccountsWithBalances = createSelector(
    accountsSelectors.getAccountsList,
    getHistoricBalances,
    getDate,
    getPreviousDayBalances,
    balancesSelectors.getAllData,
    (accounts, historicBalances, date, previousDayBalances, balancesData) => _.map(accounts, (account) => {
        const {
            id,
            DisplayName,
            BaseCurrency,
            IsSummary,
            IsGroup,
            BaseCurrencyDecimals,
        } = account;

        const historicBalance = historicBalances[id] || {};
        const balance = _.find(balancesData, ['AccountId', account.id]) || {};

        let CashAvailable;
        let TotalValue;
        let DayMovement;
        let DayMovementPct;
        let UnrealizedPositionsValue;

        if (DateTime.isToday(date)) {
            const yesterdaysBalance = _.find(previousDayBalances, ['AccountId', id]) || {};

            CashAvailable = balance.CashBalance + balance.TransactionsNotBooked;
            TotalValue = balance.TotalValue;
            UnrealizedPositionsValue = balance.UnrealizedPositionsValue;
            DayMovement = calculateMovement(yesterdaysBalance.EndEquity, balance.TotalValue, false);
            DayMovementPct = calculateMovement(yesterdaysBalance.EndEquity, balance.TotalValue, true);
        } else {
            CashAvailable = historicBalance.CashBalance;
            TotalValue = historicBalance.TotalValue;
            DayMovement = historicBalance.AccountValueDayMovement;
            DayMovementPct = historicBalance.AccountValueDayMovementPct;
            UnrealizedPositionsValue = historicBalance.UnrealizedPositionsValue;
        }

        return {
            id,
            IsSummary,
            IsGroup,
            DisplayName,
            BaseCurrency,
            BaseCurrencyDecimals,
            CashAvailable,
            TotalValue,
            UnrealizedPositionsValue,
            DayMovement,
            DayMovementPct,
        };
    })
);

export const createGetAccountSummary = () => {
    const getSummary = accountSummarySelectors.createGetSummary();
    return (state, componentId) => {
        const accountId = _.get(getComponentState(state, componentId), 'accountId') || accountConstants.SUMMARY_ACCOUNT_ID;
        return getSummary(state, accountId);
    };
};

export const hasAccountDetails = (state, componentId) => {
    const accountId = _.get(getComponentState(state, componentId), 'accountId') || accountConstants.SUMMARY_ACCOUNT_ID;
    const account = accountsSelectors.getAccountById(state, accountId);
    return balancesSelectors.hasDataByAccount(state, account.id);
};

export const getDefaultAccountId = createSelector(
    accountsSelectors.getAccountsList,
    (accounts) => _.get(_.find(accounts, { IsAccount: true }), 'id')
);
