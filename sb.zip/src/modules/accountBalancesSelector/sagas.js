import _ from 'lodash';
import * as accountBalancesSelectorTypes from './actionTypes';
import { addSagas } from 'src/sagas';
import { put, call, select, takeEvery } from 'redux-tale/effects';
import getOpenApi from 'src/modules/openApi';
import log from 'src/modules/log';
import * as accountBalancesSelectors from './selectors';
import * as accountsSelectors from 'src/modules/accounts/selectors';
import * as accountsConstants from 'src/modules/accounts/constants';
import * as accountBalancesReducer from './reducer';
import DateTime from 'src/modules/dateTime';

function* initialize({ componentId, accountId, showClient, showGroups, date }) {
    yield put({
        type: accountBalancesSelectorTypes.INITIALIZE,
        componentId,
        accountId,
        showClient,
        showGroups,
    });

    if (date) {
        yield setDate({ componentId, date });
    }
}

function* setAccount({ componentId, accountId, date }) {
    const { showClient } = yield select(accountBalancesSelectors.getComponentState, componentId);

    // filter out summary account if not meant to be displayed
    if (!showClient && accountId === accountsConstants.SUMMARY_ACCOUNT_ID) {
        accountId = yield select(accountBalancesSelectors.getDefaultAccountId);
    }

    if (DateTime.isToday(date)) {
        yield getPreviousDaysBalances({ componentId, date, accountId });
    } else {
        yield getHistoricBalances({ componentId, date, accountId });
    }

    yield put({
        type: accountBalancesSelectorTypes.SET_ACCOUNT,
        componentId,
        accountId,
        date,
    });
}

function* setDate({ componentId, date }) {
    const accountId = yield select(accountBalancesSelectors.getAccountId, componentId);
    yield getHistoricBalances({ componentId, date, accountId });

    if (DateTime.isToday(date)) {
        yield getPreviousDaysBalances({ componentId, date, accountId });
    } else {
        yield put({
            type: accountBalancesSelectorTypes.SET_PREVIOUS_DAY_BALANCES,
            componentId,
            previousDayBalances: accountBalancesReducer.initialComponentState.previousDayBalances,
        });
    }

    yield put({
        type: accountBalancesSelectorTypes.SET_DATE,
        componentId,
        date,
    });
}

function* getHistoricBalances({ componentId, date, accountId = accountsConstants.SUMMARY_ACCOUNT_ID }) {
    const historicBalances = yield fetchHistoricBalances({
        date,
        accountId,
    });

    yield put({
        type: accountBalancesSelectorTypes.SET_HISTORIC_BALANCES,
        componentId,
        historicBalances,
    });
}

function* getPreviousDaysBalances({ componentId, date, accountId = accountsConstants.SUMMARY_ACCOUNT_ID }) {
    const yesterday = DateTime.addDays(DateTime.createDate(date), -1).toOapi();

    const previousDayBalances = yield fetchHistoricBalances({
        date: yesterday,
        accountId,
    });

    yield put({
        type: accountBalancesSelectorTypes.SET_PREVIOUS_DAY_BALANCES,
        componentId,
        previousDayBalances,
    });
}

// combines account and client balances (so that currency is preserved for both client and accounts)
export function createCombinedBalances({ accountBalances, clientBalances }) {
    const summaryHistoricBalance = {
        'AccountId': accountsConstants.SUMMARY_ACCOUNT_ID,
        'EndBalance': 0,
        'EndEquity': 0,
        'StartEquity': 0,
    };

    _.forEach(clientBalances, (balance) => {
        summaryHistoricBalance.EndBalance += balance.EndBalance;
        summaryHistoricBalance.EndEquity += balance.EndEquity;
        summaryHistoricBalance.StartEquity += balance.StartEquity;
    });

    return _.concat(accountBalances, summaryHistoricBalance);
}

function* fetchHistoricBalances({ date, accountId }) {
    const account = yield select(accountsSelectors.getAccountById, accountId);

    const {
        ClientKey,
    } = account;

    try {
        const openApi = getOpenApi();

        const [accountRes, clientRes] = yield [
            call([openApi.rest, openApi.rest.get],
                'cs', 'v1/reports/balancesandequities/{ClientKey}/{date}/{date}/?CurrencyType=Account',
                { ClientKey, date }),
            call([openApi.rest, openApi.rest.get],
                'cs', 'v1/reports/balancesandequities/{ClientKey}/{date}/{date}/?CurrencyType=Client',
                { ClientKey, date }),
        ];

        return createCombinedBalances({
            accountBalances: accountRes.response.Data,
            clientBalances: clientRes.response.Data,
        });
    } catch (error) {
        log.error('Failed to get historic data in Portfolio', {
            error,
        });

        return [];
    }
}

addSagas([
    takeEvery(accountBalancesSelectorTypes.TRIGGER_INITIALIZE, initialize),
    takeEvery(accountBalancesSelectorTypes.TRIGGER_SET_ACCOUNT, setAccount),
    takeEvery(accountBalancesSelectorTypes.TRIGGER_SET_DATE, setDate),
]);
