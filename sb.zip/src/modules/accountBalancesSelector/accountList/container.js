import { connect } from 'react-redux';
import * as accountBalancesSelectors from '../selectors';
import AccountList from './accountList';

function mapStateToProps(state, ownProps) {
    return {
        accountDetails: accountBalancesSelectors.getAccountsWithBalances(state, ownProps.componentId),
    };
}

export default connect(mapStateToProps)(AccountList);
