import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import Localization from 'src/localization';
import SheetHeader from 'src/components/sheet/sheetHeader';
import SheetBody from 'src/components/sheet/sheetBody';
import * as numberFormat from 'src/numberFormat';
import Touchable from 'src/components/touchable/touchable';

class AccountList extends React.PureComponent {
    render() {
        const {
            showClient,
            showGroups,
            accountDetails,
        } = this.props;

        return (
            <div className="accountlist sheet sheet--alt grid grid--y grid--fit-fill tst-accountlist">
                <SheetHeader classNAme="grid-cell">
                    {Localization.getText('HTML5_Accounts')}
                </SheetHeader>
                <div className="grid grid--scroll">
                    <SheetBody className="grid-cell">
                        <table className="datagrid datagrid--guide datagrid--selectable">
                            <colgroup>
                                <col style={{ width: '20%' }}/>
                                <col style={{ width: '40px' }}/>
                                <col style={{ width: 'auto' }}/>
                                <col style={{ width: 'auto' }}/>
                                <col style={{ width: 'auto' }}/>
                                <col style={{ width: 'auto' }}/>
                            </colgroup>
                            <thead className="accountlist--datagrid-header tst-accountlist-header">
                                <tr>
                                    <th><p className="t-start">{Localization.getText('HTML5_Account')}</p></th>
                                    <th><p className="t-start">{Localization.getText('HTML5_Ccy')}</p></th>
                                    <th>{Localization.getText('HTML5_CashAvailableHeading')}</th>
                                    <th>{Localization.getText('HTML5_ValueOfPositionsHeading')}</th>
                                    <th>{Localization.getText('HTML5_Account_Value')}</th>
                                    <th>{Localization.getText('HTML5_1DayChange')}</th>
                                </tr>
                            </thead>

                            {_.map(accountDetails, (account, i) => {
                                const handleTap = () => this.props.onAccountChanged(account.id);

                                if (!showClient && account.IsSummary || !showGroups && account.IsGroup) {
                                    return null;
                                }

                                const baseCurrencyDecimals = isNaN(account.BaseCurrencyDecimals) ? 2 : account.BaseCurrencyDecimals;

                                return (
                                    <Touchable onTap={handleTap} key={i}>
                                        <tbody className="tst-accountlist-row">
                                            <tr className={account.IsGroup ? 'datagrid-section' : ''}>
                                                <td>
                                                    <p title={account.DisplayName} className="t-start">{account.DisplayName}</p>
                                                </td>
                                                <td>
                                                    <p className="t-start">{account.BaseCurrency}</p>
                                                </td>
                                                <td>{numberFormat.formatPrice(account.CashAvailable, baseCurrencyDecimals)}</td>
                                                <td>{numberFormat.format(account.UnrealizedPositionsValue, baseCurrencyDecimals)}</td>
                                                <td>{numberFormat.formatPrice(account.TotalValue, 0)}</td>
                                                <td>{account.IsGroup ? null : numberFormat.formatPercentageRatio(account.DayMovementPct, 1)}</td>
                                            </tr>
                                        </tbody>
                                    </Touchable>
                                );
                            })}
                        </table>
                    </SheetBody>
                </div>
            </div>
        );
    }
}

AccountList.propTypes = {
    accountDetails: PropTypes.arrayOf(PropTypes.object).isRequired,
    showClient: PropTypes.bool,
    showGroups: PropTypes.bool,
    onAccountChanged: PropTypes.func.isRequired,
};

AccountList.defaultProps = {
    showClient: true,
    showGroups: true,
};

export default AccountList;
