import _ from 'lodash';
import Localization from 'src/localization';

const STRATEGY_LABELS = {
    Iceberg: Localization.getText('HTML5_AlgoStrategy_Iceberg'),
    ImplementationShortfall: Localization.getText('HTML5_AlgoStrategy_ImplementationShortfall'),
    Reload: Localization.getText('HTML5_AlgoStrategy_Reload'),
    TWAP: Localization.getText('HTML5_AlgoStrategy_TWAP'),
    VWAP: Localization.getText('HTML5_AlgoStrategy_VWAP'),
    WithVolume: Localization.getText('HTML5_AlgoStrategy_WithVolume'),
    NordicMID: Localization.getText('HTML5_AlgoStrategy_NordicMid'),
    PreMarketLimit: Localization.getText('HTML5_AlgoStrategy_PreMarketLimit'),
    AfterMarketLimit: Localization.getText('HTML5_AlgoStrategy_AfterMarketLimit'),
    Primary: Localization.getText('HTML5_AlgoStrategy_Primary'),
    FrontArenaHedging: Localization.getText('HTML5_AlgoStrategy_FrontArenaHedging'),
    MOC: Localization.getText('HTML5_AlgoStrategy_MOC'),
    IEX: Localization.getText('HTML5_AlgoStrategy_IEX'),
    ArrivalPrice: Localization.getText('HTML5_AlgoStrategy_ArrivalPrice'),
    Close: Localization.getText('HTML5_AlgoStrategy_Close'),
    Dagger: Localization.getText('HTML5_AlgoStrategy_Dagger'),
    DarkSeek: Localization.getText('HTML5_AlgoStrategy_DarkSeek'),
    StopPOV: Localization.getText('HTML5_AlgoStrategy_StopPOV'),
    Dark: Localization.getText('HTML5_AlgoStrategy_Dark'),
    LiquiditySeeking: Localization.getText('HTML5_AlgoStrategy_LiquiditySeeking'),
};

const PARAM_LABELS = {
    EffectiveTime: Localization.getText('HTML5_AlgoParameters_StartTime'),
    StartTime: Localization.getText('HTML5_AlgoParameters_StartTime'),
    ExpireTime: Localization.getText('HTML5_AlgoParameters_EndTime'),
    EndTime: Localization.getText('HTML5_AlgoParameters_EndTime'),
    ParticipationRate: Localization.getText('HTML5_AlgoParameters_MaxParticipationRate'),
    MaxParticipationRate: Localization.getText('HTML5_AlgoParameters_MaxParticipationRate'),
    InOpenAuction: Localization.getText('HTML5_AlgoParameters_InOpenAuction'),
    InCloseAuction: Localization.getText('HTML5_AlgoParameters_InCloseAuction'),
    TriggerPx: Localization.getText('HTML5_AlgoParameters_IWouldPrice'),
    IWouldPrice: Localization.getText('HTML5_AlgoParameters_IWouldPrice'),
    MaxFloor: Localization.getText('HTML5_AlgoParameters_DisplayQuantity'),
    DisplayQuantity: Localization.getText('HTML5_AlgoParameters_DisplayQuantity'),
    MinQty: Localization.getText('HTML5_AlgoParameters_MinQty'),
    Urgency: Localization.getText('HTML5_AlgoParameters_Urgency'),
};

const PARAM_DESCRIPTIONS = {
    EffectiveTime: Localization.getText('HTML5_AlgoParameters_Description_StartTime'),
    StartTime: Localization.getText('HTML5_AlgoParameters_Description_StartTime'),
    ExpireTime: Localization.getText('HTML5_AlgoParameters_Description_EndTime'),
    EndTime: Localization.getText('HTML5_AlgoParameters_Description_EndTime'),
    ParticipationRate: Localization.getText('HTML5_AlgoParameters_Description_MaxParticipationRate'),
    MaxParticipationRate: Localization.getText('HTML5_AlgoParameters_Description_MaxParticipationRate'),
    InOpenAuction: Localization.getText('HTML5_AlgoParameters_Description_InOpenAuction'),
    InCloseAuction: Localization.getText('HTML5_AlgoParameters_Description_InCloseAuction'),
    TriggerPx: Localization.getText('HTML5_AlgoParameters_Description_IWouldPrice'),
    IWouldPrice: Localization.getText('HTML5_AlgoParameters_Description_IWouldPrice'),
    MaxFloor: Localization.getText('HTML5_AlgoParameters_Description_DisplayQuantity'),
    DisplayQuantity: Localization.getText('HTML5_AlgoParameters_Description_DisplayQuantity'),
    MinQty: Localization.getText('HTML5_AlgoParameters_Description_MinQty'),
    Urgency: Localization.getText('HTML5_AlgoParameters_Description_Urgency'),
};

export const getAlgoStrategyText = (name) => STRATEGY_LABELS[_.replace(name, ' ', '')] || name;

export const getAlgoParamNameText = (name) => PARAM_LABELS[name] || name;

export const getAlgoParamDescriptionText = (name) => PARAM_DESCRIPTIONS[name] || name;

export const getSupportedOrderTypesForStrategy = (strategies, strategyName) =>
    _.get(strategies, [strategyName, 'data', 'SupportedOrderTypes']);

export const getSupportedDurationTypesForStrategy = (strategies, strategyName) =>
    _.get(strategies, [strategyName, 'data', 'SupportedDurationTypes']);

export const getTimeAlgoParamOffStateLabel = (paramName) =>
    paramName === 'EffectiveTime' || paramName === 'StartTime' ?
        Localization.getText('HTML5_StartOfTrading') :
        Localization.getText('HTML5_EndOfTrading');
