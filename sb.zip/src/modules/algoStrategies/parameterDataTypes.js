export const INT = 'Int';
export const QUANTITY = 'Qty';
export const PRICE = 'Price';
export const STRING = 'String';
export const TIME = 'UtcTimeStamp';
