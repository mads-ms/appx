import Localization from 'src/localization';

export const OFF_TEXT = Localization.getText('HTML5_Off');
export const OFF_VALUE = 'ALGO_PARAM_IS_OFF';
export const TIME_INPUT_SELECT_TEXT = Localization.getText('HTML5_SelectTime');
export const TIME_INPUT_SELECT_VALUE = 'SelectTime';
export const ALGO_ORDER_FIELD_PREFIX = 'algoOrders';
