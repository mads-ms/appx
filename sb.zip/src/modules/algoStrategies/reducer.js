import _ from 'lodash';
import * as asyncActionStatus from 'src/asyncActionStatus';
import * as actionTypes from './actionTypes';
import * as parameterDataTypes from './parameterDataTypes';
import * as constants from './constants';

export const initialState = {};

function algoStrategies(state = initialState, action) {
    switch (action.type) {
        case actionTypes.FETCH_ALGO_STRATEGY_PENDING:
            return handleFetchPending(state, action);

        case actionTypes.FETCH_ALGO_STRATEGY_SUCCESS:
            return handleFetchSuccess(state, action);

        case actionTypes.FETCH_ALGO_STRATEGY_ERROR:
            return handleFetchError(state, action);
    }

    return state;
}

function handleFetchPending(state, action) {
    return updateItem(state, action.name, {
        status: asyncActionStatus.PENDING,
        error: null,
    });
}

function handleFetchSuccess(state, action) {
    const { name, data } = action;

    const Parameters = _.map(data.Parameters, (paramData) => {
        const {
            DataType,
            IsMandatory,
        } = paramData;

        if (DataType !== parameterDataTypes.STRING) {
            return paramData;
        }

        let { ParameterValues } = paramData;

        ParameterValues = IsMandatory ?
            ParameterValues :
            _.concat({
                Value: constants.OFF_VALUE,
                Name: constants.OFF_TEXT,
            }, ParameterValues);

        return _.defaults({ ParameterValues }, paramData);
    });

    return updateItem(state, name, {
        data: _.defaults({ Parameters }, data),
        status: asyncActionStatus.SUCCESS,
        error: null,
    });
}

function handleFetchError(state, action) {
    const { name, error } = action;

    return updateItem(state, name, {
        status: asyncActionStatus.ERROR,
        error,
    });
}

function updateItem(state, name, params) {
    return _.defaults({
        [name]: _.defaults(params, state[name]),
    }, state);
}

export default algoStrategies;
