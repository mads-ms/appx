export const TRIGGER_ALGO_STRATEGIES_FETCH = 'algo-strategies/trigger-algo-strategies-fetch';
export const FETCH_ALGO_STRATEGY_PENDING = 'algo-strategies/fetch-algo-strategy-pending';
export const FETCH_ALGO_STRATEGY_SUCCESS = 'algo-strategies/fetch-algo-strategy-success';
export const FETCH_ALGO_STRATEGY_ERROR = 'algo-strategies/fetch-algo-strategy-error';
