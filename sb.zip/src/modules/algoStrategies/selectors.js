import _ from 'lodash';
import * as asyncActionStatus from 'src/asyncActionStatus';

const DEFAULT_PARAMETERS = [];

export const getStrategies = (state) => state.algoStrategies;

export const getStrategy = (state, name) => _.get(getStrategies(state), name);

export const isStrategyFetchPending = (state, name) =>
    _.get(getStrategy(state, name), 'status') === asyncActionStatus.PENDING;

export const isStrategyFetchFailed = (state, name) =>
    _.get(getStrategy(state, name), 'status') === asyncActionStatus.ERROR;

export const isStrategyFetchComplete = (state, name) => !isStrategyFetchPending(state, name);

export const getStrategyData = (state, name) => _.get(getStrategy(state, name), 'data');

export const getParameters = (state, name) => _.get(getStrategyData(state, name), 'Parameters', DEFAULT_PARAMETERS);

export const getParameter = (state, name, paramName) => _.find(getParameters(state, name), { Name: paramName });
