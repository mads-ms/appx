import _ from 'lodash';
import SagaTester from 'redux-tale/tester';
import mockPromiseHelper from 'test/mocks/mockPromiseHelper';
import * as asyncActionStatus from 'src/asyncActionStatus';
import * as actions from 'src/modules/algoStrategies/actions';
// eslint-disable-next-line import/default
import rewire, * as sagas from 'src/modules/algoStrategies/sagas';
import reducer from 'src/modules/algoStrategies/reducer';
import * as parameterDataTypes from 'src/modules/algoStrategies/parameterDataTypes';
import * as algoStrategiesConstants from 'src/modules/algoStrategies/constants';
import strategyWithVolumeData from 'test/mocks/data/algoStrategies/strategyWithVolume.json';
import strategyImplementationShortfallData from 'test/mocks/data/algoStrategies/strategyImplementationShortfall.json';

const addOffStateToParams = ({ Parameters }) => _.map(Parameters, (paramData) => {
    const {
        DataType,
        IsMandatory,
    } = paramData;

    if (DataType !== parameterDataTypes.STRING) {
        return paramData;
    }

    let { ParameterValues } = paramData;

    ParameterValues = IsMandatory ?
        ParameterValues :
        _.concat({
            Value: algoStrategiesConstants.OFF_VALUE,
            Name: algoStrategiesConstants.OFF_TEXT,
        }, ParameterValues);

    return _.defaults({ ParameterValues }, paramData);
});

describe('src/modules/algoStrategies/sagas', () => {
    const strategyNames = ['Implementation Shortfall', 'With Volume'];
    const updatedStrategyWithVolumeData = _.defaults({
        Parameters: addOffStateToParams(strategyWithVolumeData),
    }, strategyWithVolumeData);
    const updatedStrategyImplementationShortfallData = _.defaults({
        Parameters: addOffStateToParams(strategyImplementationShortfallData),
    }, strategyImplementationShortfallData);

    mockPromiseHelper.use();

    describe('when no strategy is fetched', () => {
        beforeEach(() => {
            rewire.__Rewire__('getOpenApi', () => ({
                rest: {
                    get: (ref, url, params) => {
                        const { name } = params;
                        switch (name) {
                            case strategyNames[0]:
                                return Promise.resolve({ response: strategyImplementationShortfallData });

                            case strategyNames[1]:
                                return Promise.resolve({ response: strategyWithVolumeData });
                        }

                        return Promise.resolve({});
                    },
                },
            }));
        });

        afterEach(() => {
            rewire.__ResetDependency__('getOpenApi');
        });

        it('check if request is send and data is fetched', () => {
            const sagaTester = new SagaTester({
                intialState: {},
                reducers: { algoStrategies: reducer },
            });

            sagaTester.start(sagas.fetchAlgoStrategiesSaga);
            sagaTester.dispatch(actions.triggerAlgoStrategiesFetch(strategyNames));
            mockPromiseHelper.tick();
            sagaTester.dispatch(actions.triggerAlgoStrategiesFetch(strategyNames));
            const calledActions = sagaTester.getCalledActions();

            expect(calledActions[0]).toEqual(actions.triggerAlgoStrategiesFetch(strategyNames));
            expect(calledActions[1]).toEqual(actions.fetchAlgoStrategyPending(strategyNames[0]));
            expect(calledActions[2]).toEqual(actions.fetchAlgoStrategyPending(strategyNames[1]));
            expect(calledActions[3]).toEqual(actions.fetchAlgoStrategySuccess(strategyNames[0], strategyImplementationShortfallData));
            expect(calledActions[4]).toEqual(actions.fetchAlgoStrategySuccess(strategyNames[1], strategyWithVolumeData));

            const algoStrategiesState = sagaTester.getState().algoStrategies;

            expect(algoStrategiesState[strategyNames[0]].status).toEqual(asyncActionStatus.SUCCESS);
            expect(algoStrategiesState[strategyNames[0]].error).toEqual(null);
            expect(algoStrategiesState[strategyNames[0]].data).toEqual(updatedStrategyImplementationShortfallData);
            expect(algoStrategiesState[strategyNames[1]].status).toEqual(asyncActionStatus.SUCCESS);
            expect(algoStrategiesState[strategyNames[1]].error).toEqual(null);
            expect(algoStrategiesState[strategyNames[1]].data).toEqual(updatedStrategyWithVolumeData);

            expect(calledActions[5]).toEqual(actions.triggerAlgoStrategiesFetch(strategyNames));
            expect(calledActions.length).toEqual(6);
        });
    });
});
