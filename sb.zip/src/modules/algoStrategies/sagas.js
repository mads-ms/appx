import _ from 'lodash';
import { addSagas } from 'src/sagas';
import { put, select, takeEvery, call } from 'redux-tale/effects';
import * as actions from './actions';
import * as actionTypes from './actionTypes';
import * as selectors from './selectors';
import getOpenApi from 'src/modules/openApi';
import { getLog } from 'src/modules/log';

const log = getLog('algoStrategies.sagas');
const FETCH_STRATEGY_URL = 'v1/algostrategies/{name}';

export function* fetchAlgoStrategies({ names }) {
    yield _.map(names, (name) => call(fetchAlgoStrategy, { name }));
}

export function* fetchAlgoStrategy({ name }) {
    const isPending = yield select(selectors.isStrategyFetchPending, name);
    const isFetched = Boolean(yield select(selectors.getStrategyData, name));

    if (isPending || isFetched) {
        return;
    }

    try {
        yield put(actions.fetchAlgoStrategyPending(name));

        const { response } = yield getOpenApi().rest.get('ref', FETCH_STRATEGY_URL, { name });
        log.debug('algo strategy fetched', name);

        yield put(actions.fetchAlgoStrategySuccess(name, response));
    } catch (error) {
        yield put(actions.fetchAlgoStrategyError(name, error));
    }
}

export const fetchAlgoStrategiesSaga = takeEvery(actionTypes.TRIGGER_ALGO_STRATEGIES_FETCH, fetchAlgoStrategies);

addSagas([
    fetchAlgoStrategiesSaga,
]);
