import * as actionTypes from './actionTypes';
import './sagas';

export function triggerAlgoStrategiesFetch(names) {
    return {
        type: actionTypes.TRIGGER_ALGO_STRATEGIES_FETCH,
        names,
    };
}

export function fetchAlgoStrategyPending(name) {
    return {
        type: actionTypes.FETCH_ALGO_STRATEGY_PENDING,
        name,
    };
}

export function fetchAlgoStrategySuccess(name, data) {
    return {
        type: actionTypes.FETCH_ALGO_STRATEGY_SUCCESS,
        name,
        data,
    };
}

export function fetchAlgoStrategyError(name, error) {
    return {
        type: actionTypes.FETCH_ALGO_STRATEGY_ERROR,
        name,
        error,
    };
}
