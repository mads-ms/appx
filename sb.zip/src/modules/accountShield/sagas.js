import { put, takeEvery } from 'redux-tale/effects';
import { addSagas } from 'src/sagas';
import getOpenApi from 'src/modules/openApi';
import log from 'src/modules/log';
import * as actionTypes from './actionTypes';
import * as constants from './constants';
import * as accountsSubscriptionConfig from 'src/modules/accountsSubscription/config';
import * as accountGroupsActionTypes from 'src/modules/accounts/accountGroups/actionTypes';
import * as accountsActionTypes from 'src/modules/accounts/actionTypes';
import * as clientActionTypes from 'src/modules/clients/actionTypes';
import * as subscriptionsUpdateTypes from 'src/modules/subscriptions/sagas/updateTypes';
import * as subscriptionsActions from 'src/modules/subscriptions/actions';

function* setAccountShield({ componentId, account, value }) {
    const accountKey = account.AccountKey;
    const accountId = account.AccountId;
    const clientKey = account.ClientKey;

    /**
     * Determines account type for the Account Value Shield to determine which endpoint to use
     */

    let url;

    if (account.IsSummary) {
        url = 'v1/clients/me';
    } else if (account.IsGroup) {
        url = `v1/accountgroups/${accountKey}?ClientKey=${clientKey}`;
    } else {
        url = `v1/accounts/${accountKey}`;
    }

    try {
        yield getOpenApi()
            .rest
            .patch('port', url, null, { body: { AccountValueProtectionLimit: value } });

        yield put({
            type: actionTypes.UPDATE_ACCOUNT_SHIELD,
            componentId,
            isShown: false,
            isUpdating: false,
        });

        if (account.IsGroup) {
            yield put({
                type: accountGroupsActionTypes.UPDATE_ACCOUNT_GROUPS,
                AccountGroupKey: accountKey,
                AccountValueProtectionLimit: value,
            });
        } else if (account.IsSummary) {
            yield put({
                type: clientActionTypes.SET_ACCOUNT_SHIELD,
                AccountValueProtectionLimit: value,
            });
        } else {

            /**
             * AccountValueProtectionLimit is updated directly in the subscription state so we don't have to wait for openApi
             * this allows us to fetch the data from one source and ensure that new data from openApi will be reflected in the UI
             * - Note: Account data resides in two places in our redux state, therefore we dispatch two actions to keep them synchronized
             */
            yield put(subscriptionsActions.update(accountsSubscriptionConfig.TYPE, [{
                data: { [accountId]: { AccountValueProtectionLimit: value } },
                id: accountsSubscriptionConfig.TYPE,
                subscriptionType: accountsSubscriptionConfig.TYPE,
                type: subscriptionsUpdateTypes.DELTA,
            }]));
            yield put({
                type: accountsActionTypes.SET_ACCOUNT_SHIELD,
                accountId,
                AccountValueProtectionLimit: value,
            });
        }
    } catch (error) {
        yield put({
            type: actionTypes.SET_STATUS,
            componentId,
            status: constants.STATUS_WARNING,
        });
        const errorMessage = 'Saving account value shield failed';
        log.error(errorMessage, error);
    }
}

export const onSetAccountShieldSagas = takeEvery(
    actionTypes.TRIGGER_SET_ACCOUNT_SHIELD,
    setAccountShield
);

addSagas([
    onSetAccountShieldSagas,
]);
