import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { bindHandlers } from 'src/utils/bindHandlers';
import Localization from 'src/localization';
import * as numberFormat from 'src/numberFormat';
import * as constants from './constants';
import * as util from 'src/utils/util';
import StatusMessage from 'src/components/statusMessage/statusMessage';
import Sheet from 'src/components/sheet/sheet';
import SheetBody from 'src/components/sheet/sheetBody';
import ProComboInput from 'src/components/proComboInput/proComboInput';
import ProComboInputLabel from 'src/components/proComboInput/proComboInputLabel';
import ProComboInputNumber from 'src/components/proComboInput/proComboInputNumber';
import Button from 'src/components/button/button';
import Icon from 'src/components/icon/icon';

class AccountShield extends React.PureComponent {
    constructor(props) {
        super(props);

        this.state = {
            accountShieldValue: props.account.AccountValueProtectionLimit,
            isAmountFocused: false,
            isAmountValid: true,
            isUpdating: props.isUpdating,
        };
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.account.AccountValueProtectionLimit !== this.props.account.AccountValueProtectionLimit) {
            this.setState({ accountShieldValue: nextProps.account.AccountValueProtectionLimit });
        }

        if (!nextProps.isUpdating) {
            this.setState({ isUpdating: nextProps.isUpdating });
        }

        if (!nextProps.isShown) {
            this.props.onTabClose(this.props.componentId);
        }
    }

    handleSubmitTap() {
        const {
            accountShieldValue,
            isAmountValid,
        } = this.state;

        const {
            account,
            componentId,
            onTabClose,
            onUpdateAccountShield,
        } = this.props;

        if (isAmountValid === false) {
            return;
        }

        if (accountShieldValue === this.props.account.AccountValueProtectionLimit) {
            onTabClose(componentId);
            return;
        }

        this.setState({
            isUpdating: true,
        });

        onUpdateAccountShield(componentId, account, accountShieldValue);
    }

    handleCancelTap() {
        const {
            componentId,
            onTabClose,
            account,
        } = this.props;

        this.setState({
            isUpdating: false,
            accountShieldValue: account.AccountValueProtectionLimit,
        });

        onTabClose(componentId);
    }

    handleAmountFocus() {
        this.setState({
            isAmountFocused: true,
        });
    }

    handleAmountBlur() {
        this.setState({
            isAmountFocused: false,
        });
    }

    handleAmountChange({ value }) {
        this.setAccountShield(value);
    }

    handleAmountIncrement() {
        const { accountShieldValue } = this.state;
        const newAmount = accountShieldValue + constants.INCREMENT_DECREMENT_AMOUNT;

        this.setAccountShield(newAmount);
    }

    handleAmountDecrement() {
        const { accountShieldValue } = this.state;
        const newAmount = Math.max(accountShieldValue - constants.INCREMENT_DECREMENT_AMOUNT, constants.VALUE_MIN);

        this.setAccountShield(newAmount);
    }

    handleInputClear() {
        this.setState({ accountShieldValue: 0 });
    }

    handleStatusMessageClose() {
        this.props.onStatusMessageClose(this.props.componentId);
    }

    setAccountShield(value) {
        this.setState({
            accountShieldValue: value,
            isAmountValid: this.isAmountValid(value),
        });
    }

    isAmountValid(value) {
        return _.isNumber(value) && _.inRange(value, constants.VALUE_MIN, this.props.balance.TotalValue);
    }

    getValidationMessage(value) {
        let validationMessage;

        if (!_.isNumber(value)) {
            validationMessage = {
                message: util.formatString(
                    Localization.getText('HTML5_{0}FieldMustBeANumber'),
                    Localization.getText('HTML5_AccountShield')
                ),
                type: 'error',
            };
        } else if (value < 0) {
            validationMessage = {
                message: util.formatString(
                    Localization.getText('HTML5_{0}FieldMustBeLargerThanZero'),
                    Localization.getText('HTML5_AccountShield')
                ),
                type: 'error',
            };
        } else if (value >= this.props.balance.TotalValue) {
            validationMessage = {
                message: Localization.getText('HTML5_AccountShield_Validation_LargerThanAccountValue'),
                type: 'error',
            };
        }

        return validationMessage;
    }

    render() {
        const {
            status,
            account,
            balance,
        } = this.props;

        const {
            accountShieldValue,
            isAmountValid,
            isAmountFocused,
            isUpdating,
        } = this.state;

        const decimals = _.defaultTo(account.BaseCurrencyDecimals, 2);
        const accountShieldFormatter = (value) => value === 0 ? Localization.getText('HTML5_Off') : numberFormat.formatPrice(value, decimals);

        const validation = isAmountFocused || isAmountValid ?
            undefined : this.getValidationMessage(accountShieldValue);

        const statusMessage = status === constants.STATUS_WARNING ?
            Localization.getText('HTML5_AccountShield_StatusMessage_SaveError') : '';

        return (
            <Sheet className="grid grid--scroll">
                {status &&
                    <StatusMessage isLift type={status} onClose={this.handleStatusMessageClose}>
                        {statusMessage}
                    </StatusMessage>
                }
                <SheetBody className="grid grid--y grid--series grid--fit-all">
                    <ul className=" grid-cell kv kv--wrap kv--lines">
                        <li className="is-highlighted">
                            <p className="kv-val">{account.BaseCurrency}</p>
                            <p className="kv-key">{account.DisplayName}</p>
                        </li>
                        <li>
                            <p className="kv-val">{numberFormat.formatPrice(balance.TotalValue, decimals)}</p>
                            <p className="kv-key">{Localization.getText('HTML5_AccountValue')}</p>
                        </li>
                    </ul>
                    <div className="grid-cell">
                        <ProComboInput validation={validation}>
                            <ProComboInputLabel>
                                {Localization.getText('HTML5_AccountShield')}
                            </ProComboInputLabel>
                            <ProComboInputNumber
                                value={accountShieldValue}
                                formatter={accountShieldFormatter}
                                onFocus={this.handleAmountFocus}
                                onBlur={this.handleAmountBlur}
                                onChange={this.handleAmountChange}
                                onIncrement={this.handleAmountIncrement}
                                onDecrement={this.handleAmountDecrement}
                                hasClear
                                onClear={this.handleInputClear}
                            />
                        </ProComboInput>
                    </div>
                    <div className="grid grid--series">
                        <div className="grid-cell">
                            <Button
                                className="btn--astro btn--large btn--noround"
                                onTap={this.handleCancelTap}
                            >
                                {Localization.getText('HTML5_Cancel')}
                            </Button>
                        </div>
                        <div className="grid-cell">
                            <Button
                                className="btn--primary btn--large btn--noround"
                                onTap={this.handleSubmitTap}
                                isWaiting={isUpdating}
                                loaderAlign="center"
                            >
                                {Localization.getText('HTML5_Submit')}
                            </Button>
                        </div>
                    </div>
                    <div className="grid-cell">
                        <p className="t-meta">
                            <Icon type="info"/>
                            &nbsp;
                            {Localization.getText('HTML5_AccountShield_Footer')}
                        </p>
                    </div>
                </SheetBody>
            </Sheet>
        );
    }
}

AccountShield.propTypes = {
    componentId: PropTypes.string.isRequired,
    account: PropTypes.object.isRequired,
    balance: PropTypes.object.isRequired,
    isUpdating: PropTypes.bool,
    isShown: PropTypes.bool,
    status: PropTypes.string,
    onTabClose: PropTypes.func,
    onUpdateAccountShield: PropTypes.func.isRequired,
    onStatusMessageClose: PropTypes.func.isRequired,
};

AccountShield.defaultProps = {
    isUpdating: false,
    isShown: true,
    status: '',
    onTabClose: _.noop,
};

export default bindHandlers(AccountShield);
