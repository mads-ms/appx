export const SET_STATUS = 'account-shield/set-status';
export const UPDATE_ACCOUNT_SHIELD = 'account-shield/update-account-shield';
export const TRIGGER_SET_ACCOUNT_SHIELD = 'account-shield/trigger-set-account-shield';
