import * as accountShieldSelectors from 'src/modules/accountShield/selectors';

describe('src/modules/accountShield/selectors', () => {
    let state;

    beforeEach(() => {
        state = {
            'accountShield': {
                'trader': {
                    'isUpdating': false,
                    'isShown': true,
                    'status': '',
                },
            },
        };
    });

    it('should return false for isUpdating', () => {
        expect(accountShieldSelectors.isUpdating(state, 'trader')).toEqual(false);
    });

    it('should return true for isShown', () => {
        expect(accountShieldSelectors.isShown(state, 'trader')).toEqual(true);
    });

    it('should return a blank status message', () => {
        expect(accountShieldSelectors.getStatus(state, 'trader')).toEqual('');
    });

});
