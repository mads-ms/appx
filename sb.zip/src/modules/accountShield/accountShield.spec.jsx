import React from 'react';
import { shallow } from 'enzyme';
import AccountShield from 'src/modules/accountShield/accountShield';

describe('src/modules/accountShield/accountShield', () => {
    let wrapper;

    const account = [
        {
            id: 'account-1',
            AccountValueProtectionLimit: 50000,
            BaseCurrency: 'USD',
            DisplayName: 'Trader',
        },
    ];

    const balance = {
        TotalValue: 600000,
    };

    const props = {
        account,
        balance,
        isUpdating: false,
        status: '',
        isAmountValid: true,
    };

    const element = (
        <AccountShield
            account={props.account}
            balance={props.balance}
            isUpdating={props.isUpdating}
            status={props.status}
            isAmountValid={props.isAmountValid}
            onTabClose={props.onTabClose}
        />
    );

    beforeEach(() => {
        wrapper = shallow(element);
    });

    afterEach(() => {
        wrapper.unmount();
    });

    it('can render', () => {
        expect(wrapper.find('.grid--scroll').length).toEqual(1);
    });

    it('can render user info', () => {
        expect(wrapper.find('.kv-val').length).toEqual(2);
    });
});
