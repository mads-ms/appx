import accountShieldReducer from 'src/modules/accountShield/reducer';
import * as accountShieldActionTypes from 'src/modules/accountShield/actionTypes';

describe('src/modules/accountShield/reducer', () => {

    it('should have an initial state', () => {
        expect(accountShieldReducer(undefined, {})).toEqual({});
    });

    it('should show error message', () => {
        const action = {
            type: accountShieldActionTypes.SET_STATUS,
            status: 'error',
            componentId: 'trader',
            isShown: true,
        };

        const state = {};

        expect(accountShieldReducer(state, action)).toEqual({
            trader: {
                isUpdating: false,
                isShown: true,
                status: 'error',
            },
        });
    });

    it('should close accountShield', () => {
        const action = {
            type: accountShieldActionTypes.UPDATE_ACCOUNT_SHIELD,
            componentId: 'trader',
            isShown: false,
        };
        const state = {};

        expect(accountShieldReducer(state, action)).toEqual({
            trader: {
                isShown: false,
                isUpdating: false,
                status: '',
            },
        });
    });
});
