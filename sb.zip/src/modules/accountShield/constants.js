export const INCREMENT_DECREMENT_AMOUNT = 1000;
export const VALUE_MIN = 0;
export const STATUS_WARNING = 'warning';
