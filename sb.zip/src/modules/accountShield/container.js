import { connect } from 'react-redux';
import AccountShield from './accountShield';
import * as workspaceSelectors from 'src/modules/workspace/workspaceSelectors';
import * as accounShieldActions from './actions';
import * as accounShieldSelectors from './selectors';
import * as accountSelectors from 'src/modules/accounts/selectors';
import * as balancesSelectors from 'src/modules/balances/selectors';

function mapStateToProps() {
    const getDataByAccount = balancesSelectors.createGetDataByAccount();

    return (state, props) => {
        const { componentId } = props;
        const { accountId } = workspaceSelectors.getComponentUserSettings(state, componentId);

        return {
            account: accountSelectors.getAccountById(state, accountId),
            balance: getDataByAccount(state, accountId),
            status: accounShieldSelectors.getStatus(state, componentId),
            isUpdating: accounShieldSelectors.isUpdating(state, componentId),
            isShown: accounShieldSelectors.isShown(state, componentId),
        };
    };
}

const mapDispatchToProps = {
    onUpdateAccountShield: accounShieldActions.triggerAccountShieldUpdate,
    onStatusMessageClose: accounShieldActions.clearStatus,
};

export default connect(mapStateToProps, mapDispatchToProps)(AccountShield);
