import AccountShield from './container';
import './sagas';

export default AccountShield;
