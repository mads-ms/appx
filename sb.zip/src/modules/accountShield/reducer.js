import _ from 'lodash';
import * as actionTypes from './actionTypes';

export const initialState = {};

const initialComponentState = {
    isUpdating: false,
    isShown: true,
    status: '',
};

export default function acountShield(state = initialState, action) {
    switch (action.type) {
        case actionTypes.SET_STATUS:
            return updateStatus(state, action);

        case actionTypes.UPDATE_ACCOUNT_SHIELD:
            return setAccountShieldValue(state, action);

        default:
            return state;
    }
}

function updateStatus(state, action) {
    const {
        status,
        componentId,
    } = action;
    const componentState = state[componentId] || initialComponentState;

    return _.defaults({
        [componentId]: _.defaults({
            status,
        }, componentState),
    }, state);
}

function setAccountShieldValue(state, action) {
    const {
        isShown,
        isUpdating,
        componentId,
    } = action;
    const componentState = state[componentId] || initialComponentState;

    return _.defaults({
        [componentId]: _.defaults({
            isShown,
            isUpdating,
        }, componentState),
    }, state);
}
