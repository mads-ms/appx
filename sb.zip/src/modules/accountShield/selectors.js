import _ from 'lodash';

const getComponentState = (state, componentId) => _.get(state.accountShield, componentId);
export const isUpdating = (state, componentId) => _.get(getComponentState(state, componentId), 'isUpdating');
export const isShown = (state, componentId) => _.get(getComponentState(state, componentId), 'isShown');
export const getStatus = (state, componentId) => _.get(getComponentState(state, componentId), 'status');
