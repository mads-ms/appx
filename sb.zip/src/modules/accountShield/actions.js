import * as actionTypes from './actionTypes';
import './sagas';

export function triggerAccountShieldUpdate(componentId, account, value) {
    return {
        type: actionTypes.TRIGGER_SET_ACCOUNT_SHIELD,
        componentId,
        account,
        value,
    };
}

export function clearStatus(componentId) {
    return {
        type: actionTypes.SET_STATUS,
        componentId,
        status: '',
    };
}
