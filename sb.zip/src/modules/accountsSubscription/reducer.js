import createReducer from 'src/modules/subscriptions/createReducer';
import * as subscriptionsConfig from './config';

export default createReducer(subscriptionsConfig.TYPE, subscriptionsConfig.META);
