import * as subscriptionsSagaActions from 'src/modules/subscriptions/sagas/actions';
import * as subscriptionConfig from './config';

export function create(id, args) {
    return subscriptionsSagaActions.create({
        id,
        subscriptionType: subscriptionConfig.TYPE,
        endPoint: subscriptionConfig.END_POINT,
        args: {
            Arguments: args,
            RefreshRate: subscriptionConfig.REFRESH_RATE,
        },
        immediate: true,
    });
}

export function modify({ id, args, recreate = true, keepData = true }) {
    return subscriptionsSagaActions.modify({ id, args, recreate, keepData, subscriptionType: subscriptionConfig.TYPE });
}

export function remove(id) {
    return subscriptionsSagaActions.remove(subscriptionConfig.TYPE, id);
}
