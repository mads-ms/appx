export const REFRESH_RATE = 30000;

export const END_POINT = {
    serviceGroup: 'port',
    uri: 'v1/accounts/subscriptions',
};

export const META = { __key__: 'AccountId' };

export const TYPE = 'accounts';
