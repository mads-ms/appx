import * as subscriptionsQueries from 'src/modules/subscriptions/queries';
import * as subscriptionSelectors from 'src/modules/subscriptions/selectors';
import * as subscriptionConfig from './config';

export const getSubscription = subscriptionSelectors.createGetSubscription(subscriptionConfig.TYPE);
export const getData = (state, id) => subscriptionsQueries.getData(getSubscription(state, id));
export const getStatus = (state, id) => subscriptionsQueries.getStatus(getSubscription(state, id));
export const getArguments = (state, id) => subscriptionsQueries.getArguments(getSubscription(state, id));
