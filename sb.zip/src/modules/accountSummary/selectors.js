import _ from 'lodash';
import * as balancesSelectors from 'src/modules/balances/selectors';
import * as accountSelectors from 'src/modules/accounts/selectors';
import * as platformSettingsSelectors from 'src/modules/platformSettings/selectors';
import * as settingsSelectors from 'src/modules/settings/selectors/settingsSelectors';
import * as userSettingKeys from 'src/modules/settings/userSettingKey';
import { createSelector } from 'reselect';

export const getState = (state) => _.get(state, 'accountSummary', null);

export const getById = (state, id) => _.get(getState(state), id, null);

export const getCurrentAccountId = (state, id) => _.get(getById(state, id), 'accountId', null);

export const getDefaultAccountId = (state) => {
    const summaryAccount = accountSelectors.getSummaryAccount(state);
    return _.get(summaryAccount, 'id') || accountSelectors.getDefaultAccountId(state);
};

export const getInitialAccountId = (state) => {
    let accountId = settingsSelectors.getUserSetting(state, userSettingKeys.LastUsedAccountAccountBar);

    // Ensure the account id is always sent back as a string
    // Needed accounts may be stored as a number.
    accountId = accountId && String(accountId);

    if (!accountId || !accountSelectors.getAccountById(state, accountId)) {
        accountId = getDefaultAccountId(state);
    }

    // when a client only have one account, we want to be sure that we are not using summary id
    const accounts = accountSelectors.getAccountsList(state);

    if (accounts.length < 3) {
        accountId = _.get(_.find(accounts, { IsAccount: true }), 'AccountId');
    }

    return accountId;
};

export const getAccountId = (state, id) =>
    getCurrentAccountId(state, id) || getInitialAccountId(state);

/**
 * Returns true if the account type has valid margin data.
 * To understand this first understand that there are currently three
 * entity types that are all referred to as accounts.
 *
 *  1. The account level entity
 *  2. The client level entity (that spans all accounts)
 *  3. The ARP level entity (account risk profile).
 *
 * The margin utilization is only valid in the following cases,
 *
 *  1) The account, group or client allows margin trading
 *  2a) The account is the 'client' account and has two or more groups
 *  2b) The account is the ARP group and 'individual margining' is disabled.
 *      I.e. margining is done on underlying accounts instead so it should
 *      not be shown on group level.
 *  2c) The account is an actual account and 'individual margining' is enabled.
 *
 * Special cases,
 *
 *  2d) The account is an ARP group but it only has a single account underneath
 *  2e) The client only has a single account.
 *
 * @param account {Object} - An account data object from the Account model.
 *
 */

export const getHasMargin = createSelector(
    accountSelectors.getAccountById,
    accountSelectors.getHasIndividualMarginingById,
    accountSelectors.getAccountsCount,
    accountSelectors.getAccountGroupsCount,
    (account, hasIndividualMargining, accountsCount, accountGroupsCount) =>

        account.IsMarginTradingAllowed &&
    ((account.IsSummary && accountGroupsCount < 2 && !hasIndividualMargining) ||
    (account.IsAccount && hasIndividualMargining) ||
    (account.IsGroup && !hasIndividualMargining) ||
    ((_.size(account.Accounts) === 1) || (accountsCount === 1)))
);

/**
 * Account Summary data
 * @param {Object} state Root state
 * @param {String} accountId account id
 * @type {Object}
 */
export const createGetSummary = () => createSelector(
    accountSelectors.getAccountById,
    balancesSelectors.createGetShowCreditLine(),
    accountSelectors.getHasIndividualMarginingById,
    getHasMargin,
    accountSelectors.getIsVariationMarginEligible,
    balancesSelectors.createGetDataByAccount(),
    platformSettingsSelectors.isRealTimeNettingEnabled,
    (account,
        showCreditLine,
        hasIndividualMargining,
        hasMargin,
        isVariationMarginEligible,
        balance,
        isRealTimeNettingEnabled) => {

        const optionPremiumsMarketValue = balance.OptionPremiumsMarketValue || 0;
        const variationMargin = balance.VariationMargin || 0;
        const variationMarginCashBalance = balance.VariationMarginCashBalance || 0;

        const accountFields = {
            id: account.AccountId,
            AccountId: account.AccountId,
            AccountKey: account.AccountKey,
            AccountType: account.AccountType,
            IsAccount: account.IsAccount,
            IsSummary: account.IsSummary,
            IsGroup: account.IsGroup,
            AccountGroupName: account.AccountGroupName,
            BaseCurrency: account.BaseCurrency,
            BaseCurrencyDecimals: account.BaseCurrencyDecimals,
            IsMarginTradingAllowed: account.IsMarginTradingAllowed,
            SupportsAccountValueProtectionLimit: account.SupportsAccountValueProtectionLimit,
            AccountValueProtectionLimit: account.AccountValueProtectionLimit,
        };

        const calculatedFields = {
            MarginNetExposure: balance.MarginNetExposure || 0,
            MarginExposureCoveragePct: balance.MarginExposureCoveragePct || 0,
            CashAvailable: balance.CashBalance + balance.TransactionsNotBooked,
            PLMarginPositions: balance.UnrealizedMarginProfitLoss === 0 ? null : balance.UnrealizedMarginProfitLoss === 0,
            ValueOfPositions: balance.NonMarginPositionsValue + balance.UnrealizedMarginProfitLoss +
            balance.CostToClosePositions + optionPremiumsMarketValue,
            ShowCreditLine: showCreditLine,
            HasIndividualMargining: hasIndividualMargining,
            HasMargin: hasMargin,
            IsVariationMarginEligible: isVariationMarginEligible,
            VariationMargin: variationMargin,
            VariationMarginCashBalance: variationMarginCashBalance,
            VariationMarginAvailable: variationMargin + variationMarginCashBalance,
            IsRealTimeNettingEnabled: isRealTimeNettingEnabled,
            UnrealizedMarginOpenProfitLoss: balance.UnrealizedMarginOpenProfitLoss,
            UnrealizedMarginClosedProfitLoss: balance.UnrealizedMarginClosedProfitLoss,
        };

        return _.assign({}, balance, accountFields, calculatedFields);
    }
);
