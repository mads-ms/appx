import _ from 'lodash';
import React from 'react';
import Spine from 'spineAll';
import PropTypes from 'prop-types';
import Localization from 'src/localization';
import Button from 'src/components/button/button';
import Dialog from 'src/components/dialog/dialog';
import Icon from 'src/components/icon/icon';
import GraphBar from 'src/components/graphBar/graphBar';
import AccountSelector from 'src/modules/accountSelector';
import * as queries from './queries';
import * as numberFormat from 'src/numberFormat';
import AccountDetails from 'src/modules/accountBalancesSelector/accountDetails/accountDetails';
import { bindHandlers } from 'src/utils/bindHandlers';
import * as moduleType from 'src/modules/workspace/moduleTypes';

class AccountSummary extends React.PureComponent {
    constructor(props) {
        super(props);

        this.state = {
            isAccountDetailsShown: false,
        };
    }

    componentDidMount() {
        const {
            componentId,
            createModule,
            activateModule,
        } = this.props;
        createModule(moduleType.ACCOUNT_SUMMARY, componentId);
        activateModule(moduleType.ACCOUNT_SUMMARY, componentId);
    }

    componentWillUnmount() {
        const {
            componentId,
            deactivateModule,
            destroyModule,
        } = this.props;
        deactivateModule(moduleType.ACCOUNT_SUMMARY, componentId);
        destroyModule(moduleType.ACCOUNT_SUMMARY, componentId);
    }

    handleDetailsButtonTap() {
        this.setState({ isAccountDetailsShown: true });
    }

    handleDetailsHide() {
        this.setState({ isAccountDetailsShown: false });
    }

    handleAccountChange(accountId) {
        // spine is used to set current account globally on desktop and tablet
        Spine.trigger('app:accountChange', { id: accountId });
        this.props.onAccountChange(this.props.componentId, accountId);
    }

    render() {
        const {
            accountsList,
            balanceData,
            accountId,
            summary,
        } = this.props;

        const balance = _.find(balanceData, { id: accountId }) || {};
        const account = _.find(accountsList, { id: accountId }) || {};
        const decimals = _.defaultTo(account.BaseCurrencyDecimals, 2);
        const cashAvailable = balance.CashBalance + balance.TransactionsNotBooked;

        return (
            <div className="js-help-accountsummary tst-help-accountsummary acctsummary grid grid--serieslg grid--fit-all grid--cross-center">
                {this.state.isAccountDetailsShown &&
                    <Dialog showUnderlay onHide={this.handleDetailsHide}>
                        <AccountDetails accountDetails={summary}/>
                    </Dialog>
                }
                <div className="grid grid--series grid--fit-all grid--cross-center">
                    <div className="grid-cell">
                        <AccountSelector
                            isEnableGroups
                            selectedAccountId={accountId}
                            onChange={this.handleAccountChange}
                            isAltStyle
                        />
                    </div>
                    <div className="grid-cell tst-account-details">
                        <Button className="btn--square" onTap={this.handleDetailsButtonTap}>
                            <Icon type="info-alt"/>
                        </Button>
                    </div>
                </div>
                <div className="grid-cell acctsummary-balance">
                    <span className="acctsummary-label acctsummary-balance">{Localization.getText('HTML5_CashAvailable')}</span>
                    <span className="t-num">{numberFormat.formatPrice(cashAvailable, decimals)}</span>
                </div>
                <div className="grid-cell acctsummary-account-value">
                    <span className="acctsummary-label">{Localization.getText('HTML5_AccountValue')}</span>
                    <span className="t-num">{numberFormat.formatPrice(balance.TotalValue, decimals)}</span>
                </div>
                {queries.hasMargin(account, accountsList) && (
                    <div className="grid-cell acctsummary-margin-available">
                        <span className="acctsummary-label acctsummary-margin-available">{Localization.getText('HTML5_MarginAvailable')}</span>
                        <span className="t-num">{numberFormat.formatPrice(balance.MarginAvailableForTrading, decimals)}</span>
                    </div>
                )}
                {queries.showCreditLine(account, accountsList, balance.MaxCreditLine) && (
                    <div className="grid-cell acctcreditsummary-margin-available">
                        <span className="acctsummary-label">{Localization.getText('HTML5_StockCredits')}</span>
                        <span className="t-num">{numberFormat.formatPrice(balance.CollateralValue, decimals)}</span>
                    </div>
                )}
                {queries.hasMargin(account, accountsList) && (
                    <div className="grid-cell">
                        <span className="acctsummary-label">{Localization.getText('HTML5_MarginUtilisation')}</span>
                        <GraphBar isMedium pct={balance.MarginUtilizationPct}/>
                        <span className="t-num">{numberFormat.formatPercentage(balance.MarginUtilizationPct)}</span>
                    </div>
                )}
                {queries.showCreditLine(account, accountsList, balance.MaxCreditLine) && (
                    <div className="grid-cell">
                        <span className="acctsummary-label">{Localization.getText('HTML5_CollateralUtilization')}</span>
                        <GraphBar isMedium pct={balance.CollateralUtilization}/>
                        <span className="t-num">{numberFormat.formatPercentage(balance.CollateralUtilization)}</span>
                    </div>
                )}
                {account.IsVariationMarginEligible && (
                    <div className="grid-cell acctsummary-variation-margin-available">
                        <span className="acctsummary-label">{Localization.getText('HTML5_VariationMarginAvailable')}</span>
                        <span className="t-num">{numberFormat.formatPrice(balance.VariationMarginAvailable, decimals)}</span>
                    </div>
                )}
            </div>
        );
    }
}

AccountSummary.propTypes = {
    accountsList: PropTypes.array.isRequired,
    accountId: PropTypes.string.isRequired,
    componentId: PropTypes.string.isRequired,
    balanceData: PropTypes.array.isRequired,
    summary: PropTypes.object.isRequired,
    onAccountChange: PropTypes.func.isRequired,
    createModule: PropTypes.func.isRequired,
    activateModule: PropTypes.func.isRequired,
    deactivateModule: PropTypes.func.isRequired,
    destroyModule: PropTypes.func.isRequired,
};

export default bindHandlers(AccountSummary);
