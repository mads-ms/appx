import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import Localization from 'src/localization';
import Dialog from 'src/components/dialog/dialog';
import * as numberFormat from 'src/numberFormat';
import AccountDetails from 'src/modules/accountBalancesSelector/accountDetails/accountDetails';
import { bindHandlers } from 'src/utils/bindHandlers';
import GraphBar from 'src/components/graphBar/graphBar';
import Touchable from 'src/components/touchable/touchable';
import Icon from 'src/components/icon/icon';
import * as queries from '../queries';

class AccountsData extends React.PureComponent {
    constructor(props) {
        super(props);

        this.state = {
            isAccountDetailsShown: false,
        };
    }

    handleNameTap() {
        this.props.onAccountChange('accountsummary', this.props.balanceData.id);
        this.setState({ isAccountDetailsShown: true });

    }

    handleHideAccountDetails() {
        this.setState({ isAccountDetailsShown: false });
    }

    render() {
        const {
            account,
            balanceData,
            accountsList,
            summary,
        } = this.props;

        const {
            TotalValue,
            MarginAvailableForTrading,
            CollateralValue,
            CashBalance,
            TransactionsNotBooked,
        } = balanceData;

        const cashAvailable = CashBalance + TransactionsNotBooked;

        const decimals = _.defaultTo(account.BaseCurrencyDecimals, 2);

        const displayName =
            account.IsGroup ?
                `${Localization.getText('HTML5_AccountGroup')} \u2013 ${account.DisplayName} ` :
                account.DisplayName;

        return (
            <div className="grid-cell tst-account-details">
                {this.state.isAccountDetailsShown &&
                    <Dialog onHide={this.handleHideAccountDetails}>
                        <AccountDetails accountDetails={summary}/>
                    </Dialog>
                }
                <Touchable onTap={this.handleNameTap}>
                    <div className="divider divider--large is-highlighted grid grid--fill-fit">
                        <div className="grid-cell t-truncate">
                            {displayName}
                        </div>
                        <div className="grid-cell">
                            {account.BaseCurrency}
                            <Icon type="info-alt"/>
                        </div>
                    </div>
                </Touchable>
                <ul className="list list--lines kv kv--wrap">
                    <li className="list-item">
                        <p className="kv-val">
                            <span data-val={cashAvailable} className="t-num">{numberFormat.formatPrice(cashAvailable, decimals)}</span>
                        </p>
                        <p className="kv-key acctsummary-balance">{Localization.getText('HTML5_CashAvailable')}</p>
                    </li>
                    <li className="list-item">
                        <p className="kv-val">
                            <span data-val={TotalValue} className="t-num">{numberFormat.formatPrice(TotalValue, decimals)}</span>
                        </p>
                        <p className="kv-key">{Localization.getText('HTML5_AccountValue')}</p>
                    </li>
                </ul>
                {queries.hasMargin(account, accountsList) && (
                    <ul className="list list--lines kv kv--wrap">
                        <li className="list-item">
                            <p className="kv-val">
                                <span data-val={MarginAvailableForTrading} className="t-num">
                                    {numberFormat.formatPrice(MarginAvailableForTrading, decimals)}
                                </span>
                            </p>
                            <p className="kv-key acctsummary-margin-available">{Localization.getText('HTML5_MarginAvailable')}</p>
                        </li>
                    </ul>
                )}
                {queries.hasMargin(account, accountsList) && (
                    <ul className="list list--lines kv--wrap kv">
                        <li className="list-item">
                            <p className="kv-val">
                                <GraphBar
                                    pct={balanceData.MarginUtilizationPct}
                                    isSkinny
                                />
                                {numberFormat.formatPercentage(balanceData.MarginUtilizationPct)}
                            </p>
                            <p className="kv-key">{Localization.getText('HTML5_MarginUtilisation')}</p>
                        </li>
                    </ul>
                )}
                {queries.showCreditLine(account, accountsList, balanceData.MaxCreditLine) && (
                    <ul className="list list--lines kv kv--wrap">
                        <li className="list-item">
                            <p className="kv-val">
                                <span data-val={CollateralValue} className="t-num">{numberFormat.formatPrice(CollateralValue, decimals)}</span>
                            </p>
                            <p className="kv-key">{Localization.getText('HTML5_StockCredits')}</p>
                        </li>
                    </ul>
                )}
                {queries.showCreditLine(account, accountsList, balanceData.MaxCreditLine) && (
                    <ul className="list list--lines kv--wrap kv">
                        <li className="list-item">
                            <p className="kv-val">
                                <GraphBar
                                    pct={balanceData.CollateralUtilization}
                                    isSkinny
                                />
                                {numberFormat.formatPercentage(balanceData.CollateralUtilization)}
                            </p>
                            <p className="kv-key">{Localization.getText('HTML5_CollateralUtilization')}</p>
                        </li>
                    </ul>
                )}
            </div>
        );
    }
}

AccountsData.propTypes = {
    balanceData: PropTypes.object.isRequired,
    accountsList: PropTypes.array.isRequired,
    account: PropTypes.object.isRequired,
    summary: PropTypes.object.isRequired,
    onAccountChange: PropTypes.func.isRequired,
};

export default bindHandlers(AccountsData);
