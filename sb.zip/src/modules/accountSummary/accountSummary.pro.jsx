import config from 'src/config';
import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import Localization from 'src/localization';
import Button from 'src/components/button/button';
import Dialog from 'src/components/dialog/dialog';
import * as queries from './queries';
import * as accountConstants from 'src/modules/accounts/constants';
import * as numberFormat from 'src/numberFormat';
import AccountSelector from 'src/modules/accountSelector';
import AccountDetails from 'src/modules/accountBalancesSelector/accountDetails/accountDetails';
import { bindHandlers } from 'src/utils/bindHandlers';
import GraphBar from 'src/components/graphBar/graphBar';
import Icon from 'src/components/icon/icon';

class AccountSummary extends React.PureComponent {
    constructor(props) {
        super(props);

        this.state = {
            isAccountDetailsShown: false,
        };
    }

    handleDetailsButtonTap() {
        this.setState({ isAccountDetailsShown: true });
    }

    handleDetailsHide() {
        this.setState({ isAccountDetailsShown: false });
    }

    handleMarginAlertTap() {
        this.props.onShowMarginAlert();
    }

    handleAccountShieldTap() {
        const {
            accountId,
            account,
        } = this.props;

        // passing accountId to accountShield
        // if feature is not supported on current account then we wish to pass accountId for accounts Summary
        const shieldAccountId = account.SupportsAccountValueProtectionLimit ? accountId : accountConstants.SUMMARY_ACCOUNT_ID;
        this.props.onShowAccountShield(shieldAccountId);
    }

    handleMarginBreakdownTap() {
        this.props.onShowMarginBreakdown(this.props.accountId);
    }

    handleAccountChange(account) {
        this.props.onAccountChange(this.props.componentId, account);
    }

    render() {
        const {
            accountsList,
            accountId,
            summary,
            marginAlertValue,
            account,
            balance,
        } = this.props;

        const {
            isAccountDetailsShown,
        } = this.state;

        const decimals = _.defaultTo(account.BaseCurrencyDecimals, 2);
        const cashAvailable = balance.CashBalance + balance.TransactionsNotBooked;
        const hasMargin = queries.hasMargin(account, accountsList);
        const supportsAccountShield = queries.supportsAccountShield(account, accountsList);
        const showCreditLine = queries.showCreditLine(account, accountsList, balance.MaxCreditLine);

        return (
            <div className="tst-help-accountsummary acctsummary grid grid--y grid--fit-fill">
                {isAccountDetailsShown && (
                    <Dialog onHide={this.handleDetailsHide}>
                        <AccountDetails accountDetails={summary}/>
                    </Dialog>
                )}
                <div className="acctsummary-toolbar grid grid--series grid--fit-all grid--cross-center">
                    <div className="grid-cell">
                        <AccountSelector
                            isAstroStyle
                            isEnableGroups
                            selectedAccountId={accountId}
                            onChange={this.handleAccountChange}
                        />
                    </div>
                    <div className="grid-cell tst-account-details">
                        <Button className="btn--square btn--astro" onTap={this.handleDetailsButtonTap}>
                            <Icon type="info-alt"/>
                        </Button>
                    </div>
                </div>
                <div className="grid grid--scroll">
                    <div className="grid-cell">
                        <ul className="kv kv--wrap tst-accountsummary-list">
                            <li className="acctsummary-item acctsummary-balance">
                                <p className="kv-val t-num">{numberFormat.formatPrice(cashAvailable, decimals)}</p>
                                <p className="kv-key">{Localization.getText('HTML5_CashAvailable')}</p>
                            </li>
                            <li className="acctsummary-item acctsummary-account-value">
                                <p className="kv-val t-num">{numberFormat.formatPrice(summary.ValueOfPositions, decimals)}</p>
                                <p className="kv-key">{Localization.getText('HTML5_ValueOfPositions')}</p>
                            </li>
                            <li className="acctsummary-item acctsummary-account-value">
                                <p className="kv-val t-num">{numberFormat.formatPrice(balance.TotalValue, decimals)}</p>
                                <p className="kv-key">{Localization.getText('HTML5_AccountValue')}</p>
                            </li>
                            {supportsAccountShield && (
                                <li className="acctsummary-item">
                                    <div className="kv-val t-num">
                                        <Button className="btn--link" onTap={this.handleAccountShieldTap}>
                                            {queries.accountShieldFormatter(queries.getAccountShield(account, accountsList), decimals)}
                                        </Button>
                                    </div>
                                    <p className="kv-key">{Localization.getText('HTML5_AccountShield')}</p>
                                </li>
                            )}
                            {hasMargin && (
                                <li>
                                    <p className="kv-val">&nbsp;</p>
                                    <p className="kv-key">&nbsp;</p>
                                </li>
                            )}
                            {hasMargin && config.appFeatures.isMarginBreakdownEnabled && (
                                <li className="acctsummary-item acctsummary-account-value">
                                    <div className="kv-val t-num">
                                        <Button className="btn--link" onTap={this.handleMarginBreakdownTap}>
                                            {numberFormat.formatPrice(summary.MarginUsedByCurrentPositions, decimals)}
                                        </Button>
                                    </div>
                                    <p className="kv-key">{Localization.getText('HTML5_ReservedForMarginRequiremnt')}</p>
                                </li>
                            )}
                            {hasMargin && (
                                <li className="acctsummary-item acctsummary-margin-available">
                                    <p className="kv-val t-num">
                                        {numberFormat.formatPrice(balance.MarginAvailableForTrading, decimals)}
                                    </p>
                                    <p className="kv-key acctsummary-margin-available">
                                        {Localization.getText('HTML5_MarginAvailable')}
                                    </p>
                                </li>
                            )}
                            {hasMargin && (
                                <li className="acctsummary-item acctsummary-margin-utilisation">
                                    <div className="kv-val">
                                        <GraphBar isMedium pct={balance.MarginUtilizationPct}/>
                                        <span>{numberFormat.formatPercentage(balance.MarginUtilizationPct, 2)}</span>
                                    </div>
                                    <p className="kv-key">{Localization.getText('HTML5_MarginUtilisation')}</p>
                                </li>
                            )}
                            {hasMargin && config.appFeatures.isMarginAlertEnabled && (
                                <li className="acctsummary-item">
                                    <div className="kv-val">
                                        <Button className="btn--link" onTap={this.handleMarginAlertTap}>
                                            {queries.marginAlertFormatter(marginAlertValue)}
                                        </Button>
                                    </div>
                                    <p className="kv-key">{Localization.getText('HTML5_MarginUtilisationAlert')}</p>
                                </li>
                            )}
                            {showCreditLine && (
                                <li>
                                    <p className="kv-val">&nbsp;</p>
                                    <p className="kv-key">&nbsp;</p>
                                </li>
                            )}
                            {showCreditLine && (
                                <li className="acctsummary-item acctcreditsummary-margin-available">
                                    <p className="kv-val t-num">{numberFormat.formatPrice(balance.CollateralValue, decimals)}</p>
                                    <p className="kv-key">{Localization.getText('HTML5_StockCredits')}</p>
                                </li>
                            )}
                            {showCreditLine && (
                                <li className="acctsummary-item acctsummary-margin-utilisation">
                                    <div className="kv-val">
                                        <GraphBar isMedium pct={balance.CollateralUtilization}/>
                                        <span>{numberFormat.formatPercentage(balance.CollateralUtilization, 2)}</span>
                                    </div>
                                    <p className="kv-key">{Localization.getText('HTML5_CollateralUtilization')}</p>
                                </li>
                            )}
                        </ul>
                    </div>
                </div>
            </div>
        );
    }
}

AccountSummary.propTypes = {
    accountsList: PropTypes.array.isRequired,
    accountId: PropTypes.string.isRequired,
    componentId: PropTypes.string.isRequired,
    account: PropTypes.object.isRequired,
    balance: PropTypes.object.isRequired,
    summary: PropTypes.object.isRequired,
    marginAlertValue: PropTypes.number.isRequired,
    onAccountChange: PropTypes.func.isRequired,
    onShowMarginAlert: PropTypes.func.isRequired,
    onShowAccountShield: PropTypes.func.isRequired,
    onShowMarginBreakdown: PropTypes.func.isRequired,
};

export default bindHandlers(AccountSummary);
