import * as actionTypes from 'src/modules/accountSummary/actionTypes';
import * as moduleTypes from 'src/modules/workspace/moduleTypes';
import * as workspaceActions from 'src/modules/workspace/actions/workspaceActions';

export function setCurrentAccount(componentId, accountId) {
    return {
        type: actionTypes.SET_CURRENT_ACCOUNT,
        componentId,
        accountId,
    };
}

export function triggerAccountChange(componentId, accountId) {
    return {
        type: actionTypes.TRIGGER_ACCOUNT_CHANGE,
        componentId,
        accountId,
    };
}

export function showMarginAlert() {
    return workspaceActions.addComponentInSubWindow({
        type: moduleTypes.MARGIN_ALERT,
    });
}

export function showAccountShield(accountId) {
    return workspaceActions.addComponentInSubWindow({
        type: moduleTypes.ACCOUNT_SHIELD,
        userSettings: { accountId },
    });
}

export function showMarginBreakdown(accountId) {
    return workspaceActions.addComponentInSubWindow({
        type: moduleTypes.MARGIN_BREAKDOWN,
        userSettings: { accountId },
    });
}
