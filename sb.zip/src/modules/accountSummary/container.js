import { connect } from 'react-redux';
import config from 'src/config';
import AccountSummary from './accountSummary';
import * as actions from './actions';
import * as selectors from './selectors';
import * as accountSelectors from 'src/modules/accounts/selectors';
import * as balancesSelectors from 'src/modules/balances/selectors';
import * as marginAlertSelectors from 'src/modules/marginAlert/selectors';
import * as moduleLifecycleActions from 'src/modules/moduleLifecycle/actions';

function mapStateToProps() {
    const getSummary = selectors.createGetSummary();
    const getDataByAccount = balancesSelectors.createGetDataByAccount();

    return (state, props) => {
        const { componentId } = props;
        const accountId = selectors.getAccountId(state, componentId);
        const marginAlertValue = config.isProApp ? marginAlertSelectors.getAlert(state).alertValue : 0;

        return {
            account: accountSelectors.getAccountById(state, accountId),
            balance: getDataByAccount(state, accountId),
            balanceData: balancesSelectors.getAllData(state),
            accountsList: accountSelectors.getAccountsList(state),
            summary: getSummary(state, accountId),
            marginAlertValue,
            accountId,
        };
    };
}

const mapDispatchToProps = {
    onAccountChange: actions.triggerAccountChange,
    onShowMarginAlert: actions.showMarginAlert,
    onShowAccountShield: actions.showAccountShield,
    onShowMarginBreakdown: actions.showMarginBreakdown,
    createModule: moduleLifecycleActions.create,
    destroyModule: moduleLifecycleActions.destroy,
    activateModule: moduleLifecycleActions.activate,
    deactivateModule: moduleLifecycleActions.deactivate,
};

export default connect(mapStateToProps, mapDispatchToProps)(AccountSummary);
