export const SET_CURRENT_ACCOUNT = 'accountSummary/account/set';
export const TRIGGER_ACCOUNT_CHANGE = 'accountSummary/trigger-account-change';
