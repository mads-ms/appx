import _ from 'lodash';
import * as actionTypes from './actionTypes';

export const initialState = {};
const initialComponentState = {
    accountId: null,
};

export default (state = initialState, action) => {
    switch (action.type) {
        case actionTypes.SET_CURRENT_ACCOUNT:
            return handleSetCurrentAccount(state, action);
    }
    return state;
};

function handleSetCurrentAccount(state, action) {
    const { componentId, accountId } = action;
    const componentState = state[componentId] || initialComponentState;

    return _.defaults({
        [componentId]: _.defaults({
            accountId,
        }, componentState),
    }, state);
}
