import * as accountSummaryActions from 'src/modules/accountSummary/actions';
import * as accountSummaryActionTypes from 'src/modules/accountSummary/actionTypes';
import configureMockStore from 'redux-mock-store';
import thunkMiddleware from 'redux-thunk';

const mockStore = configureMockStore([thunkMiddleware]);

describe('src/modules/accountSummary/actions', () => {
    describe('selectAccount()', () => {
        it('should create a TRIGGER_ACCOUNT_CHANGE action', () => {

            const store = mockStore({});
            const accountId = 'foo';
            const componentId = 'bar';
            store.dispatch(accountSummaryActions.triggerAccountChange(componentId, accountId));
            const action = store.getActions()[0];

            expect(action).toEqual({
                type: accountSummaryActionTypes.TRIGGER_ACCOUNT_CHANGE,
                accountId,
                componentId,
            });
        });
    });
});
