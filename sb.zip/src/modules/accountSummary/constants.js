export const COMPONENT_ID = 'accountSummary';
