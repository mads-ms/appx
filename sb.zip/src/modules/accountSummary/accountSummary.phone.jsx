import _ from 'lodash';
import React from 'react';
import Spine from 'spineAll';
import PropTypes from 'prop-types';
import * as queries from './queries';
import Localization from 'src/localization';
import Button from 'src/components/button/button';
import AccountsData from './accountData/accountData';
import { bindHandlers } from 'src/utils/bindHandlers';

class AccountSummary extends React.PureComponent {
    handleTradeTap() {
        Spine.Route.navigate('/trade-ticket/');
    }

    handleOpenOrdersTap() {
        Spine.Route.navigate('/open-orders/');
    }

    handleOpenPositionsTap() {
        Spine.Route.navigate('/open-positions/');
    }

    render() {
        const {
            accountsList,
            balanceData,
            summary,
        } = this.props;

        const accounts = queries.getAccounts(accountsList);

        const accountsData = _.map(accounts, (account) => (
            <AccountsData
                account={account}
                balanceData={queries.findBalance(balanceData, account)}
                accountsList={accountsList}
                key={account.id}
                summary={summary}
                onAccountChange={this.props.onAccountChange}
            />
        ));

        return (
            <div className="grid grid--y grid--fill-fit">
                <div className="grid grid--scroll">
                    <div className="acctsummary grid grid--y g--fit grid--main-start">
                        {accountsData}
                    </div>
                </div>
                <div className="sheet-actions grid grid--y grid--seriessm">
                    <div className="grid-cell">
                        <Button className="btn--primary btn--large tst-trade" onTap={this.handleTradeTap}>
                            {Localization.getText('HTML5_Trade')}
                        </Button>
                    </div>
                    <div className="grid-cell">
                        <Button className="btn--alt btn--large tst-open-orders" onTap={this.handleOpenOrdersTap}>
                            {Localization.getText('HTML5_Orders')}
                        </Button>
                    </div>
                    <div className="grid-cell">
                        <Button className="btn--alt btn--large tst-open-positions" onTap={this.handleOpenPositionsTap}>
                            {Localization.getText('HTML5_Positions')}
                        </Button>
                    </div>
                </div>
            </div>
        );
    }
}

AccountSummary.propTypes = {
    balanceData: PropTypes.array.isRequired,
    accountsList: PropTypes.array.isRequired,
    summary: PropTypes.object.isRequired,
    onAccountChange: PropTypes.func.isRequired,
};

export default bindHandlers(AccountSummary);
