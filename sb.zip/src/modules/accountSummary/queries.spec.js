import * as queries from 'src/modules/accountSummary/queries';
import Localization from 'src/localization';
import * as numberFormat from 'src/numberFormat';

describe('src/modules/accountSummary/queries', () => {

    describe('hasMargin()', () => {

        it('should return true if the account allows margin trading', () => {
            const account = {
                IsMarginTradingAllowed: true,
                IsAccount: true,
                AccountGroupKey: 'defaultGroup',
            };
            const accountsList = [{
                AccountId: 'defaultGroup',
                Accounts: ['account'],
            }];

            expect(queries.hasMargin(account, accountsList)).toEqual(true);
        });

        it('should return true if account is the client account and has two or more groups', () => {
            const account = {
                IsMarginTradingAllowed: true,
                IsSummary: true,
                AccountGroupKey: 'defaultGroup',
            };
            const accountsList = [{
                IsGroup: true,
            },
            ];

            expect(queries.hasMargin(account, accountsList)).toEqual(true);
        });

        it('should return true if account is the ARP group and individual margining is disabled', () => {
            const account = {
                IsMarginTradingAllowed: true,
                IndividualMargining: false,
                IsGroup: true,
                Accounts: [{ account: 'account1' }, { account: 'account2' }],
            };
            const accountsList = [{
                AccountId: 'defaultGroup',
                Accounts: ['account1', 'account2'],
                IsGroup: true,
            },
            ];

            expect(queries.hasMargin(account, accountsList)).toEqual(true);
        });

        it('should return true if account is an actual account and individual margining is enabled', () => {
            const account = {
                IsMarginTradingAllowed: true,
                IndividualMargining: true,
                IsAccount: true,
                AccountGroupKey: 'defaultGroup',
            };
            const accountsList = [{
                AccountId: 'defaultGroup',
                Accounts: ['account1', 'account2'],
                IsGroup: true,
            },
            ];

            expect(queries.hasMargin(account, accountsList)).toEqual(true);
        });

        it('should return true if the client only has a single account', () => {
            const account = {
                IsMarginTradingAllowed: true,
            };
            const accountsList = [{
                IsAccount: true,
            },
            ];

            expect(queries.hasMargin(account, accountsList)).toEqual(true);
        });
    });

    describe('showCreditLine()', () => {

        it('should return false if client have more accounts and no groups', () => {
            const account = {
                IsAccount: true,
            };
            const accountsList = [{
                IsAccount: true,
            },
            {
                IsAccount: true,
            },
            ];
            const MaxCreditLine = 50000;

            expect(queries.showCreditLine(account, accountsList, MaxCreditLine)).toEqual(false);
        });

        it('should return false if account belongs to a group with more than one account', () => {
            const account = {
                IsAccount: true,
                AccountGroupKey: 'defaultGroup',
            };
            const accountsList = [{
                IsGroup: true,
                AccountId: 'defaultGroup',
                Accounts: ['account1', 'account2'],
            },
            {
                IsAccount: true,
            },
            ];
            const MaxCreditLine = 50000;

            expect(queries.showCreditLine(account, accountsList, MaxCreditLine)).toEqual(false);
        });

        it('should return false if client and have more than one groups', () => {
            const account = {
                IsSummary: true,
                AccountGroupKey: 'defaultGroup',
            };
            const accountsList = [{
                IsGroup: true,
            },
            {
                IsGroup: true,
            },
            ];
            const MaxCreditLine = 50000;

            expect(queries.showCreditLine(account, accountsList, MaxCreditLine)).toEqual(false);
        });

        it('should return true if client have more accounts and groups', () => {
            const account = {
                IsAccount: true,
            };
            const accountsList = [{
                IsAccount: true,
            },
            {
                IsGroup: true,
            },
            ];
            const MaxCreditLine = 50000;

            expect(queries.showCreditLine(account, accountsList, MaxCreditLine)).toEqual(true);
        });
    });

    describe('supportsAccountShield()', () => {

        it('should return true if client have supports account shield', () => {
            const account = {
                IsAccount: true,
                SupportsAccountValueProtectionLimit: false,
            };
            const accountsList = [{
                IsSummary: true,
                SupportsAccountValueProtectionLimit: true,
            },
            {
                IsAccount: true,
                SupportsAccountValueProtectionLimit: false,
            },
            ];

            expect(queries.supportsAccountShield(account, accountsList)).toEqual(true);
        });

        it('should return false if accountList has more then two accounts', () => {
            const account = {
                IsAccount: true,
                SupportsAccountValueProtectionLimit: false,
            };
            const accountsList = [{
                IsSummary: true,
                SupportsAccountValueProtectionLimit: true,
            },
            {
                IsAccount: true,
                SupportsAccountValueProtectionLimit: false,
            },
            {
                IsAccount: true,
                SupportsAccountValueProtectionLimit: false,
            },
            ];

            expect(queries.supportsAccountShield(account, accountsList)).toEqual(false);
        });

        it('should return false if account type is equal to AutoTradingFollower', () => {
            const account = {
                IsAccount: true,
                SupportsAccountValueProtectionLimit: true,
                AccountType: 'AutoTradingFollower',
            };
            const accountsList = [{
                IsSummary: true,
                SupportsAccountValueProtectionLimit: false,
            },
            {
                IsAccount: true,
                SupportsAccountValueProtectionLimit: true,
            },
            ];

            expect(queries.supportsAccountShield(account, accountsList)).toEqual(false);
        });
    });

    describe('getAccounts()', () => {

        it('accountsList have less then three accounts, filter out only IsAccount accounts', () => {
            const accountsList = [{
                IsSummary: true,
            },
            {
                IsAccount: true,
            },
            ];

            expect(queries.getAccounts(accountsList).length).toEqual(1);
        });
    });

    describe('findBalance()', () => {

        it('accountsList have less then three accounts, filter out only IsAccount accounts', () => {
            const account = {
                id: 'user2',
            };
            const balanceData = [{
                id: 'user1',
                TotalValue: 50,
            },
            {
                id: 'user2',
                TotalValue: 999,
            },
            ];

            expect(queries.findBalance(balanceData, account).TotalValue).toEqual(999);
        });
    });

    describe('isMarginClient()', () => {

        it('should return false if margin is allowed, is not summary and not just one account', () => {
            const account = {
                id: 'user2',
                IsMarginTradingAllowed: true,
            };
            const accounts = [{
                id: 'user1',
            },
            {
                id: 'user2',
                IsMarginTradingAllowed: true,
            },
            ];

            expect(queries.isMarginClient(account, accounts)).toEqual(false);
        });

        it('should return true if margin is allowed and account is summary', () => {
            const account = {
                id: 'user2',
                IsMarginTradingAllowed: true,
                IsSummary: true,
            };
            const accounts = [
                {
                    id: 'user2',
                    IsMarginTradingAllowed: true,
                },
            ];

            expect(queries.isMarginClient(account, accounts)).toEqual(true);
        });
    });

    describe('marginAlertFormatter()', () => {

        it('should return OFF when value is 0', () => {
            const value = 0;

            expect(queries.marginAlertFormatter(value)).toEqual(Localization.getText('HTML5_Off'));
        });

        it('should return 20% when value is 20', () => {
            const value = 20;

            expect(queries.marginAlertFormatter(value)).toEqual('20%');
        });
    });

    describe('accountShieldFormatter()', () => {

        it('should return 800.00', () => {
            const value = 800;
            const decimals = 2;

            expect(queries.accountShieldFormatter(value, decimals)).toEqual(numberFormat.formatPrice(800, 2));
        });
    });

    describe('getAccountShield()', () => {

        it('should return 800.00', () => {
            const account = {
                IsAccount: true,
                SupportsAccountValueProtectionLimit: false,
            };
            const accountsList = [{
                IsSummary: true,
                SupportsAccountValueProtectionLimit: true,
                AccountValueProtectionLimit: 50000,
            },
            {
                IsAccount: true,
            },
            {
                IsAccount: true,
            },
            ];
            expect(queries.getAccountShield(account, accountsList)).toEqual(50000);
        });
    });
});
