import reducer from 'src/modules/accountSummary/reducer';
import * as actionTypes from 'src/modules/accountSummary/actionTypes';

describe('src/modules/accountSummary/reducer', () => {
    let state;

    beforeEach(() => {
        state = {
            'main': {
                'accountId': 'USD_EUR_Trial',
            },
            'sub': {
                'accountId': 'Kowalski_PLN',
            },
        };
    });

    it('should set selected account id', () => {
        const action = {
            type: actionTypes.SET_CURRENT_ACCOUNT,
            componentId: 'main',
            accountId: 'USD_New',
        };
        const nextState = reducer(state, action);

        expect(nextState.main.accountId).toBe('USD_New');

        expect(state).not.toBe(nextState);
    });
});
