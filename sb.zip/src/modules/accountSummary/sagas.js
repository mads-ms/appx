import _ from 'lodash';
import { put, select, takeEvery } from 'redux-tale/effects';
import { addSagas } from 'src/sagas';
import Spine from 'spineAll';
import config from 'src/config';
import * as queries from './queries';
import * as actionTypes from './actionTypes';
import * as actions from './actions';
import * as selectors from './selectors';
import * as moduleLifecyclePatterns from 'src/modules/moduleLifecycle/sagaPatterns';
import * as moduleTypes from 'src/modules/workspace/moduleTypes';
import * as balancesActions from 'src/modules/balances/actions';
import * as accountSelectors from 'src/modules/accounts/selectors';
import * as userSettingKey from 'src/modules/settings/userSettingKey';
import * as userSettingsActions from 'src/modules/settings/actions/userSettingsActions';
import * as marginAlertActions from 'src/modules/marginAlert/actions';

function* onActivate({ componentId }) {
    const accountId = yield select(selectors.getInitialAccountId);
    yield put(balancesActions.addListener(componentId));
    yield put(actions.setCurrentAccount(componentId, accountId));

    if (config.isProApp) {
        yield fetchMarginAlert(accountId);
    }

    if (config.isTabletApp || config.appId === 'desktop') {

        // spine is used to set current account globally on desktop and tablet
        Spine.trigger('app:accountChange', { id: accountId });
    }
}

function* onDeactivate({ componentId }) {
    yield put(balancesActions.removeListener(componentId));
}

export const onActivateSaga = takeEvery(
    moduleLifecyclePatterns.moduleActivatePattern(moduleTypes.ACCOUNT_SUMMARY),
    onActivate
);

export const onDeactivateSaga = takeEvery(
    moduleLifecyclePatterns.moduleDeactivatePattern(moduleTypes.ACCOUNT_SUMMARY),
    onDeactivate
);

export const onAccountChangeSagas = takeEvery(
    actionTypes.TRIGGER_ACCOUNT_CHANGE,
    onAccountChange
);

function* onAccountChange({ componentId, accountId }) {
    yield put(userSettingsActions.setUserSetting(userSettingKey.LastUsedAccountAccountBar, accountId, false));
    yield put(userSettingsActions.setUserSetting(userSettingKey.LastUsedAccountPositionList, accountId, false));
    yield put(actions.setCurrentAccount(componentId, accountId));

    if (config.isProApp) {
        yield fetchMarginAlert(accountId);
    }
}

function* fetchMarginAlert(accountId) {
    const accountsList = yield select(accountSelectors.getAccountsList);
    const account = _.find(accountsList, { id: accountId });

    if (queries.hasMargin(account, accountsList)) {
        yield put(marginAlertActions.triggerFetchAlert());
    }
}

addSagas([
    onActivateSaga,
    onDeactivateSaga,
    onAccountChangeSagas,
]);
