import _ from 'lodash';
import config from 'src/config';
import Localization from 'src/localization';
import * as numberFormat from 'src/numberFormat';
import * as accountsQueries from 'src/modules/accounts/queries';

/**
 * Returns true if the account type has valid margin data.
 * To understand this first understand that there are currently three
 * entity types that are all referred to as accounts.
 *
 *  1. The account level entity
 *  2. The client level entity (that spans all accounts)
 *  3. The ARP level entity (account risk profile).
 *
 * The margin utilization is only valid in the following cases,
 *
 *  1) The account, group or client allows margin trading
 *  2a) The account is the 'client' account and has two or more groups
 *  2b) The account is the ARP group and 'individual margining' is disabled.
 *      I.e. margining is done on underlying accounts instead so it should
 *      not be shown on group level.
 *  2c) The account is an actual account and 'individual margining' is enabled.
 *
 * Special cases,
 *
 *  2d) The account is an ARP group but it only has a single account underneath
 *  2e) The client only has a single account.
 *
 */

export const hasMargin = (account, accountsList) => {

    // returns amount of account groups
    const accountGroupsCount = _.size(_.filter(accountsList, 'IsGroup'));

    // returns plain accounts
    const accounts = _.filter(accountsList, 'IsAccount');

    // returns amount of plain accounts
    const accountsCount = _.size(accounts);

    // checks if any account have individual margining
    const hasIndividualMargining = _.some(accounts, 'IndividualMargining');

    // get the group of current account
    const accountGroup = (account.AccountGroupKey) ? _.find(accountsList, { 'AccountId': account.AccountGroupKey }) : null;

    const isClientMargin = accountGroupsCount > 1 ? true : (accountGroupsCount === 1 && account.IndividualMargining && hasIndividualMargining);
    const isAccountMargin = accountGroup && _.get(accountGroup, 'Accounts.length') === 1 ? true : account.IndividualMargining;
    const isGroupMargin = accountGroup && _.get(accountGroup, 'Accounts.length') === 1 ? false : !account.IndividualMargining;
    const isOneAccount = _.size(account.Accounts) === 1 || accountsCount === 1;

    return account.IsMarginTradingAllowed && (
        (account.IsSummary && accountGroupsCount < 2 && !isClientMargin) ||
        (account.IsAccount && isAccountMargin) ||
        (account.IsGroup && isGroupMargin) ||
        isOneAccount);
};

export const showCreditLine = (account, accountsList, maxCreditLine) => {
    const maxCreditLineEnabled = maxCreditLine > 0;
    const accountsCount = _.size(_.filter(accountsList, 'IsAccount'));
    const accountGroupsCount = _.size(_.filter(accountsList, 'IsGroup'));
    const accountGroupKey = (account.AccountGroupKey) ? account.AccountGroupKey : null;
    const accountGroup = _.find(accountsList, { 'AccountId': accountGroupKey });

    if (account.IsAccount) {
        if (accountsCount > 1 && accountGroupsCount === 0) {
            return false;
        }

        if (accountGroup && accountGroup.Accounts.length > 1) {
            return false;
        }
    }

    if (account.IsSummary && accountGroupsCount > 1) {
        return false;
    }

    return maxCreditLineEnabled;
};

/**
 * Determines whether Account Value Shield is supported or not
 *
 * @param account {Object} - The currently selected account
 * @param accountList {Object} - Full list of accounts
 * @returns {Boolean}
 */
export const supportsAccountShield = (account, accountsList) => {
    if (!config.appFeatures.isAccountShieldEnabled) {
        return false;
    }

    const accountSummary = accountsQueries.getSummaryAccount(accountsList);

    // Saxo Select has its own account shield UI
    if (account.AccountType === 'AutoTradingFollower') {
        return false;
    }

    if (accountsList.length > 2) {
        return account.SupportsAccountValueProtectionLimit;
    }

    // if there's only one account, show it if either the account or client supports it
    return (account.SupportsAccountValueProtectionLimit || accountSummary.SupportsAccountValueProtectionLimit);
};

/**
 * when a client have only one account, don't show all account summary
 */
export const getAccounts = (accountsList) => (accountsList.length > 2) ? accountsList : _.filter(accountsList, 'IsAccount');

/**
 * finds the correct balance for the given
 */
export const findBalance = (balanceData, account) => _.find(balanceData, { id: account.id }) || {};

export const isMarginClient = (account, accounts) => (account.IsSummary || accounts.length === 1) && account.IsMarginTradingAllowed;

export const marginAlertFormatter = (value) =>
    value === 0 ? Localization.getText('HTML5_Off') : numberFormat.formatPercentage(value);

export const accountShieldFormatter = (value, decimals) =>
    value === 0 ? Localization.getText('HTML5_Off') : numberFormat.formatPrice(value, decimals);

/**
 * get account shield value for a given account
 * we want to first check if account shield value is on the given account, if not we want to check client level
 */
export const getAccountShield = (account, accountsList) => {
    const summary = _.find(accountsList, 'IsSummary');
    return _.get(account, 'AccountValueProtectionLimit') || _.get(summary, 'AccountValueProtectionLimit') || 0;
};
