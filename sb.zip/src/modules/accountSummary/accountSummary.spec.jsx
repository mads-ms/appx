import React from 'react';
import { shallow } from 'enzyme';
import AccountSummary from 'src/modules/accountSummary/accountSummary';

describe('src/modules/accountSummary/accountSummary', () => {
    let mockActions;

    beforeEach(() => {
        mockActions = {
            createModule: jasmine.createSpy('createModule'),
            destroyModule: jasmine.createSpy('destroyModule'),
            activateModule: jasmine.createSpy('activateModule'),
            deactivateModule: jasmine.createSpy('deactivateModule'),
        };
    });

    it('should call module lifecycle actions exactly once', () => {
        const wrapper = shallow(<AccountSummary {...mockActions}/>);

        expect(mockActions.createModule).toHaveBeenCalledTimes(1);
        expect(mockActions.activateModule).toHaveBeenCalledTimes(1);

        wrapper.unmount();

        expect(mockActions.destroyModule).toHaveBeenCalledTimes(1);
        expect(mockActions.deactivateModule).toHaveBeenCalledTimes(1);
    });

    it('can render available margin', () => {
        const wrapper = shallow(<AccountSummary
            accountsList={[
                {
                    IndividualMargining: true,
                    IsMarginTradingAllowed: true,
                    IsAccount: true,
                    id: 'DEMO_USD',
                    AccountGroupKey: 'groupId',
                },
                {
                    AccountId: 'groupId',
                    Accounts: ['DEMO_USD'],
                },
            ]}
            account={
                {
                    IndividualMargining: true,
                    IsMarginTradingAllowed: true,
                    IsAccount: true,
                    id: 'DEMO_USD',
                    AccountGroupKey: 'groupId',
                }
            }
            accountId="DEMO_USD"
            {...mockActions}
        />);

        expect(wrapper.find('.acctsummary-margin-available').length).toEqual(2);
    });

    it('can render credit line', () => {
        const wrapper = shallow(<AccountSummary
            accountsList={[{
                IndividualMargining: true,
                IsMarginTradingAllowed: true,
                IsAccount: true,
                id: 'DEMO_USD',
            }]}
            account={
                {
                    IndividualMargining: true,
                    IsMarginTradingAllowed: true,
                    IsAccount: true,
                    id: 'DEMO_USD',
                }
            }
            accountId="DEMO_USD"
            balanceData={[{
                MaxCreditLine: 1000,
                IsAccount: true,
                id: 'DEMO_USD',
            }]}
            {...mockActions}
        />);

        expect(wrapper.find('.acctcreditsummary-margin-available').length).toEqual(1);
    });

    it('can render available variation margin', () => {
        const wrapper = shallow(<AccountSummary
            accountsList={[{
                IsVariationMarginEligible: true,
                id: 'DEMO_USD',
            }]}
            account={
                {
                    IsVariationMarginEligible: true,
                    id: 'DEMO_USD',
                }
            }
            accountId="DEMO_USD"
            {...mockActions}
        />);

        expect(wrapper.find('.acctsummary-variation-margin-available').length).toEqual(1);
    });
});
