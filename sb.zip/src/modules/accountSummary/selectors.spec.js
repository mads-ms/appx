import * as accountSummarySelectors from 'src/modules/accountSummary/selectors';
import * as utils from 'src/modules/settings/utils';
import * as userSettingKeys from 'src/modules/settings/userSettingKey';

describe('src/modules/accountSummary/selectors', () => {
    let state;

    beforeEach(() => {
        state = {
            'accountSummary': {
                'main': {
                    'accountId': 'USD-john',
                },
                'sub': {
                },
            },
        };
    });

    it('should get state be id', () => {
        expect(accountSummarySelectors.getById(state, 'main')).toEqual({ 'accountId': 'USD-john' });
    });

    it('should get current id', () => {
        expect(accountSummarySelectors.getCurrentAccountId(state, 'main')).toEqual('USD-john');
    });

    describe('getInitialAccountId', () => {

        it('should return persisted account id if persisted account is valid', () => {
            const mockState = utils.createUserSettings({
                clients: {
                    fetch: {
                        status: 'async-action-status/success',
                        error: null,
                    },
                    data: {
                        me: {
                            ClientId: '2147044823',
                            ClientKey: 'oB7PBE-0DhiO4rT2DbngHA==',
                            CurrencyDecimals: 2,
                            DefaultAccountId: 'test-partner',
                            DefaultCurrency: 'CHF',
                            IsMarginTradingAllowed: true,
                            PositionNettingMode: 'EndOfDay',
                            LegalAssetTypes: [
                                'FxSpot',
                                'FxForwards',
                                'FxVanillaOption',
                                'FxKnockInOption',
                                'FxKnockOutOption',
                                'FxBinaryOption',
                                'FxOneTouchOption',
                                'FxNoTouchOption',
                                'FuturesStrategy',
                                'Stock',
                                'Bond',
                                'FuturesOption',
                                'StockIndexOption',
                                'StockOption',
                                'MutualFund',
                                'ManagedFund',
                                'Cash',
                                'CfdOnStock',
                                'CfdOnIndex',
                                'CfdOnFutures',
                                'StockIndex',
                            ],
                            Name: 'test',
                            Sharing: [
                                'NoSharing',
                            ],
                        },
                        impersonated: {},
                    },
                },
                accounts: {
                    fetch: {
                        status: 'async-action-status/success',
                        error: null,
                    },
                    data: [
                        {
                            AccountGroupKey: 'oB7PBE-0DhiO4rT2DbngHA==',
                            AccountId: 'test1',
                            AccountKey: '0aFpHbhPyJwBxjIh3XiefQ==',
                            AccountType: 'Normal',
                            Active: true,
                            CfdBorrowingCostsActive: false,
                            ClientId: '2147044823',
                            ClientKey: 'oB7PBE-0DhiO4rT2DbngHA==',
                            Currency: 'CHF',
                            CurrencyDecimals: 2,
                            DirectMarketAccess: false,
                            IndividualMargining: false,
                            IsCurrencyConversionAtSettlementTime: true,
                            IsMarginTradingAllowed: true,
                            IsShareable: false,
                            IsTrialAccount: true,
                            LegalAssetTypes: [
                                'FxSpot',
                                'FxForwards',
                                'CfdOnIndex',
                            ],
                            Sharing: [
                                'NoSharing',
                            ],
                        },
                        {
                            AccountGroupKey: 'oB7PBE-0DhiO4rT2DbngHA==',
                            AccountId: 'VALID_PERSISTED_ID',
                            AccountKey: '0aFpHbhPyJwBxjIh3XiefQ==',
                            AccountType: 'Normal',
                            Active: true,
                            CfdBorrowingCostsActive: false,
                            ClientId: '2147044823',
                            ClientKey: 'oB7PBE-0DhiO4rT2DbngHA==',
                            Currency: 'CHF',
                            CurrencyDecimals: 2,
                            DirectMarketAccess: false,
                            IndividualMargining: false,
                            IsCurrencyConversionAtSettlementTime: true,
                            IsMarginTradingAllowed: true,
                            IsShareable: false,
                            IsTrialAccount: true,
                            LegalAssetTypes: [
                                'FxSpot',
                                'FxForwards',
                                'CfdOnIndex',
                            ],
                            Sharing: [
                                'NoSharing',
                            ],
                        },
                    ],
                },
                subscriptions: {
                    accounts: {},
                },
            }, {
                [userSettingKeys.LastUsedAccountAccountBar]: 'VALID_PERSISTED_ID',
            });

            expect(accountSummarySelectors.getInitialAccountId(mockState)).toEqual('VALID_PERSISTED_ID');
        });

        it('should return persisted account id if persisted account is valid - alternative account', () => {
            const mockState = utils.createUserSettings({
                clients: {
                    fetch: {
                        status: 'async-action-status/success',
                        error: null,
                    },
                    data: {
                        me: {
                            ClientId: '2147044823',
                            ClientKey: 'oB7PBE-0DhiO4rT2DbngHA==',
                            CurrencyDecimals: 2,
                            DefaultAccountId: 'test-partner',
                            DefaultCurrency: 'CHF',
                            IsMarginTradingAllowed: true,
                            PositionNettingMode: 'EndOfDay',
                            LegalAssetTypes: [
                                'FxSpot',
                                'FxForwards',
                                'FxVanillaOption',
                                'FxKnockInOption',
                                'FxKnockOutOption',
                                'FxBinaryOption',
                                'FxOneTouchOption',
                                'FxNoTouchOption',
                                'FuturesStrategy',
                                'Stock',
                                'Bond',
                                'FuturesOption',
                                'StockIndexOption',
                                'StockOption',
                                'ManagedFund',
                                'Cash',
                                'CfdOnStock',
                                'CfdOnIndex',
                                'CfdOnFutures',
                                'StockIndex',
                            ],
                            Name: 'test',
                            Sharing: [
                                'NoSharing',
                            ],
                        },
                        impersonated: {},
                    },
                },
                accounts: {
                    fetch: {
                        status: 'async-action-status/success',
                        error: null,
                    },
                    data: [
                        {
                            AccountGroupKey: 'oB7PBE-0DhiO4rT2DbngHA==',
                            AccountId: 'test1',
                            AccountKey: '0aFpHbhPyJwBxjIh3XiefQ==',
                            AccountType: 'Normal',
                            Active: true,
                            CfdBorrowingCostsActive: false,
                            ClientId: '2147044823',
                            ClientKey: 'oB7PBE-0DhiO4rT2DbngHA==',
                            Currency: 'CHF',
                            CurrencyDecimals: 2,
                            DirectMarketAccess: false,
                            IndividualMargining: false,
                            IsCurrencyConversionAtSettlementTime: true,
                            IsMarginTradingAllowed: true,
                            IsShareable: false,
                            IsTrialAccount: true,
                            LegalAssetTypes: [
                                'FxSpot',
                                'FxForwards',
                                'CfdOnIndex',
                            ],
                            Sharing: [
                                'NoSharing',
                            ],
                        },
                        {
                            AccountGroupKey: 'oB7PBE-0DhiO4rT2DbngHA==',
                            AccountId: 'VALID_PERSISTED_ID',
                            AccountKey: '0aFpHbhPyJwBxjIh3XiefQ==',
                            AccountType: 'Normal',
                            Active: true,
                            CfdBorrowingCostsActive: false,
                            ClientId: '2147044823',
                            ClientKey: 'oB7PBE-0DhiO4rT2DbngHA==',
                            Currency: 'CHF',
                            CurrencyDecimals: 2,
                            DirectMarketAccess: false,
                            IndividualMargining: false,
                            IsCurrencyConversionAtSettlementTime: true,
                            IsMarginTradingAllowed: true,
                            IsShareable: false,
                            IsTrialAccount: true,
                            LegalAssetTypes: [
                                'FxSpot',
                                'FxForwards',
                                'CfdOnIndex',
                            ],
                            Sharing: [
                                'NoSharing',
                            ],
                        },
                    ],
                },
                accountGroups: {},
                subscriptions: {
                    accounts: {},
                },
            }, {
                [userSettingKeys.LastUsedAccountAccountBar]: 'test1',
            });

            expect(accountSummarySelectors.getInitialAccountId(mockState)).toEqual('test1');
        });

        it('should return default account id if the is no persisted account', () => {
            const mockState = utils.createUserSettings({
                clients: {
                    fetch: {
                        status: 'async-action-status/success',
                    },
                    data: {
                        me: {
                            ClientId: '2147044823',
                        },
                    },
                },
                accounts: {
                    data: [
                        {
                            AccountId: 'DEFAULT_ACCOUNT_ID',
                        },
                    ],
                },
                subscriptions: {
                    accounts: {},
                },
            }, {
                [userSettingKeys.LastUsedAccountAccountBar]: 'id-tablet',
            });

            expect(accountSummarySelectors.getInitialAccountId(mockState)).toEqual('DEFAULT_ACCOUNT_ID');
        });

        it('should convert to a string if it is a number', () => {
            const mockState = utils.createUserSettings({
                clients: {
                    fetch: {
                        status: 'async-action-status/success',
                    },
                    data: {
                        me: {
                            ClientId: '2147044823',
                        },
                    },
                },
                accounts: {
                    data: [
                        {
                            AccountId: '123456',
                        },
                    ],
                },
                accountGroups: {},
                subscriptions: {
                    accounts: {},
                },
            }, {
                [userSettingKeys.LastUsedAccountAccountBar]: 123456,
            });

            expect(accountSummarySelectors.getInitialAccountId(mockState)).toEqual('123456');
        });

    });
});
