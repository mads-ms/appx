import SagaTester from 'redux-tale/tester';
import
rewire, // eslint-disable-line import/default
* as sagas from 'src/modules/accountSummary/sagas';
import * as moduleLifecycleActions from 'src/modules/moduleLifecycle/actions';
import * as moduleTypes from 'src/modules/workspace/moduleTypes';
import * as balancesActions from 'src/modules/balances/actions';

describe('src/modules/accountSummary/sagas', () => {

    const componentId = 'accountsummary';

    let sagaTester;

    beforeEach(() => {
        sagaTester = new SagaTester({});
    });

    it('sets up the balance subscription when activated', () => {
        rewire.__set__('selectors', {
            getInitialAccountId() {
                return 'DEMO_USD';
            },
        });

        sagaTester.start(sagas.onActivateSaga);
        sagaTester.dispatch(moduleLifecycleActions.activate(moduleTypes.ACCOUNT_SUMMARY, componentId));
        const calledActions = sagaTester.getCalledActions();

        expect(calledActions).toContainOneAction(balancesActions.addListener(componentId));
        rewire.__ResetDependency__('accountSummarySelectors');
    });

    it('cleans up the balance subscription when deactivated', () => {
        sagaTester.start(sagas.onDeactivateSaga);
        sagaTester.dispatch(moduleLifecycleActions.deactivate(moduleTypes.ACCOUNT_SUMMARY, componentId));
        const calledActions = sagaTester.getCalledActions();

        expect(calledActions).toContainOneAction(balancesActions.removeListener(componentId));
    });
});
