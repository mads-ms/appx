import { TRIGGER_GET } from './actionTypes';
import './sagas';

export function get({ clientId, startDate, endDate }) {
    return {
        type: TRIGGER_GET,
        clientId,
        startDate,
        endDate,
    };
}
