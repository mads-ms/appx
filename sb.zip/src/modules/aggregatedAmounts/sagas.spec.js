import { put, call, select } from 'redux-tale/effects';
import {
    getAggregatedAmounts,
    fetchAmounts,
    fetchData,
} from 'src/modules/aggregatedAmounts/sagas';
import * as AggregatedAmountsActionTypes from 'src/modules/aggregatedAmounts/actionTypes';

describe('src/modules/aggregatedAmounts/sagas', () => {
    let gen;

    it('fetchAmounts should update the store with isloading info, call open api with the right parameters ' +
        'for several periods and handle both success and error in calls',
    () => {

        const clientKey = '123';
        const startDate = '2016-01-01';
        const endDate = '2016-03-31';

        const existingAggregatedAmountsState = {
            'y2016m2': {
                data: [],
                isLoading: false,
                error: false,
            },
        };

        gen = fetchAmounts(
            {
                clientKey, startDate, endDate,
            });

        expect(gen.next(existingAggregatedAmountsState).value).toEqual(select(getAggregatedAmounts));

        expect(gen.next(existingAggregatedAmountsState).value).toEqual(put({
            type: AggregatedAmountsActionTypes.AGGREGATED_AMOUNTS_ADD_BUCKETS,
            buckets: [
                {
                    bucketKey: 'y2016m1',
                    data: [],
                    isLoading: true,
                    error: false,
                },
                {
                    bucketKey: 'y2016m3',
                    data: [],
                    isLoading: true,
                    error: false,
                },
            ],
        }));

        const expectedFetchDataCalls = [
            call(fetchData,
                {
                    clientKey,
                    startDate: '2016-01-01',
                    endDate: '2016-01-31',
                }),
            call(fetchData,
                {
                    clientKey,
                    startDate: '2016-03-01',
                    endDate: '2016-03-31',
                }),
        ];

        expect(gen.next().value).toEqual(expectedFetchDataCalls);

        const mockedResFromServer = [
            {
                data: [
                    {
                        Date: '2016-01-05',
                        BookingAccountId: '123INET',
                    },
                    {
                        Date: '2016-01-06',
                        BookingAccountId: '123INET',
                    },
                ],
                clientKey,
                startDate: '2016-01-01',
                endDate: '2016-01-31',
            },
            {
                data: [],
                clientKey,
                startDate: '2016-03-01',
                endDate: '2016-03-31',
            },
        ];

        expect(gen.next(mockedResFromServer).value).toEqual(put({
            type: AggregatedAmountsActionTypes.AGGREGATED_AMOUNTS_ADD_BUCKETS,
            buckets: [
                {
                    bucketKey: 'y2016m1',
                    data: [
                        {
                            Date: '2016-01-05',
                            BookingAccountId: '123INET',
                        },
                        {
                            Date: '2016-01-06',
                            BookingAccountId: '123INET',
                        },
                    ],
                    isLoading: false,
                    error: false,
                },
                {
                    bucketKey: 'y2016m3',
                    data: [],
                    isLoading: false,
                    error: false,
                },
            ],
        }));

        expect(gen.next().done).toEqual(true);
    });

    it('fetchAmounts should throw if an error is returned', () => {

        const clientKey = '123';
        const startDate = '2016-01-01';
        const endDate = '2016-01-31';

        const existingAggregatedAmountsState = {};

        gen = fetchAmounts(
            {
                clientKey, startDate, endDate,
            });

        expect(gen.next(existingAggregatedAmountsState).value).toEqual(select(getAggregatedAmounts));

        expect(gen.next(existingAggregatedAmountsState).value).toEqual(put({
            type: AggregatedAmountsActionTypes.AGGREGATED_AMOUNTS_ADD_BUCKETS,
            buckets: [
                {
                    bucketKey: 'y2016m1',
                    data: [],
                    isLoading: true,
                    error: false,
                },
            ],
        }));

        const expectedFetchDataCalls = [
            call(fetchData,
                {
                    clientKey,
                    startDate: '2016-01-01',
                    endDate: '2016-01-31',
                }),
        ];

        expect(gen.next().value).toEqual(expectedFetchDataCalls);

        const mockedResFromServer = [
            {
                error: true,
                clientKey,
                startDate: '2016-01-01',
                endDate: '2016-01-31',
            },
        ];

        expect(gen.next(mockedResFromServer).value).toEqual(put({
            type: AggregatedAmountsActionTypes.AGGREGATED_AMOUNTS_ADD_BUCKETS,
            buckets: [
                {
                    bucketKey: 'y2016m1',
                    data: [],
                    isLoading: false,
                    error: true,
                },
            ],
        }));

        expect(() => {
            gen.next();
        }).toThrow();
    });

    it('fetchAmounts should return if there is nothing left to get',
        () => {

            const clientKey = '123';
            const startDate = '2016-01-01';
            const endDate = '2016-03-31';

            const existingAggregatedAmountsState = {
                'y2016m2': {
                    data: [],
                    isLoading: false,
                    error: false,
                },
                'y2016m1': {
                    data: [],
                    isLoading: false,
                    error: false,
                },
                'y2016m3': {
                    data: [],
                    isLoading: false,
                    error: false,
                },
            };

            gen = fetchAmounts(
                {
                    clientKey, startDate, endDate,
                });

            expect(gen.next(existingAggregatedAmountsState).value).toEqual(select(getAggregatedAmounts));

            expect(gen.next(existingAggregatedAmountsState).done).toEqual(true);
        });
});
