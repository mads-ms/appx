import _ from 'lodash';
import * as aggregatedAmountsActionTypes from './actionTypes';

// The aggregated amounts state is held in a structure like this:
// {
//    y2016m1:
//    {
//        data: [],
//        isLoading: false
//        error: false
//    },
// }
// This allows us to easily load each month separately and simultanously.
// Each item year/month entry is referred to as a bucket.

export const initialState = { };

export default function aggregatedAmountsStateReducer(state = initialState, action) {
    switch (action.type) {
        case aggregatedAmountsActionTypes.AGGREGATED_AMOUNTS_ADD_BUCKETS:
            return handleAddBuckets(state, action);

        default:
            return state;
    }
}

function handleAddBuckets(state, action) {
    return _.defaults(_.keyBy(action.buckets, 'bucketKey'), state);
}
