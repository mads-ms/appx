export const TRIGGER_GET = 'sagas/aggregatedAmounts/get';
export const AGGREGATED_AMOUNTS_ADD_BUCKETS = 'aggregated-amounts/add-buckets';
