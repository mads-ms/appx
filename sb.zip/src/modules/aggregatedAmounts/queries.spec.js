import {
    getBucketKeysFromDateRange,
    getBucketKeysInState,
    getYearMonthForBucketKey,
    getStartDateForBucketKey,
    getEndDateForBucketKey,
    getDateRangesFromBucketKeyList,
    filterByAccountInfo,
    getAggregatedAmountsArray,
    getBookedOnly,
    getPnLOnly,
    getInstrumentRelatedOnly,
    getNonInstrumentRelatedOnly,
    getTotalInstrumentRelatedPnl,
    getTotalInstrumentRelatedBookings,
    getTotalNonInstrumentRelatedBookings,
    getInstrumentRelatedPnlGroupedByAssetType,
    getProfitLossPerDay,
    getCumulativeProfitLoss,
    getPnlPerInstrumentForAssetType,
    getPnlPerInstrument,
    getTotalSecurityTransfers,
    getTotalCashTransfers,
    getBookedPerBookingType,
    __RewireAPI__ as rewire,  // eslint-disable-line import/named
} from 'src/modules/aggregatedAmounts/queries';
import DateTime from 'src/modules/dateTime';
import * as amountTypeNames from './amountTypeNames';

describe('src/modules/aggregatedAmounts/queries', () => {

    it('getBucketKeysFromDateRange should return full months partially covered months', () => {

        const startDate = DateTime.createDate('2016-01-31');
        const endDate = DateTime.createDate('2016-03-01');
        const expectedBuckets = ['y2016m1', 'y2016m2', 'y2016m3'];
        const buckets = getBucketKeysFromDateRange(startDate, endDate);
        expect(buckets).toEqual(expectedBuckets);

    });

    it('getBucketKeysInState should return all buckets in state', () => {

        const aaState = {
            'y2016m1': {
                error: null,
                isLoading: false,

            },
            'y2016m2': {
                error: null,
                isLoading: false,
            },
        };
        const startDate = DateTime.createDate('2016-01-31');
        const endDate = DateTime.createDate('2016-03-01');

        const expectedBuckets = ['y2016m1', 'y2016m2'];
        const buckets = getBucketKeysInState(aaState, startDate, endDate);
        expect(buckets).toEqual(expectedBuckets);
    });

    it('getBucketKeysInState should not return buckets that are loading', () => {

        const aaState = {
            'y2016m1': {
                error: null,
                isLoading: true,

            },
            'y2016m2': {
                error: null,
                isLoading: false,
            },
        };
        const startDate = DateTime.createDate('2016-01-31');
        const endDate = DateTime.createDate('2016-03-01');

        const expectedBuckets = ['y2016m2'];
        const buckets = getBucketKeysInState(aaState, startDate, endDate);
        expect(buckets).toEqual(expectedBuckets);
    });

    it('getBucketKeysInState should not return buckets that have errors', () => {

        const aaState = {
            'y2016m1': {
                error: 'Some error',
                isLoading: false,

            },
            'y2016m2': {
                error: null,
                isLoading: false,
            },
        };
        const startDate = DateTime.createDate('2016-01-31');
        const endDate = DateTime.createDate('2016-03-01');

        const expectedBuckets = ['y2016m2'];
        const buckets = getBucketKeysInState(aaState, startDate, endDate);
        expect(buckets).toEqual(expectedBuckets);
    });

    it('getYearMonthForBucketKey should return correct strings', () => {
        expect(getYearMonthForBucketKey('y2016m1')).toEqual('2016-01');
        expect(getYearMonthForBucketKey('y2016m2')).toEqual('2016-02');
        expect(getYearMonthForBucketKey('y2016m7')).toEqual('2016-07');
    });

    it('getStartDateForBucketKey should return correct date', () => {
        expect(getStartDateForBucketKey('y2016m1').toOapi()).toEqual('2016-01-01');
        expect(getStartDateForBucketKey('y2016m2').toOapi()).toEqual('2016-02-01');
        expect(getStartDateForBucketKey('y2016m7').toOapi()).toEqual('2016-07-01');
    });

    it('getEndDateForBucketKey should return correct date', () => {
        expect(getEndDateForBucketKey('y2016m1').toOapi()).toEqual('2016-01-31');
        expect(getEndDateForBucketKey('y2016m2').toOapi()).toEqual('2016-02-29');
        expect(getEndDateForBucketKey('y2016m7').toOapi()).toEqual('2016-07-31');
    });

    it('getDateRangesFromBucketKeyList should return correct date ranges', () => {
        const bucketKeys = ['y2016m1', 'y2016m3'];
        const dateRanges = getDateRangesFromBucketKeyList(bucketKeys);
        expect(dateRanges.length).toEqual(2);

        const firstDateRange = dateRanges[0];
        const lastDateRange = dateRanges[1];

        expect(firstDateRange.startDate.toOapi()).toEqual('2016-01-01');
        expect(firstDateRange.endDate.toOapi()).toEqual('2016-01-31');
        expect(lastDateRange.startDate.toOapi()).toEqual('2016-03-01');
        expect(lastDateRange.endDate.toOapi()).toEqual('2016-03-31');
    });

    it('filterByAccountInfo should filter aggregated amounts correctly based on the accountInfo', () => {
        rewire.__Rewire__('config', { appFeatures: { useMockedPerfData: false } });

        const aa = {
            BookingAccountId: '179643INET',
        };

        const acctInfoClientLevel = {
            isClientLevel: true,
        };

        const acctInfoMatchingAcct = {
            isRegularAccount: true,
            accountId: '179643INET',
        };

        const acctInfoNonMatchingAcct = {
            isRegularAccount: true,
            accountId: 'xxxxxx',
        };

        const acctInfoMatchingAcctGroup = {
            isAccountGroup: true,
            accountIdsInGroup: ['179643INET'],
        };

        const acctInfoNonMatchingAcctGroup = {
            isAccountGroup: true,
            accountIdsInGroup: ['xxxxxx'],
        };

        expect(filterByAccountInfo(acctInfoClientLevel, aa)).toEqual(true);
        expect(filterByAccountInfo(acctInfoMatchingAcct, aa)).toEqual(true);
        expect(filterByAccountInfo(acctInfoNonMatchingAcct, aa)).toEqual(false);
        expect(filterByAccountInfo(acctInfoMatchingAcctGroup, aa)).toEqual(true);
        expect(filterByAccountInfo(acctInfoNonMatchingAcctGroup, aa)).toEqual(false);

        rewire.__ResetDependency__('config');
    });

    it('getAggregatedAmountsArray should return a correct array', () => {
        rewire.__Rewire__('config', { appFeatures: { useMockedPerfData: false } });

        const aggregatedAmounts = {
            y2016m1: {
                data: [
                    {
                        Date: '2016-01-15',
                        BookingAccountId: '179643INET',
                    },
                    {
                        Date: '2016-02-02',
                        BookingAccountId: '179643INET',
                    },
                ],
            },
        };

        const acctInfoClientLevel = {
            isClientLevel: true,
        };

        const startDate = DateTime.createDate('2016-01-01');
        const endDate = DateTime.createDate('2016-01-31');

        expect(getAggregatedAmountsArray(aggregatedAmounts, acctInfoClientLevel, startDate, endDate)).toEqual([
            {
                Date: '2016-01-15',
                BookingAccountId: '179643INET',
            },
        ]);
        rewire.__ResetDependency__('config');
    });

    it('getAggregatedAmountsArray should sort correctly', () => {
        rewire.__Rewire__('config', { appFeatures: { useMockedPerfData: false } });

        const aggregatedAmounts = {
            y2016m1: {
                data: [
                    {
                        Date: '2016-01-15',
                        BookingAccountId: '179643INET',
                    },
                    {
                        Date: '2016-01-02',
                        BookingAccountId: '179643INET',
                    },
                    {
                        Date: '2016-01-01',
                        BookingAccountId: '179643INET',
                    },
                ],
            },
            y2016m2: {
                data: [
                    {
                        Date: '2016-02-02',
                        BookingAccountId: '179643INET',
                    },
                    {
                        Date: '2016-02-01',
                        BookingAccountId: '179643INET',
                    },
                    {
                        Date: '2016-02-21',
                        BookingAccountId: '179643INET',
                    },
                ],
            },
        };

        const acctInfoClientLevel = {
            isClientLevel: true,
        };

        const startDate = DateTime.createDate('2016-01-02');
        const endDate = DateTime.createDate('2016-02-10');

        expect(getAggregatedAmountsArray(aggregatedAmounts, acctInfoClientLevel, startDate, endDate)).toEqual([
            {
                Date: '2016-01-02',
                BookingAccountId: '179643INET',
            },
            {
                Date: '2016-01-15',
                BookingAccountId: '179643INET',
            },
            {
                Date: '2016-02-01',
                BookingAccountId: '179643INET',
            },
            {
                Date: '2016-02-02',
                BookingAccountId: '179643INET',
            },
        ]);
        rewire.__ResetDependency__('config');
    });

    it('getAggregatedAmountsArray should sort correctly including october', () => {
        rewire.__Rewire__('config', { appFeatures: { useMockedPerfData: false } });

        const aggregatedAmounts = {
            y2016m1: {
                data: [
                    {
                        Date: '2016-01-01',
                        BookingAccountId: '179643INET',
                    },
                ],
            },
            y2016m10: {
                data: [
                    {
                        Date: '2016-10-01',
                        BookingAccountId: '179643INET',
                    },
                ],
            },
            y2016m2: {
                data: [
                    {
                        Date: '2016-02-01',
                        BookingAccountId: '179643INET',
                    },
                ],
            },
        };

        const acctInfoClientLevel = {
            isClientLevel: true,
        };

        const startDate = DateTime.createDate('2016-01-01');
        const endDate = DateTime.createDate('2016-10-10');

        expect(getAggregatedAmountsArray(aggregatedAmounts, acctInfoClientLevel, startDate, endDate)).toEqual([
            {
                Date: '2016-01-01',
                BookingAccountId: '179643INET',
            },
            {
                Date: '2016-02-01',
                BookingAccountId: '179643INET',
            },
            {
                Date: '2016-10-01',
                BookingAccountId: '179643INET',
            },
        ]);
        rewire.__ResetDependency__('config');
    });

    it('getBookedOnly should only return booked amount types that affect the balance', () => {
        const aaArray =
            [
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    AffectsBalance: false,
                    AmountTypeId: 5,

                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    AffectsBalance: true,
                    AmountTypeId: 5,

                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    AffectsBalance: false,
                    AmountTypeId: -4,

                },
            ];

        const aaArrayExpected =
            [
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    AffectsBalance: true,
                    AmountTypeId: 5,
                },
            ];

        expect(getBookedOnly(aaArray)).toEqual(aaArrayExpected);
    });

    it('getPnLOnly should only return pnl amount types (AmontTypeId ==== -5)', () => {

        const aaArray =
            [
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    AmountTypeId: 4,

                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    AmountTypeId: -5,
                },
            ];

        const aaArrayExpected =
            [
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    AmountTypeId: -5,
                },
            ];

        expect(getPnLOnly(aaArray)).toEqual(aaArrayExpected);
    });

    it('getInstrumentRelatedOnly should only return amount types related to an instrument and exclude cash related amounts', () => {

        const aaArray =
            [
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    Uic: 9465,
                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    Uic: 9466,
                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    Uic: 0,
                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    Uic: 123,
                },
            ];

        const aaArrayExpected =
            [
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    Uic: 123,
                },
            ];

        expect(getInstrumentRelatedOnly(aaArray)).toEqual(aaArrayExpected);
    });

    it('getNonInstrumentRelatedOnly should only return amount types thayt are not related an instrument and exclude cash related amounts', () => {

        const aaArray =
            [
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    Uic: 9465,
                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    Uic: 9466,
                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    Uic: 0,
                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    Uic: 123,
                },
            ];

        const aaArrayExpected =
            [
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    Uic: 0,
                },
            ];

        expect(getNonInstrumentRelatedOnly(aaArray)).toEqual(aaArrayExpected);
    });

    it('getTotalInstrumentRelatedPnl should return correct value', () => {

        rewire.__Rewire__('config', { appFeatures: { useMockedPerfData: false } });

        const accountInfo = {
            isAccountGroup: false,
            isClientLevel: true,
        };

        const aggregatedAmountsArray =
            [
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    Uic: 9465,
                    AmountClientCurrency: 1111,
                    AffectsBalance: true,
                    AmountTypeId: -5,
                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    Uic: 9466,
                    AffectsBalance: true,
                    AmountTypeId: -5,
                    AmountClientCurrency: 1111,
                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    Uic: 0,
                    AffectsBalance: true,
                    AmountTypeId: -5,
                    AmountClientCurrency: 1111,
                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    Uic: 123,
                    AffectsBalance: true,
                    AmountTypeId: -5,
                    AmountClientCurrency: 1234,
                },
            ];
        expect(getTotalInstrumentRelatedPnl({
            aggregatedAmountsArray,
            accountInfo,
        })).toEqual(1234);

        rewire.__ResetDependency__('config');
    });

    it('getTotalInstrumentRelatedBookings should return correct value', () => {

        rewire.__Rewire__('config', { appFeatures: { useMockedPerfData: false } });

        const accountInfo = {
            isAccountGroup: false,
            isClientLevel: true,
        };

        const aggregatedAmountsArray =
            [
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    Uic: 9465,
                    AmountClientCurrency: 1111,
                    AffectsBalance: true,
                    AmountTypeId: 5,
                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    Uic: 9466,
                    AffectsBalance: true,
                    AmountTypeId: 5,
                    AmountClientCurrency: 1111,
                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    Uic: 0,
                    AffectsBalance: true,
                    AmountTypeId: 5,
                    AmountClientCurrency: 1111,
                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    Uic: 123,
                    AffectsBalance: true,
                    AmountTypeId: 5,
                    AmountClientCurrency: 1234,
                },
            ];

        expect(getTotalInstrumentRelatedBookings({
            aggregatedAmountsArray,
            accountInfo,
        })).toEqual(1234);

        rewire.__ResetDependency__('config');
    });

    it('getTotalNonInstrumentRelatedBookings should return correct value', () => {

        rewire.__Rewire__('config', { appFeatures: { useMockedPerfData: false } });

        const accountInfo = {
            isAccountGroup: false,
            isClientLevel: true,
        };

        const aggregatedAmountsArray =
            [
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    Uic: 9465,
                    AmountClientCurrency: 333,
                    AffectsBalance: true,
                    AmountTypeId: 5,
                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    Uic: 9466,
                    AffectsBalance: true,
                    AmountTypeId: 5,
                    AmountClientCurrency: 222,
                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    Uic: 0,
                    AffectsBalance: true,
                    AmountTypeId: 5,
                    AmountClientCurrency: 1111,
                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    Uic: 123,
                    AffectsBalance: true,
                    AmountTypeId: 5,
                    AmountClientCurrency: 1234,
                },
            ];

        expect(getTotalNonInstrumentRelatedBookings({
            aggregatedAmountsArray,
            accountInfo,
        })).toEqual(1111);

        rewire.__ResetDependency__('config');
    });

    it('getInstrumentRelatedPnlGroupedByAssetType should return correct value', () => {

        rewire.__Rewire__('config', { appFeatures: { useMockedPerfData: false } });

        const accountInfo = {
            isAccountGroup: false,
            isClientLevel: true,
        };

        const aggregatedAmountsArray =
            [
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    AssetType: 'Shares',
                    Uic: 123,
                    AmountClientCurrency: 1111,
                    AffectsBalance: true,
                    AmountTypeId: -5,
                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    AssetType: 'Bonds',
                    Uic: 345,
                    AffectsBalance: true,
                    AmountTypeId: -5,
                    AmountClientCurrency: 2222,
                },
            ];

        const expectedResult = [
            {
                AssetType: 'Shares',
                Amount: 1111,
            },
            {
                AssetType: 'Bonds',
                Amount: 2222,
            },
        ];

        expect(getInstrumentRelatedPnlGroupedByAssetType({
            aggregatedAmountsArray,
            accountInfo,
        })).toEqual(expectedResult);

        rewire.__ResetDependency__('config');
    });

    it('getProfitLossPerDay should return correct value', () => {

        rewire.__Rewire__('config', { appFeatures: { useMockedPerfData: false } });

        const accountInfo = {
            isAccountGroup: false,
            isClientLevel: true,
        };

        const aggregatedAmountsArray =
            [
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    AssetType: 'Shares',
                    Uic: 123,
                    AmountClientCurrency: 1111,
                    AffectsBalance: true,
                    AmountTypeId: -5,
                },
                {
                    Date: '2016-01-16',
                    BookingAccountId: '179643INET',
                    AssetType: 'Bonds',
                    Uic: 345,
                    AffectsBalance: true,
                    AmountTypeId: -5,
                    AmountClientCurrency: 2222,
                },
            ];

        // omit tradeDateAsDate property as jasmine's equality assertion asserts
        // on private moment state causing false negative results
        const expectedResult = [jasmine.objectContaining({
            Date: '2016-01-15',
            Amount: 1111,
        }), jasmine.objectContaining({
            Date: '2016-01-16',
            Amount: 2222,
        }),
        ];

        const actual = getProfitLossPerDay({
            aggregatedAmountsArray,
            accountInfo,
        });

        expect(actual).toEqual(expectedResult);

        rewire.__ResetDependency__('config');
    });

    it('getCumulativeProfitLoss should return correct value', () => {

        rewire.__Rewire__('config', { appFeatures: { useMockedPerfData: false } });

        const accountInfo = {
            isAccountGroup: false,
            isClientLevel: true,
        };

        const aggregatedAmountsArray =
            [
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    AssetType: 'Shares',
                    Uic: 123,
                    AmountClientCurrency: 1111,
                    AffectsBalance: true,
                    AmountTypeId: -5,
                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    AssetType: 'Bonds',
                    Uic: 345,
                    AffectsBalance: true,
                    AmountTypeId: -5,
                    AmountClientCurrency: 2222,
                },
                {
                    Date: '2016-01-16',
                    BookingAccountId: '179643INET',
                    AssetType: 'Bonds',
                    Uic: 345,
                    AffectsBalance: true,
                    AmountTypeId: -5,
                    AmountClientCurrency: 3333,
                },
                {
                    Date: '2016-01-17',
                    BookingAccountId: '179643INET',
                    AssetType: 'Bonds',
                    Uic: 345,
                    AffectsBalance: true,
                    AmountTypeId: 22,
                    AmountClientCurrency: 7777,
                },
            ];

        const expectedResult = [
            {
                Date: '2016-01-15',
                Amount: 3333,
            },
            {
                Date: '2016-01-16',
                Amount: 6666,
            },
            {
                Date: '2016-01-17',
                Amount: 6666,
            },
        ];

        expect(getCumulativeProfitLoss({
            aggregatedAmountsArray,
            accountInfo,
        })).toEqual(expectedResult);

        rewire.__ResetDependency__('config');
    });

    it('getPnlPerInstrumentForAssetType should return correct value', () => {

        rewire.__Rewire__('config', { appFeatures: { useMockedPerfData: false } });

        const accountInfo = {
            isAccountGroup: false,
            isClientLevel: true,
        };

        const aggregatedAmountsArray =
            [
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    AssetType: 'Shares',
                    Uic: 123,
                    InstrumentSymbolCode: 'SC123',
                    InstrumentDescription: 'Desc 123',
                    InstrumentISINCode: 'ISIN 123',
                    InstrumentSubType: 'Sub Type 123',
                    AmountClientCurrency: 1123,
                    AffectsBalance: true,
                    AmountTypeId: -5,
                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    AssetType: 'Shares',
                    Uic: 456,
                    InstrumentSymbolCode: 'SC456',
                    InstrumentDescription: 'Desc 456',
                    InstrumentISINCode: 'ISIN 456',
                    InstrumentSubType: 'Sub Type 456',
                    AmountClientCurrency: 1456,
                    AffectsBalance: true,
                    AmountTypeId: -5,
                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    AssetType: 'Bonds',
                    Uic: 789,
                    InstrumentSymbolCode: 'SC789',
                    InstrumentDescription: 'Desc 789',
                    InstrumentISINCode: 'ISIN 789',
                    InstrumentSubType: 'Sub Type 789',
                    AmountClientCurrency: 1789,
                    AffectsBalance: true,
                    AmountTypeId: -5,
                },
                {
                    Date: '2016-01-16',
                    BookingAccountId: '179643INET',
                    AssetType: 'Shares',
                    Uic: 123,
                    InstrumentSymbolCode: 'SC123',
                    InstrumentDescription: 'Desc 123',
                    InstrumentISINCode: 'ISIN 123',
                    InstrumentSubType: 'Sub Type 123',
                    AmountClientCurrency: 2123,
                    AffectsBalance: true,
                    AmountTypeId: -5,
                },
                {
                    Date: '2016-01-16',
                    BookingAccountId: '179643INET',
                    AssetType: 'Shares',
                    Uic: 456,
                    InstrumentSymbolCode: 'SC456',
                    InstrumentDescription: 'Desc 456',
                    InstrumentISINCode: 'ISIN 456',
                    InstrumentSubType: 'Sub Type 456',
                    AmountClientCurrency: 2456,
                    AffectsBalance: true,
                    AmountTypeId: -5,
                },
                {
                    Date: '2016-01-16',
                    BookingAccountId: '179643INET',
                    AssetType: 'Bonds',
                    Uic: 789,
                    InstrumentSymbolCode: 'SC789',
                    InstrumentDescription: 'Desc 789',
                    InstrumentISINCode: 'ISIN 789',
                    InstrumentSubType: 'Sub Type 789',
                    AmountClientCurrency: 2789,
                    AffectsBalance: true,
                    AmountTypeId: -5,
                },
            ];

        const expectedResult = [
            {
                Uic: 123,
                InstrumentSymbolCode: 'SC123',
                InstrumentDescription: 'Desc 123',
                InstrumentISINCode: 'ISIN 123',
                InstrumentSubType: 'Sub Type 123',
                AssetType: 'Shares',
                Amount: 3246,
            },
            {
                Uic: 456,
                InstrumentSymbolCode: 'SC456',
                InstrumentDescription: 'Desc 456',
                InstrumentISINCode: 'ISIN 456',
                InstrumentSubType: 'Sub Type 456',
                AssetType: 'Shares',
                Amount: 3912,
            },
        ];

        expect(getPnlPerInstrumentForAssetType({
            aggregatedAmountsArray,
            accountInfo,
            assetType: 'Shares',
        })).toEqual(expectedResult);

        rewire.__ResetDependency__('config');
    });

    it('getPnlPerInstrument should return correct value', () => {

        rewire.__Rewire__('config', { appFeatures: { useMockedPerfData: false } });

        const accountInfo = {
            isAccountGroup: false,
            isClientLevel: true,
        };

        const aggregatedAmountsArray =
            [
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    AssetType: 'Shares',
                    Uic: 123,
                    InstrumentSymbolCode: 'SC123',
                    InstrumentDescription: 'Desc 123',
                    InstrumentISINCode: 'ISIN 123',
                    InstrumentSubType: 'Sub Type 123',
                    AmountClientCurrency: 1123,
                    AffectsBalance: true,
                    AmountTypeId: -5,
                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    AssetType: 'Shares',
                    Uic: 456,
                    InstrumentSymbolCode: 'SC456',
                    InstrumentDescription: 'Desc 456',
                    InstrumentISINCode: 'ISIN 456',
                    InstrumentSubType: 'Sub Type 456',
                    AmountClientCurrency: 1456,
                    AffectsBalance: true,
                    AmountTypeId: -5,
                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    AssetType: 'Bonds',
                    Uic: 789,
                    InstrumentSymbolCode: 'SC789',
                    InstrumentDescription: 'Desc 789',
                    InstrumentISINCode: 'ISIN 789',
                    InstrumentSubType: 'Sub Type 789',
                    AmountClientCurrency: 1789,
                    AffectsBalance: true,
                    AmountTypeId: -5,
                },
                {
                    Date: '2016-01-16',
                    BookingAccountId: '179643INET',
                    AssetType: 'Shares',
                    Uic: 123,
                    InstrumentSymbolCode: 'SC123',
                    InstrumentDescription: 'Desc 123',
                    InstrumentISINCode: 'ISIN 123',
                    InstrumentSubType: 'Sub Type 123',
                    AmountClientCurrency: 2123,
                    AffectsBalance: true,
                    AmountTypeId: -5,
                },
                {
                    Date: '2016-01-16',
                    BookingAccountId: '179643INET',
                    AssetType: 'Shares',
                    Uic: 456,
                    InstrumentSymbolCode: 'SC456',
                    InstrumentDescription: 'Desc 456',
                    InstrumentISINCode: 'ISIN 456',
                    InstrumentSubType: 'Sub Type 456',
                    AmountClientCurrency: 2456,
                    AffectsBalance: true,
                    AmountTypeId: -5,
                },
                {
                    Date: '2016-01-16',
                    BookingAccountId: '179643INET',
                    AssetType: 'Bonds',
                    Uic: 789,
                    InstrumentSymbolCode: 'SC789',
                    InstrumentDescription: 'Desc 789',
                    InstrumentISINCode: 'ISIN 789',
                    InstrumentSubType: 'Sub Type 789',
                    AmountClientCurrency: 2789,
                    AffectsBalance: true,
                    AmountTypeId: -5,
                },
            ];

        const expectedResult = [
            {
                Uic: 123,
                InstrumentSymbolCode: 'SC123',
                InstrumentDescription: 'Desc 123',
                InstrumentISINCode: 'ISIN 123',
                InstrumentSubType: 'Sub Type 123',
                AssetType: 'Shares',
                Amount: 3246,
            },
            {
                Uic: 456,
                InstrumentSymbolCode: 'SC456',
                InstrumentDescription: 'Desc 456',
                InstrumentISINCode: 'ISIN 456',
                InstrumentSubType: 'Sub Type 456',
                AssetType: 'Shares',
                Amount: 3912,
            },
            {
                Uic: 789,
                InstrumentSymbolCode: 'SC789',
                InstrumentDescription: 'Desc 789',
                InstrumentISINCode: 'ISIN 789',
                InstrumentSubType: 'Sub Type 789',
                AssetType: 'Bonds',
                Amount: 4578,
            },
        ];

        expect(getPnlPerInstrument({
            aggregatedAmountsArray,
            accountInfo,
        })).toEqual(expectedResult);

        rewire.__ResetDependency__('config');
    });

    it('getTotalSecurityTransfers should return correct value', () => {

        rewire.__Rewire__('config', { appFeatures: { useMockedPerfData: false } });

        const accountInfo = {
            isAccountGroup: false,
            isClientLevel: true,
        };

        const aggregatedAmountsArray =
            [
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    Uic: 9465,
                    AmountClientCurrency: 333,
                    AffectsBalance: true,
                    AmountTypeId: -1,
                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    Uic: 9466,
                    AffectsBalance: true,
                    AmountTypeId: 5,
                    AmountClientCurrency: 222,
                },
            ];

        expect(getTotalSecurityTransfers({
            aggregatedAmountsArray,
            accountInfo,
        })).toEqual(333);

        rewire.__ResetDependency__('config');
    });

    it('getTotalCashTransfers should return correct value', () => {

        rewire.__Rewire__('config', { appFeatures: { useMockedPerfData: false } });

        const accountInfo = {
            isAccountGroup: false,
            isClientLevel: true,
        };

        const aggregatedAmountsArray =
            [
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    Uic: 9465,
                    AmountClientCurrency: 333,
                    AffectsBalance: true,
                    AmountTypeId: 76,
                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    Uic: 9466,
                    AffectsBalance: true,
                    AmountTypeId: 5,
                    AmountClientCurrency: 222,
                },
            ];

        expect(getTotalCashTransfers({
            aggregatedAmountsArray,
            accountInfo,
        })).toEqual(333);

        rewire.__ResetDependency__('config');
    });

    it('getBookedPerBookingType should return correct value', () => {

        rewire.__Rewire__('config', { appFeatures: { useMockedPerfData: false } });

        const accountInfo = {
            isAccountGroup: false,
            isClientLevel: true,
        };

        const aggregatedAmountsArray =
            [
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    AmountTypeId: 7,
                    AmountTypeName: 'Commission',
                    AmountClientCurrency: 11,
                    AffectsBalance: true,
                },
                {
                    Date: '2016-01-16',
                    BookingAccountId: '179643INET',
                    AmountTypeId: 7,
                    AmountTypeName: 'Commission',
                    AmountClientCurrency: 11,
                    AffectsBalance: true,
                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    AmountTypeId: 8,
                    AmountTypeName: 'Exchange Fee',
                    AmountClientCurrency: 12,
                    AffectsBalance: true,
                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    AmountTypeId: 8,
                    AmountTypeName: 'Exchange Fee',
                    AmountClientCurrency: 12,
                    AffectsBalance: true,
                },
                {
                    Date: '2016-01-15',
                    BookingAccountId: '179643INET',
                    AmountTypeId: 9,
                    AmountTypeName: 'Performance Fee',
                    AmountClientCurrency: 13,
                    AffectsBalance: true,
                },
                {
                    Date: '2016-01-16',
                    BookingAccountId: '179643INET',
                    AmountTypeId: 9,
                    AmountTypeName: 'Performance Fee',
                    AmountClientCurrency: 13,
                    AffectsBalance: true,
                },
            ];

        const expectedResult = [
            {
                Name: amountTypeNames.getTextById(7),
                Amount: 22,
            },
            {
                Name: amountTypeNames.getTextById(8),
                Amount: 24,
            },
            {
                Name: amountTypeNames.getTextById(9),
                Amount: 26,
            },
        ];

        expect(getBookedPerBookingType({
            aggregatedAmountsArray,
            accountInfo,
        })).toEqual(expectedResult);

        rewire.__ResetDependency__('config');
    });
});
