// AGG_AMT_* with negative numbers represent values we have computed in BackOfficeReporting as pert of the ETL process
// the ones with positive numbers match BKAmountTypes from BackOffice

// security Transfers
export const AGG_AMT_TYPE_SEC_TRANSFERS = -1;

// corrections
export const AGG_AMT_TYPE_CORRECTIONS = -2;

// cash balance
export const AGG_AMT_TYPE_CASH_BALANCE = -3;

// position value
export const AGG_AMT_TYPE_POS_VALUE = -4;

// profit/loss
export const AGG_AMT_TYPE_PROFIT_LOSS = -5;

// exposure
export const AGG_AMT_TYPE_EXPOSURE = -6;

// cash amount
export const AGG_AMT_TYPE_CASH_AMOUNT = 76;

// some select UIC' that we need to work with:

// cash inter-account transfer
export const UIC_INTER_ACCT_TRANSFER = 9465;

// cash deposit or withdrawal
export const UIC_DEPOSIT_OR_WITHDRAWAL = 9466;
