/* eslint max-lines:"off" */
// Yes...this file really need that many lines.
import _ from 'lodash';
import * as reportingQueries from 'src/modules/reporting/queries';
import config from 'src/config';
import * as aggregatedAmountsConstants from './constants';
import DateTime from 'src/modules/dateTime';
import * as amountTypeNames from './amountTypeNames';

/**
 * Returns an array with a bucket key for each month that occurs in the date range.
 * A bucket keys represents a year/month i.e:
 * [
 *      'y2016m1',
 *      'y2017m2',
 * ]
 *
 * Months are are keyed from 1-12 (not the javascripts 0-11 way!)
 */
export function getBucketKeysFromDateRange(startDate, endDate) {
    const groupedData = _.groupBy(
        reportingQueries.getAllDatesInRange(startDate, endDate),
        (item) => `y${DateTime.getYear(item)}m${DateTime.getMonth(item) + 1}`
    );

    return _.keys(groupedData);
}

/**
 * Returns an array with a bucket key for each month that occurs in the date range
 * and is also present in the state object.
 *
 * If the bucket has an error in the state or is currently being loaded it is not returned.
 */
export function getBucketKeysInState(state, startDate, endDate) {
    const bucketKeysInDateRange = getBucketKeysFromDateRange(startDate, endDate);
    return _.filter(bucketKeysInDateRange, (bucketKey) => state[bucketKey] && !state[bucketKey].error && !state[bucketKey].isLoading);
}

export function getYearMonthForBucketKey(bucketKey) {
    const year = bucketKey.substring(1, 5);
    const month = _.padStart(bucketKey.substring(6), 2, '0');

    return `${year}-${month}`;
}

export function getStartDateForBucketKey(bucketKey) {
    const year = bucketKey.substring(1, 5);
    const month = _.padStart(bucketKey.substring(6), 2, '0');

    return DateTime.createDate(`${year}-${month}-01`);
}

export function getEndDateForBucketKey(bucketKey) {
    return DateTime.createDate(DateTime.lastDateOfMonth(getStartDateForBucketKey(bucketKey)));
}

/**
 * Processes the list of bucket keys passed in and returns a list of continous
 * date ranges that will cover the buckets.
 */
export function getDateRangesFromBucketKeyList(bucketKeys) {
    const res = [];

    if (bucketKeys.length === 0) {
        return res;
    }

    // Sort the buckets earliest first
    const sortedBucketKeys = _.sortBy(bucketKeys, (bucketKey) => getStartDateForBucketKey(bucketKey));

    let dateRange = {
        startDate: getStartDateForBucketKey(sortedBucketKeys[0]),
        endDate: getEndDateForBucketKey(sortedBucketKeys[0]),
    };
    res.push(dateRange);

    for (let i = 0; i < sortedBucketKeys.length; i++) {
        const currentStartDate = getStartDateForBucketKey(sortedBucketKeys[i]);
        const currentEndDate = getEndDateForBucketKey(sortedBucketKeys[i]);

        // By subtracting 5 days from the currentStartDate we will get a date that is well inside the previous
        // month regardless of tiemzone/daylights savings etc.
        const curentStartDateMinus5Days = DateTime.addDays(currentStartDate, -5);

        if (curentStartDateMinus5Days > dateRange.endDate) {
            // This bucket does not come immediately after the previous bucket so we have a gap in the buckets
            // Create a new daterange to reflect this
            dateRange = {
                startDate: currentStartDate,
                endDate: currentEndDate,
            };
            res.push(dateRange);

        } else {
            // This bucket is immediately after the previous one so extend the daterange to cover this bucket
            dateRange.endDate = currentEndDate;
        }
    }

    return res;
}

export function filterByAccountInfo(accountInfo, aggregatedAmount) {
    if (config.appFeatures.useMockedPerfData) {
        return true;
    }

    if (accountInfo.isClientLevel) {
        return true;
    }

    if (accountInfo.isRegularAccount) {
        return (accountInfo.accountId === aggregatedAmount.BookingAccountId);
    }

    if (accountInfo.isAccountGroup) {
        return (_.includes(accountInfo.accountIdsInGroup, aggregatedAmount.BookingAccountId));
    }

    return false;
}

export function getAggregatedAmountsArray(aggregatedAmounts, accountInfo, startDate, endDate) {
    const bucketKeysInDateRange = getBucketKeysFromDateRange(startDate, endDate);
    const startDateString = startDate.toOapi();
    const endDateString = endDate.toOapi();

    return _.chain(bucketKeysInDateRange)
        .map((bucketKey) => ({ bucketKey, yearMonth: getYearMonthForBucketKey(bucketKey) }))
        .sortBy('yearMonth')
        .flatMap(({ bucketKey }) =>
            _.chain(aggregatedAmounts[bucketKey])
                .get('data', [])
                .filter((item) => {
                    const tradeDate = item.Date;

                    return (tradeDate >= startDateString &&
                        tradeDate <= endDateString && filterByAccountInfo(accountInfo, item));
                })
                .sortBy('Date')
                .value()
        )
        .value();
}

export function getBookedOnly(aggregatedAmountsArray) {
    return _.filter(aggregatedAmountsArray, (item) => (item.AffectsBalance && item.AmountTypeId > 0));
}

/**
 * Gets all position values as of the date passed. Notice that the date passed may not be a trade date.
 * We therefore locate the last trade date in the aggregatedAmountsArray and return the (end of day) position
 * values from that date.
 *
 * @param {Object[]} aggregatedAmountsArray - The array of aggregatedAmount objects to filter for position values
 * @param {ImmutableDateTime} date - The date to get position values for. If date is not a trade date the values from the
 * latest trade date before the date will be returned.
 *
 * @returns {Object[]}: an array of the the position value aggregated amount objects from the last trade date on or before date.
 */
export function getPositionValues({ aggregatedAmountsArray, date }) {
    const aggAmts = _.map(aggregatedAmountsArray, (aggAmt) => _.defaults(aggAmt, { dateObject: DateTime.createDate(aggAmt.Date) }));

    const aggAmtsOnOrBeforeDate = _.filter(aggAmts, (aggAmt) => (aggAmt.dateObject <= date));

    if (_.size(aggAmtsOnOrBeforeDate) === 0) {
        return [];
    }

    const lastTradeDateAsString = _.maxBy(aggAmtsOnOrBeforeDate, 'dateObject').Date;

    return _.filter(aggregatedAmountsArray, (aggAmt) =>
        (aggAmt.AmountTypeId === aggregatedAmountsConstants.AGG_AMT_TYPE_POS_VALUE && aggAmt.Date === lastTradeDateAsString)
    );
}

export function getPnLOnly(aggregatedAmountsArray) {
    return _.filter(aggregatedAmountsArray, (item) =>
        (item.AmountTypeId === aggregatedAmountsConstants.AGG_AMT_TYPE_PROFIT_LOSS)
    );
}

export function getInstrumentRelatedOnly(aggregatedAmountsArray) {
    return _.filter(aggregatedAmountsArray, (item) =>
        (item.Uic !== aggregatedAmountsConstants.UIC_INTER_ACCT_TRANSFER &&
        item.Uic !== aggregatedAmountsConstants.UIC_DEPOSIT_OR_WITHDRAWAL && item.Uic !== 0)
    );
}

export function getNonInstrumentRelatedOnly(aggregatedAmountsArray) {
    return _.filter(aggregatedAmountsArray, (item) =>
        (item.Uic !== aggregatedAmountsConstants.UIC_INTER_ACCT_TRANSFER &&
        item.Uic !== aggregatedAmountsConstants.UIC_DEPOSIT_OR_WITHDRAWAL && item.Uic === 0)
    );
}

/**
 * Returns the total PnL for the period. Cash transfers and non instrument
 * related items (such as service billing and interest are excluded)
 */
export function getTotalInstrumentRelatedPnl({ aggregatedAmountsArray, accountInfo }) {
    const pnLOnly = getPnLOnly(aggregatedAmountsArray);
    const instrumentRelatedAmounts = getInstrumentRelatedOnly(pnLOnly);
    const useClientCurrency = (accountInfo.isAccountGroup || accountInfo.isClientLevel);

    return _.sumBy(instrumentRelatedAmounts, (item) =>
        (useClientCurrency) ? item.AmountClientCurrency : item.AmountAccountCurrency
    );
}

/**
 * Returns the total bookings for the period. Cash transfers and non instrument
 * related items (such as service billing and interest are excluded)
 */
export function getTotalInstrumentRelatedBookings({ aggregatedAmountsArray, accountInfo }) {
    const bookedOnly = getBookedOnly(aggregatedAmountsArray);
    const instrumentRelatedAmounts = getInstrumentRelatedOnly(bookedOnly);
    const useClientCurrency = (accountInfo.isAccountGroup || accountInfo.isClientLevel);

    return _.sumBy(instrumentRelatedAmounts, (item) =>
        (useClientCurrency) ? item.AmountClientCurrency : item.AmountAccountCurrency
    );
}

/**
 * Returns the total non instrument related PnL for the period(service billing,
 * interest etc.). Cash transfers are excluded.
 */
export function getTotalNonInstrumentRelatedBookings({ aggregatedAmountsArray, accountInfo }) {
    const bookedOnly = getBookedOnly(aggregatedAmountsArray);
    const nonInstrumentRelatedAmounts = getNonInstrumentRelatedOnly(bookedOnly);
    const useClientCurrency = (accountInfo.isAccountGroup || accountInfo.isClientLevel);

    return _.sumBy(nonInstrumentRelatedAmounts, (item) =>
        (useClientCurrency) ? item.AmountClientCurrency : item.AmountAccountCurrency
    );
}

/**
 * Returns the PnL for the period grouped by Asset Type.
 *
 * Data is returned as an array objects each with AssetType and Amount.
 * Cash transfers and non instrument related items (such as service billing and
 * interest are excluded)
 */
export function getInstrumentRelatedPnlGroupedByAssetType({ aggregatedAmountsArray, accountInfo }) {
    const pnlOnly = getPnLOnly(aggregatedAmountsArray);
    const instrumentRelatedAmounts = getInstrumentRelatedOnly(pnlOnly);
    const groupedData = _.groupBy(instrumentRelatedAmounts, 'AssetType');
    const groupNames = _.keys(groupedData);
    const useClientCurrency = (accountInfo.isAccountGroup || accountInfo.isClientLevel);

    return _.map(groupNames, (groupName) => ({
        AssetType: groupName,
        Amount: _.sumBy(instrumentRelatedAmounts, (item) => {
            if (item.AssetType === groupName) {
                return useClientCurrency ? item.AmountClientCurrency : item.AmountAccountCurrency;
            }

            return 0;
        }),
    }));
}

/**
 * Returns the Pnl Per day for the period
 *
 * Data is returned as an array of objects each with a Date and an amount.
 * Cash transfers and non instrument related items (such as service billing and
 * interest are excluded)
 */
export function getProfitLossPerDay({ aggregatedAmountsArray, accountInfo }) {
    const pnlOnly = getPnLOnly(aggregatedAmountsArray);
    const instrumentRelatedAmounts = getInstrumentRelatedOnly(pnlOnly);
    const groupedData = _.groupBy(instrumentRelatedAmounts, 'Date');
    const groupNames = _.keys(groupedData);
    const useClientCurrency = (accountInfo.isAccountGroup || accountInfo.isClientLevel);
    const pnlPerday = _.map(groupNames, (groupName) => {
        const tradeDateAsDate = DateTime.createDate(groupName);

        return {
            tradeDateAsDate,
            Date: groupName,
            Amount: _.sumBy(instrumentRelatedAmounts, (item) => {
                if (item.Date === groupName) {
                    return useClientCurrency ? item.AmountClientCurrency : item.AmountAccountCurrency;
                }
                return 0;
            }),
        };
    });

    return _.orderBy(pnlPerday, ['tradeDateAsDate'], ['asc']);
}

/**
 * Returns the cumulative PnL for the period.
 *
 * Data is returned as an array of objects each with a Date and an amount.
 * Cash transfers and non instrument related items (such as service billing and
 * interest are excluded)
 */
export function getCumulativeProfitLoss({ aggregatedAmountsArray, accountInfo }) {

    // The result needs to have a record for _all_ dates in the range. Not all dates will have pnl but
    // then we should use the pnl value from the previous day. If we don't fill in values for
    // the missing days like this, we will get funny looking cumulative charts that try to extrapolate values for
    // missing days - and produce wrong results.

    // Use all agg amount records to locate the first and last date. Notice that we may not actually have pnl
    // records for these dates - so importnat that we do this before we filter the array to only hold pnl records.
    const allDatesInData = _.map(aggregatedAmountsArray, (item) => DateTime.createDate(item.Date));
    const distinctDatesSortedAsc = _.sortedUniq(allDatesInData);
    const startDate = _.head(distinctDatesSortedAsc);
    const endDate = _.last(distinctDatesSortedAsc);
    const allDates = reportingQueries.getAllDatesInRange(startDate, endDate);

    const pnlPerDay = getProfitLossPerDay({
        aggregatedAmountsArray,
        accountInfo,
    });

    return _.map(allDates, (date) => ({
        Date: date.toOapi(),
        Amount: _.sumBy(pnlPerDay, (item) => {
            if (item.tradeDateAsDate <= date) {
                return item.Amount;
            }
            return 0;
        }),
    }));
}

/**
 * Returns the PnL for the period for a specific asset type. Grouped by Instrument.
 *
 * Data is returned as an array objects with
 *  {
 *      Uic,
 *      InstrumentSymbolCode,
 *      InstrumentDescription,
 *      InstrumentISINCode,
 *      InstrumentSubType,
 *      AssetType,
 *      Amount,
 * }
 *
 * Cash transfers and non instrument related items (such as service billing and
 * interest are excluded)
 */
export function getPnlPerInstrumentForAssetType({ aggregatedAmountsArray, accountInfo, assetType }) {
    const pnlOnly = getPnLOnly(aggregatedAmountsArray);
    const instrumentRelatedAmounts = getInstrumentRelatedOnly(pnlOnly);
    const reqAssetTypeOnly = _.filter(instrumentRelatedAmounts, { 'AssetType': assetType });
    const groupedData = _.groupBy(reqAssetTypeOnly, 'Uic');
    const groupNames = _.keys(groupedData);
    const useClientCurrency = (accountInfo.isAccountGroup || accountInfo.isClientLevel);

    return _.map(groupNames, (groupName) => {
        const exampleItem = _.head(groupedData[groupName]);

        return {
            Uic: exampleItem.Uic,
            InstrumentSymbolCode: exampleItem.InstrumentSymbolCode,
            InstrumentDescription: exampleItem.InstrumentDescription,
            InstrumentISINCode: exampleItem.InstrumentISINCode,
            InstrumentSubType: exampleItem.InstrumentSubType,
            AssetType: exampleItem.AssetType,
            Amount: _.sumBy(reqAssetTypeOnly, (item) => {
                if (item.Uic === exampleItem.Uic) {
                    return useClientCurrency ? item.AmountClientCurrency : item.AmountAccountCurrency;
                }
                return 0;
            }),
        };
    });
}

/**
 * Returns the PnL for the period grouped by Instrument.
 *
 * Data is returned as an array objects with:
 *  {
 *      Uic,
 *      InstrumentSymbolCode,
 *      InstrumentDescription,
 *      InstrumentISINCode,
 *      InstrumentSubType,
 *      Amount,
 *  }
 *
 * Cash transfers and non instrument related items (such as service billing and
 * interest are excluded)
 */
export function getPnlPerInstrument({ aggregatedAmountsArray, accountInfo }) {
    const pnLOnly = getPnLOnly(aggregatedAmountsArray);
    const instrumentRelatedAmounts = getInstrumentRelatedOnly(pnLOnly);
    const groupedData = _.groupBy(instrumentRelatedAmounts, (item) => item.AssetType + '_' + item.Uic);
    const groupNames = _.keys(groupedData);
    const useClientCurrency = (accountInfo.isAccountGroup || accountInfo.isClientLevel);

    return _.map(groupNames, (groupName) => {
        const exampleItem = _.head(groupedData[groupName]);
        return {
            Uic: exampleItem.Uic,
            InstrumentSymbolCode: exampleItem.InstrumentSymbolCode,
            InstrumentDescription: exampleItem.InstrumentDescription,
            InstrumentISINCode: exampleItem.InstrumentISINCode,
            InstrumentSubType: exampleItem.InstrumentSubType,
            AssetType: exampleItem.AssetType,
            Amount: _.sumBy(instrumentRelatedAmounts, (item) => {
                if (item.AssetType === exampleItem.AssetType && item.Uic === exampleItem.Uic) {
                    return useClientCurrency ? item.AmountClientCurrency : item.AmountAccountCurrency;
                }
                return 0;
            }),
        };
    });
}

export function getTotalSecurityTransfers({ aggregatedAmountsArray, accountInfo }) {
    const secTransfers = _.filter(aggregatedAmountsArray, (item) =>
        (item.AmountTypeId === aggregatedAmountsConstants.AGG_AMT_TYPE_SEC_TRANSFERS)
    );

    const useClientCurrency = (accountInfo.isAccountGroup || accountInfo.isClientLevel);

    return _.sumBy(secTransfers, (item) =>
        (useClientCurrency) ? item.AmountClientCurrency : item.AmountAccountCurrency
    );
}

export function getTotalCashTransfers({ aggregatedAmountsArray, accountInfo }) {
    const cashTransfers = _.filter(aggregatedAmountsArray, (item) =>
        (item.AmountTypeId === aggregatedAmountsConstants.AGG_AMT_TYPE_CASH_AMOUNT && item.AffectsBalance)
    );

    const useClientCurrency = (accountInfo.isAccountGroup || accountInfo.isClientLevel);

    return _.sumBy(cashTransfers, (item) =>
        (useClientCurrency) ? item.AmountClientCurrency : item.AmountAccountCurrency
    );
}

export function getBookedPerBookingType({ aggregatedAmountsArray, accountInfo }) {
    const useClientCurrency = (accountInfo.isAccountGroup || accountInfo.isClientLevel);

    const bookedAmounts = _.map(getBookedOnly(aggregatedAmountsArray), (item) => ({
        Name: amountTypeNames.getTextById(item.AmountTypeId, item.AmountTypeName, item.AssetType),
        Amount: useClientCurrency ? item.AmountClientCurrency : item.AmountAccountCurrency,
    }));

    const groupedData = _.groupBy(bookedAmounts, 'Name');

    const unsorted = _.map(groupedData, (group, name) => ({
        Name: name,
        Amount: _.sumBy(group, 'Amount'),
    }));

    return _.orderBy(unsorted, ['Name'], ['asc']);
}
