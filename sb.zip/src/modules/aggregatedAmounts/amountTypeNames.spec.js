import _ from 'lodash';
import * as amountTypeNames from './amountTypeNames';
import * as assetTypes from 'src/modules/instruments/assetType/assetTypes';
import Localization from 'src/localization';

describe('src/modules/aggregatedAmounts/amountTypeNames', () => {

    it('handles CFD special cases', () => {

        const CFD_CASH_ADJUSTMENT_IDS = [55, 56, 57, 58, 79, 137, 170, 171, 173, 178, 179, 196];

        const cfdText = Localization.getText('HTML5_Amount_CfdCashAdjustment');

        const checkIds = (id) => {
            expect(amountTypeNames.getTextById(id, 'name', assetTypes.CFD_ON_INDEX)).toEqual(cfdText);
            expect(amountTypeNames.getTextById(id, 'name', assetTypes.CFD_ON_STOCK)).toEqual(cfdText);
            expect(amountTypeNames.getTextById(id, 'name', assetTypes.CFD_ON_FUTURES)).toEqual(cfdText);
            expect(amountTypeNames.getTextById(id, 'name', assetTypes.STOCK)).not.toEqual(cfdText);
        };

        _.forEach(CFD_CASH_ADJUSTMENT_IDS, (id) => {
            checkIds(id);
            checkIds(Number(id).toString());
        });

    });

    it('fall back to name', () => {
        expect(amountTypeNames.getTextById(-34234, 'name', assetTypes.STOCK)).toEqual('name');
        expect(amountTypeNames.getTextById(-34234, 'name', assetTypes.CFD_ON_STOCK)).toEqual('name');
    });
});
