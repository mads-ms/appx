import * as AggregatedAmountsActionTypes from 'src/modules/aggregatedAmounts/actionTypes';
import assertReduceAction from 'test/assertReduceAction';
import aggregatedAmountReducer from 'src/modules/aggregatedAmounts/reducer';

const assertAction = assertReduceAction.bind(undefined, aggregatedAmountReducer);

describe('src/modules/aggregatedAmounts/reducer', () => {

    it('returns state if action is unmatched', () => {
        const state = { someForeignState: 'something' };

        assertAction(state, {}, state, true);
    });

    it('creates state as empty object if input state is undefined', () => {
        const state = undefined;
        const expectedState = {};

        assertAction(state, {}, expectedState);
    });

    describe('AGGREGATED_AMOUNTS_ADD_BUCKETS', () => {

        it('puts aggreagted amounts data into state correctly', () => {
            const state = {};

            const action = {
                type: AggregatedAmountsActionTypes.AGGREGATED_AMOUNTS_ADD_BUCKETS,
                buckets: [
                    {
                        bucketKey: 'y2016m1',
                        data: [{ test: 1 }],
                        isLoading: false,
                        error: 'someError',
                    },
                    {
                        bucketKey: 'y2016m2',
                        data: [{ test: 2 }],
                        isLoading: false,
                        error: 'someError',
                    },
                ],
            };

            const expectedState = {
                'y2016m1': {
                    bucketKey: 'y2016m1',
                    data: [{ test: 1 }],
                    isLoading: false,
                    error: 'someError',
                },
                'y2016m2': {
                    bucketKey: 'y2016m2',
                    data: [{ test: 2 }],
                    isLoading: false,
                    error: 'someError',
                },
            };

            assertAction(state, action, expectedState);
        });
    });
});
