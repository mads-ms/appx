import _ from 'lodash';
import { put, call, select, takeEvery } from 'redux-tale/effects';
import { addSagas } from 'src/sagas';
import getOpenApi from 'src/modules/openApi';
import DateTime from 'src/modules/dateTime';
import log from 'src/modules/log';
import * as aggregatedAmountsQueries from 'src/modules/aggregatedAmounts/queries';
import * as actionTypes from './actionTypes';

export const fetchAmountsSaga = takeEvery(actionTypes.TRIGGER_GET, fetchAmounts);

addSagas([fetchAmountsSaga]);

export const getAggregatedAmounts = (state) => state.aggregatedAmounts;

export function* fetchAmounts({ clientKey, startDate, endDate }) {
    const aggregatedAmounts = yield select(getAggregatedAmounts);
    const startDateJs = DateTime.createDate(startDate);
    const endDateJs = DateTime.createDate(endDate);
    const bucketKeysInDateRange = aggregatedAmountsQueries.getBucketKeysFromDateRange(startDateJs, endDateJs);
    const bucketKeysAlreadyInStore = aggregatedAmountsQueries.getBucketKeysInState(aggregatedAmounts, startDateJs, endDateJs);
    const missingBucketKeys = _.difference(bucketKeysInDateRange, bucketKeysAlreadyInStore);

    if (missingBucketKeys.length === 0) {
        return;
    }

    const dateRanges = aggregatedAmountsQueries.getDateRangesFromBucketKeyList(missingBucketKeys);

    // add empty buckets to the store for the buckets we are about to load. This prevents other actions from
    // trying to load them simultaneously
    yield put({
        type: actionTypes.AGGREGATED_AMOUNTS_ADD_BUCKETS,
        buckets: _.map(missingBucketKeys, (bucketKey) =>
            ({
                bucketKey,
                data: [],
                isLoading: true,
                error: false,
            })),
    });

    // issue a server call to get data for each of the missing date ranges
    const dataFromServer = yield _.map(dateRanges, (dateRange) =>
        call(fetchData, {
            clientKey,
            startDate: dateRange.startDate.toOapi(),
            endDate: dateRange.endDate.toOapi(),
        })
    );

    // process the data and errors returned from the server and dispatch relevant ADD_BUCKET actions. Some calls
    // may fail and others succeed. If just one of the calls fail wee need to return failure on the entire
    // saga but we may have been able to add some of the buckets
    let errorsOccurred = false;
    const buckets = _.flatMap(dataFromServer, (result) => {
        const bucketKeys = aggregatedAmountsQueries.getBucketKeysFromDateRange(
            DateTime.createDate(result.startDate),
            DateTime.createDate(result.endDate)
        );

        if (result.error) {
            errorsOccurred = true;
            return _.map(bucketKeys, (bucketKey) => ({
                bucketKey,
                data: [],
                isLoading: false,
                error: true,
            }));
        }

        const bucketMap = {};
        _.forEach(result.data, (item) => {
            // 2017-01-01 -> 2017-01
            const yearMonthKey = item.Date.substr(0, 7);
            if (!bucketMap[yearMonthKey]) {
                bucketMap[yearMonthKey] = [];
            }
            bucketMap[yearMonthKey].push(item);
        });

        return _.map(bucketKeys, (bucketKey) => ({
            bucketKey,
            data: bucketMap[aggregatedAmountsQueries.getYearMonthForBucketKey(bucketKey)] || [],
            isLoading: false,
            error: false,
        }));
    });

    yield put({
        type: actionTypes.AGGREGATED_AMOUNTS_ADD_BUCKETS,
        buckets,
    });

    if (errorsOccurred) {
        throw new Error('Errors loading aggregated amounts');
    }
}

export function fetchData({ clientKey, startDate, endDate }) {
    return getDataFromOpenApi({ clientKey, startDate, endDate })
        .then((data) => ({ data: _.map(data.response.Data, mapAggregatedAmountItem), clientKey, startDate, endDate }))
        .catch((error) => {
            log.error('Loading Aggregated Amounts failed (v1/reports/aggregatedAmounts/)', error);
            return ({
                error: true,
                clientKey,
                startDate,
                endDate,
            });
        });
}

function getDataFromOpenApi({ clientKey, startDate, endDate }) {
    return getOpenApi().rest.get('cs', `v1/reports/aggregatedAmounts/${clientKey}/${startDate}/${endDate}/`, null, null);
}

// Some properties returned from OpenApi need a bit of massaging (if they don't exists we need blank strings, underlying instrument values
// should use Instrument values if there is no underlying etc.).
// This is needed to group and filter data correctly.
function mapAggregatedAmountItem(dataItem) {
    return _.defaults(
        {
            AffectsBalance: Boolean(dataItem.AffectsBalance),
            AssetType: dataItem.AssetType || '',
            InstrumentSymbolCode: dataItem.InstrumentSymbolCode || '',
            InstrumentDescription: dataItem.InstrumentDescription || '',
            InstrumentSubType: dataItem.InstrumentSubType || '',
            UnderlyingInstrumentUic: dataItem.UnderlyingInstrumentUic || dataItem.Uic || 0,
            UnderlyingInstrumentSymbolCode: dataItem.UnderlyingInstrumentSymbolCode || dataItem.InstrumentSymbolCode || '',
            UnderlyingInstrumentDescription: dataItem.UnderlyingInstrumentDescription || dataItem.InstrumentDescription || '',
            UnderlyingInstrumentSubType: dataItem.UnderlyingInstrumentSubType || dataItem.InstrumentSubType || '',
            RootInstrumentSectorName: dataItem.RootInstrumentSectorName,
        },
        dataItem
    );
}
