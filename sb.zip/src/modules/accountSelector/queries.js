import _ from 'lodash';
import Localization from 'src/localization';
import * as util from 'src/utils/util';
import * as validationTypes from 'src/modules/validation/validationTypes';
import * as accountQueries from 'src/modules/accounts/queries';
import * as instrumentsQueries from 'src/modules/instruments/queries';

export const getGroupCount = (accounts) => _.filter(accounts, 'IsGroup').length;

export const getAvailableBalanceLabel = (instrument) =>
    instrumentsQueries.isMarginTradable(instrument) ?
        Localization.getText('HTML5_MarginAvailable') :
        Localization.getText('HTML5_CashAvailable');

export const isMatchingCurrencyAccount = (accounts, instrument) =>
    accountQueries.getAccountsMatchingCurrency(accounts, instrument).length > 0;

export const validateAccount = (accounts, selectedAccountId, instrument) => {
    if (!instrument) {
        return;
    }

    const instrumentCurrency = instrument.CurrencyCode;
    const currentAccount = _.find(accounts, (account) => account.id === selectedAccountId);

    if (
        currentAccount &&
        currentAccount.BaseCurrency !== instrumentCurrency &&
        isMatchingCurrencyAccount(accounts, instrument)
    ) {
        return validationTypes.warning(util.formatString(
            Localization.getText('HTML5_BadAccountCurrency'),
            instrument.Symbol,
            instrumentCurrency,
            instrumentCurrency
        ));
    }
};
