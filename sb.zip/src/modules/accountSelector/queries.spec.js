import { isMatchingCurrencyAccount } from 'src/modules/accountSelector/queries';
import { CFD_ON_STOCK } from 'src/modules/instruments/assetType/assetTypes';

describe('src/modules/accountSelector/queries', () => {

    const currency = 'GBP';

    describe('isMatchingCurrencyAccount', () => {
        it('returns true if account matches instruments currency', () => {
            const accounts = [{
                Currency: 'EUR',
            }, {
                Currency: currency,
            }];
            const instrument = {
                CurrencyCode: currency,
            };

            const isMatching = isMatchingCurrencyAccount(accounts, instrument);
            expect(isMatching).toBe(true);
        });

        it('returns false if no matching account', () => {
            const accounts = [{
                Currency: 'EUR',
            }, {
                Currency: 'JPY',
            }];
            const instrument = {
                CurrencyCode: currency,
            };

            const isMatching = isMatchingCurrencyAccount(accounts, instrument);
            expect(isMatching).toBe(false);
        });

        it('ignores dma accounts if instrument is cfd and exchange isn\'t dma', () => {
            const accounts = [{
                Currency: currency,
                DirectMarketAccess: true,
                DirectMarketExchangeIds: ['exchange1'],
            }];
            const instrument = {
                CurrencyCode: currency,
                Exchange: {
                    ExchangeId: 'exchange2',
                },
                AssetType: CFD_ON_STOCK,
            };

            const isMatching = isMatchingCurrencyAccount(accounts, instrument);
            expect(isMatching).toBe(false);
        });
    });
});
