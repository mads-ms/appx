import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import Localization from 'src/localization';
import * as queries from './queries';
import Validation from 'src/modules/validation/validation';
import Dropdown from 'src/components/dropdown/dropdown';
import DropdownItem from 'src/components/dropdown/dropdownItem';
import Icon from 'src/components/icon/icon';
import Currency from './currency';
import { bindHandlers } from 'src/utils/bindHandlers';

class AccountSelector extends React.PureComponent {

    constructor(props) {
        super(props);
        this.state = {
            validation: queries.validateAccount(props.accounts, props.selectedAccountId, props.instrument),
        };
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.selectedAccountId !== this.props.selectedAccountId ||
            nextProps.instrument !== this.props.instrument) {
            this.setValidation(nextProps);
        }
    }

    setValidation({ accounts, selectedAccountId, instrument }) {
        this.setState({
            validation: queries.validateAccount(accounts, selectedAccountId, instrument),
        });
    }

    handleChange(accountId) {
        // the spine drop down converts numeric only string values to numbers ("123" => 123), but also supports
        // number values. So we make sure the account is a string.
        // this can be removed once we use a full reactified account selector
        this.props.onChange(String(accountId));
    }

    render() {
        const {
            accounts,
            balances,
            instrument,
            selectedAccountId,
            isShowGroups,
            isEnableGroups,
            isShowCurrency,
            isAltStyle,
            isProComboInputStyle,
            isAstroStyle,
            dialogType,
            dialogParent,
            isFullWidth,
            isEnabled, // to make account selector disabled explicitly
            isShortFormat,
            resizeTimestamp,
        } = this.props;
        const { validation } = this.state;
        const isShowingHierarchy = isShowGroups && queries.getGroupCount(accounts);

        let dropdownHeader;

        if (balances) {
            dropdownHeader = (
                <DropdownItem
                    className="acctselector-header list-title is-disabled"
                    isEnabled={false}
                    value="header"
                    key="header"
                >
                    {Localization.getText('HTML5_Account')}
                    <span className="acctselector-header-available">
                        {queries.getAvailableBalanceLabel(instrument)}
                    </span>
                </DropdownItem>
            );
        }

        const dropdownItems = _.map(accounts, ({
            IsGroup,
            IsAccount,
            id,
            Sharing,
            DisplayName,
            BaseCurrency,
            BaseCurrencyDecimals,
        }) => {
            const isSubItem = isShowingHierarchy && IsAccount;
            const isSimpleItem = !IsGroup && !isSubItem;
            const isItemsEnabled = !IsGroup || isEnableGroups;

            const itemClassName = classNames('acctselector-item tst-account-selector-item', {
                'list-title': IsGroup,
                'list-sub-item': isSubItem,
                'list-item': isSimpleItem,
                'is-disabled': !isItemsEnabled,
            });

            return (
                <DropdownItem
                    key={id}
                    value={id}
                    className={itemClassName}
                    isEnabled={isItemsEnabled}
                >
                    <div className="grid grid--space">
                        <div className="grid-cell g--shrink t-truncate">
                            {Sharing && <Icon type="tf"/>}
                            {DisplayName}
                        </div>
                        {isShowCurrency &&
                            <div className="grid-cell">
                                <Currency
                                    currency={BaseCurrency}
                                    decimals={BaseCurrencyDecimals}
                                    balance={balances && balances[id]}
                                    instrument={instrument}
                                    isShortFormat={isShortFormat}
                                />
                            </div>
                        }
                    </div>
                </DropdownItem>
            );
        });

        if (dropdownHeader) {
            dropdownItems.unshift(dropdownHeader);
        }

        const isDropdownEnabled = !(!isEnabled || (accounts.length === 1));
        const classes = classNames('acctselector tst-account-selector', {
            'acctselector--fullwidth': isFullWidth,
            'acctselector--procomboinput': isProComboInputStyle,
        });

        return (
            <Validation {...validation}>
                {({ validationClasses, validationMessage }) => (
                    <div className={classes}>
                        <div className={validationClasses}>
                            <Dropdown
                                label={Localization.getText('HTML5_SelectAccount')}
                                value={selectedAccountId}
                                onChange={this.handleChange}
                                isEnabled={isDropdownEnabled}
                                isAltStyle={isAltStyle}
                                isAstroStyle={isAstroStyle || isProComboInputStyle}
                                dialogType={dialogType}
                                dialogParent={dialogParent}
                                resizeTimestamp={resizeTimestamp}
                            >
                                {dropdownItems}
                            </Dropdown>
                        </div>
                        {isDropdownEnabled && validationMessage}
                    </div>
                )}
            </Validation>
        );
    }
}

AccountSelector.propTypes = {
    accounts: PropTypes.array,
    balances: PropTypes.object,
    isShowGroups: PropTypes.bool,
    isShowCurrency: PropTypes.bool,
    isEnableGroups: PropTypes.bool,
    isFullWidth: PropTypes.bool,
    onChange: PropTypes.func,
    selectedAccountId: PropTypes.string,
    title: PropTypes.string,
    isAltStyle: PropTypes.bool,
    isProComboInputStyle: PropTypes.bool,
    isAstroStyle: PropTypes.bool,
    isShortFormat: PropTypes.bool,
    dialogType: PropTypes.oneOf(['popup', 'card']),
    dialogParent: PropTypes.instanceOf(HTMLElement),
    instrument: PropTypes.object,
    isEnabled: PropTypes.bool,
    resizeTimestamp: PropTypes.any,
};

AccountSelector.defaultProps = {
    isAltStyle: false,
    isEnableGroups: false,
    isShowCurrency: true,
    isShowGroups: true,
    isFullWidth: false,
    isEnabled: true,
    isProComboInputStyle: false,
    isAstroStyle: false,
    isShortFormat: false,
};

export default bindHandlers(AccountSelector);
