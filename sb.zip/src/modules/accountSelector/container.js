import { connect } from 'react-redux';
import AccountSelector from './accountSelector';
import * as accountsSelectors from 'src/modules/accounts/selectors';

function mapStateToProps() {
    const getEntitiesToShow = accountsSelectors.createGetEntitiesToShow();
    return (state, ownProps) => {
        const accounts = getEntitiesToShow(state, {
            showTradableAccounts: ownProps.showTradableAccounts,
            instrument: ownProps.instrument,
        });

        return {
            accounts,
        };
    };
}

export default connect(mapStateToProps)(AccountSelector);
