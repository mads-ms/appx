import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import * as numberFormat from 'src/numberFormat';

export default class Currency extends React.PureComponent {
    render() {
        const {
            currency,
            decimals,
            balance,
            isShortFormat,
        } = this.props;

        let formattedBalance = '';

        if (_.isFinite(balance)) {
            if (isShortFormat) {
                formattedBalance = numberFormat.shortFormat(balance);
            } else {
                formattedBalance = numberFormat.format(balance, decimals);
            }
        }

        return (
            <span className="acctselector-currency tst-account-selector-currency">
                {formattedBalance}&nbsp;{currency}
            </span>
        );
    }
}

Currency.propTypes = {
    currency: PropTypes.string,
    decimals: PropTypes.number,
    balance: PropTypes.number,
    isShortFormat: PropTypes.bool,
};

Currency.defaultProps = {
    decimals: 2,
    isShortFormat: false,
};
