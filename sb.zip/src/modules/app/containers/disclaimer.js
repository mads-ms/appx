import App from '../components/disclaimer';
import { connect } from 'react-redux';

// selectors
import * as appSelectors from '../selectors/disclaimer/appSelectors';

// actions
import * as appInfoActions from '../actions/disclaimer/appInfoActions';
import * as loginDisclaimersActions from 'src/modules/app/actions/disclaimer/loginDisclaimersActions';
import * as mifidDisclaimerActions from 'src/modules/mifidDisclaimer/actions';

function mapStateToProps(state) {
    const appInfo = appSelectors.getAppInfo(state);
    const loginDisclaimers = appSelectors.getLoginDisclaimers(state);
    const isLoaded = appSelectors.getIsLoaded(state);
    const error = appSelectors.getError(state);
    const { showApproval, showMifid } = appInfo;
    const { currentDisclaimer } = loginDisclaimers;

    return {
        showApproval,
        showMifid,
        currentDisclaimer,
        isLoaded,
        error,
    };
}

const mapDispatchToProps = {
    fetchAppInfo: appInfoActions.fetchAppInfo,
    fetchMifid: mifidDisclaimerActions.fetchMifid,
    fetchLoginDisclaimers: loginDisclaimersActions.fetch,
    setApproveMifid: mifidDisclaimerActions.setApproveMifid,
};

export default connect(mapStateToProps, mapDispatchToProps)(App);
