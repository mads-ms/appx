import { connect } from 'react-redux';
import config from 'src/config';
import Desktop from 'src/modules/app/components/desktop';
import * as appSelectors from '../selectors';

function mapStateToProps(state) {
    const { workspace } = state;
    const { activeWorkspace } = workspace;
    return {
        isInstantDemoEnabled: config.demo.isInstantDemoAccount,
        isSignupBannerEnabled: appSelectors.getIsSignupEnabled(),
        isClientStation: appSelectors.isClientStation(),
        activeWorkspace,
    };
}

export default connect(mapStateToProps)(Desktop);
