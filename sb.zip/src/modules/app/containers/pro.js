import { connect } from 'react-redux';
import Pro from 'src/modules/app/components/pro';
import { getWindowFullScreen } from 'src/modules/windows/selectors';

function mapStateToProps(state) {
    const windowIsFullScreen = getWindowFullScreen(state);
    return {
        windowIsFullScreen,
    };
}

export default connect(mapStateToProps)(Pro);
