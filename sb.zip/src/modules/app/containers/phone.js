import { connect } from 'react-redux';
import Phone from 'src/modules/app/components/phone';
import config from 'src/config';

function mapStateToProps(state) {
    const { phoneLayout } = state;
    return {
        layout: phoneLayout,
        isInstantDemoEnabled: config.demo.isInstantDemoAccount,
    };
}

export default connect(mapStateToProps)(Phone);
