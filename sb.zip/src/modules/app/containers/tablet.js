import { connect } from 'react-redux';
import config from 'src/config';
import Tablet from 'src/modules/app/components/tablet';
import * as appSelectors from '../selectors';

function mapStateToProps(state) {
    const { workspace } = state;
    const { activeWorkspace } = workspace;
    return {
        isInstantDemoEnabled: config.demo.isInstantDemoAccount,
        isSignupBannerEnabled: appSelectors.getIsSignupEnabled(),
        activeWorkspace,
    };
}

export default connect(mapStateToProps)(Tablet);
