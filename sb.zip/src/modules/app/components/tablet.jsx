import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import Header from '../header/container';
import Workspaces from 'src/modules/workspace/containers/workspaces';
import Footer from 'src/modules/footer/container';
import Underlay from 'src/components/underlay/underlay';
import InvestmentTicketDialog from 'src/modules/saxoSelect/containers/investmentTicketDialog';
import { ACCOUNT_WORKSPACE_ID } from 'src/modules/myAccount/constants';
import LoginTracking from 'src/modules/loginTracking';
import { DragDropContext } from 'react-dnd';
import TouchBackend from 'react-dnd-touch-backend';

// required to be a class by React DND - https://github.com/react-dnd/react-dnd/issues/904
class App extends React.PureComponent {
    render() {
        const { activeWorkspace, isSignupBannerEnabled } = this.props;
        const isFooterCurrentlyShown = activeWorkspace !== ACCOUNT_WORKSPACE_ID;
        return [
            <Header key="header"/>,
            <Workspaces
                key="workspaces"
                mainWrapperClassName={classNames({
                    'is-full-height': !isFooterCurrentlyShown,
                    'has-signupbanner': isSignupBannerEnabled,
                })}
            />,
            <Footer key="footer" isShown={isFooterCurrentlyShown}/>,

            /* Global Popups*/
            <InvestmentTicketDialog key="investmentTicketDialog"/>,
            <Underlay key="underlay"/>,
            <LoginTracking key="loginTracking"/>,
        ];
    }
}

App.propTypes = {
    isActive: PropTypes.bool.isRequired,
    isInstantDemoEnabled: PropTypes.bool,
    isSignupBannerEnabled: PropTypes.bool,
    activeWorkspace: PropTypes.string.isRequired,
};

App.defaultProps = {
    isInstantDemoEnabled: false,
    isSignupBannerEnabled: false,
};

const backendOptions = { enableMouseEvents: true };

export default DragDropContext(TouchBackend(backendOptions))(App);
