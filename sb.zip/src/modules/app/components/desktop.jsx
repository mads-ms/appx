import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import Header from '../header/container';
import Workspaces from 'src/modules/workspace/containers/workspaces';
import Footer from 'src/modules/footer/container';
import Underlay from 'src/components/underlay/underlay';
import InvestmentTicketDialog from 'src/modules/saxoSelect/containers/investmentTicketDialog';
import { ACCOUNT_WORKSPACE_ID } from 'src/modules/myAccount/constants';
import SubscriptionsCount from 'src/modules/subscriptionsCount';
import LoginTracking from 'src/modules/loginTracking';
import { ContextMenu, ContextMenuItem, MenuItems, MenuTarget } from 'src/components/contextMenu';
import * as contextMenuActions from 'src/components/contextMenu/contextMenuActions';
import config from 'src/config';
import { DragDropContext } from 'react-dnd';
import TouchBackend from 'react-dnd-touch-backend';

// required to be a class by React DND - https://github.com/react-dnd/react-dnd/issues/904
class App extends React.PureComponent {
    render() {
        const { activeWorkspace, isSignupBannerEnabled, isClientStation } = this.props;

        const isHeaderShown = config.appId !== 'saxoselect' && config.appId !== 'view' && !isClientStation;
        const isFooterEverShown = config.appId !== 'saxoselect' && config.appId !== 'view' && !isClientStation;
        const isFooterCurrentlyShown = activeWorkspace !== ACCOUNT_WORKSPACE_ID && !isClientStation;

        return (
            <ContextMenu>
                <MenuItems>
                    <ContextMenuItem action={contextMenuActions.ACTION_APP_SETTINGS}/>
                    <ContextMenuItem action={contextMenuActions.ACTION_APP_LOGOUT}/>
                </MenuItems>
                <MenuTarget>
                    <span>
                        {isHeaderShown && <Header/>}
                        <Workspaces
                            mainWrapperClassName={classNames({
                                'is-full-height': !(isFooterEverShown && isFooterCurrentlyShown),
                                'has-signupbanner': isSignupBannerEnabled,
                                'is-cs-integration': isClientStation,
                            })}
                        />
                        {isFooterEverShown && <Footer isShown={isFooterCurrentlyShown}/>}
                        {/* Global Popups*/}
                        {!isClientStation && <InvestmentTicketDialog/>}
                        {!isClientStation && <Underlay/>}

                        {!isClientStation && <SubscriptionsCount/>}
                        {!isClientStation && <LoginTracking/>}
                    </span>
                </MenuTarget>
            </ContextMenu>
        );
    }
}

App.propTypes = {
    isInstantDemoEnabled: PropTypes.bool,
    isSignupBannerEnabled: PropTypes.bool,
    isClientStation: PropTypes.bool,
    activeWorkspace: PropTypes.string.isRequired,
};

App.defaultProps = {
    isInstantDemoEnabled: false,
    isSignupBannerEnabled: false,
    isClientStation: false,
};

const backendOptions = { enableMouseEvents: true };

export default DragDropContext(TouchBackend(backendOptions))(App);
