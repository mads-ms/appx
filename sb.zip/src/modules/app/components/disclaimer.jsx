import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import config from 'src/config';
import Localization from 'src/localization';
import AppApproval from 'src/modules/appApproval';
import Disclaimer from 'src/modules/disclaimer';
import MifidDisclaimer from 'src/modules/mifidDisclaimer';
import Notice from 'src/components/notice/notice';
import { VelocityTransitionGroup } from 'velocity-react';

const transitionDefaults = {
    duration: 500,
    easing: 'easeOutQuint',
    animation: {
        translateY: '-50%',
        translateX: '-50%',
        opacity: 1,
    },
    style: {
        position: 'absolute',
        height: '100%',
        width: '100%',
        top: '50%',
        left: '50%',
        translateY: '-50%',
        translateX: '-50%',
        opacity: 0,
    },
};

const transitionFirst = _.defaultsDeep({
    style: {
        translateY: '-47%',
    },
}, transitionDefaults);

const transitionNext = _.defaultsDeep({
    style: {
        translateX: '-45%',
    },
}, transitionDefaults);

const transitionExit = _.defaultsDeep({
    animation: {
        translateX: '-55%',
        opacity: 0,
    },
    style: {
        opacity: 1,
    },
}, transitionDefaults);

let isFirstDisclaimer = true;

class App extends React.PureComponent {

    componentWillMount() {
        this.props.fetchAppInfo();
        this.props.fetchLoginDisclaimers();
    }

    componentWillUpdate(nextProps) {
        if ((this.props.isLoaded === false) &&
            (nextProps.isLoaded === true)) {
            this.removeSplash();
        }

        if ((this.props.showMifid === false) &&
            (nextProps.showMifid === true)) {
            this.props.fetchMifid();
        }
    }

    removeSplash() {
        const splashEl = document.getElementById('splash');
        splashEl.parentNode.removeChild(splashEl);
    }

    render() {
        const {
            showApproval,
            showMifid,
            currentDisclaimer,
            error,
            isLoaded,
        } = this.props;

        if (!isLoaded) {
            return null;
        }

        // set transition types, depending on whether it's the first disclaimer or not
        const transitionEnter = isFirstDisclaimer ? transitionFirst : transitionNext;
        const transitionLeave = transitionExit;

        // once we are past the first disclaimer, show different transitions
        isFirstDisclaimer = false;

        let childComponent;

        if (error) {
            const { message = Localization.getText('HTML5_AnErrorOccured'), status } = error;

            // print error message and status (if available, fall back to default)
            const errorText = status ? `${message} (${status})` : message;

            return <Notice message={errorText}/>;
        }

        if (currentDisclaimer) {
            childComponent = <Disclaimer disclaimer={currentDisclaimer} key={currentDisclaimer.DisclaimerId}/>;
        } else if (showApproval) {
            childComponent = <AppApproval key="AppApproval"/>;
        } else if (showMifid) {
            childComponent = <MifidDisclaimer key="Mifid"/>;
        }

        if (!childComponent) {
            // if there are no more disclaimers to read, redirect user
            window.location = config.returnUrl;
            return null;
        }

        return (
            <VelocityTransitionGroup
                enter={transitionEnter}
                leave={transitionLeave}
                component="div"
                className="grid grid--y"
                runOnMount
            >
                {childComponent}
            </VelocityTransitionGroup>
        );
    }
}

App.propTypes = {
    showApproval: PropTypes.bool.isRequired,
    showMifid: PropTypes.bool.isRequired,
    currentDisclaimer: PropTypes.object,
    isLoaded: PropTypes.bool,
    error: PropTypes.object,
    fetchAppInfo: PropTypes.func.isRequired,
    fetchMifid: PropTypes.func.isRequired,
    fetchLoginDisclaimers: PropTypes.func.isRequired,
};

App.defaultProps = {
    isLoaded: false,
};

export default App;
