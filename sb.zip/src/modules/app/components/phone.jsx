import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import PhoneNav from 'src/modules/phoneNav/phoneNav';
import Workspace from 'src/modules/workspace/containers/workspace';
import * as workspaceIds from 'src/modules/workspace/workspaceIds';
import InvestmentTicketDialog from 'src/modules/saxoSelect/containers/phone/investmentTicketDialogWrapper';
import LoginTracking from 'src/modules/loginTracking';
import { DragDropContext } from 'react-dnd';
import TouchBackend from 'react-dnd-touch-backend';

// required to be a class by React DND - https://github.com/react-dnd/react-dnd/issues/904
class App extends React.PureComponent {
    render() {
        const { controllerStore, layout } = this.props;

        const classes = classNames('grid grid--double', {
            'app--nav': layout === 'nav',
            'app--search': layout === 'search',
        });

        return (
            <div id="app" className={classes}>
                <div id="main" className="grid grid--y grid--fit-fill">
                    <header id="header"></header>
                    <Workspace
                        id={workspaceIds.PHONE_WORKSPACE_ID}
                        isActive
                        controllerStore={controllerStore}
                    />
                    <div id="main-overlay"></div>
                </div>
                <PhoneNav controllerStore={controllerStore}/>
                <Workspace
                    id={workspaceIds.DIALOGS_ID}
                    isActive
                />
                <InvestmentTicketDialog/>

                <LoginTracking/>
            </div>
        );
    }
}

App.propTypes = {
    controllerStore: PropTypes.object.isRequired,
    layout: PropTypes.string,
    isInstantDemoEnabled: PropTypes.bool,
};

App.defaultProps = {
    isInstantDemoEnabled: false,
};

const backendOptions = { enableMouseEvents: true };

export default DragDropContext(TouchBackend(backendOptions))(App);
