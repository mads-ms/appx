/* global module */
import _ from 'lodash';
import React from 'react';
import { bindHandlers } from 'src/utils/bindHandlers';
import windowResize from 'src/modules/windows/windowResizeService';
import Examples from 'src/modules/examples';
import * as utils from 'src/modules/examples/utils';
import { DragDropContext } from 'react-dnd';
import TouchBackend from 'react-dnd-touch-backend';

class App extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            examples: [],
            resizeTimestamp: 0,
        };
    }

    componentWillMount() {
        const exampleFiles = this.getExamples();
        const modules = {};

        // Keep references to modules
        _.forEach(exampleFiles.keys(), (key) => {
            modules[key] = exampleFiles(key);
        });

        this.notifyAboutChanges(modules);

        if (module.hot) {
            module.hot.accept();

            module.hot.accept(exampleFiles.id, () => {
                const reloadedContext = this.getExamples();
                const reloadedModules = {};

                _.forEach(reloadedContext.keys(), (key) => {
                    reloadedModules[key] = reloadedContext(key);
                });

                const changedModules = _.chain(reloadedModules)
                    .map((module, key) => [key, module])
                    .reject((reloadedModule) => modules[reloadedModule[0]] === reloadedModule[1])
                    .value();

                if (changedModules.length) {
                    this.notifyAboutChanges(reloadedModules);
                }
            });
        }
    }

    componentDidMount() {
        windowResize.on('ui:resize', this.handleResize);
    }

    componentWillUnmount() {
        windowResize.off('ui:resize', this.handleResize);
    }

    handleResize() {
        this.setState({
            resizeTimestamp: Date.now(),
        });
    }

    getExamples() {
        return require.context('../../../', true, /\.example\.jsx?$/);
    }

    notifyAboutChanges(modules) {
        this.setState({
            examples: utils.getExamples(modules),
        });
    }

    render() {
        const {
            examples,
            resizeTimestamp,
        } = this.state;

        return (
            <Examples
                examples={examples}
                resizeTimestamp={resizeTimestamp}
                onResize={this.handleResize}
            />
        );
    }
}

const backendOptions = { enableMouseEvents: true };

export default DragDropContext(TouchBackend(backendOptions))(bindHandlers(App));
