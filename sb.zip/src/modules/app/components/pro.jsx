import React from 'react';
import PropTypes from 'prop-types';
import Header from '../header/container';
import Workspaces from 'src/modules/workspace/containers/workspaces';
import Underlay from 'src/components/underlay/underlay';
import WindowFrame from 'src/components/windowFrame/windowFrame';
import Footer from 'appComponents/footer/footer';
import { ContextMenu, ContextMenuItem, MenuItems, MenuTarget } from 'src/components/contextMenu';
import * as contextMenuActions from 'src/components/contextMenu/contextMenuActions';
import { DragDropContext } from 'react-dnd';
import TouchBackend from 'react-dnd-touch-backend';

// required to be a class by React DND - https://github.com/react-dnd/react-dnd/issues/904
class App extends React.PureComponent {

    render() {
        return (
            <ContextMenu isEnabled={!this.props.windowIsFullScreen}>
                <MenuItems>
                    <ContextMenuItem action={contextMenuActions.ACTION_APP_SETTINGS}/>
                    <ContextMenuItem action={contextMenuActions.ACTION_APP_MODULE_PICKER}/>
                    <ContextMenuItem action={contextMenuActions.ACTION_APP_LOGOUT}/>
                </MenuItems>
                <MenuTarget>
                    <WindowFrame>
                        <Header/>
                        <Workspaces/>
                        <Footer/>
                        {/* Global Popups*/}
                        <Underlay/>
                    </WindowFrame>
                </MenuTarget>
            </ContextMenu>
        );
    }
}

App.propTypes = {
    windowIsFullScreen: PropTypes.bool.isRequired,
};

const backendOptions = { enableMouseEvents: true };

export default DragDropContext(TouchBackend(backendOptions))(App);
