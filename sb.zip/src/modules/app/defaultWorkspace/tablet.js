import Localization from 'src/localization';
import config from 'src/config';
import * as workspaceTypes from 'src/modules/workspace/workspaceTypes';
import * as moduleTypes from 'src/modules/workspace/moduleTypes';
import { ACCOUNT_WORKSPACE_ID, ACCOUNT_MENU_COMPONENT_ID } from 'src/modules/myAccount/constants';
import * as util from 'src/utils/util';

function overviewTabs() {
    return [
        {
            id: 'overview',
            layout: {
                type: moduleTypes.OVERVIEW,
                label: Localization.getText('HTML5_Overview'),
            },
        },
        {
            id: 'charts',
            layout: {
                type: moduleTypes.CHARTS,
                label: Localization.getText('HTML5_Charts'),
            },
        },
    ];
}

export function getTrading(isLandscape, isRealTimeNettingModeEnabled) {
    const workspace = {
        id: 'trading',
        type: workspaceTypes.MAIN_WINDOW,
        name: Localization.getText('HTML5_Masthead_Trading'),
    };

    let tabs = [
        {
            id: 'watchlist',
            layout: {
                type: moduleTypes.WATCHLIST,
                label: Localization.getText('HTML5_Watchlists'),
            },
        },
        {
            id: 'positions',
            layout: {
                type: moduleTypes.POSITIONS,
                label: Localization.getText('HTML5_Positions'),
            },
        },
        {
            id: 'orders',
            layout: {
                type: moduleTypes.ORDERS,
                label: Localization.getText('HTML5_Orders'),
            },
        },
        {
            id: 'closedPositions',
            layout: {
                type: moduleTypes.CLOSED_POSITIONS,
                label: Localization.getText('HTML5_ClosedPositions'),
                isAllowed: isRealTimeNettingModeEnabled,
            },
        },
        {
            id: 'pricealerts',
            layout: {
                type: moduleTypes.PRICE_ALERTS,
                label: Localization.getText('Price Alerts'),
                isAllowed: config.appFeatures.isPriceAlertsEnabled,
            },
        },
        {
            id: 'tradeleaders',
            layout: {
                type: moduleTypes.TRADELEADERS,
                label: config.saxoSelect.saxoSelectDisplayName,
                isAllowed: config.appFeatures.isAllowAutotrading,
            },
        },
        {
            id: 'saxoselectinvestments',
            layout: {
                type: moduleTypes.SAXOSELECT_INVESTMENTS,
                label: util.formatString(
                    Localization.getText('HTML5_SaxoSelect_Investments'),
                    config.saxoSelect.saxoSelectDisplayName
                ),
                isAllowed: config.appFeatures.isAllowAutotrading,
            },
        },
    ];

    if (isLandscape) {
        tabs = tabs.concat(overviewTabs());
    }

    workspace.layout = {
        id: 'TradePanelTab',
        layout: {
            type: moduleTypes.TABS,
            className: 'tab--joined-footer',
            tabs,
        },
    };

    if (!isLandscape) {
        workspace.layout = {
            id: 'TabletPortraitSplitter',
            layout: {
                type: moduleTypes.SPLITTER,
                orientation: 'vertical',
                firstMinSize: 40,
                lastMinSize: 150,
                isEnabled: false,
                first: {
                    id: 'InfoPanelTab',
                    layout: {
                        type: moduleTypes.TABS,
                        tabs: overviewTabs(),
                    },
                },
                last: workspace.layout,
            },
        };
    }

    return workspace;
}

export function getMarkets(isMarketOverviewAllowed, hasTradingFloorSource, isTradeSignalsAllowed) {
    const partnerIFrames = config.appFeatures.iFramedPartnerContent;

    return {
        id: 'markets',
        type: workspaceTypes.MAIN_WINDOW,
        name: Localization.getText('HTML5_Masthead_NewsAndResearch'),
        layout: {
            id: 'MarketsPanelTab',
            layout: {
                type: moduleTypes.TABS,
                isShowPartnerLink: true,
                tabs: [
                    {
                        id: 'marketOverview',
                        layout: {
                            type: moduleTypes.MARKET_OVERVIEW,
                            label: Localization.getText('HTML5_Equities'),
                            isAllowed: isMarketOverviewAllowed,
                        },
                    },
                    {
                        id: 'news',
                        layout: {
                            type: moduleTypes.NEWS,
                            label: Localization.getText('News'),
                        },
                    },
                    {
                        id: 'opinions',
                        layout: {
                            type: moduleTypes.OPINIONS,
                            label: Localization.getText('HTML5_TFOpinions'),
                            isAllowed: hasTradingFloorSource,
                        },
                    },
                    {
                        id: 'partnerIFrame1',
                        layout: {
                            type: moduleTypes.PARTNER_IFRAME1,
                            label: partnerIFrames[0] ? partnerIFrames[0].label : '',
                            isAllowed: Boolean(partnerIFrames[0] && partnerIFrames[0].label && partnerIFrames[0].url),
                        },
                    },
                    {
                        id: 'partnerIFrame2',
                        layout: {
                            type: moduleTypes.PARTNER_IFRAME2,
                            label: partnerIFrames[1] ? partnerIFrames[1].label : '',
                            isAllowed: Boolean(partnerIFrames[1] && partnerIFrames[1].label && partnerIFrames[1].url),
                        },
                    },
                    {
                        id: 'partnerIFrame3',
                        layout: {
                            type: moduleTypes.PARTNER_IFRAME3,
                            label: partnerIFrames[2] ? partnerIFrames[2].label : '',
                            isAllowed: Boolean(partnerIFrames[2] && partnerIFrames[2].label && partnerIFrames[2].url),
                        },
                    },
                    {
                        id: 'integratedContent',
                        layout: {
                            type: moduleTypes.INTEGRATED_CONTENT,
                            label: config.appFeatures.integratedContent,
                            isAllowed: Boolean(config.appFeatures.integratedContent),
                        },
                    },
                    {
                        id: 'calendar',
                        layout: {
                            type: moduleTypes.CALENDAR,
                            label: Localization.getText('HTML5_Calendar'),
                        },
                    },
                    {
                        id: 'tradeSignals',
                        layout: {
                            type: moduleTypes.TRADE_SIGNALS,
                            label: Localization.getText('HTML5_Trade_Signals'),
                            isAllowed: isTradeSignalsAllowed,
                        },
                    },
                ],
            },
        },
    };
}

export function getAccount() {
    // Switch to new menu style
    return {
        id: ACCOUNT_WORKSPACE_ID,
        type: workspaceTypes.MAIN_WINDOW,
        name: Localization.getText('HTML5_Masthead_Account'),
        layout: {
            id: ACCOUNT_MENU_COMPONENT_ID,
            layout: {
                type: moduleTypes.MYACCOUNT_MENUS,
            },
        },
    };
}
