import Localization from 'src/localization';
import * as workspaceTypes from 'src/modules/workspace/workspaceTypes';
import * as moduleTypes from 'src/modules/workspace/moduleTypes';
import config from 'src/config';
import { SETTING_WATCHLIST_ID } from 'src/modules/watchlists/watchlistSettingsKeys';
import _ from 'lodash';

const watchlistTabs = [
    {
        id: 'watchlist-first-own',
        layout: {
            type: moduleTypes.WATCHLIST,
            label: Localization.getText('HTML5_Watchlists'),
        },
        userSettings: {
            isLinking: true,
        },
    },
].concat(
    _.map(config.appFeatures.proDefaultWatchlistCollectionIds,
        (watchlistId) => ({
            id: `watchlist-${watchlistId}`,
            layout: {
                type: moduleTypes.WATCHLIST,
                label: Localization.getText('HTML5_Watchlists'),
            },
            userSettings: {
                isLinking: true,
                [SETTING_WATCHLIST_ID]: String(watchlistId),
            },
        })
    ));

export default {
    id: 'default',
    name: `${Localization.getText('HTML5_View')} 1`,
    type: workspaceTypes.MAIN_WINDOW,
    layout: {
        id: 'root-grid',
        layout: {
            type: moduleTypes.GRID,
            items: [
                {
                    id: 'watchlist-tabs',
                    layout: {
                        top: 0,
                        left: 0,
                        width: 50,
                        height: 60,
                        type: moduleTypes.TABS,
                        tabs: watchlistTabs,
                    },
                },
                {
                    id: 'orders-tabs',
                    layout: {
                        top: 60,
                        left: 0,
                        width: 65,
                        height: 20,
                        type: moduleTypes.TABS,
                        tabs: [
                            {
                                id: 'orders',
                                layout: {
                                    type: moduleTypes.ORDERS,
                                    label: Localization.getText('HTML5_Orders'),
                                },
                            },
                        ],
                    },
                },
                {
                    id: 'positions-tabs',
                    layout: {
                        top: 80,
                        left: 0,
                        width: 65,
                        height: 20,
                        type: moduleTypes.TABS,
                        tabs: [
                            {
                                id: 'positions',
                                layout: {
                                    type: moduleTypes.POSITIONS,
                                    label: Localization.getText('HTML5_Positions'),
                                },
                            },
                            {
                                id: 'closedpositions',
                                layout: {
                                    type: moduleTypes.CLOSED_POSITIONS,
                                    label: Localization.getText('HTML5_ClosedPositions'),
                                },
                            },
                            {
                                id: 'tradeblotter',
                                layout: {
                                    type: moduleTypes.TRADE_BLOTTER,
                                    label: Localization.getText('HTML5_TradeBlotter'),
                                },
                            },
                        ],
                    },
                },
                {
                    id: 'tradeticket-tabs',
                    layout: {
                        top: 0,
                        left: 50,
                        width: 20,
                        height: 42.5,
                        type: moduleTypes.TABS,
                        tabs: [
                            {
                                id: 'tradeticket',
                                layout: {
                                    type: moduleTypes.TRADE_TICKET,
                                    label: Localization.getText('HTML5_Tradeticket'),
                                },
                                userSettings: {
                                    isLinking: true,
                                },
                            },
                        ],
                    },
                },
                {
                    id: 'accountsummary-tabs',
                    layout: {
                        top: 42.5,
                        left: 50,
                        width: 20,
                        height: 17.5,
                        type: moduleTypes.TABS,
                        tabs: [
                            {
                                id: 'accountsummary',
                                layout: {
                                    type: moduleTypes.ACCOUNT_SUMMARY,
                                    label: Localization.getText('Account Summary'),
                                },
                            },
                        ],
                    },
                },
                {
                    id: 'charts1-tabs',
                    layout: {
                        top: 0,
                        left: 70,
                        width: 30,
                        height: 30,
                        type: moduleTypes.TABS,
                        tabs: [
                            {
                                id: 'charts1',
                                layout: {
                                    type: moduleTypes.CHART,
                                    label: Localization.getText('HTML5_Chart'),
                                },
                                userSettings: {
                                    isLinking: true,
                                },
                            },
                        ],
                    },
                },
                {
                    id: 'charts2-tabs',
                    layout: {
                        top: 30,
                        left: 70,
                        width: 30,
                        height: 30,
                        type: moduleTypes.TABS,
                        tabs: [
                            {
                                id: 'charts2',
                                layout: {
                                    type: moduleTypes.CHART,
                                    label: Localization.getText('HTML5_Chart'),
                                },
                                userSettings: {
                                    isLinking: true,
                                    selectedPeriod: 'oneDay',
                                    instrumentIds: ['21-FxSpot'],
                                    primaryInstrument: {
                                        id: '21-FxSpot',
                                        isLinked: false,
                                    },
                                },
                            },
                        ],
                    },
                },
                {
                    id: 'news-tabs',
                    layout: {
                        top: 60,
                        left: 65,
                        width: 35,
                        height: 40,
                        type: moduleTypes.TABS,
                        tabs: [
                            {
                                id: 'news',
                                layout: {
                                    type: moduleTypes.NEWS,
                                    label: Localization.getText('News'),
                                },
                            },
                            {
                                id: 'calendar',
                                layout: {
                                    type: moduleTypes.CALENDAR,
                                    label: Localization.getText('HTML5_Calendar'),
                                },
                            },
                            {
                                id: 'opinions',
                                layout: {
                                    type: moduleTypes.OPINIONS,
                                    label: Localization.getText('HTML5_TFOpinions'),
                                },
                            },
                        ],
                    },
                },
            ],
        },
    },
};
