export const SET_PHONE_LAYOUT = 'app/set-phone-layout';

export function setPhoneLayout(layout) {
    return {
        type: SET_PHONE_LAYOUT,
        layout,
    };
}
