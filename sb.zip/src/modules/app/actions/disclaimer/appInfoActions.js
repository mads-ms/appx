import config from 'src/config';
import getOpenApi from 'src/modules/openApi';
import log from 'src/modules/log';
import * as appInfoActionTypes from './appInfoActionTypes';

export function fetchAppInfo() {
    return function(dispatch) {
        const { appId } = config;

        // the app id will not be set if approval is never required
        // for the given app - in that case, load empty info
        if (!appId) {
            dispatch({
                type: appInfoActionTypes.LOAD,
                data: null,
            });
            return;
        }

        getOpenApi()
            .rest
            .get('cs', 'v1/apps/{appId}', { appId })
            .then((response) => {
                dispatch({
                    type: appInfoActionTypes.LOAD,
                    data: response.response,
                });
            }).catch((error) => {
                dispatch({
                    type: appInfoActionTypes.ERROR,
                    error: error.response,
                });

                log.error('Fetch app info failed', error);
            });
    };
}
