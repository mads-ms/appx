import config from 'src/config';
import getOpenApi from 'src/modules/openApi';
import log from 'src/modules/log';
import * as loginDisclaimersActionTypes from './loginDisclaimersActionTypes';

export function fetch() {
    return function(dispatch) {
        const { appId } = config;
        const { language } = config.regional;

        const servicePath = appId ?
            `v1/disclaimers/LoginFlow/${language}/${appId}` :
            `v1/disclaimers/LoginFlow/${language}`;

        getOpenApi()
            .rest.get('vas', servicePath)
            .then(
                (response) => {
                    dispatch({
                        type: loginDisclaimersActionTypes.LOAD,
                        disclaimers: response.response,
                    });
                },
                (error) => {
                    dispatch({
                        type: loginDisclaimersActionTypes.ERROR,
                        error,
                    });
                    log.error('Fetch login disclaimers failed', {
                        language,
                        error,
                    });
                }
            );
    };
}
