export const LOAD = 'loginDisclaimers/load';
export const ERROR = 'loginDisclaimers/error';
