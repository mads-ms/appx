export const LOAD = 'appInfo/load';
export const ERROR = 'appInfo/error';
