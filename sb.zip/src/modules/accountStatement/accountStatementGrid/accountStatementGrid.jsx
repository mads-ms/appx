import PropTypes from 'prop-types';
import React from 'react';
import ReactGrid from 'src/components/reactGrid/reactGrid';
import Resizable from 'src/components/resizable/resizable';
import { createColumnDefinitions } from './columnDefinitions';

class AccountStatementGrid extends React.PureComponent {
    render() {
        return (
            <Resizable resizeTimestamp={this.props.resizeTimestamp}>
                {
                    (resizableProps) => (
                        <ReactGrid
                            rows={this.props.rows}
                            cols={createColumnDefinitions()}
                            width={resizableProps.parentViewport.width}
                            height={resizableProps.parentViewport.height}
                        />
                    )
                }
            </Resizable>
        );
    }
}

AccountStatementGrid.propTypes = {
    componentId: PropTypes.string.isRequired,
    rows: PropTypes.arrayOf(PropTypes.object).isRequired,
    resizeTimestamp: PropTypes.number.isRequired,
};

export default AccountStatementGrid;
