import React from 'react';
import * as numberFormat from 'src/numberFormat';
import Localization from 'src/localization';
import DateTime from 'src/modules/dateTime';
import ProfitLabel from 'src/components/reactGrid/blocks/profitLabel';

/* eslint-disable react/prop-types */
// - eslint parser incorrectly sees template() as a stateless component
export const createColumnDefinitions = () => [
    {
        id: 'postingDate',
        isEnabled: true,
        width: 110,
        primaryTitle: Localization.getText('HTML5_Posting_Date'),
        isSortable: false,
        isNotSortable: true,
        priority: 1,
        template: ({ rowData }) => DateTime.formatUserDate(DateTime.createDateTime(rowData.PostingDate)),
    },
    {
        id: 'valueDate',
        isEnabled: true,
        width: 110,
        primaryTitle: Localization.getText('HTML5_ValueDate'),
        isSortable: false,
        isNotSortable: true,
        priority: 5,
        template: ({ rowData }) => DateTime.formatUserDate(DateTime.createDateTime(rowData.ValueDate)),
    },
    {
        id: 'product',
        isEnabled: true,
        minWidth: 200,
        maxWidth: 584,
        primaryTitle: Localization.getText('HTML5_Product'),
        isSortable: false,
        isNotSortable: true,
        priority: 2,
        template: ({ rowData }) => (
            <p className="t-truncate t-bold">{rowData.ProductDescription}</p>
        ),
    },
    {
        id: 'netChange',
        isEnabled: true,
        width: 120,
        primaryTitle: Localization.getText('HTML5_NetChange'),
        isSortable: false,
        isNotSortable: true,
        priority: 3,
        template: ({ rowData }) => {
            const { NetChange } = rowData;
            return (
                <ProfitLabel value={NetChange}>
                    {numberFormat.format(NetChange, 2)}
                </ProfitLabel>
            );
        },
    },
    {
        id: 'balance',
        isEnabled: true,
        width: 120,
        isAlignEnd: true,
        primaryTitle: Localization.getText('HTML5_CashBalance'),
        isSortable: false,
        isNotSortable: true,
        priority: 4,
        template: ({ rowData }) => numberFormat.format(rowData.Balance, 2),
    },
];

export default createColumnDefinitions;
