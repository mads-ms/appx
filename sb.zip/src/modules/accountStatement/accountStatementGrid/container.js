import { connect } from 'react-redux';
import * as accountStatementSelectors from '../selectors';
import AccountStatementGrid from './accountStatementGrid';

function mapStateToProps(state, ownProps) {
    const { componentId } = ownProps;

    const {
        rangeId,
        startDate,
        endDate,
    } = accountStatementSelectors.getComponentState(state, componentId);

    return {
        componentId,
        rangeId,
        startDate,
        endDate,
        rows: accountStatementSelectors.getRows(state, componentId),
    };
}

export default connect(mapStateToProps)(AccountStatementGrid);
