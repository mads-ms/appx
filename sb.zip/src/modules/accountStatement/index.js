import AccountStatement from './container';

export default AccountStatement;
