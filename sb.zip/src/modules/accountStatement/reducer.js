import _ from 'lodash';
import * as reportingQueries from 'src/modules/reporting/queries';
import * as accountStatementTypes from './actionTypes';
import DateTime from 'src/modules/dateTime';
import { DATE_RANGE_YEAR_TO_DATE } from 'src/modules/reporting/constants';
import { createComponentReducer } from 'src/utils/createComponentReducer';
import * as moduleTypes from 'src/modules/workspace/moduleTypes';

export const initialState = {
    components: {},
};

const defaultRange = _.find(reportingQueries.getPredefinedRanges(), { id: DATE_RANGE_YEAR_TO_DATE });

export const initialComponentState = {

    // the current account to filter on, excludes summary and group accounts
    // default provided in selector
    accountId: undefined,

    // the currently selected date range (from modules/reporting/queries.getPredefinedRanges())
    rangeId: DATE_RANGE_YEAR_TO_DATE,

    // the startDate of the date range. Stored as a string in the oapi format: 'YYYY-MM-DD'
    // the startDate of the date range.
    startDate: defaultRange.startDate.toOapi(),

    // the endDate of the date range.
    endDate: defaultRange.endDate.toOapi(),

    // indicates whether data is currently being loaded from oapi
    isLoading: false,

    // indicates whether an error occurred
    error: false,

    // the last time something updated. User's own time zone stored as milliseconds since the Unix Epoch.
    updateTime: null,

    // account summary data
    data: [],
};

const updateComponentState = createComponentReducer(moduleTypes.ACCOUNT_STATEMENT, (componentState = initialComponentState, action) => {
    switch (action.type) {

        case accountStatementTypes.CHANGE_INPUT_PARAMS:
            return handleChangeInputParams(componentState, action);

        case accountStatementTypes.CHANGE_ERROR:
            return handleChangeError(componentState, action);

        default:
            return componentState;
    }
});

// handlers
function handleChangeInputParams(componentState, action) {
    return _.defaults({
        accountId: action.accountId,
        rangeId: action.rangeId,
        startDate: action.startDate,
        endDate: action.endDate,
        isLoading: action.isLoading,
        error: false,
        updateTime: DateTime.now().valueOf(),
        data: action.data,
    }, componentState);
}

function handleChangeError(componentState, action) {
    return _.defaults({
        error: action.error,
        isLoading: false,
    }, componentState);
}

// helpers
export default function accountStatementStateReducer(state = initialState, action) {
    if (action.componentId) {
        return updateComponentState(state, action);
    }

    return state;
}
