import _ from 'lodash';
import SagaTester from 'redux-tale/tester';
import { DATE_RANGE_CUSTOM } from 'src/modules/reporting/constants';
import { getReducer } from 'src/storeFactory';
import { addModuleReducers } from 'src/modules/workspace/moduleReducers';
import { setCreateStore } from 'src/store';
import * as actions from 'src/modules/accountStatement/actions';
import * as actionTypes from 'src/modules/accountStatement/actionTypes';

// eslint-disable-next-line import/default
import rewire, * as sagas from 'src/modules/accountStatement/sagas';

describe('src/modules/accountStatement/sagas', () => {
    const componentId = 'test-component';
    const accountId = '123INET';
    const rangeId = DATE_RANGE_CUSTOM;
    const startDate = '2017-01-01';
    const endDate = '2017-01-20';
    const getAccountStatements = [
        {
            AccountId: accountId,
            Balance: 194597.7,
            CurrencyCode: 'USD',
            LastBalance: 194607.6,
            NetChange: -9.9,
            PostingDate: '2017-05-30T00:00:00.000000Z',
            ProductDescription: 'CFDs ITUB:xnys 1152361764',
            ValueDate: '2017-05-30T00:00:00.000000Z',
        },
    ];

    let sagaTester;

    beforeEach(() => {

        rewire.__Rewire__('getAccountStatements', () => getAccountStatements);

        const { reducer, addReducers } = getReducer();
        addModuleReducers(addReducers);

        sagaTester = new SagaTester({
            intialState: {},
            reducers: reducer,
        });
        setCreateStore(() => ({ store: sagaTester.store }));
    });

    afterEach(() => {
        rewire.__ResetDependency__('getAccountStatements');
    });

    describe('TRIGGER_CHANGE_INPUT_PARAMS', () => {
        beforeEach(() => {
            sagaTester.start(sagas.changeInputParamsSaga);
        });

        it('dispatches two CHANGE_INPUT_PARAMS actions. One before loading and one with the resulting data', () => {
            sagaTester.dispatch(actions.changeInputParams({
                componentId,
                accountId,
                rangeId,
                startDate,
                endDate,
                isLoading: true,
            }));

            const calledActions = sagaTester.getCalledActions();
            const changeInputParamsActions = _.filter(calledActions, (action) => action.type === actionTypes.CHANGE_INPUT_PARAMS);

            // assert first CHANGE_INPUT_PARAMS action
            const firstChangeInputParamsAction = changeInputParamsActions[0];

            expect(firstChangeInputParamsAction).toEqual({
                type: actionTypes.CHANGE_INPUT_PARAMS,
                componentId,
                accountId,
                rangeId,
                startDate,
                endDate,
                isLoading: true,
            });

            // assert second CHANGE_INPUT_PARAMS action
            const secondChangeInputParamsAction = changeInputParamsActions[1];

            expect(secondChangeInputParamsAction).toEqual({
                type: actionTypes.CHANGE_INPUT_PARAMS,
                componentId,
                accountId,
                rangeId,
                startDate,
                endDate,
                isLoading: false,
                error: false,
                data: getAccountStatements,
            });
        });
    });
});
