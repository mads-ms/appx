import _ from 'lodash';
import { put, call, select, takeEvery } from 'redux-tale/effects';
import getOpenApi from 'src/modules/openApi';
import log from 'src/modules/log';
import * as accountStatementSelectors from './selectors';
import * as actionTypes from './actionTypes';
import { addSagas } from 'src/sagas';

export function *initialize({ componentId }) {
    const componentState = yield select(accountStatementSelectors.getComponentState, componentId);

    const {
        rangeId,
        startDate,
        endDate,
        accountId,
        data,
    } = componentState;

    // component already instantiated
    if (!_.isEmpty(data)) {
        return;
    }

    const account = yield select(accountStatementSelectors.getAccount, accountId);

    yield changeInputParams({
        componentId,
        accountId: account.id,
        rangeId,
        startDate,
        endDate,
    });
}

export function* changeInputParams(params) {
    const {
        componentId,
        accountId,
        rangeId,
        startDate,
        endDate,
    } = params;

    try {

        // Set the isLoading flag so the UI becomes busy
        yield put({
            type: actionTypes.CHANGE_INPUT_PARAMS,
            componentId,
            accountId,
            rangeId,
            startDate,
            endDate,
            isLoading: true,
        });

        const account = yield select(accountStatementSelectors.getAccount, accountId);

        const statements = yield fetchLatest(componentId, 'statements', getAccountStatements,
            { account, startDate, endDate });

        // null is returned if fetch is cancelled by a newer request
        if (statements === null) {
            return;
        }

        yield put({
            type: actionTypes.CHANGE_INPUT_PARAMS,
            componentId,
            accountId,
            rangeId,
            startDate,
            endDate,
            data: statements,
            isLoading: false,
            error: false,
        });

    } catch (error) {
        yield put({ type: actionTypes.CHANGE_ERROR, componentId, error: true });
    }
}

export function getAccountStatements({ account, startDate, endDate }) {
    const queryParams = {
        FromDate: startDate,
        ToDate: endDate,
    };

    if (account.IsSummary) {

        return getOpenApi().rest.get('cs', 'v1/reports/accountstatements/clients/{clientKey}', { clientKey: account.ClientKey }, { queryParams })
            .then(
                ({ response }) => {
                    const data = _.get(response, 'Data', []);

                    // filter out the weird fake entries that are returned by oapi if there is nothing posted in the period.
                    return _.filter(data, 'PostingDate');
                },
                (error) => {
                    log.error('Failed to get client level account statements', { error });
                    return [];
                }
            );
    }

    return getOpenApi().rest.get('cs', 'v1/reports/accountstatements/accounts/{accountKey}', { accountKey: account.AccountKey }, { queryParams })
        .then(
            ({ response }) => {
                const data = _.get(response, 'Data', []);

                // filter out the weird fake entries that are returned by oapi if there is nothing posted in the period.
                return _.filter(data, 'PostingDate');
            },
            (error) => {
                log.error('Failed to get account level account statements', { error });
                return [];
            }
        );
}

// redux-saga/effects/takeLatest looks like it could be used in place of fetchLatest, but it currently fails...
const requestCounters = {};
function* fetchLatest(componentId, fetchId, ...args) {

    if (!requestCounters[componentId]) {
        requestCounters[componentId] = {};
    }

    requestCounters[componentId][fetchId] = requestCounters[componentId][fetchId] ? requestCounters[componentId][fetchId] + 1 : 1;
    const localRequestCounter = requestCounters[componentId][fetchId];

    const response = yield call(...args);

    // return null if newer fetch exists
    return localRequestCounter === requestCounters[componentId][fetchId] ? response : null;
}

export const initializeSaga = takeEvery(actionTypes.TRIGGER_INITIALIZE, initialize);
export const changeInputParamsSaga = takeEvery(actionTypes.TRIGGER_CHANGE_INPUT_PARAMS, changeInputParams);

addSagas([
    initializeSaga,
    changeInputParamsSaga,
]);
