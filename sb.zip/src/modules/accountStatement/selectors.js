import _ from 'lodash';
import * as accountStatementReducer from './reducer';
import * as accountsSelectors from 'src/modules/accounts/selectors';

export const getComponentState = (state, componentId) =>
    _.get(state, ['accountStatement', 'components', componentId], accountStatementReducer.initialComponentState);

export const getAccount = (state, accountId) => {
    if (!accountId) {
        return _.head(accountsSelectors.getAccounts(state));
    }

    return accountsSelectors.getAccountById(state, accountId);
};

export const getRows = (state, componentId) => {
    const compState = getComponentState(state, componentId);

    return _.map(compState.data, (item, rowIndex) => ({
        id: rowIndex.toString(),
        data: item,
    }));
};
