import React from 'react';
import PropTypes from 'prop-types';
import * as reportingQueries from 'src/modules/reporting/queries';
import DateRange from 'src/components/reporting/dateRange';
import Localization from 'src/localization';
import AccountBalancesSelector from 'src/modules/accountBalancesSelector/container';
import { bindHandlers } from 'src/utils/bindHandlers';

class AccountStatementFilters extends React.PureComponent {

    handleDateRangeChanged(rangeId, startDate, endDate) {
        const {
            componentId,
            accountId,
        } = this.props;

        const params = {
            componentId,
            accountId,
            rangeId,
            startDate,
            endDate,
        };

        this.props.onChangeInputParams(params);
    }

    handleAccountChanged(accountId) {
        const {
            componentId,
            rangeId,
            startDate,
            endDate,
        } = this.props;

        const params = {
            componentId,
            accountId,
            rangeId,
            startDate,
            endDate,
        };

        this.props.onChangeInputParams(params);
    }

    render() {
        const {
            componentId,
            accountId,
            rangeId,
            startDate,
            endDate,
        } = this.props;

        return (
            <div>
                <div className="sep sep--bottom">
                    {Localization.getText('HTML5_Filter')}
                </div>

                <p className="form-legend">{Localization.getText('HTML5_Account')}</p>
                <AccountBalancesSelector
                    componentId={componentId}
                    onSelect={this.handleAccountChanged}
                    accountId={accountId}
                    showClient={false}
                    showGroups={false}
                />

                <p className="form-legend">{Localization.getText('HTML5_Period')}</p>
                <DateRange
                    predefinedRanges={reportingQueries.getPredefinedRanges()}
                    onChange={this.handleDateRangeChanged}
                    rangeId={rangeId}
                    startDate={startDate}
                    endDate={endDate}
                />
            </div>
        );
    }
}

AccountStatementFilters.propTypes = {
    componentId: PropTypes.string.isRequired,
    accountId: PropTypes.string.isRequired,
    rangeId: PropTypes.string.isRequired,
    startDate: PropTypes.string.isRequired,
    endDate: PropTypes.string.isRequired,
    onChangeInputParams: PropTypes.func,
};

export default bindHandlers(AccountStatementFilters);
