import _ from 'lodash';
import * as accountStatementSelectors from 'src/modules/accountStatement/selectors';
import { initialComponentState } from 'src/modules/accountStatement/reducer';
import * as asyncActionStatus from 'src/asyncActionStatus';
import dataAccounts from 'test/mocks/data/account/accounts-fetch.json';
import dataAccountGroups from 'test/mocks/data/account/accounts-group-fetch.json';
import dataClient from 'test/mocks/data/account/client.json';
import * as subscriptionsConfig from 'src/modules/accountsSubscription/config';

describe('src/modules/accountStatement/selectors', () => {
    let mockState;

    const COMPONENT_ID = 'accountStatementId';

    const clients = {
        fetch: {
            status: asyncActionStatus.SUCCESS,
            error: null,
        },
        data: {
            me: _.cloneDeep(dataClient),
            impersonated: {},
        },
    };
    const accounts = {
        fetch: {
            status: asyncActionStatus.SUCCESS,
            error: null,
        },
        data: _.cloneDeep(dataAccounts.Data),
    };
    const accountGroups = {
        fetch: {
            status: asyncActionStatus.SUCCESS,
            error: null,
        },
        data: _.cloneDeep(dataAccountGroups.Data),
    };
    const subscriptions = {
        [subscriptionsConfig.TYPE]: {},
    };

    const data = [];

    beforeEach(() => {

        mockState = {
            clients,
            accounts,
            accountGroups,
            subscriptions,
            accountStatement: {
                components: {
                    [COMPONENT_ID]: _.defaults({ data }, initialComponentState),
                },
            },
        };
    });

    describe('getComponentState()', () => {
        it('should return the initial state for a specific instance of a accountStatement', () => {
            const actual = accountStatementSelectors.getComponentState(mockState, COMPONENT_ID);
            expect(actual).toEqual(initialComponentState);
        });
    });

    describe('getAccount()', () => {
        it('should return an account given an AccountId', () => {
            const actual = accountStatementSelectors.getAccount(mockState, dataAccounts.Data[0].AccountId);
            expect(actual.AccountId).toEqual(dataAccounts.Data[0].AccountId);
        });

        it('should return a default account given an empty AccountId', () => {
            const actual = accountStatementSelectors.getAccount(mockState, '');
            expect(actual.AccountId).toEqual(dataAccounts.Data[0].AccountId);
        });
    });

});
