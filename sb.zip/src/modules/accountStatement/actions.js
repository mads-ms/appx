import * as accountStatementTypes from './actionTypes';
import * as moduleLifecycleActions from 'src/modules/moduleLifecycle/actions';
import * as moduleTypes from 'src/modules/workspace/moduleTypes';

// This import is needed to include the sagas file in the bundle
import './sagas';

export function initialize({ componentId }) {
    return (dispatch) => {
        dispatch(moduleLifecycleActions.create(moduleTypes.ACCOUNT_STATEMENT, componentId));

        dispatch({
            type: accountStatementTypes.TRIGGER_INITIALIZE,
            componentId,
        });
    };
}

export function changeInputParams({ componentId, accountId, rangeId, startDate, endDate }) {
    return {
        type: accountStatementTypes.TRIGGER_CHANGE_INPUT_PARAMS,
        componentId,
        accountId,
        rangeId,
        startDate,
        endDate,
    };
}
