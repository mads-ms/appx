export const TRIGGER_INITIALIZE = 'sagas/accountStatement/initialize';
export const TRIGGER_CHANGE_INPUT_PARAMS = 'sagas/accountStatement/change-input-params';

export const CHANGE_INPUT_PARAMS = 'accountStatement/change-input-params';
export const CHANGE_ERROR = 'accountStatement/change-error';
