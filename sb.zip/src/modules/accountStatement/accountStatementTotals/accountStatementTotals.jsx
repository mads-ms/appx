import React from 'react';
import PropTypes from 'prop-types';
import Localization from 'src/localization';
import * as numberFormat from 'src/numberFormat';

class AccountStatementTotals extends React.PureComponent {
    render() {
        const {
            account,
            totalCredited,
            totalDebited,
        } = this.props;

        const decimals = account.BaseCurrencyDecimals;

        return (
            <div className="grid grid--wells grid--toolbar sep sep--bottom">
                <div className="grid-cell">
                    <p className="t-meta">{Localization.getText('HTML5_SummaryPeriod')}</p>
                </div>
                <div className="grid-cell g--fit">
                    <p className="t-meta">{Localization.getText('HTML5_Credited')}</p>
                    <p className="t-large">{numberFormat.format(totalCredited, decimals)}</p>
                </div>
                <div className="grid-cell g--fit">
                    <p className="t-meta">{Localization.getText('HTML5_Debited')}</p>
                    <p className="t-large">{numberFormat.format(totalDebited, decimals)}</p>
                </div>
            </div>
        );
    }
}

AccountStatementTotals.propTypes = {
    totalCredited: PropTypes.number.isRequired,
    totalDebited: PropTypes.number.isRequired,
    account: PropTypes.object.isRequired,
};

export default AccountStatementTotals;
