import { connect } from 'react-redux';
import * as accountStatementSelectors from './selectors';
import AccountStatement from './accountStatement';
import * as accountStatementActions from './actions';
import DateTime from 'src/modules/dateTime';

function mapStateToProps(state, props) {

    const { componentId } = props;

    const {
        data,
        rangeId,
        startDate,
        endDate,
        isLoading,
        error,
        updateTime,
        accountId,
    } = accountStatementSelectors.getComponentState(state, componentId);

    return {
        componentId,
        data,
        account: accountStatementSelectors.getAccount(state, accountId),
        rangeId,
        startDate,
        endDate,
        isLoading,
        error,
        updateTime: DateTime.createDateTime(updateTime),
    };
}

const mapDispatchToProps = {
    onMount: accountStatementActions.initialize,
    onChangeInputParams: accountStatementActions.changeInputParams,
};

export default connect(mapStateToProps, mapDispatchToProps)(AccountStatement);
