import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import AccountStatementGrid from './accountStatementGrid/container';
import AccountStatementTotals from './accountStatementTotals/accountStatementTotals';
import AccountStatementFilters from './accountStatementFilters/accountStatementFilters';
import Localization from 'src/localization';
import Notice from 'src/components/notice/notice';
import ReportFooterLine from 'src/modules/reporting/reportFooterLine/container';
import Button from 'src/components/button/button';
import Dialog from 'src/components/dialog/dialog';
import Icon from 'src/components/icon/icon';
import * as featureTracker from 'src/featureTracker';
import config from 'src/config';
import Resizable from 'src/components/resizable/resizable';
import { bindHandlers } from 'src/utils/bindHandlers';
import InitStatus from 'src/components/reporting/initStatus';

const DEFAULT_SCREEN_THRESHOLD_WIDTH = 1024;

class AccountStatement extends React.PureComponent {
    constructor(props) {
        super(props);

        this.setEl = (ref) => {
            this.el = ref;
        };

        this.state = {
            isFilterDialogVisible: false,
        };
    }

    componentDidMount() {
        this.props.onMount({
            componentId: this.props.componentId,
        });

        featureTracker.logEvent(featureTracker.AREA_ACCOUNT_STATEMENT, 'Module loaded', {
            sessionId: config.sessionId,
        });
    }

    handleSetAnchor(ref) {
        this.anchorEl = ref;
    }

    handleFilterButtonTap() {
        this.setState({ isFilterDialogVisible: true });
    }

    handleFilterDialogHide() {
        this.setState({ isFilterDialogVisible: false });
    }

    render() {
        return (
            <Resizable resizeTimestamp={this.props.resizeTimestamp}>
                {
                    (resizableProps) => {
                        const {
                            componentId,
                            account,
                            rangeId,
                            startDate,
                            endDate,
                            isLoading,
                            error,
                            resizeTimestamp,
                            updateTime,
                            data,
                        } = this.props;

                        const {
                            width,
                            height,
                        } = resizableProps.parentViewport;

                        const {
                            isFilterDialogVisible,
                        } = this.state;

                        const totalCredited = _.sumBy(data, (item) => item.NetChange > 0 ? item.NetChange : 0);
                        const totalDebited = _.sumBy(data, (item) => item.NetChange < 0 ? item.NetChange : 0);

                        const accountId = account.AccountId;

                        const isShowNarrowView = width && (resizableProps.parentViewport.width <= DEFAULT_SCREEN_THRESHOLD_WIDTH);

                        return (
                            <div className="grid grid--fit-fill">

                                {isShowNarrowView ?
                                    <div className="reporting-filterbar sep sep--right grid-cell">
                                        <Button
                                            onTap={this.handleFilterButtonTap}
                                            onDomRef={this.handleSetAnchor}
                                            className="btn--clear btn--square"
                                        >
                                            <Icon type="filter"/>
                                        </Button>
                                    </div> :
                                    <div className="reporting-sidebar sep sep--right grid-cell">
                                        <AccountStatementFilters
                                            componentId={componentId}
                                            accountId={accountId}
                                            rangeId={rangeId}
                                            startDate={startDate}
                                            endDate={endDate}
                                            onDateRangeChange={this.handleDateRangeChange}
                                            onAccountChange={this.handleAccountChange}
                                            onChangeInputParams={this.props.onChangeInputParams}
                                        />
                                    </div>
                                }

                                <div className="grid">
                                    {(error || isLoading) ?
                                        <InitStatus
                                            isLoading={isLoading}
                                            error={Localization.getText('HTML5_Data_Load_Error')}
                                        /> :
                                        <div className="grid grid--y grid--fit-fill">

                                            <AccountStatementTotals
                                                totalCredited={totalCredited}
                                                totalDebited={totalDebited}
                                                account={account}
                                            />

                                            <div className="grid grid--y grid--fill-fit">
                                                {!data.length && (
                                                    <Notice message={Localization.getText('HTML5_no_data_for_period_account')}/>
                                                )}

                                                {data.length && (
                                                    <AccountStatementGrid
                                                        componentId={componentId}
                                                        resizeTimestamp={resizeTimestamp}
                                                    />
                                                )}

                                                <div className="grid-cell">
                                                    <ReportFooterLine
                                                        disclaimerKey="AccountStatement"
                                                        updateTime={updateTime}
                                                    />
                                                </div>
                                            </div>
                                        </div>}
                                </div>

                                {isShowNarrowView && isFilterDialogVisible && (
                                    <Dialog
                                        anchor={this.anchorEl}
                                        position="right"
                                        align="top"
                                        height={height}
                                        onHide={this.handleFilterDialogHide}
                                    >
                                        <div className="reporting-sidebar">
                                            <AccountStatementFilters
                                                componentId={componentId}
                                                accountId={accountId}
                                                rangeId={rangeId}
                                                startDate={startDate}
                                                endDate={endDate}
                                                onDateRangeChange={this.handleDateRangeChange}
                                                onChangeInputParams={this.props.onChangeInputParams}
                                            />
                                        </div>
                                    </Dialog>
                                )}
                            </div>
                        );
                    }
                }
            </Resizable>
        );
    }
}

AccountStatement.propTypes = {
    componentId: PropTypes.string.isRequired,
    resizeTimestamp: PropTypes.number.isRequired,
    data: PropTypes.arrayOf(PropTypes.object).isRequired,
    account: PropTypes.object.isRequired,
    isLoading: PropTypes.bool,
    error: PropTypes.bool,
    rangeId: PropTypes.string.isRequired,
    startDate: PropTypes.string.isRequired,
    endDate: PropTypes.string.isRequired,
    updateTime: PropTypes.object,
    onMount: PropTypes.func.isRequired,
    onChangeInputParams: PropTypes.func.isRequired,
};

AccountStatement.defaultProps = {
    isLoading: true,
};

export default bindHandlers(AccountStatement);
