import reducer, { initialComponentState } from 'src/modules/accountStatement/reducer';
import * as actionTypes from 'src/modules/accountStatement/actionTypes';
import { DATE_RANGE_CUSTOM } from 'src/modules/reporting/constants';

const joc = jasmine.objectContaining;
let mockState;

describe('src/modules/accountStatement/reducer', () => {
    const COMPONENT_ID = 'bar';

    beforeEach(() => {
        mockState = {
            components: {
                [COMPONENT_ID]: initialComponentState,
            },
        };
    });

    describe('CHANGE_INPUT_PARAMS', () => {
        it('should return the new state while reflecting the changed inputParams', () => {
            const accountId = 1234;
            const rangeId = DATE_RANGE_CUSTOM;
            const startDate = '2017-01-01';
            const endDate = '2017-05-22';
            const isLoading = false;
            const error = false;
            const data = { foo: 'bar' };

            const stubAction = {
                type: actionTypes.CHANGE_INPUT_PARAMS,
                componentId: COMPONENT_ID,
                accountId,
                rangeId,
                startDate,
                endDate,
                isLoading,
                data,
            };

            const newState = reducer(mockState, stubAction);

            expect(newState).toEqual(joc({
                components: joc({
                    [COMPONENT_ID]: joc({
                        accountId,
                        rangeId,
                        startDate,
                        endDate,
                        isLoading,
                        error,
                        data,
                    }),
                }),
            }));
        });
    });

    describe('CHANGE_ERROR', () => {
        it('should return the new state with error info', () => {
            const error = 'shit happened';
            const isLoading = false;

            const stubAction = {
                type: actionTypes.CHANGE_ERROR,
                componentId: COMPONENT_ID,
                error,
                isLoading,
            };

            const newState = reducer(mockState, stubAction);

            expect(newState).toEqual(joc({
                components: joc({
                    [COMPONENT_ID]: joc({
                        error,
                        isLoading,
                    }),
                }),
            }));
        });
    });
});
