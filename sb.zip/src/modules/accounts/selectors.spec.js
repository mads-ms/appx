import _ from 'lodash';
import Enums from 'src/spine/enums';
import config from 'src/config';
import * as accountsSelectors from 'src/modules/accounts/selectors';
import * as asyncActionStatus from 'src/asyncActionStatus';
import * as subscriptionsConfig from 'src/modules/accountsSubscription/config';
import Localization from 'src/localization';
import dataClient from 'test/mocks/data/account/client.json';
import dataAccounts from 'test/mocks/data/account/accounts-fetch.json';
import dataAccountGroups from 'test/mocks/data/account/accounts-group-fetch.json';
import dataAccountsMultipleGroups from 'test/mocks/data/account/accounts-group-new-fetch.json';
import dataAccountsSingle from 'test/mocks/data/account/accounts-single-fetch.json';
import * as balancesSubscriptionsConfig from 'src/modules/balancesSubscription/config';

describe('src/modules/accounts/selectors', () => {

    let state;

    beforeEach(() => {
        config.appFeatures.partnerLegalInstruments = Enums.InstrumentType.AllInstruments;
    });

    describe('getAccountsFetchState()', () => {
        it('should get correct fetched account state', () => {
            state = {
                accounts: {
                    fetch: {
                        status: asyncActionStatus.PENDING,
                        error: null,
                    },
                    data: [{
                        accountId: 1,
                    }],
                },
            };

            expect(accountsSelectors.getAccountsFetchState(state)).toEqual(state.accounts.fetch);
        });
    });

    describe('getFetchedAccountsLoaded()', () => {

        it('should get correct value for loaded selector', () => {
            state = {
                accounts: {
                    fetch: {
                        status: asyncActionStatus.NONE,
                        error: null,
                    },
                },
            };

            expect(accountsSelectors.getFetchedAccountsLoaded(state)).toBe(false);

            state.accounts.fetch.status = asyncActionStatus.PENDING;

            expect(accountsSelectors.getFetchedAccountsLoaded(state)).toBe(false);

            state.accounts.fetch.status = asyncActionStatus.ERROR;

            expect(accountsSelectors.getFetchedAccountsLoaded(state)).toBe(false);

            state.accounts.fetch.status = asyncActionStatus.SUCCESS;

            expect(accountsSelectors.getFetchedAccountsLoaded(state)).toBe(true);
        });

    });

    describe('getStoreAccounts()', () => {
        it('should fallback to fetched accounts accounts', () => {
            state = {
                accounts: {
                    fetch: {
                        status: asyncActionStatus.SUCCESS,
                        error: null,
                    },
                    data: [{
                        accountId: 1,
                    }],
                },
                subscriptions: {
                    accounts: {
                        accounts: {
                            data: {},
                            status: asyncActionStatus.PENDING,
                        },
                    },
                },
            };

            expect(accountsSelectors.getStoreAccounts(state)).toEqual(state.accounts.data);

            state.subscriptions = {
                accounts: {
                    accounts: {
                        data: {},
                        status: asyncActionStatus.SUCCESS,
                    },
                },
            };

            expect(accountsSelectors.getStoreAccounts(state)).toEqual(state.accounts.data);
        });

        it('should return subscribed accounts', () => {
            state = {
                accounts: {
                    fetch: {
                        status: asyncActionStatus.SUCCESS,
                        error: null,
                    },
                    data: {
                        accountA: { accountId: 'accountA' },
                    },
                },
                subscriptions: {
                    accounts: {
                        accounts: {
                            data: {
                                accountB: { AccountId: 'accountB' },
                            },
                            status: asyncActionStatus.SUCCESS,
                        },
                    },
                },
            };

            expect(accountsSelectors.getStoreAccounts(state)).toEqual({ accountB: { AccountId: 'accountB' } });
        });
    });

    describe('getAccountsList()', () => {
        it('should return empty array of accounts', () => {
            state = {
                clients: {
                    fetch: {
                        status: asyncActionStatus.NONE,
                        error: null,
                    },
                    data: {
                        me: {},
                        impersonated: {},
                    },
                },
                accounts: {
                    fetch: {
                        status: asyncActionStatus.NONE,
                        error: null,
                    },
                    data: [],
                },
                accountGroups: {
                    fetch: {
                        status: asyncActionStatus.NONE,
                        error: null,
                    },
                    data: [],
                },
                subscriptions: {
                    [subscriptionsConfig.TYPE]: {},
                },
            };

            expect(accountsSelectors.getAccountsList(state)).toEqual([]);
        });

        it('should return sorted array of accounts', () => {
            state = {
                clients: {
                    fetch: {
                        status: asyncActionStatus.SUCCESS,
                        error: null,
                    },
                    data: {
                        me: _.cloneDeep(dataClient),
                        impersonated: {},
                    },
                },
                accounts: {
                    fetch: {
                        status: asyncActionStatus.SUCCESS,
                        error: null,
                    },
                    data: _.cloneDeep(dataAccountsMultipleGroups.Data),
                },
                accountGroups: {
                    fetch: {
                        status: asyncActionStatus.SUCCESS,
                        error: null,
                    },
                    data: _.cloneDeep(dataAccountGroups.Data),
                },
                subscriptions: {
                    [subscriptionsConfig.TYPE]: {},
                },
            };

            const order = [
                'summary',
                'ebX3RYqSqK-Ebxyltl5zqg==',
                'test1',
                'test2',
                'test3',
                'mALSOh4HkR68swC3pm8lpg==',
                'group1test1',
                'group1test2',
                'group1test3',
                'PoWSOh4HkR68swC3pm8lpg==',
                'group2test1',
            ];

            const result = accountsSelectors.getAccountsList(state);
            const ids = _.map(result, 'id');

            expect(order).toEqual(ids);
        });

        it('should exclude the group when there is only one group', () => {
            state = {
                clients: {
                    fetch: {
                        status: asyncActionStatus.SUCCESS,
                        error: null,
                    },
                    data: {
                        me: _.cloneDeep(dataClient),
                        impersonated: {},
                    },
                },
                accounts: {
                    fetch: {
                        status: asyncActionStatus.SUCCESS,
                        error: null,
                    },
                    data: _.cloneDeep(dataAccounts.Data),
                },
                accountGroups: {
                    fetch: {
                        status: asyncActionStatus.SUCCESS,
                        error: null,
                    },
                    data: [],
                },
                subscriptions: {
                    [subscriptionsConfig.TYPE]: {},
                },
            };

            const order = [
                'summary',
                'test1',
                'test2',
                'test3',
            ];

            const result = accountsSelectors.getAccountsList(state);
            const ids = _.map(result, 'id');

            expect(order).toEqual(ids);
        });
    });

    describe('getAccountById()', () => {

        beforeEach(() => {
            state = {
                clients: {
                    fetch: {
                        status: asyncActionStatus.SUCCESS,
                        error: null,
                    },
                    data: {
                        me: _.cloneDeep(dataClient),
                        impersonated: {},
                    },
                },
                accounts: {
                    fetch: {
                        status: asyncActionStatus.SUCCESS,
                        error: null,
                    },
                    data: _.cloneDeep(dataAccounts.Data),
                },
                accountGroups: {
                    fetch: {
                        status: asyncActionStatus.SUCCESS,
                        error: null,
                    },
                    data: _.cloneDeep(dataAccountGroups.Data),
                },
                subscriptions: {
                    [subscriptionsConfig.TYPE]: {},
                },
            };
        });

        it('should return account by id', () => {
            const result = accountsSelectors.getAccountById(state, 'test1');
            expect(result.id).toEqual('test1');
        });

        it('should return false for non existing account', () => {
            let result = accountsSelectors.getAccountById(state, '');
            expect(result).toBeFalsy();

            result = accountsSelectors.getAccountById(state, null);
            expect(result).toBeFalsy();
        });
    });

    describe('getAccounts()', () => {
        beforeEach(() => {
            state = {
                clients: {
                    fetch: {
                        status: asyncActionStatus.SUCCESS,
                        error: null,
                    },
                    data: {
                        me: _.cloneDeep(dataClient),
                        impersonated: {},
                    },
                },
                accounts: {
                    fetch: {
                        status: asyncActionStatus.SUCCESS,
                        error: null,
                    },
                    data: _.cloneDeep(dataAccountsSingle.Data),
                },
                subscriptions: {
                    [subscriptionsConfig.TYPE]: {},
                },
            };
        });

        it('should calculate properly derived data', () => {
            const accounts = accountsSelectors.getAccounts(state);
            const account = _.head(accounts);

            expect(account.BaseCurrency).toEqual('EUR');
            expect(account.CurrencyDecimals).toEqual(2);
            expect(account.Sharing).toBe(false);
            expect(account.DisplayName).toEqual('test');
            expect(account.IndividualMargining).toBe(false);
            expect(account.IsMarginTradingAllowed).toBe(false);
        });
    });

    describe('getAccountGroups()', () => {

        describe('multiple account groups case', () => {
            beforeEach(() => {
                state = {
                    clients: {
                        fetch: {
                            status: asyncActionStatus.SUCCESS,
                            error: null,
                        },
                        data: {
                            me: _.cloneDeep(dataClient),
                            impersonated: {},
                        },
                    },
                    accounts: {
                        fetch: {
                            status: asyncActionStatus.SUCCESS,
                            error: null,
                        },
                        data: _.cloneDeep(dataAccountsMultipleGroups.Data),
                    },
                    accountGroups: {
                        fetch: {
                            status: asyncActionStatus.SUCCESS,
                            error: null,
                        },
                        data: _.cloneDeep(dataAccountGroups.Data),
                    },
                    subscriptions: {
                        [subscriptionsConfig.TYPE]: {},
                    },
                };
            });

            it('should calculate properly groups properties', () => {
                const groups = accountsSelectors.getAccountGroups(state);
                const group = _.head(groups);

                expect(groups.length).toEqual(3);
                expect(group.IsGroup).toBe(true);
                expect(group.Accounts.length).toEqual(3);
                expect(group.id).toEqual('ebX3RYqSqK-Ebxyltl5zqg==');
                expect(group.AccountId).toEqual('ebX3RYqSqK-Ebxyltl5zqg==');
                expect(group.AccountGroupName).toEqual('Default');
                expect(group.BaseCurrency).toEqual('CHF');
                expect(group.DisplayName).toEqual('Default');
                expect(group.IndividualMargining).toBe(false);
                expect(group.IsMarginTradingAllowed).toBe(true);
            });

            it('calculate properly margin properties', () => {
                state.accounts.data = _.map(state.accounts.data, (account, index) =>
                    _.defaults({ IndividualMargining: index === 0, IsMarginTradingAllowed: index === 0 }, account));

                const groups = accountsSelectors.getAccountGroups(state);
                const group = _.head(groups);

                expect(group.IndividualMargining).toBe(true);
                expect(group.IsMarginTradingAllowed).toBe(true);
            });
        });
    });

    describe('getSummaryAccount()', () => {
        beforeEach(() => {
            state = {
                clients: {
                    fetch: {
                        status: asyncActionStatus.SUCCESS,
                        error: null,
                    },
                    data: {
                        me: _.cloneDeep(dataClient),
                        impersonated: {},
                    },
                },
                accounts: {
                    fetch: {
                        status: asyncActionStatus.SUCCESS,
                        error: null,
                    },
                    data: _.cloneDeep(dataAccounts.Data),
                },
                subscriptions: {
                    [subscriptionsConfig.TYPE]: {},
                },
            };
        });

        it('should calculate properly summary account properties', () => {

            const summaryAccount = accountsSelectors.getSummaryAccount(state);

            expect(summaryAccount.id).toEqual('summary');
            expect(summaryAccount.IsSummary).toBe(true);
            expect(summaryAccount.AccountId).toEqual('');
            expect(summaryAccount.AccountKey).toEqual('oB7PBE-0DhiO4rT2DbngHA==');
            expect(summaryAccount.BaseCurrency).toEqual('CHF');
            expect(summaryAccount.BaseCurrencyDecimals).toEqual(2);
            expect(summaryAccount.IndividualMargining).toEqual(true);
            expect(summaryAccount.DisplayName).toEqual(Localization.getText('HTML5_AllAccounts'));
        });
    });

    describe('Account global selectors', () => {
        beforeEach(() => {
            state = {
                clients: {
                    fetch: {
                        status: asyncActionStatus.SUCCESS,
                        error: null,
                    },
                    data: {
                        me: _.cloneDeep(dataClient),
                        impersonated: {},
                    },
                },
                accounts: {
                    fetch: {
                        status: asyncActionStatus.SUCCESS,
                        error: null,
                    },
                    data: _.cloneDeep(dataAccounts.Data),
                },
                subscriptions: {
                    [subscriptionsConfig.TYPE]: {
                        [subscriptionsConfig.TYPE]: {},
                    },
                },
            };
        });

        describe('getHasDirectMarketAccess()', () => {
            it('should have direct market access', () => {
                expect(accountsSelectors.getHasDirectMarketAccess(state)).toBe(true);
            });

            it('should not have direct market access', () => {
                state.accounts.data = _.map(state.accounts.data, (account) => _.defaults({ DirectMarketAccess: false }, account));
                expect(accountsSelectors.getHasDirectMarketAccess(state)).toBe(false);
            });
        });

        describe('getIsVariationMarginEligible()', () => {
            it('should have variation margin', () => {
                state.clients.data = { me: { IsVariationMarginEligible: false } };
                expect(accountsSelectors.getIsVariationMarginEligible(state)).toBe(false);
            });

            it('should not have variation margins', () => {
                state.clients.data = { me: { IsVariationMarginEligible: true } };
                expect(accountsSelectors.getIsVariationMarginEligible(state)).toBe(true);
            });
        });
    });

    describe('getDefaultAccount', () => {
        it('uses client default', () => {
            state = {
                clients: {
                    fetch: {
                        status: asyncActionStatus.SUCCESS,
                        error: null,
                    },
                    data: {
                        me: _.defaults({ DefaultAccountId: 'test3' }, dataClient),
                        impersonated: {},
                    },
                },
                accounts: {
                    fetch: {
                        status: asyncActionStatus.SUCCESS,
                        error: null,
                    },
                    data: _.cloneDeep(dataAccounts.Data),
                },
                accountGroups: {
                    fetch: {
                        status: asyncActionStatus.SUCCESS,
                        error: null,
                    },
                    data: _.cloneDeep(dataAccountGroups.Data),
                },
                subscriptions: {
                    [subscriptionsConfig.TYPE]: {
                        [subscriptionsConfig.TYPE]: {},
                    },
                },
            };

            expect(accountsSelectors.getDefaultAccount(state).AccountId).toEqual('test3');
        });
    });

    describe('getDefaultAccountIdForInstrument', () => {
        const TradableOn = ['test1', 'test2', 'test3'];
        beforeEach(() => {
            state = {
                clients: {
                    fetch: {
                        status: asyncActionStatus.SUCCESS,
                        error: null,
                    },
                    data: {
                        me: _.defaults({ DefaultAccountId: 'test3' }, dataClient),
                        impersonated: {},
                    },
                },
                accounts: {
                    fetch: {
                        status: asyncActionStatus.SUCCESS,
                        error: null,
                    },
                    data: _.cloneDeep(dataAccounts.Data),
                },
                accountGroups: {
                    fetch: {
                        status: asyncActionStatus.SUCCESS,
                        error: null,
                    },
                    data: _.cloneDeep(dataAccountGroups.Data),
                },
                subscriptions: {
                    [subscriptionsConfig.TYPE]: {
                        [subscriptionsConfig.TYPE]: {},
                    },
                    [balancesSubscriptionsConfig.TYPE]: {
                        'test1': {
                            data: {
                                MarginAvailableForTrading: 3000,
                            },
                        },
                        'test2': {
                            data: {
                                MarginAvailableForTrading: 2000,
                            },
                        },
                        'test3': {
                            data: {
                                MarginAvailableForTrading: 1000,
                            },
                        },
                    },
                },
            };
        });

        it('uses client default if tradable', () => {
            expect(accountsSelectors.getDefaultAccountIdForInstrument(state, { AssetType: 'FxSpot', TradableOn })).toEqual('test3');
        });

        it('returns null if no tradable accounts', () => {
            expect(accountsSelectors.getDefaultAccountIdForInstrument(state, { AssetType: 'ContractFutures', TradableOn })).toEqual(null);
            expect(accountsSelectors.getDefaultAccountIdForInstrument(state, { AssetType: 'FxSpot', TradableOn: [] })).toEqual(null);
            expect(accountsSelectors.getDefaultAccountIdForInstrument(state, { AssetType: 'FxSpot', TradableOn: [] }, 'test3')).toEqual(null);
        });

        it('picks an account matching currency', () => {
            state.accounts.data[1].LegalAssetTypes.push('FxSpot');
            expect(accountsSelectors.getDefaultAccountIdForInstrument(state, { AssetType: 'FxSpot', TradableOn, CurrencyCode: 'EUR' })).toEqual('test2');
        });

        it('picks the most valuable account', () => {
            expect(accountsSelectors.getDefaultAccountIdForInstrument(state, { AssetType: 'FxSpot', TradableOn, CurrencyCode: 'CHF' })).toEqual('test1');
        });

        it('uses a preferred account if tradable', () => {
            state.accounts.data[0].LegalAssetTypes.push('FxSpot');
            state.accounts.data[1].LegalAssetTypes.push('FxSpot');
            expect(accountsSelectors.getDefaultAccountIdForInstrument(state, { AssetType: 'FxSpot', TradableOn }, 'test1')).toEqual('test1');
            expect(accountsSelectors.getDefaultAccountIdForInstrument(state, { AssetType: 'FxSpot', TradableOn }, 'test2')).toEqual('test2');
            expect(accountsSelectors.getDefaultAccountIdForInstrument(state, { AssetType: 'FxSpot', TradableOn }, 'test3')).toEqual('test3');
        });
    });

    describe('createGetEntitiesToShow', () => {
        const TradableOn = ['test1', 'test2', 'test3'];
        beforeEach(() => {
            state = {
                clients: {
                    fetch: {
                        status: asyncActionStatus.SUCCESS,
                        error: null,
                    },
                    data: {
                        me: _.defaults({ DefaultAccountId: 'test3' }, dataClient),
                        impersonated: {},
                    },
                },
                accounts: {
                    fetch: {
                        status: asyncActionStatus.SUCCESS,
                        error: null,
                    },
                    data: _.cloneDeep(dataAccounts.Data),
                },
                accountGroups: {
                    fetch: {
                        status: asyncActionStatus.SUCCESS,
                        error: null,
                    },
                    data: _.cloneDeep(dataAccountGroups.Data),
                },
                subscriptions: {
                    [subscriptionsConfig.TYPE]: {
                        [subscriptionsConfig.TYPE]: {},
                    },
                    [balancesSubscriptionsConfig.TYPE]: {
                        'test1': {
                            data: {
                                MarginAvailableForTrading: 3000,
                            },
                        },
                        'test2': {
                            data: {
                                MarginAvailableForTrading: 2000,
                            },
                        },
                        'test3': {
                            data: {
                                MarginAvailableForTrading: 1000,
                            },
                        },
                    },
                },
            };
        });

        it('returns accounts tradable', () => {
            const getEntitiesToShow = accountsSelectors.createGetEntitiesToShow();

            expect(getEntitiesToShow(state, {
                showTradableAccounts: true,
                instrument: { AssetType: 'FxSpot', TradableOn },
            })).toEqual([
                jasmine.objectContaining({ AccountId: 'test1' }),
                jasmine.objectContaining({ AccountId: 'test3' }),
            ]);
        });

        it('returns accounts tradable - caches the result', () => {
            const getEntitiesToShow = accountsSelectors.createGetEntitiesToShow();
            const instrument = { AssetType: 'FxSpot', TradableOn };

            expect(
                getEntitiesToShow(state, {
                    showTradableAccounts: true,
                    instrument,
                }))
                .toBe(
                    getEntitiesToShow(state, {
                        showTradableAccounts: true,
                        instrument,
                    }));
        });

        it('returns all accounts when it doesnt need to just be tradable', () => {
            const getEntitiesToShow = accountsSelectors.createGetEntitiesToShow();

            expect(getEntitiesToShow(state, {
                showTradableAccounts: false,
                instrument: { AssetType: 'FxSpot', TradableOn },
            })).toEqual([
                jasmine.objectContaining({ ClientId: '2147044823' }),
                jasmine.objectContaining({ AccountId: 'test1' }),
                jasmine.objectContaining({ AccountId: 'test2' }),
                jasmine.objectContaining({ AccountId: 'test3' }),
            ]);
        });

        it('returns no accounts tradable when nothing is tradable', () => {
            const getEntitiesToShow = accountsSelectors.createGetEntitiesToShow();

            expect(getEntitiesToShow(state, {
                showTradableAccounts: true,
                instrument: { AssetType: 'FxSpot', TradableOn: [] },
            })).toEqual([]);
        });
    });

});
