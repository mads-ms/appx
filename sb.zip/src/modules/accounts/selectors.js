import _ from 'lodash';
import Enums from 'src/spine/enums';
import { createSelector } from 'reselect';
import Localization from 'src/localization';
import * as accountQueries from 'src/modules/accounts/queries';
import * as asyncActionStatus from 'src/asyncActionStatus';
import * as clientSelectors from 'src/modules/clients/selectors';
import { TYPE } from 'src/modules/accountsSubscription/config';
import * as subscriptionSelectors from 'src/modules/accountsSubscription/selectors';
import { DEFAULT_GROUP_NAME, SUMMARY_ACCOUNT_ID } from './constants';
import * as balancesSubscriptionSelectors from 'src/modules/balancesSubscription/selectors';
import * as balancesQueries from 'src/modules/balances/queries';

export const getAccountsState = (state) => state.accounts;

export const getAccountGroupsState = (state) => getAccountsState(state).accountGroups;

export const getAccountsFetchState = (state) => getAccountsState(state).fetch;

export const getFetchedAccounts = (state) => getAccountsState(state).data;

export const getFetchedAccountsLoaded = (state) => getAccountsFetchState(state).status === asyncActionStatus.SUCCESS;

export const getSubscribedAccounts = (state) => subscriptionSelectors.getData(state, TYPE);

/**
 * Returns all plain accounts from store, subscribed one or fetched
 * @param {Object} state - Global state
 * @return {} Map of accounts
 */
// Get rest or subscribed accounts
export const getStoreAccounts = (state) => {
    const subscribedAccounts = getSubscribedAccounts(state);
    if (!_.isEmpty(subscribedAccounts)) {
        return subscribedAccounts;
    }

    return getFetchedAccounts(state);
};

/**
 * Returns all accounts without groups with additional computed  fields
 * @param {Object} state - Global state
 * @return {Object[]} Array of accounts
 */
export const getAccounts = createSelector(
    getStoreAccounts,
    clientSelectors.getClientKey,
    (accounts, clientKey) => _.chain(accounts)
        .map((data) => {

            // Create required account fields
            const account = _.clone(data);

            account.id = data.AccountId;
            account.IsAccount = true;
            account.BaseCurrency = data.Currency;
            account.BaseCurrencyDecimals = data.CurrencyDecimals;
            account.Sharing = data.Sharing && _.includes(data.Sharing, 'TradingFloor');
            account.DisplayName = data.AccountId;
            account.ClientKey = clientKey;

            if (data.DirectMarketAccess) {
                const cfdOnIndexAssetType = Enums.InstrumentType.toAssetType(Enums.InstrumentType.CfdOnIndex, false);
                account.LegalAssetTypes = _.filter(data.LegalAssetTypes, (assetType) => assetType !== cfdOnIndexAssetType);
            }

            account.LegalInstrumentTypes = accountQueries.getLegalInstrumentTypes(account);

            account.IndividualMargining = (data.IndividualMargining &&
            Enums.InstrumentType.isMarginTradableInstrument(account.LegalInstrumentTypes));

            account.IsMarginTradingAllowed = data.IsMarginTradingAllowed &&
                Enums.InstrumentType.isMarginTradableInstrument(account.LegalInstrumentTypes);

            return account;
        })
        .sortBy('DisplayName')
        .value()
);

/**
 * Returns all accounts groups with additional computed  fields
 * @param {Object} state - Global state
 * @return {Object[]} Array of account groups
 */
export const getAccountGroups = createSelector(
    getAccounts,
    getAccountGroupsState,
    clientSelectors.getClientCurrency,
    clientSelectors.getClientKey,
    (accounts, accountGroups, clientCurrency, clientKey) => _.chain(accounts)
        .groupBy('AccountGroupKey')
        .map((groupedAccounts, key) => {
            const legalAssetTypes = _.chain(groupedAccounts)
                .flatMap('LegalAssetTypes')
                .filter()
                .uniq()
                .value();

            const accountGroupName = _.head(groupedAccounts).AccountGroupName || DEFAULT_GROUP_NAME;
            const accountGroup = _.find(accountGroups, (group) => group.AccountGroupKey === key) || {};

            return {
                id: key,
                IsGroup: true,
                AccountId: key,
                AccountKey: key,
                ClientKey: clientKey,
                AccountGroupName: accountGroupName,
                BaseCurrency: clientCurrency,
                LegalAssetTypes: legalAssetTypes,
                Accounts: _.flatMap(_.sortBy(groupedAccounts, 'DisplayName')),
                IndividualMargining: _.some(groupedAccounts, 'IndividualMargining'),
                IsMarginTradingAllowed: _.some(groupedAccounts, 'IsMarginTradingAllowed'),
                DisplayName: accountGroupName,
                SupportsAccountValueProtectionLimit: accountGroup.SupportsAccountValueProtectionLimit,
                AccountValueProtectionLimit: accountGroup.AccountValueProtectionLimit,
            };
        })
        .sortBy('DisplayName')
        .value()
);

/**
 * Returns amount of plain accounts
 * @param {Object} state - Global state
 * @return {Number} amount of accounts
 */
export const getAccountsCount = (state) => _.size(getAccounts(state));

/**
 * Returns whether a user has a single or multiple accounts
 * @param {Object} state - Global state
 * @return {Boolean}
 */
export const isSingleAccount = (state) => getAccountsCount(state) === 1;

/**
 * Returns amount of account groups
 * @param {Object} state - Global state
 * @return {Number} amount of account groups
 */
export const getAccountGroupsCount = (state) => _.size(getAccountGroups(state));

/**
 * Returns summary account basing on client data
 * @param {Object} state - Global state
 * @return {Object} Summary account with computed fields
 */
export const getSummaryAccount = createSelector(
    clientSelectors.getImpersonatedOrDefaultClient,
    (client) => {
        if (_.isEmpty(client)) {
            return null;
        }

        const summaryAccount = _.clone(client);
        summaryAccount.id = SUMMARY_ACCOUNT_ID;
        summaryAccount.IsSummary = true;
        summaryAccount.AccountId = '';
        summaryAccount.AccountKey = client.ClientKey;
        summaryAccount.ClientKey = client.ClientKey;
        summaryAccount.BaseCurrency = client.DefaultCurrency;
        summaryAccount.BaseCurrencyDecimals = client.CurrencyDecimals;
        summaryAccount.Sharing = client.Sharing && _.includes(client.Sharing, 'TradingFloor');

        summaryAccount.LegalInstrumentTypes = accountQueries.getLegalInstrumentTypes(client);

        summaryAccount.IndividualMargining = Enums.InstrumentType.isMarginTradableInstrument(summaryAccount.LegalInstrumentTypes);
        summaryAccount.DisplayName = Localization.getText('HTML5_AllAccounts');

        return summaryAccount;
    });

/**
 * Gets all accounts, in order, including groups and summary account
 */
const getAllAccounts = createSelector(
    getSummaryAccount,
    getAccountGroups,
    (summaryAccount, groups) => _.reduce(groups, (result, group) => result.concat(group).concat(group.Accounts),
        summaryAccount ? [summaryAccount] : [])
);

/**
 * Gets all accounts to be displayed. If there is only one group (default), then this list does not include groups.
 */
export const getAccountsList = createSelector(
    getAccountGroups,
    getSummaryAccount,
    accountQueries.getAccountListFromGroups
);

export const getAccountMap = createSelector(
    getAllAccounts,
    (allAccounts) => _.keyBy(allAccounts, 'id')
);

export const getAccountById = (state, accountId) => getAccountMap(state)[accountId];

export const getAccountGroup = (state, id) => {
    const account = getAccountById(state, id);
    if (!account) {
        return null;
    }
    return getAccountById(state, account.AccountGroupKey);
};

export const getHasIndividualMargining = (state) => _.some(getAccounts(state), 'IndividualMargining');

/**
 * Returns true of false basing on account tree state
 * @param {Object} state - Global state
 * @return {Object} True if individual margining is supported, false otherwise
 */
export const getHasIndividualMarginingById = createSelector(
    getAccountById,
    getAccountGroup,
    getHasIndividualMargining,
    getAccountGroupsCount,
    (account, accountGroup, hasIndividualMargining, groupsCount) => {
        // Handle client case separately
        if (account.IsSummary) {
            // Case when we have more than one group
            if (groupsCount > 1) {
                return true;
            }

            // Case when we have only one group
            return (groupsCount === 1 && account.IndividualMargining && hasIndividualMargining);
        }

        // Case when we have
        if (account.IsAccount && accountGroup && accountGroup.Accounts.length === 1) {
            return true;
        }

        // Case when group contains only one account
        if (account.IsGroup && accountGroup && accountGroup.Accounts.length === 1) {
            return true;
        }

        return account.IndividualMargining;
    }
);

/**
 * Returns true is user supports DMA
 * @param {Object} state - Global state
 * @return {Object} Returns true is any accounts supports DMA
 */
export const getHasDirectMarketAccess = (state) => _.some(getAccounts(state), 'DirectMarketAccess');

/**
 * Returns true is user has support for margin variation
 * @param {Object} state - Global state
 * @return {Object} Returns true if client supports margin variation
 */
export const getIsVariationMarginEligible = (state) =>
    _.get(getSummaryAccount(state), 'IsVariationMarginEligible', false);

/**
 * Returns and array of unions of all the accounts LegalAssetTypes
 * @return {Array} Return array of instrument asset types
 */
export const getLegalAssetTypes = createSelector(
    getAllAccounts,
    (allAccounts) => _.chain(allAccounts)
        .reject((account) => account.id === SUMMARY_ACCOUNT_ID)
        .reduce((combinedLegalAssetTypes, account) => {
            const legalAssetTypes = Enums.InstrumentType.toAssetType(accountQueries.getLegalInstrumentTypes(account), true).split(',');
            return _.union(combinedLegalAssetTypes, legalAssetTypes);
        }, [])
        .value()
);

export const getDefaultAccount = (state) => {
    const accounts = getAccounts(state);
    const clientDefaultAccount = clientSelectors.getClientDefaultAccount(state);

    // if client default account is a valid account use that, otherwise use the
    // first valid account
    const defaultAccount = _.find(accounts, { id: clientDefaultAccount.DefaultAccountId });

    if (defaultAccount) {
        return defaultAccount;
    }

    return _.head(accounts);
};

export const getDefaultAccountId = (state) => getDefaultAccount(state).AccountId;

export const getAccountsForInstrument = (state, instrument) => _.filter(getAllAccounts(state),
    (account) => accountQueries.isTradingOnAccountAllowed(account, instrument));

export const getDefaultAccountIdForInstrument = (state, instrument, preferredAccountId) => {
    const validAccounts = getAccountsForInstrument(state, instrument);
    if (_.isEmpty(validAccounts)) {
        return null;
    }

    if (preferredAccountId) {
        const preferredAccount = _.find(validAccounts, { AccountId: preferredAccountId });
        if (preferredAccount) {
            return preferredAccount.AccountId;
        }
    }

    // default to highest valued account that matches the instrument currency
    const currencyAccounts = accountQueries.getAccountsMatchingCurrency(validAccounts, instrument);
    if (currencyAccounts.length > 0) {
        return _.chain(currencyAccounts)
            .map(({ id }) => ({ id, balance: balancesSubscriptionSelectors.getData(state, id) }))
            .sortBy(({ balance }) => balancesQueries.getAvailableBalanceForInstrument(balance, instrument))
            .last()
            .value()
            .id;
    }

    return getDefaultAccountId(state);
};

export const createGetEntitiesToShow = () => createSelector(
    getAccountGroups,
    getSummaryAccount,
    (state, args) => args.showTradableAccounts,
    (state, args) => args.instrument,
    accountQueries.getEntitiesToShow
);
