export const DEFAULT_GROUP_NAME = 'Default';
export const SUMMARY_ACCOUNT_ID = 'summary';

export const ACCOUNT_TYPE_NORMAL = 'Normal';
export const ACCOUNT_TYPE_SAXO_SELECT = 'AutoTradingFollower';
