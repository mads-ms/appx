import * as accountsActionTypes from 'src/modules/accounts/actionTypes';
import 'src/modules/accounts/sagas';

export function fetchAccounts() {
    return {
        type: accountsActionTypes.FETCH,
    };
}

export function fetchAccountsPending() {
    return {
        type: accountsActionTypes.FETCH_PENDING,
    };
}

export function fetchAccountsSuccess(data) {
    return {
        type: accountsActionTypes.FETCH_SUCCESS,
        data,
    };
}

export function fetchAccountsError(error) {
    return {
        type: accountsActionTypes.FETCH_ERROR,
        error,
    };
}
