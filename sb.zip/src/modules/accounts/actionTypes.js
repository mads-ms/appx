export const FETCH = 'accounts/fetch';
export const FETCH_PENDING = 'accounts/fetch-pending';
export const FETCH_SUCCESS = 'accounts/fetch-success';
export const FETCH_ERROR = 'accounts/fetch-error';
export const SET_ACCOUNT_SHIELD = 'accounts/set-account-shield';
