import connectPromise from 'src/utils/connectPromise';
import { mapMultipleRequestState } from 'src/utils/request';
import * as clientSelectors from 'src/modules/clients/selectors';
import * as getAccountSelectors from 'src/modules/accounts/selectors';
import * as asyncActionStatus from 'src/asyncActionStatus';

export function getAccountsFetchedPromise() {
    // Check both accounts and clients
    return connectPromise((state) =>
        mapMultipleRequestState([
            getAccountSelectors.getAccountsFetchState(state),
            clientSelectors.getClientsFetchState(state)], [asyncActionStatus.SUCCESS]));
}
