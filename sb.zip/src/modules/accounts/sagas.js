import _ from 'lodash';
import { put, call, select, takeEvery, take } from 'redux-tale/effects';
import Spine from 'spineAll';
import log from 'src/modules/log';
import * as perfLogActions from 'src/modules/perfLog/actions';
import getOpenApi from 'src/modules/openApi';
import { addSagas } from 'src/sagas';
import { getImpersonatedClientKey } from 'src/modules/settings/impersonatedClientSelectors';
import * as accountsActions from 'src/modules/accounts/actions';
import * as subscriptionsActions from 'src/modules/accountsSubscription/actions';
import * as clientSelectors from 'src/modules/clients/selectors';
import * as accountActionTypes from 'src/modules/accounts/actionTypes';
import * as clientActionTypes from 'src/modules/clients/actionTypes';
import * as subscriptionConfig from 'src/modules/accountsSubscription/config';
import { FETCH_ACCOUNT_DATA } from 'src/modules/perfLog/constants';
import * as clientSearchSelectClientActions from 'src/modules/clientSearch/selectClientActions';
import config from 'src/config';
import * as accountGroupActions from 'src/modules/accounts/accountGroups/actions';
import * as subscriptionsPatternMatchers from 'src/modules/subscriptions/patternMatchers';
import * as clientActions from 'src/modules/clients/actions';

export function *fetchAccounts() {

    const openApi = getOpenApi();
    yield put(perfLogActions.start(FETCH_ACCOUNT_DATA, 'default'));

    const clientKey = getImpersonatedClientKey();

    try {
        yield put(accountsActions.fetchAccountsPending());

        const endpointUser = clientKey ? '' : 'me';
        const options = clientKey ? { queryParams: { ClientKey: clientKey } } : {};

        const result = yield call([openApi.rest, openApi.rest.get], 'port', `v1/accounts/${endpointUser}`, null, options);

        yield put(perfLogActions.end(FETCH_ACCOUNT_DATA, 'default'));
        yield put(accountsActions.fetchAccountsSuccess(_.get(result.response, 'Data')));

    } catch (error) {
        if (config.isAccountApp && error && error.status === 403) {
            // Skip not permission errors for my account standalone app as user
            // may not be entitled for full GO access
            yield put(accountsActions.fetchAccountsSuccess());
            return;
        }

        const errorMessage = 'Error fetching accounts';
        log.error(errorMessage, error);

        // because the impersonated client is kept in user settings, it may come out of
        // sync with what is actually allowed. So in the case of failing to load accounts
        // and impersonating a client, reset Go to not having a impersonated client selected
        if (clientKey) {
            yield put(clientSearchSelectClientActions.deselectClient());
        } else {
            Spine.trigger('app:critical-error', errorMessage);
            yield put(accountsActions.fetchAccountsError(errorMessage));
        }
    }
}

export function *startAccountsSubscription() {
    yield take(clientActionTypes.FETCH_CLIENTS_SUCCESS);

    const state = yield select();
    const args = {
        ClientKey: clientSelectors.getClientKey(state),
    };
    yield put(subscriptionsActions.create(subscriptionConfig.TYPE, args));
    yield put(accountGroupActions.getAccountGroups());
}

function* refreshAccountShield() {
    yield put(clientActions.fetchClients());
    yield put(accountGroupActions.getAccountGroups());
}

addSagas([
    startAccountsSubscription,
    takeEvery(accountActionTypes.FETCH, fetchAccounts),
    takeEvery(subscriptionsPatternMatchers.update(subscriptionConfig.TYPE), refreshAccountShield),
]);
