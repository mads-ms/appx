import accountsReducer from 'src/modules/accounts/reducer';
import * as accountsActions from 'src/modules/accounts/actions';
import * as asyncActionStatus from 'src/asyncActionStatus';
import * as accountsActionTypes from 'src/modules/accounts/actionTypes';

describe('src/modules/accounts/reducer', () => {

    it('should have an initial state', () => {
        expect(accountsReducer(undefined, {})).toEqual({
            accountGroups: [],
            fetch: {
                status: asyncActionStatus.NONE,
                error: null,
            },
            data: {},
        });
    });

    it('should change status to pending', () => {
        const action = accountsActions.fetchAccountsPending();
        const state = {
            fetch: {
                status: asyncActionStatus.NONE,
                error: null,
            },
            data: {},
        };

        expect(accountsReducer(state, action)).toEqual({
            accountGroups: [],
            fetch: {
                status: asyncActionStatus.PENDING,
                error: null,
            },
            data: {},
        });
    });

    it('should update account on fetch success', () => {
        const data = [
            { AccountId: 'A' },
            { AccountId: 'B' },
        ];

        const action = accountsActions.fetchAccountsSuccess(data);
        const state = {
            fetch: {
                status: asyncActionStatus.PENDING,
                error: null,
            },
            data: {},
        };

        expect(accountsReducer(state, action)).toEqual({
            accountGroups: [],
            fetch: {
                status: asyncActionStatus.SUCCESS,
                error: null,
            },
            data: {
                'A': { AccountId: 'A' },
                'B': { AccountId: 'B' },
            },
        });
    });

    it('should update AccountValueProtectionLimit on given account', () => {
        const action = {
            type: accountsActionTypes.SET_ACCOUNT_SHIELD,
            accountId: 'user1',
            AccountValueProtectionLimit: 500000,
        };
        const state = {
            accountGroups: [],
            fetch: {
                status: asyncActionStatus.NONE,
                error: null,
            },
            data: {
                user1: {
                    AccountValueProtectionLimit: 300000,
                },
            },
        };

        expect(accountsReducer(state, action)).toEqual({
            accountGroups: [],
            fetch: {
                status: asyncActionStatus.NONE,
                error: null,
            },
            data: {
                user1: {
                    AccountValueProtectionLimit: 500000,
                },
            },
        });
    });
});
