import * as accountQueries from 'src/modules/accounts/queries';
import Enums from 'src/spine/enums';
import config from 'src/config';
import dataAccountsSingle from 'test/mocks/data/account/accounts-single-fetch.json';
import dataClient from 'test/mocks/data/account/client.json';

export const clientAccount = { ClientKey: 'A' };
export const account = {
    ClientKey: 'A',
    IsAccount: true,
    AccountKey: 'B',
};

export const accountGroup = {
    ClientKey: 'A',
    IsGroup: true,
    AccountKey: 'D',
};

describe('src/modules/accounts/queries', () => {

    describe('getLegalInstrumentTypes()', () => {

        beforeEach(() => {
            config.appFeatures.partnerLegalInstruments = Enums.InstrumentType.AllInstruments;
        });

        it('should return legal instrument types', () => {
            let result = accountQueries.getLegalInstrumentTypes(dataAccountsSingle.Data[0]);
            expect(result).toEqual(32);

            result = accountQueries.getLegalInstrumentTypes(dataClient);
            expect(result).toEqual(1046519);
        });

    });

    describe('getAccountArgs()', () => {

        it('should return account args', () => {
            expect(accountQueries.getAccountArgs(clientAccount)).toEqual({ ClientKey: 'A' });
            expect(accountQueries.getAccountArgs(account)).toEqual({ ClientKey: 'A', AccountKey: 'B' });
            expect(accountQueries.getAccountArgs(accountGroup)).toEqual({ ClientKey: 'A', AccountGroupKey: 'D' });
        });
    });

    describe('getAccountCurrency()', () => {

        it('should Base Currency from account', () => {
            const mockAccount = { BaseCurrency: 'USD' };
            expect(accountQueries.getAccountCurrency(mockAccount)).toEqual('USD');
        });
    });
});
