export const SET_ACCOUNT_GROUPS = 'accounts/account-groups/set-account-groups';
export const UPDATE_ACCOUNT_GROUPS = 'accounts/account-groups/update-account-groups';
