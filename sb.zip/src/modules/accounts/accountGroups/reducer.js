import _ from 'lodash';
import * as actionTypes from './actionTypes';

const initialState = [];

const accountGroups = (state = initialState, action) => {
    switch (action.type) {
        case actionTypes.SET_ACCOUNT_GROUPS:
            return setAccountGroups(state, action);

        case actionTypes.UPDATE_ACCOUNT_GROUPS:
            return updateAccountGroups(state, action);
    }

    return state;
};

function setAccountGroups(state, action) {
    return action.data.Data;
}

function updateAccountGroups(state, action) {
    const {
        AccountGroupKey,
        AccountValueProtectionLimit,
    } = action;

    return _.map(state, (group) => group.AccountGroupKey === AccountGroupKey ?
        _.defaults({ AccountValueProtectionLimit }, group) :
        group
    );
}

export default accountGroups;
