import getOpenApi from 'src/modules/openApi';
import { getLog } from 'src/modules/log';
import * as actionTypes from './actionTypes';

const log = getLog('accountGroups');

export function getAccountGroups() {
    return function(dispatch) {
        getOpenApi()
            .rest
            .get('port', 'v1/accountgroups/me/')
            .then((data) => {
                if (data.response) {
                    dispatch({
                        type: actionTypes.SET_ACCOUNT_GROUPS,
                        data: data.response,
                    });
                } else {
                    log.error('Response did not contain data.response');
                }
            })
            .catch((error) => {
                log.error('Fetching account groups failed', error);
            });
    };
}
