import _ from 'lodash';
import { combineReducers } from 'redux';
import accountGroups from './accountGroups/reducer';
import * as subscriptionsConfig from 'src/modules/accountsSubscription/config';
import * as accountsActionTypes from 'src/modules/accounts/actionTypes';
import * as asyncActionStatus from 'src/asyncActionStatus';

const key = subscriptionsConfig.META.__key__;

const initialFetchState = {
    status: asyncActionStatus.NONE,
    error: null,
};

const fetch = (state = initialFetchState, action) => {
    switch (action.type) {
        case accountsActionTypes.FETCH_PENDING:
            return _.defaults({
                status: asyncActionStatus.PENDING,
                error: null,
            }, state);

        case accountsActionTypes.FETCH_SUCCESS:
            return _.defaults({
                status: asyncActionStatus.SUCCESS,
                error: null,
            }, state);

        case accountsActionTypes.FETCH_ERROR:
            return _.defaults({
                status: asyncActionStatus.ERROR,
                error: action.error,
            }, state);
    }

    return state;
};

const data = (state = {}, action) => {
    switch (action.type) {
        case accountsActionTypes.FETCH_SUCCESS:
            return _.keyBy(action.data, key) || state.data;

        case accountsActionTypes.SET_ACCOUNT_SHIELD:
            return setAccountShield(state, action);
    }

    return state;
};

function setAccountShield(state, action) {
    const {
        accountId,
        AccountValueProtectionLimit,
    } = action;

    return _.defaults({
        [accountId]: _.defaults({
            AccountValueProtectionLimit,
        }, state[accountId]),
    }, state);
}

export default combineReducers({
    accountGroups,
    fetch,
    data,
});
