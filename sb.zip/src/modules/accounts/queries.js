import _ from 'lodash';
import config from 'src/config';
import Enums from 'src/spine/enums';
import * as assetTypeQueries from 'src/modules/instruments/assetType/queries';
import * as constants from './constants';

export const isSaxoSelect = (account) => account.AccountType === constants.ACCOUNT_TYPE_SAXO_SELECT;

export const getLegalInstrumentTypes = (account) => {
    const legalInstruments = _.reduce(account.LegalAssetTypes,
        (instrTypes, assetType) => (instrTypes | Enums.InstrumentType.fromAssetTypeString(assetType)),
        0);

    return legalInstruments & config.appFeatures.partnerLegalInstruments;
};

export const getAccountArgs = (account) => {
    const args = {};
    args.ClientKey = account.ClientKey;

    if (account.IsAccount) {
        args.AccountKey = account.AccountKey;
    } else if (account.IsGroup) {
        args.AccountGroupKey = account.AccountKey;
    }

    return args;
};

export const getAccountId = (account) => _.get(account, 'id', null);

export const getAccountCurrency = (account) => account.BaseCurrency;

export const isTradingOnAccountAllowed = (account, instrument) => {
    if (!instrument) {
        return false;
    }
    const { AssetType, TradableOn } = instrument;
    const filteredInstrumentType = Enums.InstrumentType.fromAssetTypeString(AssetType) & config.appFeatures.partnerLegalInstruments;
    if (filteredInstrumentType === 0) {
        return false;
    }
    return _.includes(account.LegalAssetTypes, AssetType) &&
        (Boolean(config.appFeatures.impersonatedClient) || _.includes(TradableOn, account.id));
};

export const getAccountListFromGroups = (groups, summaryAccount) =>
    _.reduce(groups, (result, group) =>
        groups.length > 1 ?
            result.concat(group).concat(group.Accounts) :
            result.concat(group.Accounts),
    summaryAccount ? [summaryAccount] : []);

export const getTradableAccountsForInstrument = (groups, instrument) => {
    if (config.appFeatures.impersonatedClient) {
        return getAccountListFromGroups(groups);
    }
    return _.reduce(groups, (result, group) => {
        const accounts = _.filter(group.Accounts, (account) =>
            account.AccountType !== constants.ACCOUNT_TYPE_SAXO_SELECT &&
            (_.isNil(instrument) || isTradingOnAccountAllowed(account, instrument))
        );
        if (accounts.length > 0 && groups.length > 1) {
            result = result.concat(group);
        }
        return result.concat(accounts);
    }, []);
};

export const hasCfdAccess = (account, instrument) =>
    !assetTypeQueries.isCfd(instrument) ||
    !account.DirectMarketAccess ||
    _.includes(account.DirectMarketExchangeIds, instrument.Exchange.ExchangeId);

export const getAccountsMatchingCurrency = (accounts, instrument) =>
    _.filter(getTradableAccounts(accounts, instrument), { Currency: instrument.CurrencyCode });

export const getAccountBaseCurrency = (account, client) => {
    if (account.IndividualMargining) {
        return account.BaseCurrency;
    }

    return client.DefaultCurrency;
};

export const getTradableInstruments = (accounts, instruments) =>
    _.filter(instruments, (instrument) =>
        _.some(accounts, (acc) => isTradingOnAccountAllowed(acc, instrument))
    );

function getTradableAccounts(accounts, instrument) {
    return _.filter(accounts, (account) => hasCfdAccess(account, instrument));
}

export const getEntitiesToShow = (accountsGroup, summaryAccount, isTradableOnly, instrument) => {
    if (isTradableOnly) {
        return getTradableAccountsForInstrument(accountsGroup, instrument);
    }

    const accountsList = getAccountListFromGroups(accountsGroup, summaryAccount);

    return accountsList.length === 2 ?
        _.reject(accountsList, (account) => account.id === constants.SUMMARY_ACCOUNT_ID) :
        accountsList;
};

export const getSummaryAccount = (accountsList) => _.find(accountsList, 'IsSummary');
